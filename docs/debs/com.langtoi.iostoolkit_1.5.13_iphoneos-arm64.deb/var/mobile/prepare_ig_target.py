#!/var/jb/usr/bin/python3
"""Seed the active Instagram Crane container with a RANDOM Ghost device.

Each fresh Crane container (a new account) is assigned a random, internally
consistent device drawn from DEVICE_POOL (iPhone 8 through iPhone 16, i.e.
Ghost's full supported catalog) and a random valid iOS from IOS_POOL. Combos
that are impossible in reality (e.g. iPhone 8 + iOS 17 — Apple never released
iOS 17 for iPhone 8) are rejected and re-rolled until a valid pairing is
found. Re-seeding an existing container keeps its already-assigned device.

The device is re-rolled per account. The carrier/locale/timezone persona is
rolled once per phone and then kept, so every account on one phone tells the
same regional story; if the Global Ghost profile has no persona yet, one is
drawn at random instead of being left empty or copied from another phone.
Per-account identity fields (advertisingID/vendorID/wifi/deviceName) are
freshly regenerated.
"""

import argparse
import hashlib
import json
import os
import plistlib
import random
import re
import uuid


# Instagram compatibility floor: the spoofed device must be at least an
# iPhone 8 (iPhone10,x) running iOS 16 or newer. Every DEVICE_POOL entry is
# well above this; the check stays as a safety net.
MIN_DEVICE_MAJOR = 10
MIN_IOS_MAJOR = 16


def device_major(model):
    match = re.match(r"iPhone(\d+),\d+", str(model or ""))
    return int(match.group(1)) if match else 0


def ios_major(version):
    try:
        return int(str(version or "0").split(".", 1)[0])
    except (ValueError, TypeError):
        return 0


def target_below_floor(model, ios):
    return device_major(model) < MIN_DEVICE_MAJOR or ios_major(ios) < MIN_IOS_MAJOR


CRANE_PREFS = "/var/jb/var/mobile/Library/Preferences/com.opa334.craneprefs.plist"
DATA_ROOT = "/var/mobile/Containers/Data/Application"
BUNDLE_ID = "com.burbn.instagram"
GHOST_PLIST = "com.sgwc.ghostprefs.plist"
# Central Global Ghost profile — the source of the carrier/locale/timezone
# persona that stays consistent across accounts. The DEVICE itself is now
# randomized per container instead of copied from here.
GLOBAL_PROFILE = "/var/mobile/Library/Preferences/Ghost/com.sgwc.ghostprefs.plist"

# Persona fields (NOT the device) copied from the Global Ghost profile so every
# account shares a coherent region/carrier story. Device identity is randomized.
PERSONA_FIELDS = (
    "carrierCountryCode", "carrierFlag", "carrierMCC", "carrierMNC",
    "carrierName", "carrierSelectedValue", "cellularType",
    "localeCountryCode", "localeCurrencyCode", "localeCurrencySymbol",
    "localeFlag", "localeID", "localeLanguageCode",
    "timezoneAbbreviation", "timezoneFlag", "timezoneName",
)

# --------------------------------------------------------------------------
# Device pool — iPhone 8 .. iPhone 15 Pro Max (Ghost's full supported catalog).
# Every entry is internally consistent; board codes verified against the public
# Apple machine-id tables. `res` matches IGUAFix's resolutionMap (informational
# here — IGUAFix derives the UA resolution itself from deviceModel). `chip` is
# the SoC board code used to build a matching Darwin kernel string. `min_ios`
# is the lowest iOS major the model ever shipped; `max_ios` is the highest
# iOS major Apple ever released for the model (iPhone 8/X hard-cap at 16.7.x
# since Apple stopped major updates there; A12+ still receives 18).
# --------------------------------------------------------------------------
DEVICE_POOL = (
    # iPhone 8 / 8 Plus / X — A11 Bionic (T8015), Apple cap = iOS 16.7.x
    {"model": "iPhone10,1", "hw": "D20AP",   "name": "iPhone 8",          "res": "750x1334",  "chip": "T8015", "mem": 2, "min_ios": 16, "max_ios": 16},
    {"model": "iPhone10,2", "hw": "D21AP",   "name": "iPhone 8 Plus",     "res": "1080x1920", "chip": "T8015", "mem": 3, "min_ios": 16, "max_ios": 16},
    {"model": "iPhone10,3", "hw": "D22AP",   "name": "iPhone X",          "res": "1125x2436", "chip": "T8015", "mem": 3, "min_ios": 16, "max_ios": 16},
    {"model": "iPhone10,4", "hw": "D201AP",  "name": "iPhone 8",          "res": "750x1334",  "chip": "T8015", "mem": 2, "min_ios": 16, "max_ios": 16},
    {"model": "iPhone10,5", "hw": "D211AP",  "name": "iPhone 8 Plus",     "res": "1080x1920", "chip": "T8015", "mem": 3, "min_ios": 16, "max_ios": 16},
    {"model": "iPhone10,6", "hw": "D221AP",  "name": "iPhone X",          "res": "1125x2436", "chip": "T8015", "mem": 3, "min_ios": 16, "max_ios": 16},
    # iPhone XS / XS Max / XR — A12 Bionic (T8020), Apple supports through iOS 18
    {"model": "iPhone11,2", "hw": "D321AP",  "name": "iPhone XS",         "res": "1125x2436", "chip": "T8020", "mem": 4, "min_ios": 16, "max_ios": 18},
    {"model": "iPhone11,4", "hw": "D331AP",  "name": "iPhone XS Max",     "res": "1242x2688", "chip": "T8020", "mem": 4, "min_ios": 16, "max_ios": 18},
    {"model": "iPhone11,6", "hw": "D331pAP", "name": "iPhone XS Max",     "res": "1242x2688", "chip": "T8020", "mem": 4, "min_ios": 16, "max_ios": 18},
    {"model": "iPhone11,8", "hw": "N841AP",  "name": "iPhone XR",         "res": "828x1792",  "chip": "T8020", "mem": 3, "min_ios": 16, "max_ios": 18},
    # iPhone 11 / 11 Pro / 11 Pro Max — A13 Bionic (T8030)
    {"model": "iPhone12,1", "hw": "N104AP",  "name": "iPhone 11",         "res": "828x1792",  "chip": "T8030", "mem": 4, "min_ios": 16, "max_ios": 18},
    {"model": "iPhone12,3", "hw": "D421AP",  "name": "iPhone 11 Pro",     "res": "1125x2436", "chip": "T8030", "mem": 4, "min_ios": 16, "max_ios": 18},
    {"model": "iPhone12,5", "hw": "D431AP",  "name": "iPhone 11 Pro Max", "res": "1242x2688", "chip": "T8030", "mem": 4, "min_ios": 16, "max_ios": 18},
    # iPhone 12 line — A14 Bionic (T8101)
    {"model": "iPhone13,1", "hw": "D52gAP",  "name": "iPhone 12 mini",    "res": "1080x2340", "chip": "T8101", "mem": 4, "min_ios": 16, "max_ios": 18},
    {"model": "iPhone13,2", "hw": "D53gAP",  "name": "iPhone 12",         "res": "1170x2532", "chip": "T8101", "mem": 4, "min_ios": 16, "max_ios": 18},
    {"model": "iPhone13,3", "hw": "D53pAP",  "name": "iPhone 12 Pro",     "res": "1170x2532", "chip": "T8101", "mem": 6, "min_ios": 16, "max_ios": 18},
    {"model": "iPhone13,4", "hw": "D54pAP",  "name": "iPhone 12 Pro Max", "res": "1284x2778", "chip": "T8101", "mem": 6, "min_ios": 16, "max_ios": 18},
    # iPhone 13 / 14 line — A15 Bionic (T8110)
    {"model": "iPhone14,4", "hw": "D16AP",   "name": "iPhone 13 mini",    "res": "1080x2340", "chip": "T8110", "mem": 4, "min_ios": 16, "max_ios": 18},
    {"model": "iPhone14,5", "hw": "D17AP",   "name": "iPhone 13",         "res": "1170x2532", "chip": "T8110", "mem": 4, "min_ios": 16, "max_ios": 18},
    {"model": "iPhone14,2", "hw": "D63AP",   "name": "iPhone 13 Pro",     "res": "1170x2532", "chip": "T8110", "mem": 6, "min_ios": 16, "max_ios": 18},
    {"model": "iPhone14,3", "hw": "D64AP",   "name": "iPhone 13 Pro Max", "res": "1284x2778", "chip": "T8110", "mem": 6, "min_ios": 16, "max_ios": 18},
    {"model": "iPhone14,7", "hw": "D27AP",   "name": "iPhone 14",         "res": "1170x2532", "chip": "T8110", "mem": 6, "min_ios": 16, "max_ios": 18},
    {"model": "iPhone14,8", "hw": "D28AP",   "name": "iPhone 14 Plus",    "res": "1284x2778", "chip": "T8110", "mem": 6, "min_ios": 16, "max_ios": 18},
    # iPhone 14 Pro / 15 line — A16 Bionic (T8120)
    {"model": "iPhone15,2", "hw": "D73AP",   "name": "iPhone 14 Pro",     "res": "1179x2556", "chip": "T8120", "mem": 6, "min_ios": 16, "max_ios": 18},
    {"model": "iPhone15,3", "hw": "D74AP",   "name": "iPhone 14 Pro Max", "res": "1290x2796", "chip": "T8120", "mem": 6, "min_ios": 16, "max_ios": 18},
    {"model": "iPhone15,4", "hw": "D37AP",   "name": "iPhone 15",         "res": "1179x2556", "chip": "T8120", "mem": 6, "min_ios": 17, "max_ios": 18},
    {"model": "iPhone15,5", "hw": "D38AP",   "name": "iPhone 15 Plus",    "res": "1290x2796", "chip": "T8120", "mem": 6, "min_ios": 17, "max_ios": 18},
    # iPhone 15 Pro line — A17 Pro (T8130)
    {"model": "iPhone16,1", "hw": "D83AP",   "name": "iPhone 15 Pro",     "res": "1179x2556", "chip": "T8130", "mem": 8, "min_ios": 17, "max_ios": 18},
    {"model": "iPhone16,2", "hw": "D84AP",   "name": "iPhone 15 Pro Max", "res": "1290x2796", "chip": "T8130", "mem": 8, "min_ios": 17, "max_ios": 18},
    # iPhone 16 line — A18 / A18 Pro (T8140), launched on iOS 18
    {"model": "iPhone17,1", "hw": "D93AP",   "name": "iPhone 16 Pro",     "res": "1206x2622", "chip": "T8140", "mem": 8, "min_ios": 18, "max_ios": 18},
    {"model": "iPhone17,2", "hw": "D94AP",   "name": "iPhone 16 Pro Max", "res": "1320x2868", "chip": "T8140", "mem": 8, "min_ios": 18, "max_ios": 18},
    {"model": "iPhone17,3", "hw": "D47AP",   "name": "iPhone 16",         "res": "1179x2556", "chip": "T8140", "mem": 8, "min_ios": 18, "max_ios": 18},
    {"model": "iPhone17,4", "hw": "D48AP",   "name": "iPhone 16 Plus",    "res": "1290x2796", "chip": "T8140", "mem": 8, "min_ios": 18, "max_ios": 18},
)

# iOS pool — (version, major, minor, patch, build, kernel xnu major.minor.patch,
# xnu build token for the Darwin string). All are real public builds >= iOS 16.
# The running device's own version and build are filtered out at pick time by
# random_device_fields(), so this pool does not need per-phone exclusions. It
# used to omit 20H392/20H380 by hand, which protected only the two phones those
# builds belonged to and left every other device able to draw its own identity.
IOS_POOL = (
    # iOS 16.x — the ONLY range valid for iPhone 8 / X (max_ios=16)
    ("16.5",   16, 5, 0, "20F66",  "22.5.0", "8796.121.2~5"),
    ("16.5.1", 16, 5, 1, "20F75",  "22.5.0", "8796.121.3~7"),
    ("16.6",   16, 6, 0, "20G75",  "22.6.0", "8796.141.3~6"),
    ("16.6.1", 16, 6, 1, "20G81",  "22.6.0", "8796.141.3~6"),
    ("16.7.1", 16, 7, 1, "20H321", "22.6.0", "8796.141.3~6"),
    ("16.7.4", 16, 7, 4, "20H378", "22.6.0", "8796.141.3~6"),
    ("16.7.8", 16, 7, 8, "20H430", "22.6.0", "8796.141.3~6"),
    ("16.7.10",16, 7, 10,"20H444", "22.6.0", "8796.141.3~6"),
    # iOS 17.x — iPhone XS / XR / 11+ tier
    ("17.0.3", 17, 0, 3, "21A360", "23.0.0", "10002.1.13~1"),
    ("17.1.2", 17, 1, 2, "21B101", "23.1.0", "10002.41.9~6"),
    ("17.2.1", 17, 2, 1, "21C66",  "23.2.0", "10002.61.3~2"),
    ("17.3.1", 17, 3, 1, "21D61",  "23.3.0", "10002.81.5~7"),
    ("17.4.1", 17, 4, 1, "21E237", "23.4.0", "10063.101.15~6"),
    ("17.5.1", 17, 5, 1, "21F90",  "23.5.0", "10063.121.3~5"),
    ("17.6.1", 17, 6, 1, "21G93",  "23.6.0", "10063.141.2~1"),
    ("17.7",   17, 7, 0, "21H16",  "23.6.0", "10063.141.2~1"),
    # iOS 18.x — iPhone XS+ tier (xnu tokens approximated where unverified;
    # IGUAFix Tigon KVC keys off UA/model, not kernel string, so low risk)
    ("18.0",   18, 0, 0, "22A3354","24.0.0", "11215.1.10~1"),
    ("18.1",   18, 1, 0, "22B83",  "24.1.0", "11215.41.3~2"),
    ("18.2",   18, 2, 0, "22C152", "24.2.0", "11215.61.5~1"),
)

# Optional restriction hook: set to a frozenset of model IDs to limit random
# picks to that subset (useful if a specific IGUAFix dylib resolutionMap only
# covers some models). None = no filtering, random across all of DEVICE_POOL.
SUPPORTED_MODELS = None


def physical_device():
    """Model and OS build of the phone this runs on.

    The persona must never be the device's own identity: an identical pick is
    not a spoof at all, and the sanitizer then has nothing to rewrite. This is
    read live rather than listed, because a list of builds to avoid only ever
    protects the phones it was written for.
    """
    model = ""
    try:
        model = str(os.uname().machine or "").strip()
    except Exception:
        model = ""
    version = build = ""
    try:
        system = read_plist("/System/Library/CoreServices/SystemVersion.plist")
        version = str(system.get("ProductVersion") or "").strip()
        build = str(system.get("ProductBuildVersion") or "").strip()
    except Exception:
        pass
    return {"model": model, "ios": version, "build": build}

STORAGE_OPTIONS = ("128", "256", "512")

SPOOF_FLAGS = (
    "enableSpoofAdvertisingID", "enableSpoofAlbum", "enableSpoofBatteryLevel",
    "enableSpoofBatteryState", "enableSpoofBrightness", "enableSpoofBugsnag",
    "enableSpoofCarrier", "enableSpoofCellular", "enableSpoofCellularType",
    "enableSpoofCloudToken", "enableSpoofCrane", "enableSpoofDeviceChecker",
    "enableSpoofDeviceModel", "enableSpoofDeviceName", "enableSpoofKernelVersion",
    "enableSpoofLocale", "enableSpoofLowPowerMode", "enableSpoofMail",
    "enableSpoofMemory", "enableSpoofMessage", "enableSpoofNetworkInfo",
    "enableSpoofOrientation", "enableSpoofPasteboard", "enableSpoofProcessor",
    "enableSpoofProximity", "enableSpoofScreenshot", "enableSpoofSoftwareVersion",
    "enableSpoofTimeZone", "enableSpoofVPN", "enableSpoofVendorID",
    "enableSpoofWiFi",
)


def read_plist(path):
    with open(path, "rb") as handle:
        value = plistlib.load(handle)
    return value if isinstance(value, dict) else {}


def find_app_root():
    for entry in os.listdir(DATA_ROOT):
        root = os.path.join(DATA_ROOT, entry)
        meta = os.path.join(root, ".com.apple.mobile_container_manager.metadata.plist")
        if not os.path.isfile(meta):
            continue
        try:
            if read_plist(meta).get("MCMMetadataIdentifier") == BUNDLE_ID:
                return root
        except Exception:
            continue
    return ""


def active_container():
    crane = read_plist(CRANE_PREFS)
    app = crane.get("appSettings_" + BUNDLE_ID) or {}
    container_id = str(app.get("activeContainer") or "").strip()
    name = ""
    for item in app.get("Containers", []):
        if str((item or {}).get("identifier") or "").strip() == container_id:
            name = str((item or {}).get("name") or "").strip()
            break
    return container_id, name


def fallback_data(app_root, target_id):
    # A missing active profile may use only the non-Crane parent as a shape
    # template. Never inspect an inactive Crane container: fresh device fields
    # and per-account identifiers are generated below before anything launches.
    del target_id
    path = os.path.join(app_root, "Documents", GHOST_PLIST)
    if os.path.isfile(path):
        try:
            return read_plist(path)
        except Exception:
            pass
    return {}


def random_mac():
    parts = [random.randint(0, 255) for _ in range(6)]
    parts[0] = (parts[0] | 2) & 0xFE
    return ":".join("%02X" % value for value in parts)


def random_ipv4():
    return ".".join(str(random.randint(2, 250)) for _ in range(4))


def pairing_is_real(device, ios):
    """True only for a (device, iOS) pair Apple actually shipped.

    The major-version window is not enough on its own. iOS 16.7.x is the legacy
    branch Apple kept publishing *only* for the devices that stopped at 16 — an
    A11 or older. Everything newer went 16.6.1 -> 17.x and never saw a 16.7
    build, so a persona like "iPhone 12 mini on 16.7.8" is impossible. Instagram
    440 notices: on 192.168.1.31 that pair produced one static getter read that
    the guard could not rewrite, then the app went quiet — `getter_verify_fail`,
    `residual`, fatal `getter_residual`. The same container passed immediately
    once a real pair was drawn.
    """
    version, major = ios[0], ios[1]
    if not device["min_ios"] <= major <= device.get("max_ios", 99):
        return False
    if version.startswith("16.7") and device.get("max_ios", 99) != 16:
        return False
    return True


def random_device_fields():
    """Return a full, internally consistent random device persona.

    Randomly picks a (device, iOS) pair and rejects combos that never shipped
    (see pairing_is_real). If 64 tries all fail (would require a pathological
    pool), falls back to enumerating valid pairs deterministically.
    """
    pool = DEVICE_POOL
    if SUPPORTED_MODELS is not None:
        pool = tuple(d for d in DEVICE_POOL if d["model"] in SUPPORTED_MODELS)
    # Never hand back the phone's own model or OS build.
    physical = physical_device()
    if physical["model"]:
        filtered = tuple(d for d in pool if d["model"] != physical["model"])
        if filtered:
            pool = filtered
    ios_pool = IOS_POOL
    if physical["build"] or physical["ios"]:
        filtered_ios = tuple(
            entry for entry in IOS_POOL
            if entry[4] != physical["build"] and entry[0] != physical["ios"]
        )
        if filtered_ios:
            ios_pool = filtered_ios
    device = None
    ios = None
    for _ in range(64):
        cand_dev = random.choice(pool)
        cand_ios = random.choice(ios_pool)
        if pairing_is_real(cand_dev, cand_ios):
            device, ios = cand_dev, cand_ios
            break
    if device is None:
        valid = [(d, v) for d in pool for v in ios_pool if pairing_is_real(d, v)]
        if not valid:
            raise RuntimeError("no valid (device, iOS) combination in pool")
        device, ios = random.choice(valid)
    version, major, minor, patch, build, kernel, xnu = ios
    darwin = ("Darwin Kernel Version %s: root:xnu-%s/RELEASE_ARM64_%s"
              % (kernel, xnu, device["chip"]))
    return {
        "deviceDisplayName": device["name"],
        "deviceModel": device["model"],
        "deviceHardwareModel": device["hw"],
        "deviceStorage": random.choice(STORAGE_OPTIONS),
        "iosVersion": version,
        "iosVersionMajor": major,
        "iosVersionMinor": minor,
        "iosVersionPatch": patch,
        "iosVersionBuild": "Version %s (Build %s)" % (version, build),
        "kernelVersion": kernel,
        "kernelVersionDarwin": darwin,
        "selectedKernelVersion": "%s:%s" % (version, kernel),
        "jailbroken": False,
    }


# Region personas are drawn the same way the device is: from a pool, at random.
# They differ in one way — the device is re-rolled per account, the region is
# rolled once per phone and then persists, because every account on one phone has
# to tell the same regional story. What must never happen is a persona arriving
# from somewhere else: two phones sharing a carrier and time zone is a
# correlation signal, and hand-copying is how .35 and .37 ended up identical.
# MCC/MNC pairs are the real ones for each carrier; MVNOs carry their host's.
US_CARRIERS = (
    ("AT&T", "310", "410"),
    ("T-Mobile", "310", "260"),
    ("Verizon", "311", "480"),
    ("US Cellular", "311", "220"),
    ("Cricket Wireless", "310", "410"),
    ("Metro by T-Mobile", "310", "260"),
    ("Xfinity Mobile", "311", "480"),
    ("Visible", "311", "480"),
    ("Google Fi", "310", "260"),
    ("Mint Mobile", "310", "260"),
)
US_TIMEZONES = (
    ("America/New_York", "EST"),
    ("America/Detroit", "EST"),
    ("America/Chicago", "CST"),
    ("America/Denver", "MST"),
    ("America/Phoenix", "MST"),
    ("America/Los_Angeles", "PST"),
    ("America/Anchorage", "AKST"),
    ("Pacific/Honolulu", "HST"),
)
US_FLAG = "\U0001F1FA\U0001F1F8"

# A persona is only usable if these carry values; the rest are display sugar.
PERSONA_REQUIRED = (
    "localeID", "localeCountryCode", "localeLanguageCode",
    "timezoneName", "timezoneAbbreviation",
    "carrierName", "carrierMCC", "carrierMNC",
)


def random_persona():
    """One internally consistent region persona, drawn independently."""
    carrier, mcc, mnc = random.choice(US_CARRIERS)
    timezone, abbreviation = random.choice(US_TIMEZONES)
    return {
        "carrierName": carrier,
        "carrierMCC": mcc,
        "carrierMNC": mnc,
        "carrierCountryCode": "US",
        "carrierFlag": US_FLAG,
        "carrierSelectedValue": "%s:%s:%s" % (carrier, mcc, mnc),
        "cellularType": "LTE",
        "localeID": "en_US",
        "localeCountryCode": "US",
        "localeLanguageCode": "en",
        "localeCurrencyCode": "USD",
        "localeCurrencySymbol": "$",
        "localeFlag": "US",
        "localeFlagCode": "US",
        "localeFlagEmoji": US_FLAG,
        "timezoneName": timezone,
        "timezoneAbbreviation": abbreviation,
        "timezoneFlag": US_FLAG,
        "timezoneSelectedValue": "%s:%s" % (timezone, abbreviation),
    }


def persona_is_complete(profile):
    return all(str(profile.get(field) or "").strip() for field in PERSONA_REQUIRED)


def load_persona(fresh_persona=False):
    """The phone's region persona: kept if it has one, drawn if it does not.

    The generated persona is persisted because GLOBAL_PROFILE is one of the
    destinations every seed is mirrored to, so the roll happens once per phone.
    """
    try:
        profile = read_plist(GLOBAL_PROFILE)
    except Exception:
        profile = {}
    if fresh_persona or not persona_is_complete(profile):
        return random_persona()
    return {key: profile[key] for key in PERSONA_FIELDS if key in profile}


# A spoof flag with nothing behind it is worse than no spoof at all: Ghost then
# hands the app an empty locale, and Instagram dies in CFCalendar
# (_CFCalendarCreate -> CFStringGetLength on NULL, reached through Security's DER
# date decoding) on every launch. Seen on 192.168.1.33, whose Global Ghost
# profile carried no persona at all: 17 crashes in a day and no run could pass.
PERSONA_SPOOF_GROUPS = (
    ("enableSpoofLocale", ("localeID", "localeCountryCode", "localeLanguageCode")),
    ("enableSpoofTimeZone", ("timezoneName", "timezoneAbbreviation")),
    ("enableSpoofCarrier", ("carrierName", "carrierMCC", "carrierMNC")),
)


def disable_valueless_spoofs(data):
    """Turn off any persona spoof whose values are missing. Returns what it cut."""
    disabled = []
    for flag, fields in PERSONA_SPOOF_GROUPS:
        if not data.get(flag):
            continue
        if all(str(data.get(field) or "").strip() for field in fields):
            continue
        data[flag] = False
        disabled.append(flag)
    return disabled


def apply_target(data, fresh_identity, fresh_persona=False):
    # Region persona stays consistent across accounts on this phone.
    data.update(load_persona(fresh_persona=fresh_persona))

    if fresh_identity:
        # New account -> new random device + fresh identity IDs.
        data.update(random_device_fields())
        data.update({
            "advertisingID": str(uuid.uuid4()).upper(),
            "vendorID": str(uuid.uuid4()).upper(),
            "wifiBSSID": random_mac(),
            "wifiAddress": random_ipv4(),
            "cellularAddress": random_ipv4(),
        })
        display = str(data.get("deviceDisplayName") or "iPhone").strip() or "iPhone"
        slug = display.replace(" ", "-")
        suffix = random.randint(100, 999)
        data["deviceName"] = "%s %d" % (display, suffix)
        data["deviceNameNode"] = "%s-%d" % (slug, suffix)
        data["deviceNameHost"] = "%s-%d.local" % (slug.lower(), suffix)
    elif not data.get("deviceModel"):
        # Existing container missing a device (unexpected) -> assign one.
        data.update(random_device_fields())

    data["enableGhost"] = True
    for key in SPOOF_FLAGS:
        data[key] = True
    data["jailbroken"] = False
    # Must come after the blanket enable above, or it would just be overwritten.
    data["ghostDisabledValuelessSpoofs"] = disable_valueless_spoofs(data)
    return data


def atomic_write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    temporary = path + ".iguafix-new"
    with open(temporary, "wb") as handle:
        plistlib.dump(data, handle, fmt=plistlib.FMT_BINARY)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)
    os.chmod(path, 0o644)


def atomic_write_many(destinations, data):
    """Write the same plist atomically to every destination path.

    Mirrors the random device profile to the Crane slot, the main container
    Documents/, and the Global Ghost master so ghost-global-syncd cannot revert
    the seed and every reader (Ghost.dylib, IGUAFix, syncd) sees a consistent
    device. Continues on individual failures; returns the paths that succeeded.
    """
    written = []
    for dest in destinations:
        try:
            atomic_write(dest, data)
            written.append(dest)
        except OSError:
            continue
    return written


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--fresh-identifiers", action="store_true")
    # Re-roll the phone's region persona. Needed when a persona was copied
    # from another device and has to be made independent again.
    parser.add_argument("--fresh-persona", action="store_true")
    parser.add_argument("--expected-container-id", default="")
    args = parser.parse_args()

    if not os.path.isfile(CRANE_PREFS):
        raise SystemExit(json.dumps({"success": False, "reason": "crane_prefs_missing"}))
    app_root = find_app_root()
    container_id, container_name = active_container()
    if not app_root or not container_id or container_id == "DEFAULT":
        raise SystemExit(json.dumps({
            "success": False,
            "reason": "active_crane_container_missing",
            "container_id": container_id,
        }))
    expected_container_id = str(args.expected_container_id or "").strip().upper()
    if expected_container_id and container_id.upper() != expected_container_id:
        print(json.dumps({
            "success": False,
            "reason": "active_container_changed",
            "expected_container_id": expected_container_id,
            "container_id": container_id,
        }))
        return 1

    base = os.path.join(app_root, "Library", "___Crane_Containers", container_id)
    if not os.path.isdir(base):
        raise SystemExit(json.dumps({
            "success": False,
            "reason": "container_not_materialized",
            "container_id": container_id,
        }))
    path = os.path.join(base, "Documents", GHOST_PLIST)
    existed = os.path.isfile(path)
    data = read_plist(path) if existed else fallback_data(app_root, container_id)
    data = apply_target(
        data,
        fresh_identity=(not existed or args.fresh_identifiers),
        fresh_persona=args.fresh_persona,
    )

    # Enforce the Instagram floor: >= iPhone 8 (iPhone10,x) and iOS >= 16.
    model = data.get("deviceModel")
    ios = data.get("iosVersion")
    if target_below_floor(model, ios):
        raise SystemExit(json.dumps({
            "success": False,
            "reason": "target_below_floor",
            "deviceModel": model,
            "iosVersion": ios,
            "floor": {"minDevice": "iPhone10,x (iPhone 8)", "minIOS": MIN_IOS_MAJOR},
        }, ensure_ascii=False))

    # Mirror the seeded device to (a) the Crane slot the caller is switching to,
    # (b) the main container Documents/ that IG reads before the Crane redirect
    # resolves, and (c) the Global Ghost master ghost-global-syncd copies from.
    # With the three files identical the syncd revert loop is a no-op and every
    # reader (Ghost.dylib, IGUAFix, cold-launch analytics) sees the same phone.
    destinations = [
        path,                                              # Crane slot Documents
        os.path.join(app_root, "Documents", GHOST_PLIST),  # main container Documents
        GLOBAL_PROFILE,                                    # Global master
    ]
    mirrored = []
    if not args.dry_run:
        current_id, _current_name = active_container()
        if current_id.upper() != container_id.upper():
            print(json.dumps({
                "success": False,
                "reason": "active_container_changed",
                "expected_container_id": container_id,
                "container_id": current_id,
            }))
            return 1
        mirrored = atomic_write_many(destinations, data)
        final_id, _final_name = active_container()
        if final_id.upper() != container_id.upper():
            print(json.dumps({
                "success": False,
                "reason": "active_container_changed",
                "expected_container_id": container_id,
                "container_id": final_id,
                "mirrored_paths": mirrored,
            }))
            return 1

    if not args.dry_run and path in mirrored:
        with open(path, "rb") as handle:
            profile_sha256 = hashlib.sha256(handle.read()).hexdigest()
    else:
        profile_sha256 = hashlib.sha256(
            plistlib.dumps(data, fmt=plistlib.FMT_BINARY)
        ).hexdigest()

    print(json.dumps({
        "success": True,
        "dry_run": args.dry_run,
        "fresh_identifiers": args.fresh_identifiers,
        "fresh_persona": args.fresh_persona,
        "container_id": container_id,
        "container_name": container_name,
        "prefs_path": path,
        "mirrored_paths": mirrored,
        "created": not existed,
        "deviceModel": data.get("deviceModel"),
        "deviceDisplayName": data.get("deviceDisplayName"),
        "iosVersion": data.get("iosVersion"),
        "iosVersionBuild": data.get("iosVersionBuild"),
        "profile_sha256": profile_sha256,
    }, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
