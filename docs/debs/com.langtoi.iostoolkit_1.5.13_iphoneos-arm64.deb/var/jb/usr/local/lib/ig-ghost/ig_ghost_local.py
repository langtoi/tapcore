"""On-device ig-ghost helper.

Replaces the paramiko-backed :class:`ig_ghost_guard_cli.Remote` with a local
process shim so the same apply/check/enable/disable/state/remove verbs run
directly on the iPhone.  The local-only ``instagram`` verb force-applies and
verifies the currently active Crane container without randomizing or switching.

Not for use on the PC controller — that path continues to import paramiko.
"""
from __future__ import annotations

import json
import os
import plistlib
import pwd
import shlex
import shutil
import subprocess
import sys
import tempfile
from typing import Any, Tuple


class _LocalSftp:
    """Subset of paramiko SFTPClient consumed by ig_ghost_guard_cli."""

    @staticmethod
    def remove(path: str) -> None:
        os.remove(path)

    @staticmethod
    def stat(path: str) -> os.stat_result:
        return os.stat(path)


class LocalRemote:
    """subprocess-backed drop-in for :class:`ig_ghost_guard_cli.Remote`.

    Public surface mirrors the SSH remote: ``command``, ``sudo``,
    ``read_bytes``, ``read_plist``, ``exists``, ``write_atomic``, plus the
    ``sftp.remove`` / ``sftp.stat`` calls used for on-device housekeeping.
    """

    SUDO = "/var/jb/usr/bin/sudo"
    SHELL = "/var/jb/usr/bin/sh"

    def __init__(self, device: Any):
        self.device = device
        self.sftp = _LocalSftp()

    # Context manager parity with SSH Remote.
    def __enter__(self) -> "LocalRemote":
        return self

    def __exit__(self, *_args: object) -> None:
        return None

    # ------------------------------------------------------------------
    # Command execution
    # ------------------------------------------------------------------
    def command(self, command: str, *, timeout: int = 30) -> Tuple[int, str, str]:
        proc = subprocess.run(
            [self.SHELL, "-c", command],
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        return proc.returncode, proc.stdout, proc.stderr

    def sudo(self, command: str, *, timeout: int = 60) -> Tuple[int, str, str]:
        wrapped = self.SUDO + " -S -p '' " + self.SHELL + " -c " + shlex.quote(command)
        password = getattr(self.device, "password", "") or ""
        proc = subprocess.run(
            [self.SHELL, "-c", wrapped],
            input=password + "\n",
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        return proc.returncode, proc.stdout, proc.stderr

    # ------------------------------------------------------------------
    # File primitives
    # ------------------------------------------------------------------
    @staticmethod
    def read_bytes(path: str) -> bytes:
        with open(path, "rb") as handle:
            return handle.read()

    def read_plist(self, path: str) -> dict:
        value = plistlib.loads(self.read_bytes(path))
        if not isinstance(value, dict):
            raise RuntimeError(f"plist is not a dictionary: {path}")
        return value

    @staticmethod
    def exists(path: str) -> bool:
        return os.path.exists(path)

    @staticmethod
    def write_atomic(path: str, data: bytes, mode: int = 0o600) -> None:
        parent = os.path.dirname(path) or "."
        os.makedirs(parent, exist_ok=True)
        fd, tmp = tempfile.mkstemp(prefix=".ig-ghost-", dir=parent)
        try:
            with os.fdopen(fd, "wb") as handle:
                handle.write(data)
            os.chmod(tmp, mode)
            if os.geteuid() == 0 and path.startswith("/var/mobile/"):
                mobile = pwd.getpwnam("mobile")
                os.chown(tmp, mobile.pw_uid, mobile.pw_gid)
            os.replace(tmp, path)
        except Exception:
            try:
                os.remove(tmp)
            except OSError:
                pass
            raise


def _patch_cli_module():
    """Import the shipped CLI and swap in :class:`LocalRemote`.

    Also fill a stub for paramiko so the CLI's ``import paramiko`` inside
    :meth:`Remote.__enter__` never triggers when we invoke the CLI's helpers
    directly (belt and braces — LocalRemote replaces Remote entirely).
    """
    lib_dir = os.path.dirname(os.path.realpath(__file__))
    if lib_dir not in sys.path:
        sys.path.insert(0, lib_dir)

    # paramiko stub so the shipped CLI never explodes at import time.
    if "paramiko" not in sys.modules:
        import types

        stub = types.ModuleType("paramiko")

        def _blocked(*_args, **_kwargs):
            raise RuntimeError(
                "paramiko is unavailable on-device; LocalRemote should be used"
            )

        stub.SSHClient = _blocked  # type: ignore[attr-defined]
        stub.AutoAddPolicy = _blocked  # type: ignore[attr-defined]
        sys.modules["paramiko"] = stub

    import ig_ghost_guard_cli as cli  # noqa: E402

    cli.Remote = LocalRemote  # replace paramiko-backed remote
    return cli


HTTPD_LABEL = "com.langtoi.igghostguard.httpd"
HTTPD_PLIST = "/var/jb/Library/LaunchDaemons/com.langtoi.igghostguard.httpd.plist"
HTTPD_PID_PATH = "/var/mobile/ig-ghost-httpd.pid"


def _launchctl(action: str, *extra: str) -> Tuple[int, str, str]:
    proc = subprocess.run(
        ["/var/jb/bin/launchctl", action, *extra],
        capture_output=True,
        text=True,
        check=False,
    )
    return proc.returncode, proc.stdout, proc.stderr


def _httpd_pid() -> int | None:
    try:
        with open(HTTPD_PID_PATH, "r", encoding="utf-8") as fh:
            return int(fh.read().strip() or "0") or None
    except OSError:
        return None


def _httpd_alive(pid: int | None) -> bool:
    if not pid:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


HTTPD_BIN = "/var/jb/usr/bin/ig-ghost-httpd"
HTTPD_STDOUT = "/var/mobile/ig-ghost-httpd.stdout.log"
HTTPD_STDERR = "/var/mobile/ig-ghost-httpd.stderr.log"


def _kill_pid(pid: int) -> bool:
    import signal
    try:
        os.kill(pid, signal.SIGTERM)
        # short wait then confirm
        for _ in range(10):
            try:
                os.kill(pid, 0)
            except OSError:
                return True
            import time
            time.sleep(0.1)
        os.kill(pid, signal.SIGKILL)
        return True
    except OSError:
        return False


def _pgrep_httpd() -> list[int]:
    """Return PIDs of any running ig-ghost-httpd (excluding the launcher).

    Uses ps because iOS lacks pgrep.
    """
    try:
        proc = subprocess.run(
            ["/bin/ps", "-ax", "-o", "pid=", "-o", "command="],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
    except Exception:
        return []
    pids: list[int] = []
    for line in proc.stdout.splitlines():
        parts = line.strip().split(None, 1)
        if len(parts) != 2:
            continue
        try:
            command = shlex.split(parts[1])
        except ValueError:
            continue
        # The real daemon is always the final argv item. Requiring this exact
        # path avoids treating a shell, grep, or diagnostic command that merely
        # mentions ``ig-ghost-httpd`` as a live server.
        if not command or command[-1] != HTTPD_BIN:
            continue
        try:
            pids.append(int(parts[0]))
        except ValueError:
            pass
    return pids


def _handle_http(argv: list[str]) -> int:
    """`ig-ghost http (start|stop|status)`.

    Uses a plain `nohup` background launch instead of launchd — the
    LaunchDaemon plist ships for parity but Dopamine's rootless launchd
    context refuses to spawn our Python daemon reliably (exit code 78
    with no captured stderr). Directly forking gives predictable behaviour
    and the daemon still detaches from the caller.
    """
    sub = argv[0] if argv else ""
    if sub == "start":
        # If any instance is already running, report it instead of double-launching.
        running = _pgrep_httpd()
        if running:
            print(json.dumps({"ok": True, "already_running": True, "pids": running}, indent=2))
            return 0
        # `nohup … &` alone detaches on POSIX; `disown` is a bash builtin absent
        # from the /var/jb/usr/bin/sh (dash) that runs this line.
        cmd = (
            f"nohup {HTTPD_BIN} </dev/null "
            f">>{shlex.quote(HTTPD_STDOUT)} 2>>{shlex.quote(HTTPD_STDERR)} &"
        )
        subprocess.run(["/var/jb/usr/bin/sh", "-c", cmd], check=False)
        # Wait a moment then verify.
        import time
        for _ in range(20):
            time.sleep(0.15)
            pids = _pgrep_httpd()
            if pids:
                print(json.dumps({"ok": True, "started": True, "pids": pids}, indent=2))
                return 0
        # Fallback: read stderr tail for diagnostics.
        tail = ""
        try:
            with open(HTTPD_STDERR, "r", encoding="utf-8", errors="replace") as fh:
                tail = fh.read()[-400:]
        except OSError:
            pass
        print(json.dumps({"ok": False, "error": "did_not_start", "stderr_tail": tail}, indent=2))
        return 1
    if sub == "stop":
        killed: list[int] = []
        for pid in _pgrep_httpd():
            if _kill_pid(pid):
                killed.append(pid)
        print(json.dumps({"ok": True, "killed": killed}, indent=2))
        return 0
    if sub == "status":
        pids = _pgrep_httpd()
        payload = {
            "ok": True,
            "label": HTTPD_LABEL,
            "pids": pids,
            "alive": bool(pids),
            "plist": HTTPD_PLIST,
        }
        print(json.dumps(payload, indent=2))
        return 0
    print(
        json.dumps(
            {"ok": False, "error": "usage: ig-ghost http (start|stop|status)"},
            indent=2,
        )
    )
    return 2


def main(argv: list[str] | None = None) -> int:
    """Entry used by /var/jb/usr/bin/ig-ghost."""
    if argv is None:
        argv = sys.argv[1:]

    # Local `http` verb — daemon lifecycle.
    if argv and argv[0] == "http":
        return _handle_http(argv[1:])

    # Local active-container workflow.  Intercept before the shared argparse
    # parser because the PC/fleet CLI intentionally has no container-mutating
    # verb and this command must never target another device over SSH.
    if argv and argv[0] == "instagram":
        from ig_ghost_workflow import main as workflow_main

        return workflow_main(argv[1:])

    # Force local execution unless caller explicitly opts in to fleet mode.
    if argv and argv[0] not in {"build"} and "--ip" not in argv:
        argv = argv[:1] + ["--ip", "127.0.0.1"] + argv[1:]

    cli = _patch_cli_module()

    saved_argv = sys.argv
    sys.argv = ["ig-ghost"] + list(argv)
    try:
        return cli.main()
    finally:
        sys.argv = saved_argv


if __name__ == "__main__":
    raise SystemExit(main())
