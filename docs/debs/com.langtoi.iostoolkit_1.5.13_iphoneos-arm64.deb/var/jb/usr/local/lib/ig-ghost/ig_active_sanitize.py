"""Sanitize queued Instagram identity data for one active Crane container.

The force-active workflow already protects live User-Agent headers.  Instagram
also persists device identity in preferences and local upload queues; stale
rows can be transmitted after a container switch even when the live header is
clean.  This module only touches the explicitly supplied active container and
the matching Crane subdirectory in Instagram's app group.  It never walks or
modifies an inactive Crane container.
"""
from __future__ import annotations

import argparse
import dataclasses
import functools
import hashlib
import json
import os
import plistlib
import pwd
import shutil
import sqlite3
import subprocess
import time
from pathlib import Path
from typing import Any, Iterable


INSTAGRAM_GROUP = "group.com.burbn.instagram"
THREADS_BUNDLE = "com.burbn.barcelona"
FFLOGGER_INSERT_TRIGGER = "igghostguard_batch_os_build_insert"
FFLOGGER_UPDATE_TRIGGER = "igghostguard_batch_os_build_update"
ANALYTICS_INSERT_TRIGGER = "igghostguard_analytics_device_insert"
ANALYTICS_UPDATE_TRIGGER = "igghostguard_analytics_device_update"
ANALYTICS_PAYLOAD_TRIGGER = "igghostguard_analytics_payload_insert"
ANALYTICS_UPLOAD_TRIGGER = "igghostguard_analytics_upload_insert"
FFLOGGER_USER_VERSION = 15
FFLOGGER_SCHEMA = (
    "create table batch(id integer primary key autoincrement, identities_hash integer unique, "
    "timestamp integer, device_id text, family_device_id text, os_build_number text, "
    "app_id text, app_version text, build_num integer, bundle_id text, session_id text, "
    "sequence_id integer, consent_state integer, user_identity_type integer, claims text, "
    "account_id text, actor_id text, uid text, identifier text, proxy_app_id text, "
    "proxy_app_version text)",
    "create table buffer_event(id integer primary key autoincrement, identities_hash integer, "
    "name text, time_in_ms integer, tags integer, sample_rate integer, requested_latency integer, "
    "extra text, extra_binary binary, compression_method text, trace_id text)",
    "create table checksum(id integer primary key autoincrement, checksum_hash integer unique, "
    "identities_hash integer, type integer, checksum text, timestamp integer)",
    "create table claim(id integer primary key autoincrement, principal_subject_hash integer, "
    "claim text, expires_at integer)",
    "create table collection_constraint(id integer primary key autoincrement, "
    "identities_hash integer unique, value integer, expression_op text, expression_refs text)",
    "create table event(id integer primary key autoincrement, identities_hash integer, "
    "name text, time_in_ms integer, tags integer, sample_rate integer, requested_latency integer, "
    "extra text, extra_binary binary, compression_method text, trace_id text, debug_token text)",
    "create index event_0 on event(requested_latency)",
    "create table event_config(id integer primary key autoincrement, event_config_hash integer unique, "
    "identities_hash integer, event_name text, sampling_rate integer, collection_constraint_ref integer)",
    "create table upload(id integer primary key autoincrement, request_data binary, num_events integer, "
    "is_compressed integer, compression_method text, event_names text, event_timestamps text)",
)
ANALYTICS_USER_VERSION = 5
ANALYTICS_SCHEMA = (
    "create table analytics_events(id integer primary key asc autoincrement, "
    "event_name text not null, sub_event_name text not null, module text not null, "
    "event_timestamp numeric not null, requested_latency numeric not null, "
    "event_tag integer not null, applied_sample_rate integer not null, "
    "event_byte_size integer not null, app_identity text not null, "
    "device_identity text not null, user_identity text not null, "
    "event_payload blob not null, stored_timestamp numeric not null, "
    "privacy_context text default '', compression_type integer default 0, "
    "trace_id text default '', upload_domain_type integer default 0)",
    "create index analytics_event_indexes on analytics_events"
    "(requested_latency, event_timestamp, stored_timestamp)",
    "create table analytics_uploads(id integer primary key asc autoincrement, "
    "batched_timestamp numeric not null, is_multi_batch integer not null, "
    "events_count integer not null, batches_count integer not null, "
    "upload_byte_size integer not null, retry_count integer default 0, "
    "minimum_latency numeric not null, events_in_upload text not null, "
    "upload_payload blob not null, upload_status integer not null, "
    "stored_timestamp numeric not null, compression_type integer default 0, "
    "upload_domain_type integer default 0, event_timestamps_in_upload text default '')",
    "create index analytics_upload_indexes on analytics_uploads"
    "(minimum_latency, batched_timestamp, stored_timestamp)",
)


@dataclasses.dataclass(frozen=True)
class TargetIdentity:
    model: str
    hardware: str
    display_name: str
    ios: str
    build: str
    resolution: str


def _plist(path: str) -> dict[str, Any]:
    with open(path, "rb") as handle:
        value = plistlib.load(handle)
    if not isinstance(value, dict):
        raise ValueError(f"plist is not a dictionary: {path}")
    return value


def identity_from_profile(raw: bytes) -> TargetIdentity:
    value = plistlib.loads(raw)
    if not isinstance(value, dict):
        raise ValueError("active profile is not a dictionary")
    model = str(value.get("deviceModel") or "").strip()
    hardware = str(value.get("deviceHardwareModel") or "").strip()
    display_name = str(value.get("deviceDisplayName") or "").strip()
    ios = str(value.get("iosVersion") or "").strip()
    build_raw = str(value.get("iosVersionBuild") or "").strip()
    build = build_raw
    if "Build " in build_raw:
        build = build_raw.split("Build ", 1)[1].split(")", 1)[0].strip()

    # Keep this map deliberately local and finite: unsupported profiles must
    # fail instead of silently inventing a screen identity.
    from ig_ghost_guard_cli import RES_MAP

    resolution = RES_MAP.get(model, "")
    if not all((model, hardware, display_name, ios, build, resolution)):
        raise ValueError("active profile has an incomplete/unsupported identity")
    return TargetIdentity(model, hardware, display_name, ios, build, resolution)


def _add(replacements: list[tuple[str, str]], old: str, new: str) -> None:
    old = str(old or "").strip()
    new = str(new or "").strip()
    if len(old) < 4 or not new or old == new:
        return
    pair = (old, new)
    if pair not in replacements:
        replacements.append(pair)


def _sysctl(name: str) -> str:
    for binary in ("/var/jb/usr/sbin/sysctl", "/usr/sbin/sysctl", "sysctl"):
        try:
            result = subprocess.run(
                [binary, "-n", name], capture_output=True, text=True, timeout=5
            )
        except Exception:
            continue
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    return ""


@functools.lru_cache(maxsize=1)
def physical_identity() -> dict[str, str]:
    """The real identity of the device this runs on.

    Everything the guard has to erase starts here, so it is read from the
    device instead of being written down: a marker list pinned to one phone's
    hardware silently stops covering the model, board id, and OS strings of any
    other phone, which lets the real identity survive in the analytics queue on
    a device the list was not written for.

    Returns an empty mapping off-device (tests, build hosts) so the caller
    falls back to the historical marker list alone.
    """
    from ig_ghost_guard_cli import DEVICE_NAMES, RES_MAP

    values: dict[str, str] = {}
    model = ""
    try:
        model = str(os.uname().machine or "").strip()
    except Exception:
        model = ""
    if not model.startswith("iPhone"):
        model = _sysctl("hw.machine") or _sysctl("hw.product")
    if not model.startswith("iPhone"):
        return {}
    values["model"] = model
    values["display_name"] = DEVICE_NAMES.get(model, "")
    values["resolution"] = RES_MAP.get(model, "")
    # hw.target is the board id (the D22AP/D211AP form the caches carry).
    values["hardware"] = _sysctl("hw.target") or _sysctl("hw.model")
    try:
        with open("/System/Library/CoreServices/SystemVersion.plist", "rb") as handle:
            system = plistlib.load(handle)
        values["ios"] = str(system.get("ProductVersion") or "")
        values["build"] = str(system.get("ProductBuildVersion") or "")
    except Exception:
        values["ios"] = ""
        values["build"] = _sysctl("kern.osversion")
    return {key: value for key, value in values.items() if value}


# Hardware the workspace's own phones have run on. The live device identity is
# read at runtime; this list only keeps older markers reachable, so a container
# carrying data from another phone (a restored archive, a moved SIM) is still
# cleaned. It must never be the only source of markers.
LEGACY_SOURCE_IDENTITIES = (
    {
        "model": "iPhone10,3",
        "display_name": "iPhone X",
        "hardware": "D22AP",
        "ios": "16.7.16",
        "build": "20H392",
        "resolution": "1125x2436",
    },
    {"model": "iPhone10,6", "display_name": "iPhone X", "resolution": "1125x2436"},
    {"build": "20H380"},
)


def _add_source_markers(
    replacements: list[tuple[str, str]],
    source: dict[str, str],
    identity: TargetIdentity,
) -> None:
    """Map one real-world identity onto the spoofed one."""
    target_major = identity.ios.split(".", 1)[0]
    width, height = identity.resolution.split("x", 1)

    model = source.get("model", "")
    _add(replacements, model, identity.model)
    _add(replacements, source.get("display_name", ""), identity.display_name)
    _add(replacements, source.get("hardware", ""), identity.hardware)
    _add(replacements, source.get("build", ""), identity.build)
    ios = source.get("ios", "")
    _add(replacements, ios, identity.ios)
    _add(replacements, ios.replace(".", "_"), identity.ios.replace(".", "_"))
    resolution = source.get("resolution", "")
    _add(replacements, resolution, identity.resolution)
    if "x" in resolution:
        source_width, source_height = resolution.split("x", 1)
        _add(replacements, f"{source_height}x{source_width}", f"{height}x{width}")
    if model:
        # The queued composite form is "1:<model>:<ios major>". The major that
        # wrote a given row is not knowable from here, so cover the source's own
        # major plus the ones these caches have been seen carrying.
        majors = {major for major in (ios.split(".", 1)[0], "16", "17", "18") if major}
        for major in sorted(majors):
            _add(
                replacements,
                f"1:{model}:{major}",
                f"1:{identity.model}:{target_major}",
            )


def build_replacements(
    identity: TargetIdentity,
    physical: dict[str, str] | None = None,
) -> tuple[tuple[str, str], ...]:
    replacements: list[tuple[str, str]] = []
    source = physical_identity() if physical is None else physical
    if source:
        _add_source_markers(replacements, source, identity)
    for legacy in LEGACY_SOURCE_IDENTITIES:
        _add_source_markers(replacements, legacy, identity)
    return tuple(sorted(replacements, key=lambda pair: len(pair[0]), reverse=True))


def _replace_text(text: str, replacements: Iterable[tuple[str, str]]) -> tuple[str, int]:
    changed = 0
    result = text
    for old, new in replacements:
        count = result.count(old)
        if count:
            result = result.replace(old, new)
            changed += count
    return result, changed


def _replace_value(value: Any, replacements: tuple[tuple[str, str], ...]) -> tuple[Any, int]:
    if isinstance(value, str):
        return _replace_text(value, replacements)
    if isinstance(value, list):
        changed = 0
        output = []
        for item in value:
            patched, count = _replace_value(item, replacements)
            output.append(patched)
            changed += count
        return output, changed
    if isinstance(value, tuple):
        patched, changed = _replace_value(list(value), replacements)
        return tuple(patched), changed
    if isinstance(value, dict):
        changed = 0
        output: dict[Any, Any] = {}
        for key, item in value.items():
            patched, count = _replace_value(item, replacements)
            output[key] = patched
            changed += count
        return output, changed
    if isinstance(value, (bytes, bytearray)):
        raw = bytes(value)
        try:
            nested = plistlib.loads(raw)
        except Exception:
            return value, 0
        patched, changed = _replace_value(nested, replacements)
        if not changed:
            return value, 0
        return plistlib.dumps(patched, fmt=plistlib.FMT_BINARY), changed
    return value, 0


def sanitize_preferences(path: str, replacements: tuple[tuple[str, str], ...]) -> int:
    if not os.path.isfile(path):
        return 0
    value = _plist(path)
    patched, changed = _replace_value(value, replacements)
    if changed:
        temporary = f"{path}.igghost.tmp.{os.getpid()}"
        with open(temporary, "wb") as handle:
            plistlib.dump(patched, handle, fmt=plistlib.FMT_BINARY)
        os.chmod(temporary, os.stat(path).st_mode & 0o777)
        os.replace(temporary, path)
    return changed


def _quoted(identifier: str) -> str:
    return '"' + identifier.replace('"', '""') + '"'


def _tables(connection: sqlite3.Connection) -> set[str]:
    return {
        str(row[0])
        for row in connection.execute("select name from sqlite_master where type='table'")
    }


def _columns(connection: sqlite3.Connection, table: str) -> list[str]:
    return [str(row[1]) for row in connection.execute(f"pragma table_info({_quoted(table)})")]


def _sql_literal(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def initialize_fflogger_schema(connection: sqlite3.Connection) -> None:
    """Create the schema Instagram 438 uses when a fresh container has none."""
    existing = _tables(connection) - {"sqlite_sequence"}
    if existing:
        raise ValueError(f"refusing to replace an existing FFLogger schema: {sorted(existing)}")
    for statement in FFLOGGER_SCHEMA:
        connection.execute(statement)
    connection.execute(f"pragma user_version={FFLOGGER_USER_VERSION}")


def initialize_analytics_schema(connection: sqlite3.Connection) -> None:
    """Create the analytics store a fresh container has not written yet.

    Instagram only builds this database on its first launch, which is after
    the guard triggers would normally be installed.  Pre-creating it lets the
    triggers exist before the very first event is queued, so a brand-new
    container never records the real device identity.
    """
    existing = _tables(connection) - {"sqlite_sequence"}
    if existing:
        raise ValueError(f"refusing to replace an existing analytics schema: {sorted(existing)}")
    for statement in ANALYTICS_SCHEMA:
        connection.execute(statement)
    connection.execute(f"pragma user_version={ANALYTICS_USER_VERSION}")


def _make_mobile_owned(path: str) -> None:
    if os.geteuid() != 0 or not path.startswith("/var/mobile/"):
        return
    mobile = pwd.getpwnam("mobile")
    for candidate in (path, path + "-wal", path + "-shm", path + "-journal"):
        if not os.path.exists(candidate):
            continue
        os.chown(candidate, mobile.pw_uid, mobile.pw_gid)
        os.chmod(candidate, 0o600)


def install_fflogger_build_guard(
    connection: sqlite3.Connection,
    identity: TargetIdentity,
) -> int:
    """Force FFLogger's build column inside the same SQLite transaction.

    A database trigger avoids process-wide OS spoofing.  The latter breaks
    METAGetWKWebViewUserAgent on Instagram 438.  Recreating the named triggers
    on every force-apply also guarantees that a switched Crane profile cannot
    retain the previous container's target build.
    """
    tables = _tables(connection)
    if "batch" not in tables:
        raise ValueError("FFLogger database is missing the batch table")
    columns = set(_columns(connection, "batch"))
    if not {"id", "os_build_number"}.issubset(columns):
        raise ValueError("FFLogger batch schema is unsupported")

    changed = max(
        int(
            connection.execute(
                "update batch set os_build_number=? "
                "where os_build_number is not ?",
                (identity.build, identity.build),
            ).rowcount
            or 0
        ),
        0,
    )
    connection.execute(f"drop trigger if exists {_quoted(FFLOGGER_INSERT_TRIGGER)}")
    connection.execute(f"drop trigger if exists {_quoted(FFLOGGER_UPDATE_TRIGGER)}")
    target = _sql_literal(identity.build)
    connection.execute(
        f"create trigger {_quoted(FFLOGGER_INSERT_TRIGGER)} "
        "after insert on batch "
        f"when new.os_build_number is not {target} "
        "begin "
        f"update batch set os_build_number={target} where id=new.id; "
        "end"
    )
    connection.execute(
        f"create trigger {_quoted(FFLOGGER_UPDATE_TRIGGER)} "
        "after update of os_build_number on batch "
        f"when new.os_build_number is not {target} "
        "begin "
        f"update batch set os_build_number={target} where id=new.id; "
        "end"
    )
    return changed


def _logical_marker_hits(
    connection: sqlite3.Connection,
    markers: tuple[str, ...],
) -> list[dict[str, Any]]:
    hits: list[dict[str, Any]] = []
    for table in sorted(_tables(connection) - {"sqlite_sequence"}):
        for column in _columns(connection, table):
            found: list[str] = []
            for marker in markers:
                count = int(
                    connection.execute(
                        f"select count(*) from {_quoted(table)} "
                        f"where instr(cast({_quoted(column)} as blob), ?) > 0",
                        (marker.encode("utf-8"),),
                    ).fetchone()[0]
                )
                if count:
                    found.append(marker)
            if found:
                hits.append({"table": table, "column": column, "markers": found})
    return hits


def fflogger_guard_state(
    path: str,
    identity: TargetIdentity,
    replacements: tuple[tuple[str, str], ...],
) -> dict[str, Any]:
    if not os.path.isfile(path):
        return {"success": False, "present": False, "error": "fflogger_missing"}

    def inspect(connection: sqlite3.Connection, read_mode: str) -> dict[str, Any]:
        connection.execute("pragma busy_timeout=250")
        trigger_rows = connection.execute(
            "select name, sql from sqlite_master where type='trigger' and name in (?, ?)",
            (FFLOGGER_INSERT_TRIGGER, FFLOGGER_UPDATE_TRIGGER),
        ).fetchall()
        triggers = {str(name): str(sql or "") for name, sql in trigger_rows}
        target_in_triggers = all(
            name in triggers and identity.build in triggers[name]
            for name in (FFLOGGER_INSERT_TRIGGER, FFLOGGER_UPDATE_TRIGGER)
        )
        non_target_rows = int(
            connection.execute(
                "select count(*) from batch where os_build_number is not ?",
                (identity.build,),
            ).fetchone()[0]
        )
        marker_hits = _logical_marker_hits(
            connection,
            tuple(old for old, _new in replacements),
        )
        return {
            "success": target_in_triggers and non_target_rows == 0 and not marker_hits,
            "present": True,
            "read_mode": read_mode,
            "target_build": identity.build,
            "triggers": sorted(triggers),
            "target_in_triggers": target_in_triggers,
            "non_target_rows": non_target_rows,
            "logical_marker_hits": marker_hits,
        }

    connection: sqlite3.Connection | None = None
    try:
        connection = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=0.25)
        return inspect(connection, "live_read_only")
    except sqlite3.OperationalError as exc:
        if connection is not None:
            connection.close()
            connection = None
        if "locked" not in str(exc).lower():
            return {
                "success": False,
                "present": True,
                "error": f"{type(exc).__name__}: {exc}",
            }
        try:
            # FFLogger uses exclusive locking while Instagram is alive.  The
            # immutable view verifies the checkpointed schema/main database;
            # scan_scope independently audits every byte of the live WAL.
            connection = sqlite3.connect(
                f"file:{path}?mode=ro&immutable=1", uri=True, timeout=10
            )
            state = inspect(connection, "immutable_fallback")
            state["live_lock"] = f"{type(exc).__name__}: {exc}"
            return state
        except sqlite3.Error as fallback_exc:
            return {
                "success": False,
                "present": True,
                "error": f"{type(fallback_exc).__name__}: {fallback_exc}",
                "live_lock": f"{type(exc).__name__}: {exc}",
            }
    except sqlite3.Error as exc:
        return {
            "success": False,
            "present": True,
            "error": f"{type(exc).__name__}: {exc}",
        }
    finally:
        if connection is not None:
            connection.close()


def analytics_queue_state(
    path: str,
    identity: TargetIdentity,
    replacements: tuple[tuple[str, str], ...],
) -> dict[str, Any]:
    """Verify query-visible analytics queues, excluding only stale free pages."""
    if not os.path.isfile(path):
        return {"success": True, "present": False, "logical_marker_hits": []}
    connection: sqlite3.Connection | None = None
    try:
        connection = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=0.5)
        connection.execute("pragma busy_timeout=500")
        tables = _tables(connection)
        required = {"analytics_events", "analytics_uploads"}
        if not required.issubset(tables):
            return {
                "success": False,
                "present": True,
                "error": "analytics_schema_unsupported",
                "tables": sorted(tables),
            }
        hits = _logical_marker_hits(
            connection,
            tuple(old for old, _new in replacements),
        )
        event_columns = set(_columns(connection, "analytics_events"))
        guard_required = {"id", "device_identity"}.issubset(event_columns)
        trigger_rows = connection.execute(
            "select name, sql from sqlite_master where type='trigger' "
            "and name in (?, ?, ?, ?)",
            (
                ANALYTICS_INSERT_TRIGGER,
                ANALYTICS_UPDATE_TRIGGER,
                ANALYTICS_PAYLOAD_TRIGGER,
                ANALYTICS_UPLOAD_TRIGGER,
            ),
        ).fetchall()
        triggers = {str(name): str(sql or "") for name, sql in trigger_rows}
        target_in_triggers = (
            not guard_required
            or all(
                name in triggers and identity.build in triggers[name]
                for name in (
                    ANALYTICS_INSERT_TRIGGER,
                    ANALYTICS_UPDATE_TRIGGER,
                )
            )
        )
        payload_guarded = analytics_payload_guard_installed(
            connection, replacements, triggers
        )
        rows = {
            table: int(
                connection.execute(
                    f"select count(*) from {_quoted(table)}"
                ).fetchone()[0]
            )
            for table in sorted(required)
        }
        return {
            "success": not hits and target_in_triggers and payload_guarded,
            "present": True,
            "read_mode": "live_read_only",
            "rows": rows,
            "logical_marker_hits": hits,
            "device_identity_guard_required": guard_required,
            "device_identity_guarded": target_in_triggers,
            "payload_guarded": payload_guarded,
            "target_build": identity.build,
            "triggers": sorted(triggers),
        }
    except sqlite3.Error as exc:
        return {
            "success": False,
            "present": True,
            "error": f"{type(exc).__name__}: {exc}",
        }
    finally:
        if connection is not None:
            connection.close()


def _delete_marker_rows(
    connection: sqlite3.Connection,
    table: str,
    markers: tuple[str, ...],
) -> int:
    columns = _columns(connection, table)
    if not columns:
        return 0
    predicates: list[str] = []
    parameters: list[str] = []
    for column in columns:
        for marker in markers:
            predicates.append(f"cast({_quoted(column)} as text) like ?")
            parameters.append(f"%{marker}%")
    if not predicates:
        return 0
    cursor = connection.execute(
        f"delete from {_quoted(table)} where " + " or ".join(predicates),
        parameters,
    )
    return max(int(cursor.rowcount or 0), 0)


def _scannable_columns(
    connection: sqlite3.Connection,
    table: str,
    *,
    exclude: Iterable[str] = (),
) -> list[str]:
    """Columns a marker can hide in: text, blob, and untyped ones."""
    skipped = set(exclude)
    columns: list[str] = []
    for row in connection.execute(f"pragma table_info({_quoted(table)})"):
        name = str(row[1])
        declared = str(row[2] or "").lower()
        if name in skipped:
            continue
        if declared and not any(
            token in declared for token in ("char", "clob", "text", "blob")
        ):
            continue
        columns.append(name)
    return columns


def _marker_hit_expression(
    columns: Iterable[str],
    markers: tuple[str, ...],
    prefix: str,
) -> str:
    # Match the detector byte for byte: analytics_queue_state finds a marker with
    # instr(cast(column as blob), <utf-8 bytes>), so the guard has to test the
    # same thing. A blob literal keeps binary payloads out of text conversion.
    parts: list[str] = []
    for column in columns:
        reference = f"{prefix}{_quoted(column)}"
        for marker in markers:
            encoded = marker.encode("utf-8").hex()
            parts.append(f"instr(cast({reference} as blob), x'{encoded}') > 0")
    return " or ".join(parts)


def _analytics_purge_trigger_sql(
    name: str,
    table: str,
    columns: Iterable[str],
    markers: tuple[str, ...],
) -> str:
    condition = _marker_hit_expression(columns, markers, "new.")
    return (
        f"create trigger {_quoted(name)} after insert on {_quoted(table)} "
        f"when {condition} "
        f"begin delete from {_quoted(table)} where id=new.id; end"
    )


def _analytics_purge_targets(
    connection: sqlite3.Connection,
) -> list[tuple[str, str, list[str]]]:
    tables = _tables(connection)
    targets: list[tuple[str, str, list[str]]] = []
    for name, table, exclude in (
        # device_identity is normalized by the identity guard instead of being
        # dropped, so exclude it here or every guarded write would be deleted.
        (ANALYTICS_PAYLOAD_TRIGGER, "analytics_events", ("id", "device_identity")),
        (ANALYTICS_UPLOAD_TRIGGER, "analytics_uploads", ("id",)),
    ):
        if table not in tables:
            continue
        columns = _columns(connection, table)
        if "id" not in columns:
            continue
        scannable = _scannable_columns(connection, table, exclude=exclude)
        if scannable:
            targets.append((name, table, scannable))
    return targets


def install_analytics_payload_guard(
    connection: sqlite3.Connection,
    replacements: tuple[tuple[str, str], ...],
) -> int:
    """Drop queued rows that smuggle the real identity outside device_identity.

    The identity guard only rewrites the device_identity column. Threads was
    observed queueing an event whose event_payload blob carried the real model
    and marketing name, which that guard cannot reach: the column is a blob and
    may be compressed, so rewriting bytes inside it is not safe. These telemetry
    queues are local and retryable, so the same policy the offline pass already
    uses for polluted rows applies here — delete the row as it is written.
    """

    markers = tuple(old for old, _new in replacements)
    if not markers:
        return 0
    changed = 0
    for name, table, columns in _analytics_purge_targets(connection):
        connection.execute(f"drop trigger if exists {_quoted(name)}")
        connection.execute(_analytics_purge_trigger_sql(name, table, columns, markers))
        changed += 1
    return changed


def _normalized_sql(sql: str) -> str:
    # sqlite_master keeps the statement as written except for the leading
    # keywords, which it stores uppercased, so compare case- and space-folded.
    return " ".join(str(sql or "").split()).lower()


def analytics_payload_guard_installed(
    connection: sqlite3.Connection,
    replacements: tuple[tuple[str, str], ...],
    triggers: dict[str, str],
) -> bool:
    """True when the stored triggers cover exactly the markers being scanned."""

    markers = tuple(old for old, _new in replacements)
    if not markers:
        return True
    for name, table, columns in _analytics_purge_targets(connection):
        expected = _analytics_purge_trigger_sql(name, table, columns, markers)
        if _normalized_sql(triggers.get(name, "")) != _normalized_sql(expected):
            return False
    return True


def install_analytics_identity_guard(
    connection: sqlite3.Connection,
    identity: TargetIdentity,
    replacements: tuple[tuple[str, str], ...],
) -> int:
    """Rewrite the queued device build in the same transaction as each write."""

    tables = _tables(connection)
    if "analytics_events" not in tables:
        return 0
    columns = set(_columns(connection, "analytics_events"))
    if not {"id", "device_identity"}.issubset(columns):
        return 0

    def expression(source: str) -> str:
        value = source
        for old, new in replacements:
            value = (
                f"replace({value}, {_sql_literal(old)}, "
                f"{_sql_literal(new)})"
            )
        return value

    existing_expression = expression("device_identity")
    changed = max(
        int(
            connection.execute(
                "update analytics_events set device_identity="
                f"{existing_expression} "
                f"where device_identity is not {existing_expression}"
            ).rowcount
            or 0
        ),
        0,
    )
    connection.execute(
        f"drop trigger if exists {_quoted(ANALYTICS_INSERT_TRIGGER)}"
    )
    connection.execute(
        f"drop trigger if exists {_quoted(ANALYTICS_UPDATE_TRIGGER)}"
    )
    inserted_expression = expression("new.device_identity")
    connection.execute(
        f"create trigger {_quoted(ANALYTICS_INSERT_TRIGGER)} "
        "after insert on analytics_events "
        f"when new.device_identity is not {inserted_expression} "
        "begin "
        "update analytics_events "
        f"set device_identity={inserted_expression} where id=new.id; "
        "end"
    )
    connection.execute(
        f"create trigger {_quoted(ANALYTICS_UPDATE_TRIGGER)} "
        "after update of device_identity on analytics_events "
        f"when new.device_identity is not {inserted_expression} "
        "begin "
        "update analytics_events "
        f"set device_identity={inserted_expression} where id=new.id; "
        "end"
    )
    return changed


def sanitize_sqlite(
    path: str,
    identity: TargetIdentity,
    replacements: tuple[tuple[str, str], ...],
    kind: str,
) -> int:
    seedable = kind in ("fflogger", "analytics")
    created = seedable and not os.path.isfile(path)
    if not os.path.isfile(path) and not seedable:
        return 0
    if created:
        os.makedirs(os.path.dirname(path), exist_ok=True)
    changed = 0
    connection = sqlite3.connect(path, timeout=10)
    try:
        connection.execute("pragma busy_timeout=10000")
        tables = _tables(connection)
        markers = tuple(old for old, _new in replacements)
        if kind == "fflogger":
            if "batch" not in tables:
                initialize_fflogger_schema(connection)
                changed += 1
            changed += install_fflogger_build_guard(connection, identity)
        elif kind == "analytics":
            if "analytics_events" not in tables:
                initialize_analytics_schema(connection)
                # Instagram opens this store in WAL mode; matching it here keeps
                # the file it finds on first launch identical to one it wrote.
                connection.execute("pragma journal_mode=wal")
                tables = _tables(connection)
                changed += 1
            # These tables are local, retryable upload queues.  Deleting only
            # rows containing a forbidden identity is safer than byte-editing
            # arbitrary encoded payloads.
            for table in ("analytics_events", "analytics_uploads"):
                if table in tables:
                    changed += _delete_marker_rows(connection, table, markers)
            changed += install_analytics_identity_guard(
                connection, identity, replacements
            )
            changed += install_analytics_payload_guard(connection, replacements)
        elif kind == "crypto" and "secure_message_peer_devices_v2" in tables:
            for old, _new in replacements:
                cursor = connection.execute(
                    "update secure_message_peer_devices_v2 set model=? where model=?",
                    (identity.model, old),
                )
                changed += max(int(cursor.rowcount or 0), 0)
        connection.commit()
        try:
            connection.execute("pragma wal_checkpoint(truncate)")
        except sqlite3.DatabaseError:
            pass
        if changed or kind == "analytics":
            try:
                connection.execute("vacuum")
            except sqlite3.DatabaseError:
                pass
    finally:
        connection.close()
        if created:
            _make_mobile_owned(path)
    return changed


def _instagram_group_roots() -> list[str]:
    parent = "/var/mobile/Containers/Shared/AppGroup"
    roots: list[str] = []
    if not os.path.isdir(parent):
        return roots
    for name in os.listdir(parent):
        root = os.path.join(parent, name)
        metadata = os.path.join(root, ".com.apple.mobile_container_manager.metadata.plist")
        try:
            value = _plist(metadata)
        except Exception:
            continue
        if str(value.get("MCMMetadataIdentifier") or "") == INSTAGRAM_GROUP:
            roots.append(root)
    return roots


def scope_files(active_root: str, active_id: str) -> list[tuple[str, str]]:
    files: list[tuple[str, str]] = [
        (os.path.join(active_root, "Library/Preferences/com.burbn.instagram.plist"), "plist"),
        (os.path.join(active_root, "Documents/FFLogger.sql"), "fflogger"),
        (
            os.path.join(
                active_root,
                "Library/Application Support/com.burbn.instagram/analytics/"
                "unified_micro_batch/FBAnalyticsUnifiedEventStore.sqlite",
            ),
            "analytics",
        ),
    ]
    for group_root in _instagram_group_roots():
        crane_root = os.path.join(group_root, "Library/___Crane_Containers", active_id)
        if not os.path.isdir(crane_root):
            continue
        for directory, _dirs, names in os.walk(crane_root):
            for name in names:
                if name.startswith("crypto_db_") and name.endswith(".db"):
                    files.append((os.path.join(directory, name), "crypto"))
    return files


def _backup_file(path: str, backup_dir: str) -> list[str]:
    copied: list[str] = []
    for candidate in (path, path + "-wal", path + "-shm", path + "-journal"):
        if not os.path.isfile(candidate):
            continue
        digest = hashlib.sha256(candidate.encode("utf-8", "surrogateescape")).hexdigest()[:16]
        destination = os.path.join(backup_dir, f"{digest}_{os.path.basename(candidate)}")
        shutil.copy2(candidate, destination)
        copied.append(destination)
    return copied


def scan_scope(
    active_root: str,
    active_id: str,
    replacements: tuple[tuple[str, str], ...],
) -> list[dict[str, Any]]:
    markers = tuple(old.encode("utf-8") for old, _new in replacements)
    result: list[dict[str, Any]] = []
    for path, kind in scope_files(active_root, active_id):
        for candidate in (path, path + "-wal", path + "-shm", path + "-journal"):
            if not os.path.isfile(candidate):
                continue
            try:
                with open(candidate, "rb") as handle:
                    raw = handle.read()
            except OSError:
                continue
            found = [marker.decode("utf-8") for marker in markers if marker in raw]
            if found:
                result.append(
                    {
                        "path": candidate,
                        "kind": kind,
                        "markers": found,
                        "size": len(raw),
                    }
                )
    return result


def effective_scan_scope(
    active_root: str,
    active_id: str,
    identity: TargetIdentity,
    replacements: tuple[tuple[str, str], ...],
) -> dict[str, Any]:
    """Combine raw-file coverage with the live logical FFLogger state.

    An AFTER trigger can leave an obsolete string in an older WAL page even
    though that value was replaced atomically before the transaction committed.
    Such bytes are not query-visible and cannot be selected by FFLogger's
    uploader.  They are exempted only for old build markers and only when both
    triggers, every logical table, and every current batch row verify clean.
    """
    raw_hits = scan_scope(active_root, active_id, replacements)
    ff_path = next(
        (path for path, kind in scope_files(active_root, active_id) if kind == "fflogger"),
        os.path.join(active_root, "Documents/FFLogger.sql"),
    )
    ff_guard = fflogger_guard_state(ff_path, identity, replacements)
    analytics_path = next(
        (path for path, kind in scope_files(active_root, active_id) if kind == "analytics"),
        os.path.join(
            active_root,
            "Library/Application Support/com.burbn.instagram/analytics/"
            "unified_micro_batch/FBAnalyticsUnifiedEventStore.sqlite",
        ),
    )
    analytics_state = analytics_queue_state(
        analytics_path, identity, replacements
    )
    old_builds = {
        old for old, new in replacements if new == identity.build and old != identity.build
    }
    effective_hits: list[dict[str, Any]] = []
    for hit in raw_hits:
        markers = list(hit["markers"])
        if hit["kind"] == "fflogger" and ff_guard.get("success"):
            markers = [marker for marker in markers if marker not in old_builds]
        elif hit["kind"] == "analytics" and analytics_state.get("success"):
            # VACUUM normally removes these bytes. If SQLite retains a stale
            # free page, only a successful live logical scan may exempt it.
            markers = []
        if markers:
            retained = dict(hit)
            retained["markers"] = markers
            effective_hits.append(retained)
    if not ff_guard.get("success"):
        effective_hits.append(
            {
                "path": ff_path,
                "kind": "fflogger_guard",
                "markers": [],
                "error": ff_guard.get("error") or "fflogger_guard_invalid",
            }
        )
    if not analytics_state.get("success"):
        effective_hits.append(
            {
                "path": analytics_path,
                "kind": "analytics_queue",
                "markers": [],
                "error": analytics_state.get("error") or "analytics_queue_invalid",
            }
        )
    return {
        "success": not effective_hits,
        "raw_hits": raw_hits,
        "effective_hits": effective_hits,
        "fflogger_guard": ff_guard,
        "analytics_queue": analytics_state,
    }


def sanitize_active_scope(
    active_root: str,
    active_id: str,
    profile_raw: bytes,
    *,
    backup_root: str = "/var/mobile/igghostguard_sanitize_backups",
) -> dict[str, Any]:
    identity = identity_from_profile(profile_raw)
    replacements = build_replacements(identity)
    started = time.time()
    backup_dir = os.path.join(
        backup_root,
        active_id,
        time.strftime("%Y%m%d_%H%M%S", time.localtime(started)),
    )
    os.makedirs(backup_dir, exist_ok=True)

    before = scan_scope(active_root, active_id, replacements)
    changes: list[dict[str, Any]] = []
    backups: list[str] = []
    for path, kind in scope_files(active_root, active_id):
        if not os.path.isfile(path) and kind not in ("fflogger", "analytics"):
            continue
        if os.path.isfile(path):
            backups.extend(_backup_file(path, backup_dir))
        if kind == "plist":
            count = sanitize_preferences(path, replacements)
        else:
            count = sanitize_sqlite(path, identity, replacements, kind)
        changes.append({"path": path, "kind": kind, "changes": count})

    after = scan_scope(active_root, active_id, replacements)
    effective_after = effective_scan_scope(
        active_root,
        active_id,
        identity,
        replacements,
    )
    return {
        "success": effective_after["success"],
        "active_id": active_id,
        "active_root": active_root,
        "identity": dataclasses.asdict(identity),
        "before": before,
        "after": after,
        "effective_after": effective_after,
        "changes": changes,
        "backup_dir": backup_dir,
        "backup_count": len(backups),
        "elapsed_seconds": round(time.time() - started, 3),
    }


def _threads_analytics_path(active_root: str) -> str:
    return os.path.join(
        active_root,
        "Library/Application Support/com.burbn.barcelona/analytics/"
        "unified_micro_batch/FBAnalyticsUnifiedEventStore.sqlite",
    )


def _threads_cache_root(active_root: str) -> str:
    return os.path.join(
        active_root,
        "Library/Caches/com.burbn.barcelona.application_status",
    )


def _marker_hits_in_file(
    path: str,
    replacements: tuple[tuple[str, str], ...],
) -> list[str]:
    try:
        with open(path, "rb") as handle:
            raw = handle.read()
    except OSError:
        return []
    return [
        old
        for old, _new in replacements
        if old.encode("utf-8") in raw
    ]


def scan_threads_scope(
    active_root: str,
    replacements: tuple[tuple[str, str], ...],
) -> list[dict[str, Any]]:
    candidates: list[tuple[str, str]] = [
        (
            os.path.join(
                active_root,
                "Library/Preferences/com.burbn.barcelona.plist",
            ),
            "plist",
        ),
        (_threads_analytics_path(active_root), "analytics"),
    ]
    cache_root = _threads_cache_root(active_root)
    if os.path.isdir(cache_root):
        for directory, _dirs, names in os.walk(cache_root):
            for name in names:
                candidates.append(
                    (os.path.join(directory, name), "application_status_cache")
                )
    result: list[dict[str, Any]] = []
    for path, kind in candidates:
        sidecars = (
            (path, path + "-wal", path + "-shm", path + "-journal")
            if kind == "analytics"
            else (path,)
        )
        for candidate in sidecars:
            if not os.path.isfile(candidate):
                continue
            markers = _marker_hits_in_file(candidate, replacements)
            if markers:
                result.append(
                    {
                        "path": candidate,
                        "kind": kind,
                        "markers": markers,
                        "size": os.path.getsize(candidate),
                    }
                )
    return result


def effective_threads_scan(
    active_root: str,
    identity: TargetIdentity,
    replacements: tuple[tuple[str, str], ...],
) -> dict[str, Any]:
    raw_hits = scan_threads_scope(active_root, replacements)
    analytics_path = _threads_analytics_path(active_root)
    analytics_state = analytics_queue_state(
        analytics_path, identity, replacements
    )
    effective_hits: list[dict[str, Any]] = []
    for hit in raw_hits:
        if hit["kind"] == "analytics" and analytics_state.get("success"):
            continue
        effective_hits.append(hit)
    if not analytics_state.get("success"):
        effective_hits.append(
            {
                "path": analytics_path,
                "kind": "analytics_queue",
                "markers": [],
                "error": (
                    analytics_state.get("error")
                    or "analytics_queue_invalid"
                ),
            }
        )
    return {
        "success": not effective_hits,
        "raw_hits": raw_hits,
        "effective_hits": effective_hits,
        "analytics_queue": analytics_state,
    }


def sanitize_threads_scope(
    active_root: str,
    active_id: str,
    profile_raw: bytes,
    *,
    backup_root: str = "/var/mobile/igghostguard_sanitize_backups",
) -> dict[str, Any]:
    identity = identity_from_profile(profile_raw)
    replacements = build_replacements(identity)
    started = time.time()
    backup_dir = os.path.join(
        backup_root,
        active_id,
        time.strftime("%Y%m%d_%H%M%S", time.localtime(started)),
    )
    os.makedirs(backup_dir, exist_ok=True)
    before = scan_threads_scope(active_root, replacements)
    backups: list[str] = []
    changes: list[dict[str, Any]] = []

    preferences = os.path.join(
        active_root, "Library/Preferences/com.burbn.barcelona.plist"
    )
    if os.path.isfile(preferences):
        backups.extend(_backup_file(preferences, backup_dir))
        changes.append(
            {
                "path": preferences,
                "kind": "plist",
                "changes": sanitize_preferences(
                    preferences, replacements
                ),
            }
        )

    analytics = _threads_analytics_path(active_root)
    if os.path.isfile(analytics):
        backups.extend(_backup_file(analytics, backup_dir))
    # A fresh container has no store yet; seeding it here installs the guard
    # before Threads queues its first event.
    changes.append(
        {
            "path": analytics,
            "kind": "analytics",
            "changes": sanitize_sqlite(
                analytics, identity, replacements, "analytics"
            ),
        }
    )

    removed_cache_files = 0
    cache_root = _threads_cache_root(active_root)
    if os.path.isdir(cache_root):
        for directory, _dirs, names in os.walk(cache_root):
            for name in names:
                path = os.path.join(directory, name)
                if not _marker_hits_in_file(path, replacements):
                    continue
                backups.extend(_backup_file(path, backup_dir))
                os.remove(path)
                removed_cache_files += 1
    changes.append(
        {
            "path": cache_root,
            "kind": "application_status_cache",
            "changes": removed_cache_files,
        }
    )

    after = scan_threads_scope(active_root, replacements)
    effective_after = effective_threads_scan(
        active_root, identity, replacements
    )
    return {
        "success": effective_after["success"],
        "active_id": active_id,
        "active_root": active_root,
        "identity": dataclasses.asdict(identity),
        "before": before,
        "after": after,
        "effective_after": effective_after,
        "changes": changes,
        "backup_dir": backup_dir,
        "backup_count": len(backups),
        "elapsed_seconds": round(time.time() - started, 3),
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--active-root", required=True)
    parser.add_argument("--active-id", required=True)
    parser.add_argument("--profile", required=True)
    parser.add_argument(
        "--backup-root", default="/var/mobile/igghostguard_sanitize_backups"
    )
    parser.add_argument(
        "--scan-only",
        action="store_true",
        help="read-only marker scan; safe while Instagram owns the databases",
    )
    parser.add_argument("--report")
    args = parser.parse_args(argv)

    with open(args.profile, "rb") as handle:
        profile_raw = handle.read()
    if args.scan_only:
        identity = identity_from_profile(profile_raw)
        replacements = build_replacements(identity)
        scan = effective_scan_scope(
            args.active_root,
            args.active_id.upper(),
            identity,
            replacements,
        )
        report = {
            "success": scan["success"],
            "scan_only": True,
            "active_id": args.active_id.upper(),
            "active_root": args.active_root,
            "identity": dataclasses.asdict(identity),
            **scan,
        }
    else:
        report = sanitize_active_scope(
            args.active_root,
            args.active_id.upper(),
            profile_raw,
            backup_root=args.backup_root,
        )
    encoded = json.dumps(report, ensure_ascii=False, sort_keys=True)
    if args.report:
        Path(args.report).parent.mkdir(parents=True, exist_ok=True)
        Path(args.report).write_text(encoded + "\n", encoding="utf-8")
    print(encoded)
    return 0 if report["success"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
