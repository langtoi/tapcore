"""One-way active-container workflow for Instagram and Threads.

``ghost_instagram`` keeps its existing command name and asynchronous surface,
but the worker now completes two guarded phases: Instagram first, then Threads
from the freshly verified Instagram snapshot.  A PASS therefore means both
apps used one profile hash and each app passed its own runtime accounting.
"""
from __future__ import annotations

import argparse
import contextlib
import json
import os
import tempfile
import time
from typing import Any, Optional

import ig_ghost_workflow
import threads_ghost_workflow


WORKFLOW_VERSION = "1.7"
LATEST_REPORT = "/var/mobile/Library/Logs/ig-ghost/ghost_instagram_latest.json"


def _write_json_atomic(path: str, payload: dict[str, Any]) -> None:
    parent = os.path.dirname(path) or "."
    os.makedirs(parent, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".ghost-meta-", dir=parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, 0o644)
        os.replace(temporary, path)
    except Exception:
        with contextlib.suppress(OSError):
            os.unlink(temporary)
        raise


def run_force_meta(
    *,
    instagram_paths: ig_ghost_workflow.WorkflowPaths = ig_ghost_workflow.DEFAULT_PATHS,
    instagram_runner: Optional[ig_ghost_workflow.CommandRunner] = None,
    threads_paths: threads_ghost_workflow.WorkflowPaths = threads_ghost_workflow.DEFAULT_PATHS,
    threads_runner: Optional[threads_ghost_workflow.CommandRunner] = None,
    latest_report: str = LATEST_REPORT,
    verification_mode: str = "account_creation",
) -> dict[str, Any]:
    started_at = time.time()
    result: dict[str, Any] = {
        "success": False,
        "verdict": "FAIL",
        "action": "ghost_instagram",
        "mode": "instagram_threads_one_way_sync",
        "workflow_version": WORKFLOW_VERSION,
        "force_active": True,
        "identity_source": "active_instagram",
        "verification_mode": verification_mode,
        "started_at": started_at,
    }
    try:
        instagram = ig_ghost_workflow.run_force_active(
            paths=instagram_paths,
            runner=instagram_runner,
            verification_mode=verification_mode,
        )
        result["apps"] = {"instagram": instagram}
        if instagram.get("success") is not True:
            result.update(
                {
                    "stage": "instagram",
                    "error": instagram.get("error") or "instagram_failed",
                    "message": "Instagram guarded phase did not pass; Threads was not changed",
                }
            )
            return result

        active_instagram = instagram.get("active_container") or {}
        threads = threads_ghost_workflow.run_force_threads(
            paths=threads_paths,
            runner=threads_runner,
            expected_instagram_id=str(active_instagram.get("id") or ""),
            verification_mode=verification_mode,
        )
        result["apps"]["threads"] = threads
        if threads.get("success") is not True:
            result.update(
                {
                    "stage": "threads",
                    "error": threads.get("error") or "threads_failed",
                    "message": "Instagram passed, but Threads synchronization did not pass",
                }
            )
            return result

        instagram_hash = str((instagram.get("identity") or {}).get("profile_sha256") or "")
        threads_hash = str((threads.get("identity") or {}).get("profile_sha256") or "")
        instagram_snapshot = instagram.get("snapshot") or {}
        threads_snapshot = threads.get("snapshot") or {}
        identity_keys = (
            "snapshot_id",
            "model",
            "hardware",
            "display_name",
            "ios",
            "build",
            "resolution",
        )
        mismatches = {
            key: {
                "instagram": instagram_snapshot.get(key),
                "threads": threads_snapshot.get(key),
            }
            for key in identity_keys
            if instagram_snapshot.get(key) != threads_snapshot.get(key)
        }
        if not instagram_hash or instagram_hash != threads_hash or mismatches:
            result.update(
                {
                    "stage": "cross_app_validation",
                    "error": "cross_app_identity_mismatch",
                    "message": "Instagram and Threads reports do not describe one identity",
                    "problems": {
                        "instagram_profile_sha256": instagram_hash,
                        "threads_profile_sha256": threads_hash,
                        "snapshot_mismatches": mismatches,
                    },
                }
            )
            return result

        result.update(
            {
                "success": True,
                "verdict": "PASS",
                "stage": "complete",
                "identity": {
                    **{
                        key: instagram_snapshot.get(key)
                        for key in identity_keys
                    },
                    "profile_sha256": instagram_hash,
                },
                "active_containers": {
                    "instagram": instagram.get("active_container"),
                    "threads": threads.get("active_container"),
                },
                "runtime": {
                    "instagram": instagram.get("runtime"),
                    "threads": threads.get("runtime"),
                },
                "cross_app_identity_equal": True,
                "legacy_bidirectional_sync_disabled": bool(
                    (threads.get("legacy_sync") or {}).get("disabled") is True
                ),
                "coverage": (
                    "Both app PIDs passed the account-creation request-entry "
                    "contract with one active Instagram profile hash. Every "
                    "request which actually occurred was accounted for; the setup "
                    "command does not manufacture or require 100 requests. "
                    "Existing Meta server sessions created before this run are not "
                    "renamed automatically."
                ),
            }
        )
        return result
    except Exception as exc:
        result.update(
            {
                "stage": "unexpected",
                "error": type(exc).__name__,
                "message": str(exc),
            }
        )
        return result
    finally:
        result["finished_at"] = time.time()
        result["elapsed_seconds"] = round(result["finished_at"] - started_at, 3)
        result["report_path"] = latest_report
        with contextlib.suppress(Exception):
            _write_json_atomic(latest_report, result)


def parse_args(argv: Optional[list[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="ghost_instagram run",
        description="Force and verify active Instagram, then synchronize active Threads",
    )
    return parser.parse_args(argv)


def main(argv: Optional[list[str]] = None) -> int:
    parse_args(argv)
    result = run_force_meta()
    print(json.dumps(result, ensure_ascii=False, separators=(",", ":")))
    return 0 if result.get("success") else 1


if __name__ == "__main__":
    raise SystemExit(main())
