"""Force-apply Instagram Ghost Guard to the currently active Crane container.

This module never creates, deletes, or switches Crane containers.  On the first
invocation for a new active UUID it replaces any inherited Global Ghost copy
with a freshly randomized profile, then records a marker inside that Crane
container.  Later invocations for the same UUID keep that assigned identity.
Every invocation closes the old Instagram PID, force-mirrors the active plist,
removes the old guard snapshot/status, launches a fresh guarded PID, and
validates the full warm-up report.
"""
from __future__ import annotations

import argparse
import contextlib
import dataclasses
import fcntl
import hashlib
import json
import os
import plistlib
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, Iterable, Optional


BUNDLE_ID = "com.burbn.instagram"
GHOST_PLIST = "com.sgwc.ghostprefs.plist"
CRANE_RELATIVE_ROOT = "Library/___Crane_Containers"
SNAPSHOT_RELATIVE_PATH = "Library/Preferences/com.langtoi.igghostguard.snapshot.plist"
STATUS_RELATIVE_PATH = "Library/Caches/com.langtoi.igghostguard.status.plist"
SEED_MARKER_RELATIVE_PATH = (
    "Library/Preferences/com.langtoi.igghostguard.container-seed.plist"
)
INSTAGRAM_PREFS_RELATIVE_PATH = "Library/Preferences/com.burbn.instagram.plist"
WORKFLOW_VERSION = "1.8"
WARMUP_SECONDS = 45
MIN_REQUESTS = 100
FRESH_CONTAINER_MIN_REQUESTS = 1
FILESYSTEM_TIMESTAMP_TOLERANCE = 5.0
ACTIVE_PROFILE_WAIT_SECONDS = 3.0
ACTIVE_PROFILE_POLL_SECONDS = 0.1


@dataclasses.dataclass(frozen=True)
class WorkflowPaths:
    data_root: str = "/var/mobile/Containers/Data/Application"
    crane_prefs_candidates: tuple[str, ...] = (
        "/var/jb/var/mobile/Library/Preferences/com.opa334.craneprefs.plist",
        "/var/mobile/Library/Preferences/com.opa334.craneprefs.plist",
    )
    global_profile: str = (
        "/var/mobile/Library/Preferences/Ghost/com.sgwc.ghostprefs.plist"
    )
    lock_path: str = "/var/mobile/Library/Caches/com.langtoi.ghost-instagram.lock"
    latest_report: str = (
        "/var/mobile/Library/Logs/ig-ghost/ghost_instagram_latest.json"
    )
    sanitize_backup_root: str = "/var/mobile/igghostguard_sanitize_backups"
    ig_ghost: str = "/var/jb/usr/bin/ig-ghost"
    crane_cli: str = "/var/jb/usr/bin/crane-cli"
    killall: str = "/var/jb/usr/bin/killall"
    ps: str = "/bin/ps"
    sudo: str = "/var/jb/usr/bin/sudo"
    launchctl: str = "/var/jb/usr/bin/launchctl"
    sync_plist: str = (
        "/var/jb/Library/LaunchDaemons/com.langtoi.ghost-global-sync.plist"
    )
    sync_status: str = (
        "/var/mobile/Library/Preferences/Ghost/ghost-global-sync-status.json"
    )
    sync_start: str = "/var/jb/usr/bin/ghost-global-sync-start"
    prepare_target: str = "/var/mobile/prepare_ig_target.py"
    active_profile_wait_seconds: float = ACTIVE_PROFILE_WAIT_SECONDS
    active_profile_poll_seconds: float = ACTIVE_PROFILE_POLL_SECONDS


DEFAULT_PATHS = WorkflowPaths()


@dataclasses.dataclass(frozen=True)
class ActiveContainer:
    identifier: str
    name: str
    app_root: str
    root: str
    source_path: str
    parent_profile_path: str


@dataclasses.dataclass(frozen=True)
class SyncServiceState:
    loaded: bool
    pids: tuple[int, ...]


class WorkflowError(RuntimeError):
    def __init__(
        self,
        code: str,
        message: str,
        *,
        stage: str,
        details: Optional[dict[str, Any]] = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.stage = stage
        self.details = details or {}


class CommandRunner:
    """Small injectable subprocess facade used by the live workflow and tests."""

    def run(
        self,
        argv: Iterable[str],
        *,
        timeout: int = 30,
        input_text: Optional[str] = None,
    ) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            list(argv),
            input=input_text,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )


def _read_plist(path: str) -> dict[str, Any]:
    with open(path, "rb") as handle:
        value = plistlib.load(handle)
    if not isinstance(value, dict):
        raise ValueError("plist root is not a dictionary")
    return value


def _read_bytes(path: str) -> bytes:
    with open(path, "rb") as handle:
        return handle.read()


def _sha256(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _active_session_context(active: ActiveContainer) -> dict[str, Any]:
    """Classify whether full authenticated traffic can exist before launch.

    A newly created Crane container starts at Instagram's Join screen and has
    no last-logged-in account marker. Requiring MQTT plus 100 requests in that
    state is impossible; the guard can still prove that every request which
    does occur was audited and that all four source getter hooks were installed.

    An unreadable preferences file is treated conservatively as authenticated
    (full coverage required) rather than weakening verification on ambiguity.
    """
    preferences_path = os.path.join(active.root, INSTAGRAM_PREFS_RELATIVE_PATH)
    if not os.path.isfile(preferences_path):
        return {
            "state": "fresh_logged_out",
            "account_marker_present": False,
            "fresh_container_bootstrap": True,
            "preferences_path": preferences_path,
        }
    try:
        preferences = _read_plist(preferences_path)
    except Exception as exc:
        return {
            "state": "unknown_require_full",
            "account_marker_present": None,
            "fresh_container_bootstrap": False,
            "preferences_path": preferences_path,
            "read_error": type(exc).__name__,
        }
    account = preferences.get("last-logged-in-account-dict")
    account_marker_present = isinstance(account, dict) and bool(account)
    return {
        "state": (
            "account_marker_present"
            if account_marker_present
            else "fresh_logged_out"
        ),
        "account_marker_present": account_marker_present,
        "fresh_container_bootstrap": not account_marker_present,
        "preferences_path": preferences_path,
    }


def _file_sha256(path: str) -> str:
    return _sha256(_read_bytes(path))


def _atomic_write(path: str, raw: bytes, mode: int) -> None:
    parent = os.path.dirname(path) or "."
    os.makedirs(parent, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".ghost-instagram-", dir=parent)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, mode)
        os.replace(temporary, path)
    except Exception:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise


def _write_json_atomic(path: str, payload: dict[str, Any]) -> None:
    raw = (
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    ).encode("utf-8")
    _atomic_write(path, raw, 0o644)


def _find_app_root(paths: WorkflowPaths) -> str:
    if not os.path.isdir(paths.data_root):
        raise WorkflowError(
            "instagram_container_missing",
            "Instagram application data root is missing",
            stage="resolve_active",
        )
    for entry in os.listdir(paths.data_root):
        root = os.path.join(paths.data_root, entry)
        metadata_path = os.path.join(
            root, ".com.apple.mobile_container_manager.metadata.plist"
        )
        if not os.path.isfile(metadata_path):
            continue
        try:
            metadata = _read_plist(metadata_path)
        except Exception:
            continue
        if metadata.get("MCMMetadataIdentifier") == BUNDLE_ID:
            return root
    raise WorkflowError(
        "instagram_container_missing",
        "Instagram application data container was not found",
        stage="resolve_active",
    )


def _read_crane_prefs(paths: WorkflowPaths) -> dict[str, Any]:
    errors: list[str] = []
    for candidate in paths.crane_prefs_candidates:
        if not os.path.isfile(candidate):
            continue
        try:
            return _read_plist(candidate)
        except Exception as exc:
            errors.append(f"{candidate}:{type(exc).__name__}")
    raise WorkflowError(
        "crane_preferences_missing",
        "Crane preferences are unavailable" + (f": {errors}" if errors else ""),
        stage="resolve_active",
    )


def _active_from_crane_cli(
    paths: WorkflowPaths, runner: CommandRunner
) -> str:
    completed = runner.run([paths.crane_cli, "list", BUNDLE_ID], timeout=20)
    if completed.returncode != 0:
        raise WorkflowError(
            "active_container_unverified",
            "crane-cli could not report the active Instagram container",
            stage="resolve_active",
            details={"stderr": completed.stderr.strip()[-300:]},
        )
    for line in completed.stdout.splitlines():
        match = re.match(r"^\s*\*\s*\[([^]]+)\]", line)
        if match:
            identifier = match.group(1).strip().upper()
            if identifier == "DEFAULT":
                break
            if re.fullmatch(r"[A-F0-9-]{36}", identifier):
                return identifier
            break
    raise WorkflowError(
        "active_container_missing",
        "A named Crane container is not active for Instagram",
        stage="resolve_active",
    )


def _active_crane_selection(
    paths: WorkflowPaths, runner: CommandRunner
) -> tuple[str, dict[str, Any]]:
    prefs = _read_crane_prefs(paths)
    settings = prefs.get("appSettings_" + BUNDLE_ID) or {}
    if not isinstance(settings, dict):
        settings = {}
    identifier = str(settings.get("activeContainer") or "").strip().upper()
    if identifier == "DEFAULT" or not re.fullmatch(r"[A-F0-9-]{36}", identifier):
        raise WorkflowError(
            "active_container_missing",
            "A named Crane container is not active for Instagram",
            stage="resolve_active",
        )
    cli_identifier = _active_from_crane_cli(paths, runner)
    if cli_identifier != identifier:
        raise WorkflowError(
            "active_container_changed",
            "Crane preferences and crane-cli disagree about the active container",
            stage="resolve_active",
            details={"preferences": identifier, "crane_cli": cli_identifier},
        )
    return identifier, settings


def resolve_active_container(
    paths: WorkflowPaths, runner: CommandRunner
) -> ActiveContainer:
    identifier, settings = _active_crane_selection(paths, runner)

    name = ""
    containers = settings.get("Containers")
    if isinstance(containers, list):
        for item in containers:
            if not isinstance(item, dict):
                continue
            if str(item.get("identifier") or "").strip().upper() == identifier:
                name = str(item.get("name") or "").strip()
                break
    if not name:
        name = identifier

    app_root = _find_app_root(paths)
    root = os.path.join(app_root, CRANE_RELATIVE_ROOT, identifier)
    source_path = os.path.join(root, "Documents", GHOST_PLIST)
    return ActiveContainer(
        identifier=identifier,
        name=name,
        app_root=app_root,
        root=root,
        source_path=source_path,
        parent_profile_path=os.path.join(app_root, "Documents", GHOST_PLIST),
    )


def _await_active_profile(
    active: ActiveContainer,
    paths: WorkflowPaths,
    runner: CommandRunner,
) -> tuple[bytes, dict[str, Any], dict[str, Any]]:
    """Wait for the new active container's own profile after create/switch.

    Crane can publish the new active UUID a fraction of a second before the
    spoof tool finishes writing Documents/com.sgwc.ghostprefs.plist.  The
    workflow stays locked and Instagram stays closed while waiting.  Every
    poll revalidates the active UUID; no parent, Global, or inactive profile is
    ever considered as a fallback.
    """

    started = time.monotonic()
    deadline = started + max(0.0, paths.active_profile_wait_seconds)
    polls = 0
    last_invalid: Optional[WorkflowError] = None

    while True:
        if os.path.isfile(active.source_path):
            try:
                raw = _read_bytes(active.source_path)
                identity = _validate_identity(raw)
                return raw, identity, {
                    "waited_seconds": round(time.monotonic() - started, 3),
                    "polls": polls,
                    "profile_became_ready": polls > 0,
                }
            except WorkflowError as exc:
                if exc.code != "active_profile_invalid":
                    raise
                last_invalid = exc
            except OSError:
                # The producer may still be replacing the file atomically.
                pass

        now = time.monotonic()
        if now >= deadline:
            details = {
                "container_id": active.identifier,
                "source_path": active.source_path,
                "waited_seconds": round(now - started, 3),
                "polls": polls,
            }
            if last_invalid is not None:
                raise WorkflowError(
                    "active_profile_invalid",
                    "The active Ghost profile did not become valid before timeout",
                    stage="validate_active_profile",
                    details={**last_invalid.details, **details},
                ) from last_invalid
            if not os.path.isdir(active.root):
                raise WorkflowError(
                    "active_container_missing",
                    "The active Crane container directory did not appear before timeout",
                    stage="resolve_active",
                    details={"path": active.root, **details},
                )
            raise WorkflowError(
                "active_profile_missing",
                "The active Crane container did not receive its Ghost profile before timeout",
                stage="validate_active_profile",
                details=details,
            )

        time.sleep(
            min(
                max(0.001, paths.active_profile_poll_seconds),
                max(0.0, deadline - now),
            )
        )
        polls += 1
        try:
            current_id, _settings = _active_crane_selection(paths, runner)
        except WorkflowError as exc:
            if exc.code in {"active_container_missing", "active_container_changed"}:
                raise WorkflowError(
                    "active_container_changed",
                    "The active Crane container changed while awaiting its profile",
                    stage="await_active_profile",
                    details={"expected_id": active.identifier, "polls": polls, **exc.details},
                ) from exc
            raise
        if current_id != active.identifier:
            raise WorkflowError(
                "active_container_changed",
                "The active Crane container changed while awaiting its profile",
                stage="await_active_profile",
                details={
                    "expected_id": active.identifier,
                    "current_id": current_id,
                    "polls": polls,
                },
            )


def _assert_same_active(
    expected: ActiveContainer,
    paths: WorkflowPaths,
    runner: CommandRunner,
    stage: str,
    *,
    require_profile: bool = True,
) -> ActiveContainer:
    try:
        identifier, _settings = _active_crane_selection(paths, runner)
    except WorkflowError as exc:
        if exc.code in {"active_container_missing", "active_container_changed"}:
            raise WorkflowError(
                "active_container_changed",
                "The active Crane container changed during the workflow",
                stage=stage,
                details={"expected_id": expected.identifier, **exc.details},
            ) from exc
        raise
    if identifier != expected.identifier:
        raise WorkflowError(
            "active_container_changed",
            "The active Crane container changed during the workflow",
            stage=stage,
            details={
                "expected_id": expected.identifier,
                "current_id": identifier,
            },
        )
    if require_profile and not os.path.isfile(expected.source_path):
        raise WorkflowError(
            "active_profile_missing",
            "The active Crane container has no Ghost profile",
            stage=stage,
            details={
                "container_id": expected.identifier,
                "source_path": expected.source_path,
            },
        )
    return expected


def _validate_identity(raw: bytes) -> dict[str, Any]:
    try:
        prefs = plistlib.loads(raw)
    except Exception as exc:
        raise WorkflowError(
            "active_profile_invalid",
            f"The active Ghost profile cannot be parsed: {type(exc).__name__}",
            stage="validate_active_profile",
        ) from exc
    if not isinstance(prefs, dict):
        raise WorkflowError(
            "active_profile_invalid",
            "The active Ghost profile is not a dictionary",
            stage="validate_active_profile",
        )

    # Reuse the exact identity and resolution contract enforced by apply.
    import ig_ghost_guard_cli as guard

    model = str(prefs.get("deviceModel") or "").strip()
    identity = {
        "model": model,
        "hardware": str(prefs.get("deviceHardwareModel") or "").strip(),
        "display_name": str(prefs.get("deviceDisplayName") or "").strip(),
        "ios": str(prefs.get("iosVersion") or "").strip(),
        "build": guard.parse_build(prefs.get("iosVersionBuild"), required=False),
        "resolution": guard.RES_MAP.get(model, ""),
    }
    if not all(identity.values()):
        raise WorkflowError(
            "active_profile_invalid",
            "The active Ghost identity is incomplete or unsupported",
            stage="validate_active_profile",
            details={"identity": identity},
        )
    identity["profile_sha256"] = _sha256(raw)
    identity["snapshot_id"] = guard.snapshot_id_from_global_bytes(raw)
    return identity


def _seed_marker_path(active: ActiveContainer) -> str:
    return os.path.join(active.root, SEED_MARKER_RELATIVE_PATH)


def _read_seed_marker(active: ActiveContainer) -> Optional[dict[str, Any]]:
    """Return this container's seed marker, ignoring a marker copied by Crane."""

    path = _seed_marker_path(active)
    if not os.path.isfile(path):
        return None
    try:
        marker = _read_plist(path)
    except Exception as exc:
        raise WorkflowError(
            "container_seed_marker_invalid",
            "The active container seed marker is unreadable",
            stage="seed_active_profile",
            details={"path": path, "error": type(exc).__name__},
        ) from exc
    marker_id = str(marker.get("container_id") or "").strip().upper()
    if marker_id != active.identifier:
        # A Crane clone can copy Library/Preferences from another UUID.  Such a
        # marker cannot authorize reuse of the copied device identity.
        return None
    if marker.get("seeded") is not True:
        raise WorkflowError(
            "container_seed_marker_invalid",
            "The active container seed marker is incomplete",
            stage="seed_active_profile",
            details={"path": path, "container_id": active.identifier},
        )
    return marker


def _parse_prepare_result(
    completed: subprocess.CompletedProcess[str],
    active: ActiveContainer,
) -> dict[str, Any]:
    try:
        payload = json.loads(completed.stdout.strip())
    except Exception as exc:
        raise WorkflowError(
            "active_profile_seed_failed",
            "The random profile generator returned invalid JSON",
            stage="seed_active_profile",
            details={
                "returncode": completed.returncode,
                "stdout": completed.stdout.strip()[-500:],
                "stderr": completed.stderr.strip()[-500:],
            },
        ) from exc
    if not isinstance(payload, dict):
        payload = {}
    returned_id = str(payload.get("container_id") or "").strip().upper()
    if (
        completed.returncode != 0
        or payload.get("success") is not True
        or returned_id != active.identifier
    ):
        raise WorkflowError(
            "active_profile_seed_failed",
            "The random profile generator did not seed the expected container",
            stage="seed_active_profile",
            details={
                "expected_container_id": active.identifier,
                "returncode": completed.returncode,
                "result": payload,
                "stderr": completed.stderr.strip()[-500:],
            },
        )
    return payload


def _generate_active_profile(
    active: ActiveContainer,
    paths: WorkflowPaths,
    runner: CommandRunner,
    *,
    require_existing_profile: bool,
) -> tuple[dict[str, Any], bytes, dict[str, Any]]:
    """Generate one fresh profile while continuously pinning the active UUID."""

    _assert_same_active(
        active,
        paths,
        runner,
        "before_seed",
        require_profile=require_existing_profile,
    )
    completed = runner.run(
        [
            paths.prepare_target,
            "--fresh-identifiers",
            "--expected-container-id",
            active.identifier,
        ],
        timeout=45,
    )
    generator = _parse_prepare_result(completed, active)
    _assert_same_active(active, paths, runner, "after_seed")

    try:
        seeded_raw = _read_bytes(active.source_path)
    except OSError as exc:
        raise WorkflowError(
            "active_profile_seed_failed",
            "The seeded active profile is missing",
            stage="seed_active_profile",
            details={"source_path": active.source_path},
        ) from exc
    seeded_identity = _validate_identity(seeded_raw)
    generator_mismatches = {
        key: {"generator": generator.get(key), "profile": expected}
        for key, expected in (
            ("deviceModel", seeded_identity["model"]),
            ("deviceDisplayName", seeded_identity["display_name"]),
            ("iosVersion", seeded_identity["ios"]),
        )
        if generator.get(key) != expected
    }
    if generator_mismatches:
        raise WorkflowError(
            "active_profile_seed_mismatch",
            "The random generator output does not match the active profile",
            stage="seed_active_profile",
            details={"mismatches": generator_mismatches},
        )
    return generator, seeded_raw, seeded_identity


def _persist_seed_marker(
    active: ActiveContainer,
    seeded_raw: bytes,
    seeded_identity: dict[str, Any],
) -> tuple[str, float]:
    marker_path = _seed_marker_path(active)
    seeded_at = time.time()
    marker_payload = {
        "schema": 1,
        "seeded": True,
        "container_id": active.identifier,
        "container_name": active.name,
        "seeded_at": seeded_at,
        "profile_sha256": seeded_identity["profile_sha256"],
        "profile_data": seeded_raw,
        "model": seeded_identity["model"],
        "hardware": seeded_identity["hardware"],
        "display_name": seeded_identity["display_name"],
        "ios": seeded_identity["ios"],
        "build": seeded_identity["build"],
    }
    _atomic_write(
        marker_path,
        plistlib.dumps(marker_payload, fmt=plistlib.FMT_BINARY),
        0o644,
    )
    persisted_marker = _read_seed_marker(active)
    if (
        persisted_marker is None
        or persisted_marker.get("profile_sha256")
        != seeded_identity["profile_sha256"]
    ):
        raise WorkflowError(
            "container_seed_marker_failed",
            "The new container seed marker was not persisted",
            stage="seed_active_profile",
            details={"path": marker_path},
        )
    return marker_path, seeded_at


def _recover_or_seed_missing_active_profile(
    active: ActiveContainer,
    paths: WorkflowPaths,
    runner: CommandRunner,
) -> tuple[bytes, dict[str, Any], dict[str, Any]]:
    """Restore this UUID's own snapshot or create a fresh random profile."""

    marker = _read_seed_marker(active)
    marker_path = _seed_marker_path(active)
    if marker is not None:
        assigned_raw = marker.get("profile_data")
        if not isinstance(assigned_raw, bytes):
            raise WorkflowError(
                "container_seed_snapshot_missing",
                "The active profile is missing and its assigned snapshot is unavailable",
                stage="seed_active_profile",
                details={
                    "container_id": active.identifier,
                    "marker_path": marker_path,
                },
            )
        assigned_identity = _validate_identity(assigned_raw)
        if marker.get("profile_sha256") != assigned_identity["profile_sha256"]:
            raise WorkflowError(
                "container_seed_snapshot_invalid",
                "The assigned profile snapshot hash does not match its marker",
                stage="seed_active_profile",
                details={"container_id": active.identifier},
            )
        _assert_same_active(
            active,
            paths,
            runner,
            "before_restore_missing_seed",
            require_profile=False,
        )
        _atomic_write(active.source_path, assigned_raw, 0o644)
        _assert_same_active(active, paths, runner, "after_restore_missing_seed")
        return assigned_raw, assigned_identity, {
            "new_container": False,
            "randomized": False,
            "reason": "missing_profile_restored_from_own_marker",
            "marker_path": marker_path,
            "seeded_at": marker.get("seeded_at"),
            "seed_profile_sha256": assigned_identity["profile_sha256"],
            "current_profile_sha256": assigned_identity["profile_sha256"],
            "restored_assigned_profile": True,
            "profile_created": True,
        }

    _generator, seeded_raw, seeded_identity = _generate_active_profile(
        active,
        paths,
        runner,
        require_existing_profile=False,
    )
    marker_path, seeded_at = _persist_seed_marker(
        active, seeded_raw, seeded_identity
    )
    return seeded_raw, seeded_identity, {
        "new_container": True,
        "randomized": True,
        "reason": "missing_active_profile_seeded",
        "marker_path": marker_path,
        "seeded_at": seeded_at,
        "profile_sha256": seeded_identity["profile_sha256"],
        "model": seeded_identity["model"],
        "display_name": seeded_identity["display_name"],
        "ios": seeded_identity["ios"],
        "build": seeded_identity["build"],
        "profile_created": True,
    }


def _ensure_active_container_seed(
    active: ActiveContainer,
    active_raw: bytes,
    identity: dict[str, Any],
    paths: WorkflowPaths,
    runner: CommandRunner,
) -> tuple[bytes, dict[str, Any], dict[str, Any]]:
    """Randomize an unseen active UUID once, then keep it stable on retries."""

    marker_path = _seed_marker_path(active)
    marker = _read_seed_marker(active)
    if marker is not None:
        assigned_raw = marker.get("profile_data")
        snapshot_recovered = False
        if not isinstance(assigned_raw, bytes):
            if marker.get("profile_sha256") != identity["profile_sha256"]:
                raise WorkflowError(
                    "container_seed_snapshot_missing",
                    "The assigned container profile is missing after its live copy changed",
                    stage="seed_active_profile",
                    details={
                        "container_id": active.identifier,
                        "marker_path": marker_path,
                        "seed_profile_sha256": marker.get("profile_sha256"),
                        "current_profile_sha256": identity["profile_sha256"],
                    },
                )
            # Upgrade a v1.0.67 marker while its assigned live profile is still
            # intact.  Future Global sync overwrites can then be repaired.
            assigned_raw = active_raw
            marker["profile_data"] = assigned_raw
            _atomic_write(
                marker_path,
                plistlib.dumps(marker, fmt=plistlib.FMT_BINARY),
                0o644,
            )
            snapshot_recovered = True

        try:
            assigned_identity = _validate_identity(assigned_raw)
        except WorkflowError as exc:
            raise WorkflowError(
                "container_seed_snapshot_invalid",
                "The assigned container profile snapshot is invalid",
                stage="seed_active_profile",
                details={"container_id": active.identifier, "marker_path": marker_path},
            ) from exc
        if marker.get("profile_sha256") != assigned_identity["profile_sha256"]:
            raise WorkflowError(
                "container_seed_snapshot_invalid",
                "The assigned container profile snapshot hash does not match its marker",
                stage="seed_active_profile",
                details={
                    "container_id": active.identifier,
                    "marker_path": marker_path,
                    "marker_profile_sha256": marker.get("profile_sha256"),
                    "snapshot_profile_sha256": assigned_identity["profile_sha256"],
                },
            )

        restored_assigned_profile = (
            identity["profile_sha256"] != assigned_identity["profile_sha256"]
        )
        overwritten_profile_sha256 = None
        if restored_assigned_profile:
            overwritten_profile_sha256 = identity["profile_sha256"]
            _assert_same_active(active, paths, runner, "before_restore_seed")
            _atomic_write(active.source_path, assigned_raw, 0o644)
            _assert_same_active(active, paths, runner, "after_restore_seed")
            restored_raw = _read_bytes(active.source_path)
            if _sha256(restored_raw) != assigned_identity["profile_sha256"]:
                raise WorkflowError(
                    "container_seed_restore_failed",
                    "The assigned profile could not be restored to the active container",
                    stage="seed_active_profile",
                    details={"source_path": active.source_path},
                )
            active_raw = restored_raw
            identity = assigned_identity

        return active_raw, identity, {
            "new_container": False,
            "randomized": False,
            "reason": "already_seeded",
            "marker_path": marker_path,
            "seeded_at": marker.get("seeded_at"),
            "seed_profile_sha256": marker.get("profile_sha256"),
            "current_profile_sha256": identity["profile_sha256"],
            "snapshot_recovered": snapshot_recovered,
            "restored_assigned_profile": restored_assigned_profile,
            "overwritten_profile_sha256": overwritten_profile_sha256,
            "profile_changed_since_seed": False,
        }

    _generator, seeded_raw, seeded_identity = _generate_active_profile(
        active,
        paths,
        runner,
        require_existing_profile=True,
    )
    if seeded_identity["profile_sha256"] == identity["profile_sha256"]:
        raise WorkflowError(
            "active_profile_seed_not_fresh",
            "The new container retained the inherited Ghost identity",
            stage="seed_active_profile",
            details={
                "container_id": active.identifier,
                "profile_sha256": identity["profile_sha256"],
            },
        )
    marker_path, seeded_at = _persist_seed_marker(
        active, seeded_raw, seeded_identity
    )
    return seeded_raw, seeded_identity, {
        "new_container": True,
        "randomized": True,
        "reason": "new_active_container",
        "marker_path": marker_path,
        "seeded_at": seeded_at,
        "previous_profile_sha256": identity["profile_sha256"],
        "profile_sha256": seeded_identity["profile_sha256"],
        "model": seeded_identity["model"],
        "display_name": seeded_identity["display_name"],
        "ios": seeded_identity["ios"],
        "build": seeded_identity["build"],
    }


def _inactive_profile_hashes(active: ActiveContainer) -> dict[str, str]:
    crane_root = os.path.join(active.app_root, CRANE_RELATIVE_ROOT)
    hashes: dict[str, str] = {}
    if not os.path.isdir(crane_root):
        return hashes
    for identifier in sorted(os.listdir(crane_root)):
        if identifier.upper() == active.identifier:
            continue
        profile = os.path.join(crane_root, identifier, "Documents", GHOST_PLIST)
        if os.path.isfile(profile):
            hashes[identifier.upper()] = _file_sha256(profile)
    return hashes


def _live_instagram_pids(paths: WorkflowPaths, runner: CommandRunner) -> list[int]:
    completed = runner.run(
        [paths.ps, "-ax", "-o", "pid=", "-o", "command="], timeout=15
    )
    pids: list[int] = []
    for line in completed.stdout.splitlines():
        if "Instagram.app/Instagram" not in line:
            continue
        try:
            pids.append(int(line.strip().split(None, 1)[0]))
        except (ValueError, IndexError):
            continue
    return sorted(set(pids))


def _stop_instagram(paths: WorkflowPaths, runner: CommandRunner) -> None:
    runner.run([paths.killall, "Instagram"], timeout=10)
    time.sleep(1)
    runner.run([paths.killall, "-9", "Instagram"], timeout=10)
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        if not _live_instagram_pids(paths, runner):
            return
        time.sleep(0.25)
    remaining = _live_instagram_pids(paths, runner)
    if remaining:
        raise WorkflowError(
            "instagram_stop_failed",
            "Instagram remained running before force apply",
            stage="stop_old_runtime",
            details={"pids": remaining},
        )


def _sync_daemon_pids(paths: WorkflowPaths, runner: CommandRunner) -> tuple[int, ...]:
    completed = runner.run(
        [paths.ps, "-ax", "-o", "pid=", "-o", "command="], timeout=15
    )
    result: list[int] = []
    for line in completed.stdout.splitlines():
        if "/var/jb/usr/bin/ghost-global-syncd" not in line:
            continue
        try:
            result.append(int(line.strip().split(None, 1)[0]))
        except (ValueError, IndexError):
            continue
    return tuple(sorted(set(result)))


def _sudo(
    paths: WorkflowPaths,
    runner: CommandRunner,
    argv: Iterable[str],
    *,
    timeout: int = 30,
) -> subprocess.CompletedProcess[str]:
    password = os.environ.get("IG_IPHONE_PASSWORD", "alpine")
    return runner.run(
        [paths.sudo, "-S", "-p", "", *list(argv)],
        timeout=timeout,
        input_text=password + "\n",
    )


def _pause_sync_service(
    paths: WorkflowPaths, runner: CommandRunner
) -> SyncServiceState:
    label = "system/com.langtoi.ghost-global-sync"
    loaded = runner.run([paths.launchctl, "print", label], timeout=15).returncode == 0
    pids = _sync_daemon_pids(paths, runner)
    if loaded:
        completed = _sudo(
            paths, runner, [paths.launchctl, "bootout", label], timeout=30
        )
        if completed.returncode != 0:
            raise WorkflowError(
                "sync_pause_failed",
                "Could not pause ghost-global-sync before force mirror",
                stage="pause_sync",
                details={"stderr": completed.stderr.strip()[-300:]},
            )
    remaining = _sync_daemon_pids(paths, runner)
    if remaining:
        completed = _sudo(
            paths,
            runner,
            ["/var/jb/usr/bin/kill", "-TERM", *[str(pid) for pid in remaining]],
            timeout=15,
        )
        if completed.returncode != 0:
            raise WorkflowError(
                "sync_pause_failed",
                "Could not stop the running ghost-global-sync process",
                stage="pause_sync",
                details={"pids": list(remaining)},
            )
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline and _sync_daemon_pids(paths, runner):
        time.sleep(0.25)
    if _sync_daemon_pids(paths, runner):
        raise WorkflowError(
            "sync_pause_failed",
            "ghost-global-sync remained running",
            stage="pause_sync",
        )
    return SyncServiceState(loaded=loaded, pids=pids)


def _restore_sync_service(
    paths: WorkflowPaths,
    runner: CommandRunner,
    state: SyncServiceState,
    expected_profile_hash: str,
) -> None:
    if not state.loaded and not state.pids:
        return
    bootstrap_rc: Optional[int] = None
    if state.loaded:
        bootstrap = _sudo(
            paths,
            runner,
            [paths.launchctl, "bootstrap", "system", paths.sync_plist],
            timeout=30,
        )
        bootstrap_rc = bootstrap.returncode
        # A concurrently restored service reports an already-loaded error;
        # verify the final process/status below instead of accepting its text.
        _sudo(
            paths,
            runner,
            [paths.launchctl, "enable", "system/com.langtoi.ghost-global-sync"],
            timeout=15,
        )
        _sudo(
            paths,
            runner,
            [
                paths.launchctl,
                "kickstart",
                "-k",
                "system/com.langtoi.ghost-global-sync",
            ],
            timeout=30,
        )
    else:
        # Preserve a manually started worker without converting it into a
        # launchd-managed service.
        _sudo(paths, runner, [paths.sync_start], timeout=30)
    deadline = time.monotonic() + 12
    last_status: dict[str, Any] = {}
    while time.monotonic() < deadline:
        try:
            with open(paths.sync_status, "r", encoding="utf-8") as handle:
                loaded = json.load(handle)
            if isinstance(loaded, dict):
                last_status = loaded
        except Exception:
            pass
        if (
            last_status.get("success") is True
            and last_status.get("profile_sha256") == expected_profile_hash
            and _sync_daemon_pids(paths, runner)
        ):
            return
        time.sleep(0.5)
    raise WorkflowError(
        "sync_restore_failed",
        "ghost-global-sync did not reconcile the forced active profile",
        stage="restore_sync",
        details={
            "bootstrap_rc": bootstrap_rc,
            "status": last_status,
        },
    )


def _remove_if_exists(path: str) -> bool:
    try:
        os.unlink(path)
        return True
    except FileNotFoundError:
        return False


def _sanitize_active_storage(
    active: ActiveContainer,
    active_raw: bytes,
    paths: WorkflowPaths,
) -> dict[str, Any]:
    import ig_active_sanitize as sanitizer

    try:
        report = sanitizer.sanitize_active_scope(
            active.root,
            active.identifier,
            active_raw,
            backup_root=paths.sanitize_backup_root,
        )
    except Exception as exc:
        raise WorkflowError(
            "active_storage_sanitize_failed",
            f"Could not sanitize the active container queues: {type(exc).__name__}: {exc}",
            stage="sanitize_active_storage",
        ) from exc
    if report.get("success") is not True:
        raise WorkflowError(
            "active_storage_residual",
            "The active container still contains a real/stale device identity",
            stage="sanitize_active_storage",
            details={
                "after": report.get("after") or [],
                "effective_after": report.get("effective_after") or {},
            },
        )
    return report


def _scan_active_storage(
    active: ActiveContainer,
    active_raw: bytes,
) -> dict[str, Any]:
    import ig_active_sanitize as sanitizer

    try:
        target = sanitizer.identity_from_profile(active_raw)
        replacements = sanitizer.build_replacements(target)
        report = sanitizer.effective_scan_scope(
            active.root,
            active.identifier,
            target,
            replacements,
        )
    except Exception as exc:
        raise WorkflowError(
            "active_storage_scan_failed",
            f"Could not audit the live active-container queues: {type(exc).__name__}: {exc}",
            stage="validate_storage",
        ) from exc
    if report.get("success") is not True:
        raise WorkflowError(
            "active_storage_leak",
            "A real/stale device identity remains readable by the active runtime",
            stage="validate_storage",
            details=report,
        )
    return report


def _validate_apply_result(
    entry: dict[str, Any],
    snapshot: dict[str, Any],
    active: ActiveContainer,
    identity: dict[str, Any],
    previous_pids: list[int],
    previous_pid: int,
    previous_launch_id: str,
    workflow_started_at: float,
    *,
    minimum_requests_required: int,
    require_all_getters: bool,
    coverage_mode: str,
) -> dict[str, Any]:
    if entry.get("ok") is not True:
        raise WorkflowError(
            "apply_failed",
            "ig-ghost apply did not pass",
            stage="apply",
            details={
                "problems": entry.get("problems") or [],
                "error": entry.get("error") or "",
            },
        )
    status = entry.get("status") or {}
    warmup = entry.get("warmup") or {}
    if not isinstance(snapshot, dict) or not isinstance(status, dict):
        raise WorkflowError(
            "apply_report_invalid",
            "The apply report is missing snapshot/status data",
            stage="validate_runtime",
        )

    expected_snapshot = {
        "model": identity["model"],
        "hardware": identity["hardware"],
        "display_name": identity["display_name"],
        "ios": identity["ios"],
        "build": identity["build"],
        "resolution": identity["resolution"],
        "snapshot_id": identity["snapshot_id"],
        "source_path": active.source_path,
    }
    mismatches = {
        key: {"expected": value, "actual": snapshot.get(key)}
        for key, value in expected_snapshot.items()
        if snapshot.get(key) != value
    }
    if mismatches:
        raise WorkflowError(
            "snapshot_identity_mismatch",
            "The frozen snapshot does not match the active container profile",
            stage="validate_runtime",
            details={"mismatches": mismatches},
        )

    pid = int(status.get("pid", 0) or 0)
    launch_id = str(status.get("launch_id") or "")
    all_getters = all(
        int(status.get(key, 0) or 0) > 0
        for key in (
            "getter_static_calls",
            "getter_api_calls",
            "getter_mqtt_calls",
            "getter_webview_calls",
        )
    )
    same_pid = warmup.get("same_pid") is True
    new_launch = bool(launch_id) and launch_id != previous_launch_id
    if pid <= 0 or pid == previous_pid or pid in previous_pids:
        raise WorkflowError(
            "new_pid_not_created",
            "Force apply did not produce a new Instagram PID",
            stage="validate_runtime",
            details={
                "previous_pid": previous_pid,
                "previous_pids": previous_pids,
                "pid": pid,
            },
        )
    if not new_launch:
        raise WorkflowError(
            "new_launch_not_created",
            "Force apply reused the previous launch id",
            stage="validate_runtime",
            details={"previous_launch_id": previous_launch_id, "launch_id": launch_id},
        )
    if not same_pid or (require_all_getters and not all_getters):
        raise WorkflowError(
            "runtime_verification_failed",
            "Warm-up did not keep one PID or satisfy required getter coverage",
            stage="validate_runtime",
            details={
                "warmup": warmup,
                "require_all_getters": require_all_getters,
            },
        )
    created_at = float(snapshot.get("created_at", 0) or 0)
    if created_at + 1.0 < workflow_started_at:
        raise WorkflowError(
            "snapshot_not_refreshed",
            "The snapshot was not written by this workflow run",
            stage="validate_runtime",
        )

    calls = int(status.get("calls", 0) or 0)
    ua_reads = int(status.get("ua_reads", 0) or 0)
    requests_without_ua = int(status.get("requests_without_ua", 0) or 0)
    getter_calls = int(status.get("getter_calls", 0) or 0)
    request_accounting_closed = all(
        (
            int(status.get("header_reads", -1)) == calls,
            ua_reads > 0,
            ua_reads + requests_without_ua == calls,
            int(status.get("target_verified", -1)) == calls,
            int(status.get("verified_requests", -1)) == calls,
            int(status.get("url_scanned", -1)) == calls,
            int(status.get("rewrote", 0))
            + int(status.get("already_target", 0))
            + requests_without_ua
            == calls,
        )
    )
    getter_accounting_closed = all(
        (
            int(status.get("getter_target_after", -1)) == getter_calls,
            int(status.get("getter_rewritten", 0))
            + int(status.get("getter_already_target", 0))
            == getter_calls,
        )
    )
    zero_failures = all(
        int(status.get(key, -1)) == 0
        for key in (
            "getter_verify_fail",
            "getter_errors",
            "persistence_errors",
            "residual",
            "blocked",
            "errors",
        )
    )
    tigon_hook_seen = int(status.get("tigon_hooks", 0) or 0) == 1
    system_identity_hook_seen = all(
        (
            status.get("target_bundle") == BUNDLE_ID,
            status.get("source_getters_required") is True,
            status.get("sysctl_enabled") is True,
            status.get("sysctl_scope") == "hw.product",
            int(status.get("sysctl_hooks", -1)) == 1,
            int(status.get("sysctl_rewrites", 0)) > 0,
            status.get("system_identity_verified") is True,
            status.get("mobilegestalt_verified") is True,
            status.get("mobilegestalt_scope") == "ProductType",
            int(status.get("mobilegestalt_hooks", -1)) == 1,
            int(status.get("sysctl_product_rewrites", 0)) > 0,
            int(status.get("sysctl_build_rewrites", -1)) == 0,
            int(status.get("sysctl_version_rewrites", -1)) == 0,
            int(status.get("sysctl_mib_rewrites", -1)) == 0,
            int(status.get("mobilegestalt_product_rewrites", 0)) > 0,
            int(status.get("mobilegestalt_version_rewrites", -1)) == 0,
            int(status.get("mobilegestalt_build_rewrites", -1)) == 0,
        )
    )
    persistence_hook_seen = all(
        (
            status.get("persistence_enabled") is True,
            int(status.get("persistence_hooks", 0) or 0) == 1,
        )
    )
    new_crashes = entry.get("new_crashes") or []
    if (
        calls < minimum_requests_required
        or not request_accounting_closed
        or not getter_accounting_closed
        or not zero_failures
        or not tigon_hook_seen
        or not system_identity_hook_seen
        or not persistence_hook_seen
        or new_crashes
    ):
        raise WorkflowError(
            "runtime_accounting_failed",
            "The guarded runtime did not satisfy the closed accounting contract",
            stage="validate_runtime",
            details={
                "calls": calls,
                "minimum_requests": minimum_requests_required,
                "request_accounting_closed": request_accounting_closed,
                "getter_accounting_closed": getter_accounting_closed,
                "zero_failures": zero_failures,
                "tigon_hook_seen": tigon_hook_seen,
                "system_identity_hook_seen": system_identity_hook_seen,
                "persistence_hook_seen": persistence_hook_seen,
                "new_crashes": new_crashes,
            },
        )

    return {
        "previous_pid": previous_pid,
        "previous_pids": previous_pids,
        "pid": pid,
        "previous_launch_id": previous_launch_id,
        "launch_id": launch_id,
        "status_reset": True,
        "new_launch_id": new_launch,
        "same_pid_during_warmup": same_pid,
        "elapsed_seconds": warmup.get("elapsed_seconds"),
        "coverage_mode": coverage_mode,
        "minimum_requests_required": minimum_requests_required,
        "all_getters_required": require_all_getters,
        "full_authenticated_coverage": bool(
            coverage_mode == "authenticated_full"
            and calls >= MIN_REQUESTS
            and all_getters
        ),
        "requests": calls,
        "ua_reads": ua_reads,
        "requests_without_ua": requests_without_ua,
        "new_requests_during_warmup": int(warmup.get("new_calls", 0) or 0),
        "getter_calls": int(status.get("getter_calls", 0) or 0),
        "new_getters_during_warmup": int(
            warmup.get("new_getter_calls", 0) or 0
        ),
        "all_getters_seen": all_getters,
        "unseen_getters": [
            key
            for key in (
                "getter_static_calls",
                "getter_api_calls",
                "getter_mqtt_calls",
                "getter_webview_calls",
            )
            if int(status.get(key, 0) or 0) <= 0
        ],
        "tigon_hook_seen": tigon_hook_seen,
        "sysctl_hook_seen": system_identity_hook_seen,
        "system_identity_verified": bool(
            status.get("system_identity_verified") is True
        ),
        "mobilegestalt_verified": bool(
            status.get("mobilegestalt_verified") is True
        ),
        "mobilegestalt_hooks": int(
            status.get("mobilegestalt_hooks", 0) or 0
        ),
        "mobilegestalt_rewrites": int(
            status.get("mobilegestalt_rewrites", 0) or 0
        ),
        "sysctl_rewrites": int(status.get("sysctl_rewrites", 0) or 0),
        "sysctl_product_rewrites": int(
            status.get("sysctl_product_rewrites", 0) or 0
        ),
        "sysctl_build_rewrites": int(
            status.get("sysctl_build_rewrites", 0) or 0
        ),
        "sysctl_version_rewrites": int(
            status.get("sysctl_version_rewrites", 0) or 0
        ),
        "sysctl_mib_rewrites": int(
            status.get("sysctl_mib_rewrites", 0) or 0
        ),
        "persistence_hook_seen": persistence_hook_seen,
        "persistence_writes": int(status.get("persistence_writes", 0) or 0),
        "persistence_rewrites": int(status.get("persistence_rewrites", 0) or 0),
        "request_accounting_closed": request_accounting_closed,
        "getter_accounting_closed": getter_accounting_closed,
        "residual": int(status.get("residual", 0) or 0),
        "blocked": int(status.get("blocked", 0) or 0),
        "errors": int(status.get("errors", 0) or 0),
        "new_crashes": new_crashes,
    }


def run_force_active(
    *,
    paths: WorkflowPaths = DEFAULT_PATHS,
    runner: Optional[CommandRunner] = None,
    verification_mode: str = "auto",
) -> dict[str, Any]:
    runner = runner or CommandRunner()
    started_at = time.time()
    result: dict[str, Any] = {
        "success": False,
        "verdict": "FAIL",
        "action": "ghost_instagram",
        "workflow_version": WORKFLOW_VERSION,
        "force_active": True,
        "verification_mode": verification_mode,
        "started_at": started_at,
    }
    active: Optional[ActiveContainer] = None
    instagram_was_stopped = False
    sync_state: Optional[SyncServiceState] = None
    sync_restored = False
    lock_handle = None
    lock_acquired = False
    apply_entry: dict[str, Any] = {}
    sanitize_before_launch: dict[str, Any] = {}
    storage_after_warmup: dict[str, Any] = {}

    try:
        os.makedirs(os.path.dirname(paths.lock_path), exist_ok=True)
        lock_handle = open(paths.lock_path, "a+")
        try:
            fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            lock_acquired = True
        except OSError as exc:
            raise WorkflowError(
                "workflow_busy",
                "Another ghost_instagram workflow is already running",
                stage="lock",
            ) from exc

        active = resolve_active_container(paths, runner)
        status_path = os.path.join(active.root, STATUS_RELATIVE_PATH)
        snapshot_path = os.path.join(active.root, SNAPSHOT_RELATIVE_PATH)
        previous_status: dict[str, Any] = {}
        try:
            previous_status = _read_plist(status_path)
        except Exception:
            pass
        previous_launch_id = str(previous_status.get("launch_id") or "")
        previous_pids = _live_instagram_pids(paths, runner)
        previous_pid = int(previous_status.get("pid", 0) or 0)
        if previous_pid <= 0 and previous_pids:
            previous_pid = previous_pids[-1]

        result["active_container"] = {
            "id": active.identifier,
            "name": active.name,
            "source_path": active.source_path,
        }
        result["previous_runtime"] = {
            "pid": previous_pid,
            "pids": previous_pids,
            "launch_id": previous_launch_id,
        }

        _stop_instagram(paths, runner)
        instagram_was_stopped = True
        inactive_before = _inactive_profile_hashes(active)
        sync_state = _pause_sync_service(paths, runner)
        container_seed: Optional[dict[str, Any]] = None
        try:
            active_raw, identity, profile_wait = _await_active_profile(
                active, paths, runner
            )
            profile_wait["profile_auto_seeded"] = False
        except WorkflowError as exc:
            if exc.code != "active_profile_missing":
                raise
            active_raw, identity, container_seed = (
                _recover_or_seed_missing_active_profile(active, paths, runner)
            )
            profile_wait = {
                "waited_seconds": exc.details.get("waited_seconds"),
                "polls": exc.details.get("polls"),
                "profile_became_ready": False,
                "profile_auto_seeded": True,
            }
        result["active_container"].update(
            {
                "profile_waited_seconds": profile_wait["waited_seconds"],
                "profile_wait_polls": profile_wait["polls"],
                "profile_became_ready": profile_wait["profile_became_ready"],
                "profile_auto_seeded": profile_wait["profile_auto_seeded"],
            }
        )
        # Keep the inherited identity in the failure report if seeding itself
        # fails.  A successful seed replaces this value below.
        result["identity"] = dict(identity)
        if verification_mode not in {"auto", "account_creation"}:
            raise WorkflowError(
                "verification_mode_invalid",
                "Unknown Instagram verification mode",
                stage="select_contract",
                details={"verification_mode": verification_mode},
            )
        session_context = _active_session_context(active)
        account_creation_bootstrap = verification_mode == "account_creation"
        fresh_container_bootstrap = account_creation_bootstrap or bool(
            session_context.get("fresh_container_bootstrap")
        )
        minimum_requests_required = (
            FRESH_CONTAINER_MIN_REQUESTS
            if fresh_container_bootstrap
            else MIN_REQUESTS
        )
        require_all_getters = not fresh_container_bootstrap
        if account_creation_bootstrap:
            coverage_mode = "account_creation_bootstrap"
        elif fresh_container_bootstrap:
            coverage_mode = "fresh_container_bootstrap"
        else:
            coverage_mode = "authenticated_full"
        result["container_session"] = session_context
        if container_seed is None:
            active_raw, identity, container_seed = _ensure_active_container_seed(
                active,
                active_raw,
                identity,
                paths,
                runner,
            )
        result["identity"] = dict(identity)
        result["container_seed"] = container_seed
        _assert_same_active(active, paths, runner, "before_mirror")

        mirror_paths = (
            active.source_path,
            active.parent_profile_path,
            paths.global_profile,
        )
        for destination in mirror_paths:
            _atomic_write(destination, active_raw, 0o644)
        mirror_hashes = {path: _file_sha256(path) for path in mirror_paths}
        if any(value != identity["profile_sha256"] for value in mirror_hashes.values()):
            raise WorkflowError(
                "force_mirror_failed",
                "Not every Instagram identity reader received the active profile",
                stage="force_mirror",
                details={"hashes": mirror_hashes},
            )
        sanitize_before_launch = _sanitize_active_storage(
            active,
            active_raw,
            paths,
        )
        _assert_same_active(active, paths, runner, "before_launch")

        if sync_state.loaded or sync_state.pids:
            _restore_sync_service(
                paths, runner, sync_state, identity["profile_sha256"]
            )
            sync_restored = True

        _remove_if_exists(status_path)
        _remove_if_exists(snapshot_path)
        status_reset = not os.path.exists(status_path)
        snapshot_reset = not os.path.exists(snapshot_path)
        if not status_reset or not snapshot_reset:
            raise WorkflowError(
                "runtime_reset_failed",
                "The old guard snapshot/status could not be removed",
                stage="reset_runtime",
            )
        # cfprefsd is restarted automatically; clearing it here makes the
        # parent/global mirror visible before the fresh app process starts.
        runner.run([paths.killall, "cfprefsd"], timeout=10)

        os.makedirs(os.path.dirname(paths.latest_report), exist_ok=True)
        fd, apply_report_path = tempfile.mkstemp(
            prefix=".ghost-instagram-apply-",
            suffix=".json",
            dir=os.path.dirname(paths.latest_report),
        )
        os.close(fd)
        try:
            command = [
                sys.executable,
                paths.ig_ghost,
                "apply",
                "--warmup-seconds",
                str(WARMUP_SECONDS),
                "--min-requests",
                str(minimum_requests_required),
                "--allow-iguafix-overlap",
                "--no-frida-launch-fallback",
                "--report",
                apply_report_path,
            ]
            if fresh_container_bootstrap:
                command.append("--fresh-container-bootstrap")
            completed = runner.run(command, timeout=180)
            try:
                with open(apply_report_path, "r", encoding="utf-8") as handle:
                    report = json.load(handle)
            except Exception as exc:
                raise WorkflowError(
                    "apply_report_invalid",
                    f"Could not read the apply report: {type(exc).__name__}",
                    stage="apply",
                    details={
                        "returncode": completed.returncode,
                        "stdout": completed.stdout.strip()[-500:],
                        "stderr": completed.stderr.strip()[-500:],
                    },
                ) from exc
            if not isinstance(report, list) or len(report) != 1 or not isinstance(report[0], dict):
                raise WorkflowError(
                    "apply_report_invalid",
                    "The apply report must contain exactly one device result",
                    stage="apply",
                )
            apply_entry = report[0]
            if completed.returncode != 0 and apply_entry.get("ok") is True:
                raise WorkflowError(
                    "apply_exit_mismatch",
                    "ig-ghost returned failure despite an ok report",
                    stage="apply",
                    details={"returncode": completed.returncode},
                )
        finally:
            try:
                os.unlink(apply_report_path)
            except OSError:
                pass

        _assert_same_active(active, paths, runner, "after_warmup")
        current_raw = _read_bytes(active.source_path)
        if _sha256(current_raw) != identity["profile_sha256"]:
            raise WorkflowError(
                "active_profile_changed",
                "The active profile changed during warm-up",
                stage="validate_runtime",
            )
        inactive_after = _inactive_profile_hashes(active)
        if inactive_after != inactive_before:
            raise WorkflowError(
                "inactive_container_changed",
                "An inactive Crane container profile changed during force apply",
                stage="validate_isolation",
                details={"before": inactive_before, "after": inactive_after},
            )
        for destination in (active.parent_profile_path, paths.global_profile):
            if _file_sha256(destination) != identity["profile_sha256"]:
                raise WorkflowError(
                    "force_mirror_changed",
                    "An early-reader profile diverged during warm-up",
                    stage="validate_runtime",
                    details={"path": destination},
                )

        try:
            frozen_snapshot = _read_plist(snapshot_path)
            snapshot_mtime = os.stat(snapshot_path).st_mtime
        except Exception as exc:
            raise WorkflowError(
                "snapshot_missing",
                "The fresh Guard snapshot is missing or unreadable",
                stage="validate_runtime",
            ) from exc
        # APFS/NTFS bridge timestamps can trail Python's realtime clock by a
        # few seconds. The old file was unlinked above and created_at is also
        # checked, so a five-second filesystem tolerance does not permit reuse.
        if snapshot_mtime + FILESYSTEM_TIMESTAMP_TOLERANCE < started_at:
            raise WorkflowError(
                "snapshot_not_refreshed",
                "The Guard snapshot file was not rewritten by this workflow run",
                stage="validate_runtime",
                details={"mtime": snapshot_mtime, "started_at": started_at},
            )
        report_snapshot = apply_entry.get("snapshot") or {}
        snapshot_report_mismatches = {
            key: {
                "report": report_snapshot.get(key),
                "frozen": frozen_snapshot.get(key),
            }
            for key in (
                "snapshot_id",
                "model",
                "hardware",
                "display_name",
                "ios",
                "build",
                "resolution",
                "source_path",
            )
            if report_snapshot.get(key) != frozen_snapshot.get(key)
        }
        if snapshot_report_mismatches:
            raise WorkflowError(
                "apply_report_snapshot_mismatch",
                "The apply report and frozen Guard snapshot disagree",
                stage="validate_runtime",
                details={"mismatches": snapshot_report_mismatches},
            )

        runtime = _validate_apply_result(
            apply_entry,
            frozen_snapshot,
            active,
            identity,
            previous_pids,
            previous_pid,
            previous_launch_id,
            started_at,
            minimum_requests_required=minimum_requests_required,
            require_all_getters=require_all_getters,
            coverage_mode=coverage_mode,
        )
        storage_after_warmup = _scan_active_storage(active, current_raw)
        if not storage_after_warmup.get("success"):
            raise WorkflowError(
                "active_storage_residual_after_warmup",
                "The active container produced a real or stale device identity during warm-up",
                stage="validate_storage_after_warmup",
                details=storage_after_warmup,
            )
        live_pids = _live_instagram_pids(paths, runner)
        if runtime["pid"] not in live_pids:
            raise WorkflowError(
                "pid_not_live_instagram",
                "The verified Instagram PID is no longer running",
                stage="validate_runtime",
                details={"pid": runtime["pid"], "live_pids": live_pids},
            )

        result.update(
            {
                "success": True,
                "verdict": "PASS",
                "stage": "complete",
                "mirrored_paths": list(mirror_paths),
                "mirror_hashes": mirror_hashes,
                "mirror_sha256": identity["profile_sha256"],
                "inactive_containers_unchanged": True,
                "inactive_profile_hashes": inactive_after,
                "storage_sanitize": sanitize_before_launch,
                "storage_after_warmup": storage_after_warmup,
                "device_identity_markers_clean": True,
                "snapshot_refreshed": True,
                "snapshot": {
                    key: frozen_snapshot.get(key)
                    for key in (
                        "snapshot_id",
                        "model",
                        "hardware",
                        "display_name",
                        "ios",
                        "build",
                        "resolution",
                        "source_path",
                        "created_at",
                    )
                }
                | {
                    "source_profile_sha256": identity["profile_sha256"],
                    "file_mtime": snapshot_mtime,
                },
                "runtime": runtime,
                "coverage": (
                    (
                        "Account-creation setup: all installed IGUserAgent hooks "
                        "and every request which actually occurred on the login/"
                        "signup flow were audited; no artificial 100-request "
                        "requirement was applied. "
                        if coverage_mode == "account_creation_bootstrap"
                        else (
                            "Fresh logged-out container: all four IGUserAgent hooks "
                            "installed and every observed IGTigon request header/URL "
                            "audited; authenticated MQTT and 100-request coverage are "
                            "deferred until login. "
                            if fresh_container_bootstrap
                            else "All four IGUserAgent getters and at least 100 "
                            "IGTigon requests verified. "
                        )
                    )
                    + "ProductType sysctl/MobileGestalt surfaces were "
                    "self-verified; OS/build kernel hooks remain disabled "
                    "because META 439 aborts before main when they are changed. "
                    "METAHealthCheckResponse plus active "
                    "FFLogger/analytics/crypto queues were checked; no "
                    "encrypted-wire or automatic Accounts Center claim."
                ),
            }
        )
    except WorkflowError as exc:
        result.update(
            {
                "success": False,
                "verdict": "FAIL",
                "stage": exc.stage,
                "error": exc.code,
                "message": str(exc),
                "problems": exc.details,
            }
        )
        if instagram_was_stopped:
            with contextlib.suppress(Exception):
                _stop_instagram(paths, runner)
    except Exception as exc:
        result.update(
            {
                "success": False,
                "verdict": "FAIL",
                "stage": "unexpected",
                "error": type(exc).__name__,
                "message": str(exc),
            }
        )
        if instagram_was_stopped:
            with contextlib.suppress(Exception):
                _stop_instagram(paths, runner)
    finally:
        if (
            sync_state is not None
            and (sync_state.loaded or sync_state.pids)
            and not sync_restored
        ):
            try:
                expected_hash = str((result.get("identity") or {}).get("profile_sha256") or "")
                _restore_sync_service(paths, runner, sync_state, expected_hash)
            except Exception as exc:
                result["success"] = False
                result["verdict"] = "FAIL"
                result["stage"] = "restore_sync"
                result["error"] = "sync_restore_failed"
                result["message"] = str(exc)
                with contextlib.suppress(Exception):
                    _stop_instagram(paths, runner)
        result["finished_at"] = time.time()
        result["elapsed_seconds"] = round(result["finished_at"] - started_at, 3)
        result["report_path"] = paths.latest_report
        if lock_acquired:
            with contextlib.suppress(Exception):
                _write_json_atomic(
                    paths.latest_report,
                    {**result, "apply_report": apply_entry},
                )
        if lock_handle is not None:
            with contextlib.suppress(Exception):
                fcntl.flock(lock_handle.fileno(), fcntl.LOCK_UN)
            lock_handle.close()
    return result


def parse_args(argv: Optional[list[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="ig-ghost instagram",
        description="Force apply and verify the currently active Crane container",
    )
    return parser.parse_args(argv)


def main(argv: Optional[list[str]] = None) -> int:
    parse_args(argv)
    result = run_force_active()
    # Keep stdout machine-readable for AutoTouch RUNLUA's JSON auto-decoder.
    print(json.dumps(result, ensure_ascii=False, separators=(",", ":")))
    return 0 if result.get("success") else 1


if __name__ == "__main__":
    raise SystemExit(main())
