"""Versioned Instagram/Threads Crane account archive helpers.

The archive is intentionally transport-only.  It is a regular ZIP with mode
0600, a JSON manifest, SHA-256 checksums, one canonical Ghost profile, and one
or two application sections.  Device mutation lives in ``crane_account.py``.
"""

from __future__ import annotations

import base64
import datetime as _datetime
import hashlib
import json
import os
import pathlib
import plistlib
import posixpath
import shutil
import stat
import tempfile
import zipfile
from typing import Any, Iterable
from urllib.parse import quote


ARCHIVE_SCHEMA = 1
ARCHIVE_TYPE = "langtoi_instagram_threads_account"
ARCHIVE_EXTENSION = ".ghostacct"
MANIFEST_NAME = "Manifest.json"
CHECKSUMS_NAME = "SHA256SUMS"
IDENTITY_MEMBER = "Identity/com.sgwc.ghostprefs.plist"
VALID_SELECTORS = {"both", "instagram", "threads"}
APP_BUNDLES = {
    "instagram": "com.burbn.instagram",
    "threads": "com.burbn.barcelona",
}
MAX_ARCHIVE_ENTRIES = 500_000
MAX_UNCOMPRESSED_BYTES = 24 * 1024 * 1024 * 1024


class ArchiveError(RuntimeError):
    def __init__(
        self,
        code: str,
        message: str,
        *,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.details = details or {}


def sha256_bytes(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def sha256_file(path: str | os.PathLike[str]) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        while True:
            block = handle.read(1024 * 1024)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def encoded_root_name(identifier: str) -> str:
    value = str(identifier or "").strip()
    if not value:
        raise ArchiveError("root_identifier_missing", "A Crane root has no identifier")
    return quote(value, safe="")


def _jsonable(value: Any) -> Any:
    if isinstance(value, bytes):
        return {"__bytes__": base64.b64encode(value).decode("ascii")}
    if isinstance(value, _datetime.datetime):
        return {"__datetime__": value.isoformat()}
    if isinstance(value, dict):
        return {
            str(key): _jsonable(item)
            for key, item in sorted(value.items(), key=lambda pair: str(pair[0]))
        }
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def canonical_json_bytes(value: Any) -> bytes:
    return json.dumps(
        _jsonable(value),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def _parse_build(raw: Any) -> str:
    import re

    match = re.search(r"Build\s+\(?([A-Za-z0-9]+)", str(raw or ""))
    return match.group(1) if match else ""


def validate_ghost_profile(raw: bytes) -> dict[str, Any]:
    try:
        prefs = plistlib.loads(raw)
    except Exception as exc:
        raise ArchiveError(
            "identity_profile_invalid",
            f"Ghost profile is not a readable plist: {type(exc).__name__}",
        ) from exc
    if not isinstance(prefs, dict):
        raise ArchiveError(
            "identity_profile_invalid", "Ghost profile root is not a dictionary"
        )

    model = str(prefs.get("deviceModel") or "").strip()
    identity = {
        "model": model,
        "hardware": str(prefs.get("deviceHardwareModel") or "").strip(),
        "display_name": str(prefs.get("deviceDisplayName") or "").strip(),
        "ios": str(prefs.get("iosVersion") or "").strip(),
        "build": _parse_build(prefs.get("iosVersionBuild")),
    }
    try:
        import ig_ghost_guard_cli as guard

        identity["resolution"] = str(guard.RES_MAP.get(model) or "")
        identity["snapshot_id"] = guard.snapshot_id_from_global_bytes(raw)
    except Exception:
        identity["resolution"] = ""
        identity["snapshot_id"] = sha256_bytes(canonical_json_bytes(identity))[:16]
    if not all(identity.values()):
        raise ArchiveError(
            "identity_profile_invalid",
            "Ghost profile is incomplete or uses an unsupported model",
            details={"identity": identity},
        )
    identity["profile_sha256"] = sha256_bytes(raw)
    return identity


_KEYCHAIN_STABLE_FIELDS = (
    "class",
    "agrp",
    "acct",
    "svce",
    "gena",
    "v_Data",
    "pdmn",
    "sync",
    "tomb",
)
_KEYCHAIN_VOLATILE_FIELDS = {
    "cdat",
    "mdat",
    "sha1",
    "musr",
    "persistref",
    "persistent_ref",
}


def keychain_fingerprint(value: Any) -> dict[str, Any]:
    """Return a stable multiset fingerprint for a Crane keychain dump.

    Crane may recreate dates, row hashes, persistent references, and multi-user
    identifiers during restore.  The access group, class, account/service, data
    bytes, protection domain, synchronizable flag, and tombstone flag are the
    stable identity of an item.
    """

    if not isinstance(value, dict):
        raise ArchiveError(
            "keychain_invalid", "Keychain.plist root is not a dictionary"
        )
    groups: dict[str, int] = {}
    item_hashes: list[str] = []
    for group, raw_items in sorted(value.items(), key=lambda pair: str(pair[0])):
        if not isinstance(raw_items, list):
            raise ArchiveError(
                "keychain_invalid",
                "A keychain access-group value is not a list",
                details={"group": str(group)},
            )
        groups[str(group)] = len(raw_items)
        for raw_item in raw_items:
            if not isinstance(raw_item, dict):
                normalized = raw_item
            else:
                normalized = {
                    key: raw_item[key]
                    for key in _KEYCHAIN_STABLE_FIELDS
                    if key in raw_item
                }
                if not normalized:
                    normalized = {
                        str(key): item
                        for key, item in raw_item.items()
                        if str(key) not in _KEYCHAIN_VOLATILE_FIELDS
                    }
            item_hashes.append(sha256_bytes(canonical_json_bytes(normalized)))
    item_hashes.sort()
    payload = {"groups": groups, "items": item_hashes}
    return {
        "total_items": len(item_hashes),
        "groups": groups,
        "item_hashes": item_hashes,
        "sha256": sha256_bytes(canonical_json_bytes(payload)),
    }


def read_keychain_fingerprint(path: str | os.PathLike[str]) -> dict[str, Any]:
    try:
        with open(path, "rb") as handle:
            value = plistlib.load(handle)
    except Exception as exc:
        raise ArchiveError(
            "keychain_invalid",
            f"Keychain dump cannot be read: {type(exc).__name__}",
        ) from exc
    return keychain_fingerprint(value)


def _meaningful(value: Any) -> bool:
    if value is None or isinstance(value, bool):
        return False
    if isinstance(value, (int, float)):
        return value != 0
    if isinstance(value, str):
        return value.strip().lower() not in {
            "",
            "0",
            "(null)",
            "null",
            "none",
            "unknown",
        }
    if isinstance(value, (list, tuple, set)):
        return any(_meaningful(item) for item in value)
    return bool(value)


def account_marker(app_key: str, preferences: Any) -> dict[str, Any]:
    if not isinstance(preferences, dict):
        return {"present": False, "values": {}, "sha256": ""}
    if app_key == "instagram":
        account = preferences.get("last-logged-in-account-dict")
        if not isinstance(account, dict) or not account:
            return {"present": False, "values": {}, "sha256": ""}
        stable_keys = (
            "username",
            "pk",
            "pk_id",
            "user_id",
            "uid",
            "full_name",
        )
        values = {
            key: account[key]
            for key in stable_keys
            if key in account and _meaningful(account[key])
        }
        if not values:
            values = {"account": account}
    elif app_key == "threads":
        analytics = preferences.get("FBAnalyticsCurrentLoggedInUserIdentityDict")
        app_uid = analytics.get("app_uid") if isinstance(analytics, dict) else None
        candidates = {
            "analytics_app_uid": app_uid,
            "last_known_owner_fbid": preferences.get(
                "kFBQPLLoggingPolicyLastKnownOwnerFbID"
            ),
            "account_model_owner_fbids": preferences.get(
                "kFBQPLLoggingPolicyAccountModelsOwnerFbIDsKey"
            ),
        }
        values = {
            key: value for key, value in candidates.items() if _meaningful(value)
        }
        if not values:
            return {"present": False, "values": {}, "sha256": ""}
    else:
        raise ArchiveError("app_invalid", f"Unsupported app: {app_key}")
    return {
        "present": True,
        "values": _jsonable(values),
        "sha256": sha256_bytes(canonical_json_bytes(values)),
    }


def account_markers_match(expected: Any, actual: Any) -> bool:
    if not isinstance(expected, dict) or not isinstance(actual, dict):
        return False
    return (
        expected.get("present") is True
        and actual.get("present") is True
        and str(expected.get("sha256") or "")
        == str(actual.get("sha256") or "")
    )


def _iter_stage_files(root: str) -> Iterable[tuple[str, str, bool]]:
    for directory, dirs, files in os.walk(root):
        link_dirs = [
            name
            for name in dirs
            if os.path.islink(os.path.join(directory, name))
        ]
        dirs[:] = [name for name in dirs if name not in link_dirs]
        dirs.sort()
        files.sort()
        for name in sorted(link_dirs) + files:
            absolute = os.path.join(directory, name)
            relative = os.path.relpath(absolute, root).replace(os.sep, "/")
            yield relative, absolute, os.path.islink(absolute)


def _iter_stage_directories(root: str) -> Iterable[str]:
    for directory, dirs, _files in os.walk(root, followlinks=False):
        dirs.sort()
        for name in dirs:
            absolute = os.path.join(directory, name)
            if os.path.islink(absolute):
                continue
            relative = os.path.relpath(absolute, root).replace(os.sep, "/")
            yield relative.rstrip("/") + "/"


def _symlink_bytes(path: str) -> bytes:
    try:
        return os.readlink(path).encode("utf-8")
    except UnicodeEncodeError as exc:
        raise ArchiveError(
            "archive_path_unsafe",
            "A symbolic-link target is not valid UTF-8",
            details={"path": path},
        ) from exc


def write_checksums(stage_root: str) -> dict[str, str]:
    checksums: dict[str, str] = {}
    for relative, absolute, is_link in _iter_stage_files(stage_root):
        if relative == CHECKSUMS_NAME:
            continue
        checksums[relative] = (
            sha256_bytes(_symlink_bytes(absolute))
            if is_link
            else sha256_file(absolute)
        )
    path = os.path.join(stage_root, CHECKSUMS_NAME)
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        for relative, digest in sorted(checksums.items()):
            handle.write(f"{digest}  {relative}\n")
    os.chmod(path, 0o600)
    return checksums


def _write_manifest(stage_root: str, manifest: dict[str, Any]) -> None:
    path = os.path.join(stage_root, MANIFEST_NAME)
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        json.dump(manifest, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")
    os.chmod(path, 0o600)


def build_archive(
    stage_root: str,
    output_path: str,
    manifest: dict[str, Any],
) -> dict[str, Any]:
    manifest = dict(manifest)
    manifest["archive_schema"] = ARCHIVE_SCHEMA
    manifest["archive_type"] = ARCHIVE_TYPE
    _write_manifest(stage_root, manifest)
    checksums = write_checksums(stage_root)

    output_path = os.path.abspath(output_path)
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    fd, temporary = tempfile.mkstemp(
        prefix=".ghostacct-", suffix=".partial", dir=os.path.dirname(output_path)
    )
    os.close(fd)
    try:
        with zipfile.ZipFile(
            temporary,
            "w",
            compression=zipfile.ZIP_DEFLATED,
            compresslevel=6,
            allowZip64=True,
        ) as archive:
            for relative in _iter_stage_directories(stage_root):
                info = zipfile.ZipInfo(relative)
                info.create_system = 3
                info.external_attr = ((stat.S_IFDIR | 0o700) << 16) | 0x10
                archive.writestr(info, b"")
            for relative, absolute, is_link in _iter_stage_files(stage_root):
                if not is_link:
                    archive.write(absolute, relative)
                    continue
                info = zipfile.ZipInfo(relative)
                info.create_system = 3
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = (stat.S_IFLNK | 0o777) << 16
                archive.writestr(info, _symlink_bytes(absolute))
        os.chmod(temporary, 0o600)
        validated = validate_archive(temporary)
        os.replace(temporary, output_path)
    except Exception:
        try:
            os.remove(temporary)
        except OSError:
            pass
        raise
    return {
        "archive_path": output_path,
        "archive_sha256": sha256_file(output_path),
        "size_bytes": os.path.getsize(output_path),
        "entry_count": validated["entry_count"],
        "checksums": len(checksums),
        "manifest": validated["manifest"],
    }


def _safe_member_name(name: str) -> bool:
    if not name or "\x00" in name or name.startswith(("/", "\\")):
        return False
    normalized = pathlib.PurePosixPath(name.replace("\\", "/"))
    return all(part not in {"", ".", ".."} for part in normalized.parts)


def _parse_checksums(raw: bytes) -> dict[str, str]:
    result: dict[str, str] = {}
    try:
        lines = raw.decode("utf-8").splitlines()
    except UnicodeDecodeError as exc:
        raise ArchiveError("archive_invalid", "SHA256SUMS is not UTF-8") from exc
    for line in lines:
        if not line:
            continue
        if "  " not in line:
            raise ArchiveError("archive_invalid", "Malformed SHA256SUMS entry")
        digest, name = line.split("  ", 1)
        if len(digest) != 64 or any(ch not in "0123456789abcdef" for ch in digest):
            raise ArchiveError("archive_invalid", "Malformed SHA-256 digest")
        if not _safe_member_name(name) or name == CHECKSUMS_NAME:
            raise ArchiveError(
                "archive_invalid", "Unsafe member name in SHA256SUMS"
            )
        if name in result:
            raise ArchiveError("archive_invalid", "Duplicate SHA256SUMS entry")
        result[name] = digest
    return result


def _safe_symlink_target(member: str, raw: bytes) -> str:
    try:
        target = raw.decode("utf-8")
    except UnicodeDecodeError:
        return ""
    if (
        not target
        or "\x00" in target
        or "\\" in target
        or target.startswith("/")
    ):
        return ""
    parts = pathlib.PurePosixPath(member).parts
    if (
        len(parts) < 5
        or parts[0] != "Apps"
        or parts[2] != "roots"
    ):
        return ""
    roots_prefix = "/".join(parts[:3])
    resolved = posixpath.normpath(
        posixpath.join(posixpath.dirname(member), target)
    )
    resolved_parts = pathlib.PurePosixPath(resolved).parts
    if (
        len(resolved_parts) < 4
        or "/".join(resolved_parts[:3]) != roots_prefix
    ):
        return ""
    return resolved


def validate_archive(path: str | os.PathLike[str]) -> dict[str, Any]:
    archive_path = os.fspath(path)
    if not os.path.isfile(archive_path):
        raise ArchiveError(
            "archive_missing", f"Archive does not exist: {archive_path}"
        )
    try:
        archive = zipfile.ZipFile(archive_path, "r")
    except Exception as exc:
        raise ArchiveError(
            "archive_invalid", f"Archive cannot be opened: {type(exc).__name__}"
        ) from exc
    with archive:
        entries = archive.infolist()
        if len(entries) > MAX_ARCHIVE_ENTRIES:
            raise ArchiveError("archive_too_large", "Archive has too many entries")
        total_size = sum(int(item.file_size) for item in entries)
        if total_size > MAX_UNCOMPRESSED_BYTES:
            raise ArchiveError(
                "archive_too_large", "Archive uncompressed size exceeds the limit"
            )
        names: set[str] = set()
        symlink_names: set[str] = set()
        symlink_targets: dict[str, str] = {}
        for item in entries:
            name = item.filename
            if not _safe_member_name(name):
                raise ArchiveError(
                    "archive_path_unsafe",
                    "Archive contains an unsafe path",
                    details={"member": name},
                )
            if name in names:
                raise ArchiveError(
                    "archive_invalid",
                    "Archive contains a duplicate member",
                    details={"member": name},
                )
            names.add(name)
            unix_mode = (item.external_attr >> 16) & 0xFFFF
            if unix_mode and stat.S_ISLNK(unix_mode):
                if item.is_dir() or item.file_size > 4096:
                    raise ArchiveError(
                        "archive_path_unsafe",
                        "Archive contains an invalid symbolic link",
                        details={"member": name},
                    )
                target_raw = archive.read(item)
                resolved_target = _safe_symlink_target(name, target_raw)
                if not resolved_target:
                    raise ArchiveError(
                        "archive_path_unsafe",
                        (
                            "Archive symbolic link escapes the selected "
                            "application roots"
                        ),
                        details={"member": name},
                    )
                symlink_names.add(name.rstrip("/"))
                symlink_targets[name.rstrip("/")] = resolved_target
        for link_name in symlink_names:
            if any(
                name != link_name and name.startswith(link_name + "/")
                for name in names
            ):
                raise ArchiveError(
                    "archive_path_unsafe",
                    "Archive contains members below a symbolic link",
                    details={"member": link_name},
                )
        required = {MANIFEST_NAME, CHECKSUMS_NAME, IDENTITY_MEMBER}
        missing = sorted(required - names)
        if missing:
            raise ArchiveError(
                "archive_section_missing",
                "Archive is missing required top-level members",
                details={"missing": missing},
            )
        try:
            manifest = json.loads(archive.read(MANIFEST_NAME).decode("utf-8"))
        except Exception as exc:
            raise ArchiveError(
                "archive_invalid", "Manifest.json is invalid"
            ) from exc
        if not isinstance(manifest, dict):
            raise ArchiveError("archive_invalid", "Manifest root is not an object")
        if manifest.get("archive_schema") != ARCHIVE_SCHEMA:
            raise ArchiveError(
                "archive_schema_unsupported",
                "Archive schema is unsupported",
                details={"schema": manifest.get("archive_schema")},
            )
        if manifest.get("archive_type") != ARCHIVE_TYPE:
            raise ArchiveError("archive_invalid", "Archive type is incorrect")
        selection = str(manifest.get("selection") or "")
        if selection not in VALID_SELECTORS:
            raise ArchiveError("archive_invalid", "Manifest selection is invalid")
        apps = manifest.get("apps")
        if not isinstance(apps, dict):
            raise ArchiveError("archive_invalid", "Manifest apps is invalid")
        expected_apps = (
            {"instagram", "threads"}
            if selection == "both"
            else {selection}
        )
        if set(apps) != expected_apps:
            raise ArchiveError(
                "archive_section_missing",
                "Manifest app sections do not match selection",
                details={"expected": sorted(expected_apps), "actual": sorted(apps)},
            )
        checksums = _parse_checksums(archive.read(CHECKSUMS_NAME))
        actual_files = {
            name
            for name in names
            if name != CHECKSUMS_NAME and not name.endswith("/")
        }
        if set(checksums) != actual_files:
            raise ArchiveError(
                "archive_checksum_set_mismatch",
                "SHA256SUMS does not cover exactly every archive file",
                details={
                    "missing": sorted(actual_files - set(checksums))[:20],
                    "extra": sorted(set(checksums) - actual_files)[:20],
                },
            )
        for name, expected in checksums.items():
            actual = sha256_bytes(archive.read(name))
            if actual != expected:
                raise ArchiveError(
                    "archive_checksum_mismatch",
                    "Archive member checksum is incorrect",
                    details={"member": name, "expected": expected, "actual": actual},
                )
        identity_raw = archive.read(IDENTITY_MEMBER)
        identity = validate_ghost_profile(identity_raw)
        manifest_identity = manifest.get("identity") or {}
        if (
            not isinstance(manifest_identity, dict)
            or manifest_identity.get("profile_sha256")
            != identity["profile_sha256"]
        ):
            raise ArchiveError(
                "identity_mismatch",
                "Manifest identity does not match the canonical profile",
                details={
                    "manifest": manifest_identity,
                    "profile": identity,
                },
            )
        for app_key in expected_apps:
            app = apps.get(app_key)
            if not isinstance(app, dict):
                raise ArchiveError(
                    "archive_section_missing",
                    f"Archive app section is missing: {app_key}",
                )
            expected_bundle = APP_BUNDLES[app_key]
            if app.get("bundle_id") != expected_bundle:
                raise ArchiveError(
                    "archive_invalid",
                    "App bundle id is incorrect",
                    details={"app": app_key, "bundle_id": app.get("bundle_id")},
                )
            keychain_member = f"Apps/{app_key}/Keychain.plist"
            if keychain_member not in names:
                raise ArchiveError(
                    "archive_section_missing",
                    f"Archive keychain section is missing: {app_key}",
                )
            stored_fingerprint = app.get("keychain_fingerprint")
            live_fingerprint = keychain_fingerprint(
                plistlib.loads(archive.read(keychain_member))
            )
            if (
                not isinstance(stored_fingerprint, dict)
                or stored_fingerprint.get("sha256") != live_fingerprint["sha256"]
            ):
                raise ArchiveError(
                    "keychain_fingerprint_mismatch",
                    "Manifest keychain fingerprint does not match",
                    details={"app": app_key},
                )
            roots = app.get("roots")
            if not isinstance(roots, dict) or expected_bundle not in roots:
                raise ArchiveError(
                    "archive_section_missing",
                    "Primary application root is missing",
                    details={"app": app_key},
                )
            declared_root_dirs: set[str] = set()
            for root_id, member_dir in roots.items():
                if (
                    not isinstance(member_dir, str)
                    or not member_dir
                    or "/" in member_dir
                    or "\\" in member_dir
                    or member_dir in {".", ".."}
                ):
                    raise ArchiveError(
                        "archive_path_unsafe",
                        "A declared Crane root directory is unsafe",
                        details={"app": app_key, "root": root_id},
                    )
                declared_root_dirs.add(member_dir)
                expected_prefix = f"Apps/{app_key}/roots/{member_dir}/"
                if expected_prefix not in names and not any(
                    name.startswith(expected_prefix) for name in names
                ):
                    raise ArchiveError(
                        "archive_section_missing",
                        "A declared Crane root has no archive members",
                        details={"app": app_key, "root": root_id},
                    )
            for link_name, resolved_target in symlink_targets.items():
                link_parts = pathlib.PurePosixPath(link_name).parts
                if len(link_parts) < 4 or link_parts[1] != app_key:
                    continue
                target_parts = pathlib.PurePosixPath(
                    resolved_target
                ).parts
                if (
                    link_parts[3] not in declared_root_dirs
                    or target_parts[3] not in declared_root_dirs
                ):
                    raise ArchiveError(
                        "archive_path_unsafe",
                        (
                            "Archive symbolic link references an "
                            "undeclared Crane root"
                        ),
                        details={
                            "app": app_key,
                            "member": link_name,
                            "target": resolved_target,
                        },
                    )
        for link_name in symlink_targets:
            link_parts = pathlib.PurePosixPath(link_name).parts
            if (
                len(link_parts) < 4
                or link_parts[1] not in expected_apps
            ):
                raise ArchiveError(
                    "archive_path_unsafe",
                    "Archive symbolic link belongs to an undeclared app",
                    details={"member": link_name},
                )
        return {
            "manifest": manifest,
            "identity": identity,
            "identity_raw": identity_raw,
            "entry_count": len(entries),
            "uncompressed_bytes": total_size,
            "archive_sha256": sha256_file(archive_path),
        }


def extract_archive(
    archive_path: str | os.PathLike[str],
    destination: str | os.PathLike[str],
) -> dict[str, Any]:
    validated = validate_archive(archive_path)
    target = os.path.abspath(os.fspath(destination))
    shutil.rmtree(target, ignore_errors=True)
    os.makedirs(target, mode=0o700, exist_ok=True)
    with zipfile.ZipFile(archive_path, "r") as archive:
        for item in archive.infolist():
            name = item.filename.replace("\\", "/")
            output = os.path.abspath(os.path.join(target, *name.split("/")))
            if os.path.commonpath((target, output)) != target:
                raise ArchiveError(
                    "archive_path_unsafe",
                    "Archive extraction escaped its destination",
                    details={"member": name},
                )
            if item.is_dir():
                os.makedirs(output, mode=0o700, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(output), mode=0o700, exist_ok=True)
            unix_mode = (item.external_attr >> 16) & 0xFFFF
            if unix_mode and stat.S_ISLNK(unix_mode):
                target_value = archive.read(item).decode("utf-8")
                os.symlink(target_value, output)
                continue
            with archive.open(item, "r") as source, open(output, "wb") as sink:
                shutil.copyfileobj(source, sink, length=1024 * 1024)
            os.chmod(output, 0o600)
    return validated
