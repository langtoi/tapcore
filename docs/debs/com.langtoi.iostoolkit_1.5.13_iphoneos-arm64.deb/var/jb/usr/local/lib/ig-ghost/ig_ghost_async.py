"""Detached job launcher for the active Instagram / Threads workflows.

The AutoTouch/BAS ``RUNLUA`` bridge must return quickly; keeping its Lua
``execute()`` call open for the 45-second warm-up is unreliable when AutoTouch
loses foreground execution.  This module starts the real workflow in a new
session, persists an inspectable job record, and provides a fast ``status``
command for polling.

A selector picks which guarded workflow the worker runs:

* ``instagram`` — Instagram only (``ig_ghost_workflow.run_force_active``).
* ``threads``   — Threads only (``threads_ghost_workflow.run_force_threads``),
  which reads the active Instagram container as its identity source.
* ``both``      — the Instagram-then-Threads meta workflow
  (``meta_ghost_workflow.run_force_meta``). This is the default, so a bare
  ``ghost_instagram`` is unchanged.
"""
from __future__ import annotations

import fcntl
import json
import os
import re
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path
from typing import Any


SCHEMA = 1
JOB_DIR = Path(
    os.environ.get(
        "IG_GHOST_JOB_DIR", "/var/mobile/Library/Logs/ig-ghost/jobs"
    )
)
LATEST_PATH = Path(
    os.environ.get(
        "IG_GHOST_LATEST_JOB",
        "/var/mobile/Library/Logs/ig-ghost/ghost_instagram_job_latest.json",
    )
)
LAUNCH_LOCK = Path(
    os.environ.get(
        "IG_GHOST_LAUNCH_LOCK",
        "/var/mobile/Library/Caches/com.langtoi.ghost-instagram-launch.lock",
    )
)
WORKER_LOG = Path(
    os.environ.get(
        "IG_GHOST_WORKER_LOG",
        "/var/mobile/Library/Logs/ig-ghost/ghost_instagram_worker.log",
    )
)
SELF_PATH = os.environ.get(
    "IG_GHOST_ASYNC_SELF",
    "/var/jb/usr/local/lib/ig-ghost/ig_ghost_async.py",
)
MAX_SAVED_JOBS = 20
JOB_ID_RE = re.compile(r"^[a-f0-9]{32}$")

# Selector decides which guarded workflow the worker runs. ``both`` is the
# historical Instagram-then-Threads meta workflow and stays the default so a
# bare ``ghost_instagram`` keeps behaving exactly as before.
DEFAULT_SELECTOR = "both"
SELECTOR_ALIASES = {
    "instagram": "instagram",
    "ig": "instagram",
    "threads": "threads",
    "th": "threads",
    "thread": "threads",
    "both": "both",
    "meta": "both",
}
SELECTORS = ("instagram", "threads", "both")
# Which wrapper a user polls status through, per selector.
STATUS_WRAPPER = {
    "instagram": "/var/jb/usr/bin/ghost_ig",
    "threads": "/var/jb/usr/bin/ghost_th",
    "both": "/var/jb/usr/bin/ghost_instagram",
}


def _normalize_selector(value: Any) -> str:
    if value is None:
        return DEFAULT_SELECTOR
    return SELECTOR_ALIASES.get(str(value).strip().lower(), DEFAULT_SELECTOR)


def _is_selector_token(value: Any) -> bool:
    return value is not None and str(value).strip().lower() in SELECTOR_ALIASES


def _status_command(selector: str) -> str:
    return f"{STATUS_WRAPPER.get(selector, STATUS_WRAPPER['both'])} status"


def _selector_latest_path(selector: str) -> Path:
    # ``both`` shares the historical global pointer so a plain
    # ``ghost_instagram status`` keeps resolving the meta job. Per-app selectors
    # get their own pointer so each app's status is retrievable independently.
    if not selector or selector == "both":
        return LATEST_PATH
    return LATEST_PATH.with_name(
        f"{LATEST_PATH.stem}.{selector}{LATEST_PATH.suffix}"
    )


def _run_selected(selector: str) -> dict[str, Any]:
    if selector == "instagram":
        import ig_ghost_workflow

        return ig_ghost_workflow.run_force_active()
    if selector == "threads":
        import threads_ghost_workflow

        return threads_ghost_workflow.run_force_threads()
    import meta_ghost_workflow

    return meta_ghost_workflow.run_force_meta()


def _atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".ig-ghost-job-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, 0o644)
        os.replace(temporary, path)
    except Exception:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise


def _read_json(path: Path) -> dict[str, Any] | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return None
    return value if isinstance(value, dict) else None


def _job_path(job_id: str) -> Path:
    if not JOB_ID_RE.fullmatch(job_id):
        raise ValueError("invalid_job_id")
    return JOB_DIR / f"{job_id}.json"


def _pid_alive(pid: Any) -> bool:
    try:
        value = int(pid)
        if value <= 0:
            return False
        os.kill(value, 0)
        return True
    except (OSError, TypeError, ValueError):
        return False


def _write_state(payload: dict[str, Any]) -> None:
    job_id = str(payload["job_id"])
    selector = _normalize_selector(payload.get("selector"))
    _atomic_json(_job_path(job_id), payload)
    pointer = {
        "schema": SCHEMA,
        "job_id": job_id,
        "state_path": str(_job_path(job_id)),
        "selector": selector,
        "updated_at": time.time(),
    }
    # Global pointer drives the cross-selector busy check; the per-selector
    # pointer lets each app's status be polled on its own.
    _atomic_json(LATEST_PATH, pointer)
    selector_path = _selector_latest_path(selector)
    if selector_path != LATEST_PATH:
        _atomic_json(selector_path, pointer)


def _latest_job_id(selector: str | None = None) -> str | None:
    pointer = _read_json(_selector_latest_path(selector or DEFAULT_SELECTOR)) or {}
    job_id = str(pointer.get("job_id") or "")
    return job_id if JOB_ID_RE.fullmatch(job_id) else None


def _mark_dead_worker(payload: dict[str, Any]) -> dict[str, Any]:
    if payload.get("state") not in {"starting", "running"}:
        return payload
    if _pid_alive(payload.get("pid")):
        return payload
    updated = {
        **payload,
        "state": "finished",
        "success": False,
        "verdict": "FAIL",
        "error": "worker_died",
        "finished_at": time.time(),
    }
    _write_state(updated)
    return updated


def read_status(
    job_id: str | None = None, selector: str | None = None
) -> dict[str, Any]:
    selected = job_id or _latest_job_id(selector)
    if not selected:
        return {
            "schema": SCHEMA,
            "success": False,
            "state": "missing",
            "error": "job_not_found",
        }
    try:
        payload = _read_json(_job_path(selected))
    except ValueError:
        payload = None
    if payload is None:
        return {
            "schema": SCHEMA,
            "success": False,
            "state": "missing",
            "job_id": selected,
            "error": "job_not_found",
        }
    return _mark_dead_worker(payload)


def _cleanup_old_jobs() -> None:
    try:
        rows = sorted(
            JOB_DIR.glob("*.json"), key=lambda path: path.stat().st_mtime, reverse=True
        )
    except OSError:
        return
    for path in rows[MAX_SAVED_JOBS:]:
        try:
            path.unlink()
        except OSError:
            pass


def start_job(selector: str | None = None) -> tuple[dict[str, Any], int]:
    selector = _normalize_selector(selector)
    status_command = _status_command(selector)
    LAUNCH_LOCK.parent.mkdir(parents=True, exist_ok=True)
    with LAUNCH_LOCK.open("a+") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        # The busy check reads the global pointer, so a job for any selector
        # blocks a new one — one workflow may touch the containers at a time.
        current = read_status()
        if current.get("state") in {"starting", "running"} and _pid_alive(
            current.get("pid")
        ):
            return (
                {
                    "schema": SCHEMA,
                    "success": False,
                    "accepted": False,
                    "state": current.get("state"),
                    "error": "workflow_busy",
                    "job_id": current.get("job_id"),
                    "pid": current.get("pid"),
                    "selector": current.get("selector"),
                    "status_command": _status_command(
                        _normalize_selector(current.get("selector"))
                    ),
                },
                1,
            )

        now = time.time()
        job_id = uuid.uuid4().hex
        state = {
            "schema": SCHEMA,
            "success": True,
            "accepted": True,
            "state": "starting",
            "job_id": job_id,
            "selector": selector,
            "pid": 0,
            "started_at": now,
            "updated_at": now,
            "status_path": str(_job_path(job_id)),
            "status_command": status_command,
        }
        _write_state(state)
        WORKER_LOG.parent.mkdir(parents=True, exist_ok=True)
        environment = dict(os.environ)
        environment["PATH"] = (
            "/bin:/usr/bin:/var/jb/bin:/var/jb/usr/bin:/var/jb/usr/sbin:"
            + environment.get("PATH", "")
        )
        with WORKER_LOG.open("ab", buffering=0) as log:
            process = subprocess.Popen(
                [sys.executable, SELF_PATH, "_worker", job_id, selector],
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                cwd="/",
                env=environment,
                close_fds=True,
                start_new_session=True,
            )
        state.update(
            {
                "state": "running",
                "pid": int(process.pid),
                "updated_at": time.time(),
            }
        )
        _write_state(state)
        _cleanup_old_jobs()
        return state, 0


def run_worker(job_id: str, selector: str | None = None) -> int:
    try:
        path = _job_path(job_id)
    except ValueError:
        return 2

    # The launcher holds this lock until it has persisted our PID. Waiting for
    # it removes the parent/child state-write race without keeping the lock for
    # the long workflow itself.
    LAUNCH_LOCK.parent.mkdir(parents=True, exist_ok=True)
    with LAUNCH_LOCK.open("a+") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        state = _read_json(path) or {
            "schema": SCHEMA,
            "job_id": job_id,
            "started_at": time.time(),
        }
        # The explicit argv selector wins; fall back to whatever start_job
        # persisted, then to the historical meta default.
        selector = _normalize_selector(selector or state.get("selector"))
        state.update(
            {
                "success": True,
                "accepted": True,
                "state": "running",
                "selector": selector,
                "pid": os.getpid(),
                "updated_at": time.time(),
                "status_path": str(path),
                "status_command": _status_command(selector),
            }
        )
        _write_state(state)

    try:
        result = _run_selected(selector)
    except Exception as exc:
        result = {
            "success": False,
            "verdict": "FAIL",
            "stage": "async_worker",
            "error": type(exc).__name__,
            "message": str(exc),
        }

    finished = time.time()
    final = {
        **state,
        "success": result.get("success") is True,
        "state": "finished",
        "verdict": result.get("verdict") or (
            "PASS" if result.get("success") is True else "FAIL"
        ),
        "error": result.get("error") or "",
        "stage": result.get("stage") or "",
        "finished_at": finished,
        "updated_at": finished,
        "elapsed_seconds": round(finished - float(state.get("started_at", finished)), 3),
        "report_path": result.get("report_path"),
        "result": result,
    }
    _write_state(final)
    return 0 if final["success"] else 1


def run_synchronous(selector: str, arguments: list[str]) -> int:
    selector = _normalize_selector(selector)
    if selector == "both":
        # Preserve the meta workflow's own CLI (argument parsing, output shape).
        from meta_ghost_workflow import main as workflow_main

        return workflow_main(arguments)
    result = _run_selected(selector)
    _print(result)
    return 0 if result.get("success") is True else 1


def _print(payload: dict[str, Any]) -> None:
    print(json.dumps(payload, ensure_ascii=False, separators=(",", ":")))


def main(argv: list[str] | None = None) -> int:
    arguments = list(sys.argv[1:] if argv is None else argv)

    # An optional leading selector token binds the whole invocation to one app.
    # This is how the ghost_ig / ghost_th wrappers work (``… instagram status``),
    # so a subcommand still reaches the right app instead of starting a new job.
    # ``_worker`` is internal and never carries a leading selector.
    forced_selector: str | None = None
    if arguments and arguments[0] != "_worker" and _is_selector_token(arguments[0]):
        forced_selector = _normalize_selector(arguments[0])
        arguments = arguments[1:]

    command = arguments[0] if arguments else "start"

    if command == "_worker":
        job_id = arguments[1] if len(arguments) > 1 else ""
        selector = arguments[2] if len(arguments) > 2 else None
        return run_worker(job_id, selector)

    if command == "status":
        token = arguments[1] if len(arguments) > 1 else None
        selector = forced_selector
        job_id: str | None = None
        if _is_selector_token(token):
            selector = _normalize_selector(token)
        elif token:
            job_id = token
        payload = read_status(job_id, selector)
        _print(payload)
        return 0 if payload.get("state") == "running" or payload.get("success") else 1

    if command == "run":
        rest = arguments[1:]
        selector = forced_selector or DEFAULT_SELECTOR
        if forced_selector is None and rest and _is_selector_token(rest[0]):
            selector = _normalize_selector(rest[0])
            rest = rest[1:]
        return run_synchronous(selector, rest)

    if command == "start":
        rest = arguments[1:]
        selector = forced_selector
        if selector is None:
            selector = (
                _normalize_selector(rest[0])
                if rest and _is_selector_token(rest[0])
                else DEFAULT_SELECTOR
            )
        payload, returncode = start_job(selector)
        _print(payload)
        return returncode

    # No recognised subcommand. A bare selector (``ghost_ig`` → ``instagram``)
    # is the common case and means "start that app".
    if not arguments or forced_selector is not None:
        payload, returncode = start_job(forced_selector or DEFAULT_SELECTOR)
        _print(payload)
        return returncode

    _print(
        {
            "schema": SCHEMA,
            "success": False,
            "error": (
                "usage: ghost_instagram [instagram|threads|both] "
                "| [selector] start|status [job_id]|run"
            ),
        }
    )
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
