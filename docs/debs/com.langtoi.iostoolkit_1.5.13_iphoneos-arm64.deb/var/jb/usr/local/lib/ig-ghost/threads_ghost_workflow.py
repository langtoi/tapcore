"""Force Threads to use the currently active Instagram Crane identity.

The active Instagram container is the only identity source.  Every invocation
rechecks both Crane selections, copies the exact Instagram profile bytes only
to the active Threads container and its early-reader parent, writes a fresh
Threads Guard snapshot, launches a new Threads PID, and validates a closed
45-second request-accounting window.  No container is created, switched, or
randomized here.
"""
from __future__ import annotations

import argparse
import contextlib
import dataclasses
import fcntl
import hashlib
import json
import os
import plistlib
import re
import subprocess
import tempfile
import time
import urllib.request
from typing import Any, Iterable, Optional


IG_BUNDLE_ID = "com.burbn.instagram"
THREADS_BUNDLE_ID = "com.burbn.barcelona"
GHOST_PLIST = "com.sgwc.ghostprefs.plist"
CRANE_RELATIVE_ROOT = "Library/___Crane_Containers"
IG_SNAPSHOT_RELATIVE_PATH = (
    "Library/Preferences/com.langtoi.igghostguard.snapshot.plist"
)
THREADS_SNAPSHOT_RELATIVE_PATH = (
    "Library/Preferences/com.langtoi.threadsghostguard.snapshot.plist"
)
THREADS_STATUS_RELATIVE_PATH = (
    "Library/Caches/com.langtoi.threadsghostguard.status.plist"
)
THREADS_PREFS_RELATIVE_PATH = "Library/Preferences/com.burbn.barcelona.plist"
WORKFLOW_VERSION = "1.7"
GUARD_VERSION = "1.3.2"
WARMUP_SECONDS = 45
MAX_WARMUP_SECONDS = 120
MIN_REQUESTS = 100
FRESH_CONTAINER_MIN_REQUESTS = 1
FEED_REFRESH_INTERVAL_SECONDS = 6
FEED_SCROLL_FIRST_DELAY_SECONDS = 5
FEED_SCROLL_RETRY_INTERVAL_SECONDS = 30
FEED_SCROLL_SWIPE_COUNT = 10
# Minimum time the contract must hold before the warm-up loop is allowed to exit
# early. The counters are already authoritative; this only stops a launch that
# has not issued its first request yet from being accepted on an empty window.
CONTRACT_SETTLE_SECONDS = 2.0
LEGACY_SYNC_LABEL = "user/501/com.langtoi.ghost-global-sync"


@dataclasses.dataclass(frozen=True)
class WorkflowPaths:
    data_root: str = "/var/mobile/Containers/Data/Application"
    crane_prefs_candidates: tuple[str, ...] = (
        "/var/jb/var/mobile/Library/Preferences/com.opa334.craneprefs.plist",
        "/var/mobile/Library/Preferences/com.opa334.craneprefs.plist",
    )
    global_profile: str = (
        "/var/mobile/Library/Preferences/Ghost/com.sgwc.ghostprefs.plist"
    )
    lock_path: str = "/var/mobile/Library/Caches/com.langtoi.ghost-threads.lock"
    latest_report: str = (
        "/var/mobile/Library/Logs/ig-ghost/ghost_threads_latest.json"
    )
    crash_root: str = "/var/mobile/Library/Logs/CrashReporter"
    crane_cli: str = "/var/jb/usr/bin/crane-cli"
    killall: str = "/var/jb/usr/bin/killall"
    ps: str = "/bin/ps"
    uiopen: str = "/var/jb/usr/bin/uiopen"
    autotouch_endpoint: str = "http://127.0.0.1:3000/"
    sudo: str = "/var/jb/usr/bin/sudo"
    launchctl: str = "/var/jb/usr/bin/launchctl"
    guard_dylib: str = "/var/jb/usr/lib/TweakInject/ThreadsGhostGuard.dylib"
    guard_filter: str = "/var/jb/usr/lib/TweakInject/ThreadsGhostGuard.plist"
    legacy_sync_dylib: str = "/var/jb/usr/lib/TweakInject/IGUAFix.dylib"
    legacy_sync_filter: str = "/var/jb/usr/lib/TweakInject/IGUAFix.plist"
    sanitize_backup_root: str = (
        "/var/mobile/igghostguard_sanitize_backups/threads"
    )


DEFAULT_PATHS = WorkflowPaths()


@dataclasses.dataclass(frozen=True)
class ActiveContainer:
    bundle_id: str
    identifier: str
    name: str
    app_root: str
    root: str
    source_path: str
    parent_profile_path: str


class WorkflowError(RuntimeError):
    def __init__(
        self,
        code: str,
        message: str,
        *,
        stage: str,
        details: Optional[dict[str, Any]] = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.stage = stage
        self.details = details or {}


class CommandRunner:
    def run(
        self,
        argv: Iterable[str],
        *,
        timeout: int = 30,
        input_text: Optional[str] = None,
    ) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            list(argv),
            input=input_text,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )


def _read_bytes(path: str) -> bytes:
    with open(path, "rb") as handle:
        return handle.read()


def _read_plist(path: str) -> dict[str, Any]:
    with open(path, "rb") as handle:
        value = plistlib.load(handle)
    if not isinstance(value, dict):
        raise ValueError("plist root is not a dictionary")
    return value


def _sha256(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _has_nonzero_account_identifier(value: Any) -> bool:
    """Return whether a known Threads account marker contains a real id."""
    if value is None or isinstance(value, bool):
        return False
    if isinstance(value, (int, float)):
        return value != 0
    if isinstance(value, str):
        normalized = value.strip().lower()
        return normalized not in {
            "",
            "0",
            "(null)",
            "null",
            "none",
            "unknown",
        }
    if isinstance(value, (list, tuple, set)):
        return any(_has_nonzero_account_identifier(item) for item in value)
    return False


def _threads_session_context(active: ActiveContainer) -> dict[str, Any]:
    """Select the request contract from active Threads account evidence.

    A newly created Crane container has no authenticated feed, so it cannot
    produce 100 requests.  We accept the smaller bootstrap contract only when
    the preferences are missing or explicitly contain Threads' logged-out
    markers.  Unreadable or ambiguous preferences fail closed to the full
    authenticated contract.
    """
    preferences_path = os.path.join(active.root, THREADS_PREFS_RELATIVE_PATH)
    if not os.path.isfile(preferences_path):
        return {
            "state": "fresh_logged_out",
            "account_marker_present": False,
            "fresh_container_bootstrap": True,
            "preferences_path": preferences_path,
            "evidence": ["preferences_missing"],
        }
    try:
        preferences = _read_plist(preferences_path)
    except Exception as exc:
        return {
            "state": "unknown_require_full",
            "account_marker_present": None,
            "fresh_container_bootstrap": False,
            "preferences_path": preferences_path,
            "read_error": type(exc).__name__,
        }

    analytics_identity = preferences.get(
        "FBAnalyticsCurrentLoggedInUserIdentityDict"
    )
    app_uid: Any = None
    if isinstance(analytics_identity, dict):
        app_uid = analytics_identity.get("app_uid")
    known_markers = {
        "analytics_app_uid": app_uid,
        "last_known_owner_fbid": preferences.get(
            "kFBQPLLoggingPolicyLastKnownOwnerFbID"
        ),
        "account_model_owner_fbids": preferences.get(
            "kFBQPLLoggingPolicyAccountModelsOwnerFbIDsKey"
        ),
    }
    account_sources = sorted(
        key
        for key, value in known_markers.items()
        if _has_nonzero_account_identifier(value)
    )
    if account_sources:
        return {
            "state": "account_marker_present",
            "account_marker_present": True,
            "fresh_container_bootstrap": False,
            "preferences_path": preferences_path,
            "account_marker_sources": account_sources,
        }

    logged_out_data_present = "logged-out-data" in preferences
    explicit_zero_marker = any(
        value is not None and not _has_nonzero_account_identifier(value)
        for value in known_markers.values()
    )
    if logged_out_data_present or explicit_zero_marker:
        evidence: list[str] = []
        if logged_out_data_present:
            evidence.append("logged-out-data")
        if explicit_zero_marker:
            evidence.append("zero_account_marker")
        return {
            "state": "fresh_logged_out",
            "account_marker_present": False,
            "fresh_container_bootstrap": True,
            "preferences_path": preferences_path,
            "evidence": evidence,
        }

    return {
        "state": "unknown_require_full",
        "account_marker_present": None,
        "fresh_container_bootstrap": False,
        "preferences_path": preferences_path,
        "evidence": ["no_known_session_marker"],
    }


def _bootstrap_contract_must_upgrade(session_context: dict[str, Any]) -> bool:
    """Upgrade an established bootstrap run only on positive login evidence.

    Threads writes its preferences in stages on first launch.  A new container
    can therefore move briefly from preferences-missing to an otherwise empty
    plist before its explicit logged-out markers appear.  That transient
    unknown state must not turn a 45-second bootstrap into a futile 120-second
    authenticated wait.  An invocation which *starts* unknown still selects
    the full contract; this helper only governs later upgrades.
    """
    return session_context.get("account_marker_present") is True


def _file_sha256(path: str) -> str:
    return _sha256(_read_bytes(path))


def _atomic_write(path: str, raw: bytes, mode: int = 0o644) -> None:
    parent = os.path.dirname(path) or "."
    os.makedirs(parent, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".ghost-threads-", dir=parent)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, mode)
        os.replace(temporary, path)
    except Exception:
        with contextlib.suppress(OSError):
            os.unlink(temporary)
        raise


def _write_json_atomic(path: str, payload: dict[str, Any]) -> None:
    _atomic_write(
        path,
        (json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode(
            "utf-8"
        ),
    )


def _remove(path: str) -> None:
    with contextlib.suppress(FileNotFoundError):
        os.unlink(path)


def _validate_identity(raw: bytes) -> dict[str, Any]:
    try:
        prefs = plistlib.loads(raw)
    except Exception as exc:
        raise WorkflowError(
            "instagram_profile_invalid",
            f"The active Instagram profile cannot be parsed: {type(exc).__name__}",
            stage="validate_source",
        ) from exc
    if not isinstance(prefs, dict):
        raise WorkflowError(
            "instagram_profile_invalid",
            "The active Instagram profile is not a dictionary",
            stage="validate_source",
        )
    import ig_ghost_guard_cli as guard

    model = str(prefs.get("deviceModel") or "").strip()
    identity = {
        "model": model,
        "hardware": str(prefs.get("deviceHardwareModel") or "").strip(),
        "display_name": str(prefs.get("deviceDisplayName") or "").strip(),
        "ios": str(prefs.get("iosVersion") or "").strip(),
        "build": guard.parse_build(prefs.get("iosVersionBuild"), required=False),
        "resolution": guard.RES_MAP.get(model, ""),
    }
    if not all(identity.values()):
        raise WorkflowError(
            "instagram_profile_invalid",
            "The active Instagram profile is incomplete or unsupported",
            stage="validate_source",
            details={"identity": identity},
        )
    identity["profile_sha256"] = _sha256(raw)
    identity["snapshot_id"] = guard.snapshot_id_from_global_bytes(raw)
    return identity


def _find_app_root(bundle_id: str, paths: WorkflowPaths) -> str:
    if not os.path.isdir(paths.data_root):
        raise WorkflowError(
            "application_data_root_missing",
            "The application data root is missing",
            stage="resolve_active",
        )
    for entry in os.listdir(paths.data_root):
        root = os.path.join(paths.data_root, entry)
        metadata = os.path.join(
            root, ".com.apple.mobile_container_manager.metadata.plist"
        )
        if not os.path.isfile(metadata):
            continue
        try:
            if _read_plist(metadata).get("MCMMetadataIdentifier") == bundle_id:
                return root
        except Exception:
            continue
    raise WorkflowError(
        "application_container_missing",
        f"No data container exists for {bundle_id}",
        stage="resolve_active",
    )


def _read_crane_prefs(paths: WorkflowPaths) -> dict[str, Any]:
    for candidate in paths.crane_prefs_candidates:
        if not os.path.isfile(candidate):
            continue
        try:
            return _read_plist(candidate)
        except Exception:
            continue
    raise WorkflowError(
        "crane_preferences_missing",
        "Crane preferences are unavailable",
        stage="resolve_active",
    )


def _cli_active_id(
    bundle_id: str, paths: WorkflowPaths, runner: CommandRunner
) -> str:
    completed = runner.run([paths.crane_cli, "list", bundle_id], timeout=20)
    if completed.returncode != 0:
        raise WorkflowError(
            "active_container_unverified",
            f"crane-cli could not report the active container for {bundle_id}",
            stage="resolve_active",
            details={"stderr": completed.stderr.strip()[-300:]},
        )
    for line in completed.stdout.splitlines():
        match = re.match(r"^\s*\*\s*\[([^]]+)\]", line)
        if match:
            identifier = match.group(1).strip().upper()
            if re.fullmatch(r"[A-F0-9-]{36}", identifier):
                return identifier
            break
    raise WorkflowError(
        "active_container_missing",
        f"A named Crane container is not active for {bundle_id}",
        stage="resolve_active",
    )


def resolve_active_container(
    bundle_id: str,
    paths: WorkflowPaths,
    runner: CommandRunner,
    *,
    require_profile: bool = True,
) -> ActiveContainer:
    prefs = _read_crane_prefs(paths)
    settings = prefs.get("appSettings_" + bundle_id) or {}
    if not isinstance(settings, dict):
        settings = {}
    identifier = str(settings.get("activeContainer") or "").strip().upper()
    if not re.fullmatch(r"[A-F0-9-]{36}", identifier):
        raise WorkflowError(
            "active_container_missing",
            f"A named Crane container is not active for {bundle_id}",
            stage="resolve_active",
        )
    cli_identifier = _cli_active_id(bundle_id, paths, runner)
    if cli_identifier != identifier:
        raise WorkflowError(
            "active_container_changed",
            "Crane preferences and crane-cli disagree",
            stage="resolve_active",
            details={
                "bundle_id": bundle_id,
                "preferences": identifier,
                "crane_cli": cli_identifier,
            },
        )
    name = identifier
    containers = settings.get("Containers")
    if isinstance(containers, list):
        for item in containers:
            if not isinstance(item, dict):
                continue
            if str(item.get("identifier") or "").strip().upper() == identifier:
                name = str(item.get("name") or "").strip() or identifier
                break
    app_root = _find_app_root(bundle_id, paths)
    root = os.path.join(app_root, CRANE_RELATIVE_ROOT, identifier)
    source = os.path.join(root, "Documents", GHOST_PLIST)
    if require_profile and not os.path.isfile(source):
        raise WorkflowError(
            "active_profile_missing",
            f"The active {bundle_id} container has no Ghost profile",
            stage="validate_source",
            details={"container_id": identifier, "source_path": source},
        )
    return ActiveContainer(
        bundle_id=bundle_id,
        identifier=identifier,
        name=name,
        app_root=app_root,
        root=root,
        source_path=source,
        parent_profile_path=os.path.join(app_root, "Documents", GHOST_PLIST),
    )


def _assert_same_active(
    expected: ActiveContainer,
    paths: WorkflowPaths,
    runner: CommandRunner,
    stage: str,
    *,
    require_profile: bool = True,
) -> None:
    current = resolve_active_container(
        expected.bundle_id,
        paths,
        runner,
        require_profile=require_profile,
    )
    if current.identifier != expected.identifier:
        raise WorkflowError(
            "active_container_changed",
            "A Crane container changed during the IG to Threads workflow",
            stage=stage,
            details={
                "bundle_id": expected.bundle_id,
                "expected_id": expected.identifier,
                "current_id": current.identifier,
            },
        )


def _inactive_profile_hashes(active: ActiveContainer) -> dict[str, str]:
    root = os.path.join(active.app_root, CRANE_RELATIVE_ROOT)
    result: dict[str, str] = {}
    if not os.path.isdir(root):
        return result
    for identifier in sorted(os.listdir(root)):
        if identifier.upper() == active.identifier:
            continue
        profile = os.path.join(root, identifier, "Documents", GHOST_PLIST)
        if os.path.isfile(profile):
            result[identifier.upper()] = _file_sha256(profile)
    return result


def _live_threads_pids(paths: WorkflowPaths, runner: CommandRunner) -> list[int]:
    completed = runner.run(
        [paths.ps, "-ax", "-o", "pid=", "-o", "command="], timeout=15
    )
    result: list[int] = []
    for line in completed.stdout.splitlines():
        if "Threads.app/Threads" not in line:
            continue
        try:
            result.append(int(line.strip().split(None, 1)[0]))
        except (ValueError, IndexError):
            continue
    return sorted(set(result))


def _stop_threads(paths: WorkflowPaths, runner: CommandRunner) -> None:
    runner.run([paths.killall, "Threads"], timeout=10)
    time.sleep(1)
    runner.run([paths.killall, "-9", "Threads"], timeout=10)
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        if not _live_threads_pids(paths, runner):
            return
        time.sleep(0.25)
    remaining = _live_threads_pids(paths, runner)
    if remaining:
        raise WorkflowError(
            "threads_stop_failed",
            "Threads remained running before force apply",
            stage="stop_old_runtime",
            details={"pids": remaining},
        )


def _sudo(
    paths: WorkflowPaths,
    runner: CommandRunner,
    argv: Iterable[str],
    *,
    timeout: int = 30,
) -> subprocess.CompletedProcess[str]:
    password = os.environ.get("IG_IPHONE_PASSWORD", "alpine")
    return runner.run(
        [paths.sudo, "-S", "-p", "", *list(argv)],
        timeout=timeout,
        input_text=password + "\n",
    )


def retire_legacy_sync(paths: WorkflowPaths, runner: CommandRunner) -> dict[str, Any]:
    disabled = _sudo(
        paths,
        runner,
        [paths.launchctl, "disable", LEGACY_SYNC_LABEL],
        timeout=20,
    )
    if disabled.returncode != 0:
        raise WorkflowError(
            "legacy_sync_disable_failed",
            "Could not disable the old bidirectional Ghost sync service",
            stage="disable_legacy_sync",
            details={"stderr": disabled.stderr.strip()[-300:]},
        )
    # bootout returns nonzero when the disabled one-shot service is already
    # unloaded, which is an acceptable final state.
    _sudo(
        paths,
        runner,
        [paths.launchctl, "bootout", LEGACY_SYNC_LABEL],
        timeout=20,
    )
    completed = runner.run(
        [paths.ps, "-ax", "-o", "pid=", "-o", "command="], timeout=15
    )
    pids: list[int] = []
    for line in completed.stdout.splitlines():
        if "ghost-global-sync" not in line:
            continue
        try:
            pids.append(int(line.strip().split(None, 1)[0]))
        except (ValueError, IndexError):
            continue
    if pids:
        killed = _sudo(
            paths,
            runner,
            ["/var/jb/usr/bin/kill", "-TERM", *[str(pid) for pid in pids]],
            timeout=15,
        )
        if killed.returncode != 0:
            raise WorkflowError(
                "legacy_sync_disable_failed",
                "The old Ghost sync process remained alive",
                stage="disable_legacy_sync",
                details={"pids": pids},
            )
    return {"label": LEGACY_SYNC_LABEL, "disabled": True, "stopped_pids": pids}


def _assert_guard_installed(paths: WorkflowPaths) -> None:
    missing = [
        path
        for path in (paths.guard_dylib, paths.guard_filter)
        if not os.path.isfile(path)
    ]
    if missing:
        raise WorkflowError(
            "threads_guard_missing",
            "ThreadsGhostGuard is not installed",
            stage="validate_guard",
            details={"missing": missing},
        )
    try:
        filter_payload = _read_plist(paths.guard_filter)
        bundles = filter_payload.get("Filter", {}).get("Bundles", [])
    except Exception as exc:
        raise WorkflowError(
            "threads_guard_filter_invalid",
            f"Threads Guard filter cannot be read: {type(exc).__name__}",
            stage="validate_guard",
        ) from exc
    if bundles != [THREADS_BUNDLE_ID]:
        raise WorkflowError(
            "threads_guard_filter_invalid",
            "Threads Guard filter does not target only Threads",
            stage="validate_guard",
            details={"bundles": bundles},
        )
    overlaps = [
        path
        for path in (paths.legacy_sync_dylib, paths.legacy_sync_filter)
        if os.path.exists(path)
    ]
    if overlaps:
        raise WorkflowError(
            "legacy_iguafix_overlap",
            "The crash-prone IGUAFix filter is still active for Threads",
            stage="validate_guard",
            details={"paths": overlaps},
        )


def _list_threads_crashes(paths: WorkflowPaths) -> set[str]:
    try:
        names = os.listdir(paths.crash_root)
    except OSError:
        return set()
    return {
        os.path.join(paths.crash_root, name)
        for name in names
        if name.startswith("Threads-") and ".ips" in name
    }


def _sanitize_active_storage(
    active: ActiveContainer,
    profile_raw: bytes,
    paths: WorkflowPaths,
) -> dict[str, Any]:
    import ig_active_sanitize as sanitizer

    try:
        report = sanitizer.sanitize_threads_scope(
            active.root,
            active.identifier,
            profile_raw,
            backup_root=paths.sanitize_backup_root,
        )
    except Exception as exc:
        raise WorkflowError(
            "threads_storage_sanitize_failed",
            "Could not sanitize Threads persistent identity queues: "
            f"{type(exc).__name__}: {exc}",
            stage="sanitize_active_storage",
        ) from exc
    if report.get("success") is not True:
        raise WorkflowError(
            "threads_storage_residual",
            "Threads still contains a real/stale device identity",
            stage="sanitize_active_storage",
            details={
                "after": report.get("after") or [],
                "effective_after": report.get("effective_after") or {},
            },
        )
    return report


def _remediate_after_warmup(
    active: ActiveContainer,
    profile_raw: bytes,
    paths: WorkflowPaths,
    runner: CommandRunner,
) -> dict[str, Any]:
    """Re-clean what Threads itself wrote while it was running.

    Sanitizing before launch is not sufficient for values the app writes at
    runtime. Threads records the real OS version under
    ``kUserDefaultActivityMonitorOsVersionKey`` in its own preferences during
    warm-up, through a path the guard does not cover: observed on 192.168.1.36
    (real 16.7.16 against a 16.5 persona) and on all three Threads containers of
    192.168.1.34 (16.7.12), where it went unnoticed only because the marker list
    did not yet cover that device.

    The analytics queues defend themselves with SQL triggers; a plist cannot, so
    it is rewritten here instead. Threads is closed first: preferences are cached
    by cfprefsd on behalf of the running process, which would write the real
    value back over this one.

    This cleans what is stored. It cannot un-send anything the app already
    transmitted during warm-up — closing that needs the guard itself to cover the
    read path.
    """
    import ig_active_sanitize as sanitizer

    _stop_threads(paths, runner)
    try:
        identity = sanitizer.identity_from_profile(profile_raw)
        replacements = sanitizer.build_replacements(identity)
        preferences = os.path.join(active.root, THREADS_PREFS_RELATIVE_PATH)
        changed = sanitizer.sanitize_preferences(preferences, replacements)
    except Exception as exc:
        raise WorkflowError(
            "threads_warmup_remediation_failed",
            "Could not re-sanitize Threads preferences after warm-up: "
            f"{type(exc).__name__}: {exc}",
            stage="remediate_after_warmup",
        ) from exc
    return {"preferences_path": preferences, "preference_changes": changed}


def _scan_active_storage(
    active: ActiveContainer,
    profile_raw: bytes,
) -> dict[str, Any]:
    import ig_active_sanitize as sanitizer

    try:
        identity = sanitizer.identity_from_profile(profile_raw)
        replacements = sanitizer.build_replacements(identity)
        report = sanitizer.effective_threads_scan(
            active.root, identity, replacements
        )
    except Exception as exc:
        raise WorkflowError(
            "threads_storage_scan_failed",
            "Could not audit Threads persistent identity queues: "
            f"{type(exc).__name__}: {exc}",
            stage="validate_storage",
        ) from exc
    if report.get("success") is not True:
        raise WorkflowError(
            "threads_storage_leak",
            "Threads produced a real/stale persistent device identity",
            stage="validate_storage",
            details=report,
        )
    return report


def _fresh_threads_snapshot(
    instagram_snapshot: dict[str, Any],
    identity: dict[str, Any],
    source_path: str,
) -> dict[str, Any]:
    expected = {
        "bundle_id": IG_BUNDLE_ID,
        "snapshot_id": identity["snapshot_id"],
        "model": identity["model"],
        "hardware": identity["hardware"],
        "display_name": identity["display_name"],
        "ios": identity["ios"],
        "build": identity["build"],
        "resolution": identity["resolution"],
    }
    mismatches = {
        key: {"expected": value, "actual": instagram_snapshot.get(key)}
        for key, value in expected.items()
        if instagram_snapshot.get(key) != value
    }
    if mismatches:
        raise WorkflowError(
            "instagram_snapshot_stale",
            "The Instagram Guard snapshot does not match its active profile",
            stage="validate_source",
            details={"mismatches": mismatches},
        )
    result = dict(instagram_snapshot)
    result.update(
        {
            "schema": 1,
            "bundle_id": THREADS_BUNDLE_ID,
            "source_path": source_path,
            "created_at": time.time(),
        }
    )
    return result


def _status_problems(
    status: dict[str, Any], snapshot_id: str, minimum_requests: int
) -> list[str]:
    problems: list[str] = []
    calls = int(status.get("calls", 0) or 0)
    ua_reads = int(status.get("ua_reads", 0) or 0)
    without_ua = int(status.get("requests_without_ua", 0) or 0)
    exact = {
        "guard_version": GUARD_VERSION,
        "target_bundle": THREADS_BUNDLE_ID,
        "snapshot_id": snapshot_id,
        "getter_selectors": 0,
        "getter_hooks": 0,
        "getter_calls": 0,
        "getter_errors": 0,
        "tigon_hooks": 1,
        "sysctl_hooks": 1,
        "sysctl_scope": "hw.product",
        "mobilegestalt_hooks": 1,
        "mobilegestalt_scope": "ProductType",
        "sysctl_build_rewrites": 0,
        "sysctl_version_rewrites": 0,
        "sysctl_mib_rewrites": 0,
        "mobilegestalt_version_rewrites": 0,
        "mobilegestalt_build_rewrites": 0,
        "persistence_hooks": 1,
        "persistence_errors": 0,
        "application_status_hooks": 3,
        "application_status_errors": 0,
        "residual": 0,
        "blocked": 0,
        "errors": 0,
    }
    for key, expected in exact.items():
        if status.get(key) != expected:
            problems.append(key)
    for key in (
        "config_loaded",
        "ready",
        "sysctl_enabled",
        "system_identity_verified",
        "mobilegestalt_enabled",
        "mobilegestalt_verified",
        "persistence_enabled",
        "application_status_enabled",
    ):
        if status.get(key) is not True:
            problems.append(key)
    if status.get("source_getters_required") is not False:
        problems.append("source_getters_required")
    if str(status.get("fatal_reason") or ""):
        problems.append("fatal_reason")
    if calls < minimum_requests:
        problems.append(f"calls<{minimum_requests}")
    if ua_reads <= 0:
        problems.append("ua_reads")
    accounting = all(
        (
            int(status.get("header_reads", -1)) == calls,
            ua_reads + without_ua == calls,
            int(status.get("target_verified", -1)) == calls,
            int(status.get("verified_requests", -1)) == calls,
            int(status.get("url_scanned", -1)) == calls,
            int(status.get("rewrote", 0))
            + int(status.get("already_target", 0))
            + without_ua
            == calls,
        )
    )
    if not accounting:
        problems.append("request_accounting")
    for key in ("sysctl_product_rewrites", "mobilegestalt_product_rewrites"):
        if int(status.get(key, 0) or 0) <= 0:
            problems.append(key)
    return problems


def _needs_feed_refresh(status: dict[str, Any], minimum_requests: int) -> bool:
    """Keep ordinary Threads feed traffic moving until the audit sample is large enough."""
    return int(status.get("calls", 0) or 0) < minimum_requests


def _feed_scroll_lua(swipe_count: int = FEED_SCROLL_SWIPE_COUNT) -> str:
    """Build a resolution-independent upward feed gesture for AutoTouch."""
    count = max(1, min(int(swipe_count), 20))
    return (
        "local w,h=getScreenResolution(); "
        "if not w then w=1125; h=2436 end; "
        "local x=math.floor(w*0.5); "
        "local y1=math.floor(h*0.78); "
        "local y2=math.floor(h*0.30); "
        f"for i=1,{count} do "
        "touchDown(0,x,y1); usleep(30000); "
        "for k=1,12 do "
        "touchMove(0,x,math.floor(y1+(y2-y1)*k/12)); usleep(20000); "
        "end; touchUp(0,x,y2); usleep(500000); end; "
        'return "ghost_threads_feed_scroll_done"'
    )


def _autotouch_feed_scroll(endpoint: str) -> dict[str, Any]:
    body = json.dumps(
        {"action": "RUNLUA", "data": _feed_scroll_lua()},
        separators=(",", ":"),
    ).encode("utf-8")
    request = urllib.request.Request(
        endpoint,
        data=body,
        headers={"Content-Type": "application/json", "Accept": "*/*"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=15) as response:
            decoded = json.loads(response.read().decode("utf-8", "replace"))
        if not isinstance(decoded, dict) or decoded.get("success") is not True:
            return {"success": False, "error": "autotouch_rejected"}
        return {
            "success": True,
            "message": str(decoded.get("message") or ""),
        }
    except Exception as exc:
        return {
            "success": False,
            "error": f"{type(exc).__name__}: {exc}",
        }


def run_force_threads(
    *,
    paths: WorkflowPaths = DEFAULT_PATHS,
    runner: Optional[CommandRunner] = None,
    expected_instagram_id: Optional[str] = None,
    warmup_seconds: int = WARMUP_SECONDS,
    maximum_warmup_seconds: int = MAX_WARMUP_SECONDS,
    minimum_requests: int = MIN_REQUESTS,
    verification_mode: str = "auto",
) -> dict[str, Any]:
    runner = runner or CommandRunner()
    started_at = time.time()
    result: dict[str, Any] = {
        "success": False,
        "verdict": "FAIL",
        "action": "ghost_threads",
        "workflow_version": WORKFLOW_VERSION,
        "force_active": True,
        "identity_source": "active_instagram",
        "verification_mode": verification_mode,
        "started_at": started_at,
    }
    threads_started = False
    storage_sanitize: dict[str, Any] = {}
    storage_after_warmup: dict[str, Any] = {}
    lock_handle = None
    lock_acquired = False
    try:
        os.makedirs(os.path.dirname(paths.lock_path), exist_ok=True)
        lock_handle = open(paths.lock_path, "a+")
        try:
            fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            lock_acquired = True
        except OSError as exc:
            raise WorkflowError(
                "workflow_busy",
                "Another Threads Ghost workflow is already running",
                stage="lock",
            ) from exc

        legacy_sync = retire_legacy_sync(paths, runner)
        _assert_guard_installed(paths)
        instagram = resolve_active_container(IG_BUNDLE_ID, paths, runner)
        threads = resolve_active_container(
            THREADS_BUNDLE_ID,
            paths,
            runner,
            require_profile=False,
        )
        threads_profile_existed = os.path.isfile(threads.source_path)
        if expected_instagram_id and instagram.identifier != expected_instagram_id:
            raise WorkflowError(
                "active_container_changed",
                "Instagram changed after its guarded phase",
                stage="resolve_active",
                details={
                    "expected_id": expected_instagram_id,
                    "current_id": instagram.identifier,
                },
            )
        result["source_container"] = {
            "id": instagram.identifier,
            "name": instagram.name,
            "source_path": instagram.source_path,
        }
        result["active_container"] = {
            "id": threads.identifier,
            "name": threads.name,
            "source_path": threads.source_path,
            "profile_existed_before": threads_profile_existed,
        }
        if verification_mode not in {"auto", "account_creation"}:
            raise WorkflowError(
                "verification_mode_invalid",
                "Unknown Threads verification mode",
                stage="select_contract",
                details={"verification_mode": verification_mode},
            )
        initial_session_context = _threads_session_context(threads)
        current_session_context = initial_session_context
        account_creation_bootstrap = verification_mode == "account_creation"
        fresh_container_bootstrap = account_creation_bootstrap or bool(
            initial_session_context.get("fresh_container_bootstrap")
        )
        minimum_requests_required = (
            FRESH_CONTAINER_MIN_REQUESTS
            if fresh_container_bootstrap
            else minimum_requests
        )
        if account_creation_bootstrap:
            coverage_mode = "account_creation_bootstrap"
        elif fresh_container_bootstrap:
            coverage_mode = "fresh_container_bootstrap"
        else:
            coverage_mode = "authenticated_full"
        result["container_session"] = initial_session_context
        session_states_seen = [str(initial_session_context.get("state") or "")]
        contract_upgraded_during_warmup = False
        result["verification_contract"] = {
            "coverage_mode": coverage_mode,
            "minimum_requests_required": minimum_requests_required,
            "verification_mode": verification_mode,
            "session_states_seen": session_states_seen,
            "upgraded_during_warmup": False,
        }

        source_raw = _read_bytes(instagram.source_path)
        identity = _validate_identity(source_raw)
        result["identity"] = dict(identity)
        instagram_snapshot_path = os.path.join(
            instagram.root, IG_SNAPSHOT_RELATIVE_PATH
        )
        try:
            instagram_snapshot = _read_plist(instagram_snapshot_path)
        except Exception as exc:
            raise WorkflowError(
                "instagram_snapshot_missing",
                "The active Instagram Guard snapshot is unavailable",
                stage="validate_source",
                details={"path": instagram_snapshot_path},
            ) from exc
        threads_snapshot_path = os.path.join(
            threads.root, THREADS_SNAPSHOT_RELATIVE_PATH
        )
        threads_status_path = os.path.join(threads.root, THREADS_STATUS_RELATIVE_PATH)
        fresh_snapshot = _fresh_threads_snapshot(
            instagram_snapshot, identity, threads.source_path
        )
        inactive_before = _inactive_profile_hashes(threads)
        previous_status: dict[str, Any] = {}
        with contextlib.suppress(Exception):
            previous_status = _read_plist(threads_status_path)
        previous_pids = _live_threads_pids(paths, runner)
        previous_pid = int(previous_status.get("pid", 0) or 0)
        if previous_pid <= 0 and previous_pids:
            previous_pid = previous_pids[-1]
        previous_launch_id = str(previous_status.get("launch_id") or "")

        _stop_threads(paths, runner)
        _assert_same_active(instagram, paths, runner, "before_mirror")
        _assert_same_active(
            threads,
            paths,
            runner,
            "before_mirror",
            require_profile=False,
        )
        _remove(threads_status_path)
        _remove(threads_snapshot_path)
        mirror_paths = (
            threads.source_path,
            threads.parent_profile_path,
            instagram.parent_profile_path,
            paths.global_profile,
        )
        for destination in mirror_paths:
            _atomic_write(destination, source_raw)
        _atomic_write(
            threads_snapshot_path,
            plistlib.dumps(fresh_snapshot, fmt=plistlib.FMT_BINARY),
        )
        if os.path.exists(threads_status_path):
            raise WorkflowError(
                "status_reset_failed",
                "The old Threads Guard status was not removed",
                stage="reset_runtime",
            )
        mirror_hashes = {path: _file_sha256(path) for path in mirror_paths}
        if any(value != identity["profile_sha256"] for value in mirror_hashes.values()):
            raise WorkflowError(
                "force_mirror_failed",
                "Not every active IG/Threads identity reader received the IG profile",
                stage="force_mirror",
                details={"hashes": mirror_hashes},
            )
        storage_sanitize = _sanitize_active_storage(
            threads, source_raw, paths
        )
        _assert_same_active(instagram, paths, runner, "before_launch")
        _assert_same_active(threads, paths, runner, "before_launch")
        crashes_before = _list_threads_crashes(paths)
        launched = runner.run(
            [paths.uiopen, "--url", "barcelona://"], timeout=20
        )
        if launched.returncode != 0:
            raise WorkflowError(
                "threads_launch_failed",
                "uiopen could not launch Threads",
                stage="launch",
                details={"stderr": launched.stderr.strip()[-300:]},
            )
        threads_started = True

        startup_deadline = time.monotonic() + 20
        status: dict[str, Any] = {}
        while time.monotonic() < startup_deadline:
            try:
                status = _read_plist(threads_status_path)
            except Exception:
                status = {}
            pid = int(status.get("pid", 0) or 0)
            launch_id = str(status.get("launch_id") or "")
            if (
                pid > 0
                and pid != previous_pid
                and pid not in previous_pids
                and launch_id
                and launch_id != previous_launch_id
                and pid in _live_threads_pids(paths, runner)
            ):
                break
            time.sleep(0.5)
        else:
            raise WorkflowError(
                "threads_guard_start_timeout",
                "Threads did not produce a fresh guarded PID",
                stage="launch",
                details={"status": status, "previous_pids": previous_pids},
            )

        pid = int(status["pid"])
        launch_id = str(status["launch_id"])
        initial_calls = int(status.get("calls", 0) or 0)
        warmup_started = time.monotonic()
        minimum_deadline = warmup_started + max(0, warmup_seconds)
        maximum_deadline = warmup_started + max(
            max(0, warmup_seconds), max(0, maximum_warmup_seconds)
        )
        samples = 0
        next_active_check = warmup_started
        next_feed_refresh = warmup_started + FEED_REFRESH_INTERVAL_SECONDS
        next_feed_scroll = warmup_started + FEED_SCROLL_FIRST_DELAY_SECONDS
        feed_refresh_attempts = 0
        feed_refresh_failures = 0
        feed_scroll_attempts = 0
        feed_scroll_successes = 0
        feed_scroll_failures = 0
        last_feed_scroll_error = ""
        while True:
            now = time.monotonic()
            accounting_closed = not _status_problems(
                status, identity["snapshot_id"], minimum_requests_required
            )
            # Contract-based exit: every counter validated after the loop is already
            # closed for this PID, so waiting out minimum_warmup_seconds would only
            # re-prove the same facts. The 45 s floor is gone; the 120 s ceiling and
            # the post-loop _status_problems() re-check are unchanged.
            if accounting_closed and now - warmup_started >= CONTRACT_SETTLE_SECONDS:
                break
            if now >= maximum_deadline:
                break
            if now >= next_active_check:
                _assert_same_active(instagram, paths, runner, "warmup")
                _assert_same_active(threads, paths, runner, "warmup")
                current_session_context = _threads_session_context(threads)
                current_state = str(current_session_context.get("state") or "")
                if current_state not in session_states_seen:
                    session_states_seen.append(current_state)
                if (
                    not account_creation_bootstrap
                    and _bootstrap_contract_must_upgrade(current_session_context)
                ):
                    # Verification can only become stricter during one run. If
                    # login completes during warm-up, require the full sample.
                    contract_upgraded_during_warmup = (
                        coverage_mode != "authenticated_full"
                    ) or contract_upgraded_during_warmup
                    fresh_container_bootstrap = False
                    minimum_requests_required = minimum_requests
                    coverage_mode = "authenticated_full"
                result["verification_contract"].update(
                    {
                        "coverage_mode": coverage_mode,
                        "minimum_requests_required": minimum_requests_required,
                        "session_states_seen": list(session_states_seen),
                        "upgraded_during_warmup": contract_upgraded_during_warmup,
                    }
                )
                next_active_check = now + 5
            live = _live_threads_pids(paths, runner)
            if pid not in live:
                raise WorkflowError(
                    "threads_pid_changed",
                    "The guarded Threads PID exited during warm-up",
                    stage="warmup",
                    details={"expected_pid": pid, "live_pids": live},
                )
            try:
                current = _read_plist(threads_status_path)
            except Exception as exc:
                raise WorkflowError(
                    "threads_status_missing",
                    "Threads Guard status disappeared during warm-up",
                    stage="warmup",
                ) from exc
            if int(current.get("pid", 0) or 0) != pid or str(
                current.get("launch_id") or ""
            ) != launch_id:
                raise WorkflowError(
                    "threads_pid_changed",
                    "Threads Guard switched PID or launch id during warm-up",
                    stage="warmup",
                )
            status = current
            samples += 1
            now = time.monotonic()
            if now >= next_feed_scroll and _needs_feed_refresh(
                status, minimum_requests_required
            ):
                feed_scroll = _autotouch_feed_scroll(paths.autotouch_endpoint)
                feed_scroll_attempts += 1
                if feed_scroll.get("success") is True:
                    feed_scroll_successes += 1
                else:
                    feed_scroll_failures += 1
                    last_feed_scroll_error = str(feed_scroll.get("error") or "")
                next_feed_scroll = now + FEED_SCROLL_RETRY_INTERVAL_SECONDS
            if now >= next_feed_refresh and _needs_feed_refresh(
                status, minimum_requests_required
            ):
                refreshed = runner.run(
                    [paths.uiopen, "--url", "barcelona://"], timeout=10
                )
                feed_refresh_attempts += 1
                if refreshed.returncode != 0:
                    feed_refresh_failures += 1
                next_feed_refresh = now + FEED_REFRESH_INTERVAL_SECONDS
            time.sleep(
                min(1.0, max(0.0, maximum_deadline - time.monotonic()))
            )

        _assert_same_active(instagram, paths, runner, "after_warmup")
        _assert_same_active(threads, paths, runner, "after_warmup")
        current_session_context = _threads_session_context(threads)
        current_state = str(current_session_context.get("state") or "")
        if current_state not in session_states_seen:
            session_states_seen.append(current_state)
        if (
            not account_creation_bootstrap
            and _bootstrap_contract_must_upgrade(current_session_context)
        ):
            contract_upgraded_during_warmup = (
                coverage_mode != "authenticated_full"
            ) or contract_upgraded_during_warmup
            fresh_container_bootstrap = False
            minimum_requests_required = minimum_requests
            coverage_mode = "authenticated_full"
        elif (
            not account_creation_bootstrap
            and coverage_mode == "fresh_container_bootstrap"
            and current_session_context.get("state") != "fresh_logged_out"
        ):
            raise WorkflowError(
                "threads_session_unresolved",
                "Threads did not finish publishing a logged-out or authenticated session marker",
                stage="validate_runtime",
                details={
                    "initial_session": initial_session_context,
                    "final_session": current_session_context,
                    "session_states_seen": session_states_seen,
                },
            )
        result["container_session"] = {
            **current_session_context,
            "initial_state": initial_session_context.get("state"),
            "state_changed_during_warmup": (
                current_session_context.get("state")
                != initial_session_context.get("state")
            ),
        }
        result["verification_contract"].update(
            {
                "coverage_mode": coverage_mode,
                "minimum_requests_required": minimum_requests_required,
                "session_states_seen": list(session_states_seen),
                "upgraded_during_warmup": contract_upgraded_during_warmup,
            }
        )
        current_source = _read_bytes(instagram.source_path)
        if _sha256(current_source) != identity["profile_sha256"]:
            raise WorkflowError(
                "instagram_profile_changed",
                "The Instagram source profile changed during Threads warm-up",
                stage="validate_runtime",
            )
        if _file_sha256(threads.source_path) != identity["profile_sha256"]:
            raise WorkflowError(
                "threads_profile_changed",
                "The active Threads profile changed during warm-up",
                stage="validate_runtime",
            )
        inactive_after = _inactive_profile_hashes(threads)
        if inactive_after != inactive_before:
            raise WorkflowError(
                "inactive_container_changed",
                "An inactive Threads container changed",
                stage="validate_isolation",
                details={"before": inactive_before, "after": inactive_after},
            )
        crashes_after = _list_threads_crashes(paths)
        new_crashes = sorted(crashes_after - crashes_before)
        problems = _status_problems(
            status, identity["snapshot_id"], minimum_requests_required
        )
        if new_crashes:
            problems.append("new_crash")
        if problems:
            raise WorkflowError(
                "threads_runtime_accounting_failed",
                "Threads did not satisfy the guarded request contract",
                stage="validate_runtime",
                details={
                    "problems": problems,
                    "status": status,
                    "new_crashes": new_crashes,
                    "session": result.get("container_session"),
                    "verification_contract": result.get(
                        "verification_contract"
                    ),
                },
            )
        warmup_remediation = _remediate_after_warmup(
            threads, source_raw, paths, runner
        )
        storage_after_warmup = _scan_active_storage(
            threads, source_raw
        )
        result.update(
            {
                "success": True,
                "verdict": "PASS",
                "stage": "complete",
                "legacy_sync": legacy_sync,
                "mirror_paths": list(mirror_paths),
                "mirror_hashes": mirror_hashes,
                "inactive_containers_unchanged": True,
                "active_profile_created": not threads_profile_existed,
                "inactive_profile_hashes": inactive_after,
                "storage_sanitize": storage_sanitize,
                "warmup_remediation": warmup_remediation,
                "storage_after_warmup": storage_after_warmup,
                "snapshot_refreshed": True,
                "snapshot": {
                    key: fresh_snapshot.get(key)
                    for key in (
                        "snapshot_id",
                        "model",
                        "hardware",
                        "display_name",
                        "ios",
                        "build",
                        "resolution",
                        "source_path",
                        "created_at",
                    )
                },
                "runtime": {
                    "previous_pid": previous_pid,
                    "previous_pids": previous_pids,
                    "pid": pid,
                    "previous_launch_id": previous_launch_id,
                    "launch_id": launch_id,
                    "status_reset": True,
                    "new_launch_id": True,
                    "same_pid_during_warmup": True,
                    "coverage_mode": coverage_mode,
                    "minimum_requests_required": minimum_requests_required,
                    "full_authenticated_coverage": bool(
                        coverage_mode == "authenticated_full"
                        and int(status.get("calls", 0) or 0)
                        >= minimum_requests
                    ),
                    "session_states_seen": list(session_states_seen),
                    "contract_upgraded_during_warmup": (
                        contract_upgraded_during_warmup
                    ),
                    "minimum_warmup_seconds": warmup_seconds,
                    "maximum_warmup_seconds": maximum_warmup_seconds,
                    "elapsed_warmup_seconds": round(
                        time.monotonic() - warmup_started, 3
                    ),
                    "samples": samples,
                    "feed_refresh_url": "barcelona://",
                    "feed_refresh_interval_seconds": FEED_REFRESH_INTERVAL_SECONDS,
                    "feed_refresh_attempts": feed_refresh_attempts,
                    "feed_refresh_failures": feed_refresh_failures,
                    "feed_scroll_swipes_per_attempt": FEED_SCROLL_SWIPE_COUNT,
                    "feed_scroll_attempts": feed_scroll_attempts,
                    "feed_scroll_successes": feed_scroll_successes,
                    "feed_scroll_failures": feed_scroll_failures,
                    "last_feed_scroll_error": last_feed_scroll_error,
                    "requests": int(status.get("calls", 0) or 0),
                    "new_requests_during_warmup": int(status.get("calls", 0) or 0)
                    - initial_calls,
                    "request_accounting_closed": True,
                    "tigon_hook_seen": True,
                    "application_status_hooks": int(
                        status.get("application_status_hooks", 0) or 0
                    ),
                    "application_status_writes": int(
                        status.get("application_status_writes", 0) or 0
                    ),
                    "application_status_rewrites": int(
                        status.get("application_status_rewrites", 0) or 0
                    ),
                    "application_status_errors": int(
                        status.get("application_status_errors", 0) or 0
                    ),
                    "sysctl_product_rewrites": int(
                        status.get("sysctl_product_rewrites", 0) or 0
                    ),
                    "mobilegestalt_product_rewrites": int(
                        status.get("mobilegestalt_product_rewrites", 0) or 0
                    ),
                    "residual": 0,
                    "blocked": 0,
                    "errors": 0,
                    "new_crashes": [],
                },
                "coverage": (
                    (
                        "Account-creation setup: every Threads IGTigon request "
                        "which actually occurred on the login/signup flow was "
                        "rewritten or verified against the active Instagram "
                        "identity; no artificial 100-request requirement was "
                        "applied. "
                    )
                    if coverage_mode == "account_creation_bootstrap"
                    else (
                        (
                            "Fresh logged-out Threads container: every observed startup "
                            "IGTigon request was rewritten or verified against the active "
                            "Instagram identity. Authenticated 100-request coverage is "
                            "deferred until a Threads account exists and this command is "
                            "run again. "
                        )
                        if coverage_mode == "fresh_container_bootstrap"
                        else (
                            "Authenticated Threads container: at least 100 IGTigon "
                            "request entries were rewritten or verified against the "
                            "active Instagram identity. "
                        )
                    )
                )
                + (
                    "ProductType sysctl/MobileGestalt was self-verified. OS/build "
                    "kernel hooks remain disabled for Meta 439 stability. Accounts "
                    "Center is not opened automatically. This is not encrypted-wire "
                    "or automatic server-session-label proof."
                ),
            }
        )
    except WorkflowError as exc:
        result.update(
            {
                "success": False,
                "verdict": "FAIL",
                "stage": exc.stage,
                "error": exc.code,
                "message": str(exc),
                "problems": exc.details,
            }
        )
        if threads_started:
            with contextlib.suppress(Exception):
                _stop_threads(paths, runner)
    except Exception as exc:
        result.update(
            {
                "success": False,
                "verdict": "FAIL",
                "stage": "unexpected",
                "error": type(exc).__name__,
                "message": str(exc),
            }
        )
        if threads_started:
            with contextlib.suppress(Exception):
                _stop_threads(paths, runner)
    finally:
        result["finished_at"] = time.time()
        result["elapsed_seconds"] = round(result["finished_at"] - started_at, 3)
        result["report_path"] = paths.latest_report
        if lock_acquired:
            with contextlib.suppress(Exception):
                _write_json_atomic(paths.latest_report, result)
        if lock_handle is not None:
            with contextlib.suppress(Exception):
                fcntl.flock(lock_handle.fileno(), fcntl.LOCK_UN)
            lock_handle.close()
    return result


def parse_args(argv: Optional[list[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="ghost_threads run",
        description="Force active Threads to the active Instagram identity",
    )
    return parser.parse_args(argv)


def main(argv: Optional[list[str]] = None) -> int:
    parse_args(argv)
    result = run_force_threads()
    print(json.dumps(result, ensure_ascii=False, separators=(",", ":")))
    return 0 if result.get("success") else 1


if __name__ == "__main__":
    raise SystemExit(main())
