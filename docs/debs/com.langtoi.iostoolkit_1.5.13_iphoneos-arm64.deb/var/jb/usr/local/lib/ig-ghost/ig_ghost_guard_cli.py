"""Install, apply and audit the persistent on-device Instagram Ghost guard.

Unlike ``ig_ghost_manual_cli.py``, this CLI never attaches Frida. ``apply``
freezes the canonical Global Ghost snapshot into the Instagram data container,
installs the rootless tweak and relaunches Instagram. The CLI may then exit;
the tweak is injected again on every later Instagram PID.

Inventory format for fleet mode (one device per line):

    192.168.1.37
    192.168.1.38,device_password

Blank lines and lines beginning with ``#`` are ignored.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import os
import plistlib
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable


BUNDLE_ID = "com.burbn.instagram"
INSTAGRAM_URL = "instagram://"
PROCESS_NAME = "Instagram"
PACKAGE_ID = "com.langtoi.igghostguard"
PACKAGE_VERSION = "1.3.1"
GUARD_VERSION = "1.3.1"
# Minimum time the validated contract must hold before a warm-up window may exit
# early. Counter validation is unchanged; this only prevents accepting a launch
# that has not issued its first request yet.
CONTRACT_SETTLE_SECONDS = 2.0
GHOST_NAME = "com.sgwc.ghostprefs.plist"
GLOBAL_GHOST_PATH = f"/var/mobile/Library/Preferences/Ghost/{GHOST_NAME}"
CRANE_CONTAINERS_RELATIVE_PATH = "Library/___Crane_Containers"
SNAPSHOT_RELATIVE_PATH = (
    "Library/Preferences/com.langtoi.igghostguard.snapshot.plist"
)
STATUS_RELATIVE_PATH = "Library/Caches/com.langtoi.igghostguard.status.plist"
INSTALLED_DYLIB = (
    "/var/jb/Library/MobileSubstrate/DynamicLibraries/IGGhostGuard.dylib"
)
INSTALLED_FILTER = (
    "/var/jb/Library/MobileSubstrate/DynamicLibraries/IGGhostGuard.plist"
)
REAL_TWEAK_LOAD_DIR = "/var/jb/usr/lib/TweakInject"
DISABLED_DYLIB = f"{INSTALLED_DYLIB}.disabled"
DISABLED_FILTER = f"{INSTALLED_FILTER}.disabled"

ROOT = Path(__file__).resolve().parent
PACKAGE_SOURCE = ROOT / "substrate" / "ig_ghost_guard"
DIST_DIR = PACKAGE_SOURCE / "dist"
DEFAULT_DEB = DIST_DIR / f"{PACKAGE_ID}_{PACKAGE_VERSION}_iphoneos-arm64.deb"
DEFAULT_MANIFEST = DIST_DIR / "manifest.json"
DEFAULT_WARMUP_SECONDS = 30
DEFAULT_MIN_REQUESTS = 30
DEFAULT_AUTOTOUCH_PORT = 3000
IOS_PS = "/bin/ps"

GETTER_COUNTER_KEYS = (
    "getter_static_calls",
    "getter_api_calls",
    "getter_mqtt_calls",
    "getter_webview_calls",
)

RES_MAP = {
    "iPhone8,1": "750x1334", "iPhone8,2": "1080x1920", "iPhone8,4": "640x1136",
    "iPhone9,1": "750x1334", "iPhone9,2": "1080x1920", "iPhone9,3": "750x1334",
    "iPhone9,4": "1080x1920", "iPhone10,1": "750x1334", "iPhone10,2": "1080x1920",
    "iPhone10,3": "1125x2436", "iPhone10,4": "750x1334", "iPhone10,5": "1080x1920",
    "iPhone10,6": "1125x2436", "iPhone11,2": "1125x2436", "iPhone11,4": "1242x2688",
    "iPhone11,6": "1242x2688", "iPhone11,8": "828x1792", "iPhone12,1": "828x1792",
    "iPhone12,3": "1125x2436", "iPhone12,5": "1242x2688", "iPhone12,8": "750x1334",
    "iPhone13,1": "1080x2340", "iPhone13,2": "1170x2532", "iPhone13,3": "1170x2532",
    "iPhone13,4": "1284x2778", "iPhone14,2": "1170x2532", "iPhone14,3": "1284x2778",
    "iPhone14,4": "1080x2340", "iPhone14,5": "1170x2532", "iPhone14,6": "750x1334",
    "iPhone14,7": "1170x2532", "iPhone14,8": "1284x2778", "iPhone15,2": "1179x2556",
    "iPhone15,3": "1290x2796", "iPhone15,4": "1179x2556", "iPhone15,5": "1290x2796",
    "iPhone16,1": "1179x2556", "iPhone16,2": "1290x2796", "iPhone17,1": "1206x2622",
    "iPhone17,2": "1320x2868", "iPhone17,3": "1179x2556", "iPhone17,4": "1290x2796",
}

DEVICE_NAMES = {
    "iPhone8,1": "iPhone 6s", "iPhone8,2": "iPhone 6s Plus", "iPhone8,4": "iPhone SE",
    "iPhone9,1": "iPhone 7", "iPhone9,3": "iPhone 7", "iPhone9,2": "iPhone 7 Plus",
    "iPhone9,4": "iPhone 7 Plus", "iPhone10,1": "iPhone 8", "iPhone10,4": "iPhone 8",
    "iPhone10,2": "iPhone 8 Plus", "iPhone10,5": "iPhone 8 Plus",
    "iPhone10,3": "iPhone X", "iPhone10,6": "iPhone X", "iPhone11,2": "iPhone XS",
    "iPhone11,4": "iPhone XS Max", "iPhone11,6": "iPhone XS Max", "iPhone11,8": "iPhone XR",
    "iPhone12,1": "iPhone 11", "iPhone12,3": "iPhone 11 Pro", "iPhone12,5": "iPhone 11 Pro Max",
    "iPhone12,8": "iPhone SE", "iPhone13,1": "iPhone 12 mini", "iPhone13,2": "iPhone 12",
    "iPhone13,3": "iPhone 12 Pro", "iPhone13,4": "iPhone 12 Pro Max",
    "iPhone14,4": "iPhone 13 mini", "iPhone14,5": "iPhone 13", "iPhone14,2": "iPhone 13 Pro",
    "iPhone14,3": "iPhone 13 Pro Max", "iPhone14,6": "iPhone SE", "iPhone14,7": "iPhone 14",
    "iPhone14,8": "iPhone 14 Plus", "iPhone15,2": "iPhone 14 Pro", "iPhone15,3": "iPhone 14 Pro Max",
    "iPhone15,4": "iPhone 15", "iPhone15,5": "iPhone 15 Plus", "iPhone16,1": "iPhone 15 Pro",
    "iPhone16,2": "iPhone 15 Pro Max", "iPhone17,1": "iPhone 16 Pro",
    "iPhone17,2": "iPhone 16 Pro Max", "iPhone17,3": "iPhone 16", "iPhone17,4": "iPhone 16 Plus",
}


@dataclass(frozen=True)
class DeviceSpec:
    ip: str
    username: str
    password: str


@dataclass(frozen=True)
class Snapshot:
    model: str
    hardware: str
    display_name: str
    ios: str
    build: str
    resolution: str
    bad_markers: tuple[str, ...]
    replacements: tuple[tuple[str, str], ...]
    snapshot_id: str
    data_root: str
    source_path: str

    def plist_payload(self) -> dict[str, Any]:
        width, height = self.resolution.split("x", 1)
        return {
            "schema": 1,
            "bundle_id": BUNDLE_ID,
            "source_path": self.source_path,
            "created_at": time.time(),
            "snapshot_id": self.snapshot_id,
            "model": self.model,
            "hardware": self.hardware,
            "display_name": self.display_name,
            "ios": self.ios,
            "ios_u": self.ios.replace(".", "_"),
            "build": self.build,
            "resolution": self.resolution,
            "resolution_reverse": f"{height}x{width}",
            "bad_markers": list(self.bad_markers),
            "replacements": [list(pair) for pair in self.replacements],
        }

    def public_payload(self) -> dict[str, Any]:
        payload = self.plist_payload()
        payload.pop("bad_markers", None)
        payload.pop("replacements", None)
        return payload


class Remote:
    def __init__(self, device: DeviceSpec):
        self.device = device
        self.client: Any = None
        self.sftp: Any = None

    def __enter__(self) -> "Remote":
        try:
            import paramiko
        except ImportError as exc:
            raise RuntimeError(
                "paramiko is required for apply/check; use the Windows Python "
                "runtime that already has paramiko installed"
            ) from exc
        last_error: Exception | None = None
        for _attempt in range(3):
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            try:
                client.connect(
                    self.device.ip,
                    username=self.device.username,
                    password=self.device.password,
                    timeout=15,
                    banner_timeout=15,
                    auth_timeout=15,
                )
                self.client = client
                self.sftp = client.open_sftp()
                return self
            except Exception as exc:
                last_error = exc
                client.close()
                time.sleep(1)
        raise RuntimeError(f"SSH failed: {type(last_error).__name__}: {last_error}")

    def __exit__(self, *_args: object) -> None:
        if self.sftp is not None:
            self.sftp.close()
        if self.client is not None:
            self.client.close()

    def command(self, command: str, *, timeout: int = 30) -> tuple[int, str, str]:
        _stdin, stdout, stderr = self.client.exec_command(command, timeout=timeout)
        out = stdout.read().decode(errors="replace")
        err = stderr.read().decode(errors="replace")
        return int(stdout.channel.recv_exit_status()), out, err

    def sudo(self, command: str, *, timeout: int = 60) -> tuple[int, str, str]:
        # Dopamine rootless has no /bin/sh; its POSIX shell lives in /var/jb.
        wrapped = (
            "sudo -S -p '' /var/jb/usr/bin/sh -c " + shlex.quote(command)
        )
        stdin, stdout, stderr = self.client.exec_command(wrapped, timeout=timeout)
        stdin.write(self.device.password + "\n")
        stdin.flush()
        out = stdout.read().decode(errors="replace")
        err = stderr.read().decode(errors="replace")
        return int(stdout.channel.recv_exit_status()), out, err

    def read_bytes(self, path: str) -> bytes:
        with self.sftp.open(path, "rb") as handle:
            return handle.read()

    def read_plist(self, path: str) -> dict[str, Any]:
        value = plistlib.loads(self.read_bytes(path))
        if not isinstance(value, dict):
            raise RuntimeError(f"plist is not a dictionary: {path}")
        return value

    def exists(self, path: str) -> bool:
        try:
            self.sftp.stat(path)
            return True
        except OSError:
            return False

    def write_atomic(self, path: str, data: bytes, mode: int = 0o600) -> None:
        parent = path.rsplit("/", 1)[0]
        code, _out, err = self.command(f"mkdir -p {shlex.quote(parent)}")
        if code != 0:
            raise RuntimeError(f"cannot create remote directory: {err.strip()}")
        temporary = f"{path}.tmp.{os.getpid()}.{threading.get_ident()}"
        with self.sftp.open(temporary, "wb") as handle:
            handle.write(data)
            handle.flush()
        self.sftp.chmod(temporary, mode)
        try:
            self.sftp.posix_rename(temporary, path)
        except (AttributeError, OSError):
            try:
                self.sftp.remove(path)
            except OSError:
                pass
            self.sftp.rename(temporary, path)

    def upload(self, local: Path, remote: str, mode: int = 0o644) -> None:
        self.sftp.put(str(local), remote)
        self.sftp.chmod(remote, mode)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def windows_to_wsl(path: Path) -> str:
    text = str(path.resolve()).replace("\\", "/")
    match = re.match(r"^([A-Za-z]):/(.*)$", text)
    if not match:
        raise RuntimeError(f"cannot translate path to WSL: {path}")
    return f"/mnt/{match.group(1).lower()}/{match.group(2)}"


def build_package() -> tuple[Path, dict[str, Any]]:
    required = ("Makefile", "Tweak.xm", "control", "IGGhostGuard.plist")
    for name in required:
        if not (PACKAGE_SOURCE / name).is_file():
            raise RuntimeError(f"package source missing: {PACKAGE_SOURCE / name}")

    DIST_DIR.mkdir(parents=True, exist_ok=True)
    if os.name == "nt":
        source = windows_to_wsl(PACKAGE_SOURCE)
        dist = windows_to_wsl(DIST_DIR)
        script = " && ".join(
            [
                "set -eu",
                "rm -rf /tmp/ig_ghost_guard_build",
                "mkdir -p /tmp/ig_ghost_guard_build",
                f"cp {shlex.quote(source)}/Makefile {shlex.quote(source)}/Tweak.xm "
                f"{shlex.quote(source)}/control {shlex.quote(source)}/IGGhostGuard.plist "
                "/tmp/ig_ghost_guard_build/",
                "chmod 755 /tmp/ig_ghost_guard_build",
                "chmod 644 /tmp/ig_ghost_guard_build/*",
                "THEOS=$HOME/theos make -C /tmp/ig_ghost_guard_build clean package FINALPACKAGE=1",
                f"mkdir -p {shlex.quote(dist)}",
                f"cp /tmp/ig_ghost_guard_build/packages/{DEFAULT_DEB.name} {shlex.quote(dist)}/",
                f"cp /tmp/ig_ghost_guard_build/.theos/_/var/jb/Library/MobileSubstrate/"
                f"DynamicLibraries/IGGhostGuard.dylib {shlex.quote(dist)}/IGGhostGuard.dylib",
            ]
        )
        completed = subprocess.run(["wsl.exe", "--", "bash", "-lc", script])
        if completed.returncode != 0:
            raise RuntimeError(f"Theos build failed with exit code {completed.returncode}")
        staged_dylib = DIST_DIR / "IGGhostGuard.dylib"
    else:
        # WSL may point TMPDIR at a DrvFS Windows directory where chmod is a
        # no-op (0777), which dpkg-deb correctly rejects. Force Linux /tmp.
        build_tmp = "/tmp" if Path("/tmp").is_dir() else None
        with tempfile.TemporaryDirectory(
            prefix="ig_ghost_guard_build_", dir=build_tmp
        ) as temp:
            staging = Path(temp)
            for name in required:
                shutil.copy2(PACKAGE_SOURCE / name, staging / name)
            os.chmod(staging, 0o755)
            for name in required:
                os.chmod(staging / name, 0o644)
            environment = os.environ.copy()
            environment.setdefault("THEOS", str(Path.home() / "theos"))
            completed = subprocess.run(
                ["make", "clean", "package", "FINALPACKAGE=1"],
                cwd=staging,
                env=environment,
            )
            if completed.returncode != 0:
                raise RuntimeError(f"Theos build failed with exit code {completed.returncode}")
            built_deb = staging / "packages" / DEFAULT_DEB.name
            staged_dylib = (
                staging
                / ".theos/_/var/jb/Library/MobileSubstrate/DynamicLibraries/IGGhostGuard.dylib"
            )
            if not built_deb.is_file() or not staged_dylib.is_file():
                raise RuntimeError("Theos output is incomplete")
            shutil.copy2(built_deb, DEFAULT_DEB)
            shutil.copy2(staged_dylib, DIST_DIR / "IGGhostGuard.dylib")
            staged_dylib = DIST_DIR / "IGGhostGuard.dylib"

    manifest = {
        "package_id": PACKAGE_ID,
        "package_version": PACKAGE_VERSION,
        "guard_version": GUARD_VERSION,
        "deb": DEFAULT_DEB.name,
        "deb_sha256": sha256_file(DEFAULT_DEB),
        "dylib_sha256": sha256_file(staged_dylib),
        "built_at": time.time(),
    }
    DEFAULT_MANIFEST.write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return DEFAULT_DEB, manifest


def load_manifest(deb: Path) -> dict[str, Any]:
    manifest_path = deb.parent / "manifest.json"
    if not manifest_path.is_file():
        return {"deb_sha256": sha256_file(deb)}
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("deb_sha256") != sha256_file(deb):
        raise RuntimeError("package manifest does not match the selected deb")
    return manifest


def parse_build(raw: object, *, required: bool = True) -> str:
    match = re.search(r"Build\s+\(?([A-Za-z0-9]+)", str(raw or ""))
    if match:
        return match.group(1)
    if required:
        raise RuntimeError(f"cannot parse iosVersionBuild: {raw!r}")
    return ""


def find_parent_data_root(remote: Remote) -> str:
    code, output, error = remote.command(
        "find /var/mobile/Containers/Data/Application -maxdepth 2 "
        "-name .com.apple.mobile_container_manager.metadata.plist 2>/dev/null"
    )
    if code not in (0, 1):
        raise RuntimeError(f"cannot enumerate app containers: {error.strip()}")
    for metadata_path in output.splitlines():
        try:
            metadata = remote.read_plist(metadata_path.strip())
        except Exception:
            continue
        if metadata.get("MCMMetadataIdentifier") == BUNDLE_ID:
            return metadata_path.rsplit("/", 1)[0]
    raise RuntimeError("Instagram data container not found")


def active_crane_container_id(remote: Remote) -> str | None:
    """Return Crane's active container UUID, or ``None`` for Default/no Crane."""
    code, output, _error = remote.command(
        "/var/jb/usr/bin/crane-cli list " + BUNDLE_ID + " 2>/dev/null"
    )
    if code != 0:
        return None
    for line in output.splitlines():
        match = re.match(r"^\s*\*\s*\[([^]]+)\]", line)
        if not match:
            continue
        identifier = match.group(1).strip()
        if identifier.upper() == "DEFAULT":
            return None
        if not re.fullmatch(r"[A-Fa-f0-9-]{36}", identifier):
            raise RuntimeError(f"invalid active Crane container id: {identifier!r}")
        return identifier.upper()
    return None


def find_data_root(remote: Remote) -> str:
    """Resolve the filesystem root actually virtualized into Instagram.

    Crane keeps ``NSHomeDirectory`` looking like the parent app container while
    redirecting file access into ``Library/___Crane_Containers/<active UUID>``.
    Writing the frozen snapshot only to the parent therefore makes the guard
    fail closed at launch. Resolve the active UUID before Instagram is stopped.
    """
    parent = find_parent_data_root(remote)
    crane_id = active_crane_container_id(remote)
    if not crane_id:
        return parent
    active = f"{parent}/{CRANE_CONTAINERS_RELATIVE_PATH}/{crane_id}"
    if not remote.exists(active):
        raise RuntimeError(f"active Crane container directory is missing: {active}")
    return active


def ghost_source_path(data_root: str) -> str:
    if f"/{CRANE_CONTAINERS_RELATIVE_PATH}/" in data_root:
        return f"{data_root}/Documents/{GHOST_NAME}"
    return GLOBAL_GHOST_PATH


def current_snapshot_id(remote: Remote, data_root: str) -> str:
    return snapshot_id_from_global_bytes(remote.read_bytes(ghost_source_path(data_root)))


def _add_pair(replacements: list[tuple[str, str]], old: object, new: str) -> None:
    old_text = str(old or "").strip()
    if len(old_text) < 4 or old_text == new:
        return
    pair = (old_text, new)
    if pair not in replacements:
        replacements.append(pair)


def collect_snapshot(remote: Remote) -> Snapshot:
    # Contract: the effective identity source is read exactly once per apply.
    # Non-Crane keeps the canonical Global Ghost behavior. Crane must use the
    # active account's Documents plist because each account can have its own
    # stable random device.
    data_root = find_data_root(remote)
    source_path = ghost_source_path(data_root)
    prefs = plistlib.loads(remote.read_bytes(source_path))
    if not isinstance(prefs, dict):
        raise RuntimeError("Global Ghost plist is not a dictionary")
    model = str(prefs.get("deviceModel") or "").strip()
    hardware = str(prefs.get("deviceHardwareModel") or "").strip()
    display_name = str(prefs.get("deviceDisplayName") or "").strip()
    ios = str(prefs.get("iosVersion") or "").strip()
    build = parse_build(prefs.get("iosVersionBuild"))
    resolution = RES_MAP.get(model, "")
    if not (model and hardware and ios and build and resolution):
        raise RuntimeError(
            "unsupported/incomplete Global Ghost target "
            f"model={model!r} hardware={hardware!r} ios={ios!r} "
            f"build={build!r} resolution={resolution!r}"
        )

    stale: dict[str, Any] = {}
    try:
        stale = remote.read_plist(f"{data_root}/Documents/{GHOST_NAME}")
    except Exception:
        pass
    try:
        system = remote.read_plist("/System/Library/CoreServices/SystemVersion.plist")
    except Exception:
        system = {}
    _code, physical_model, _error = remote.command("uname -m 2>/dev/null")
    physical_model = physical_model.strip()

    width, height = resolution.split("x", 1)
    resolution_reverse = f"{height}x{width}"
    allowed = {
        model, hardware, display_name, ios, ios.replace(".", "_"), build,
        resolution, resolution_reverse,
    }
    replacements: list[tuple[str, str]] = []
    physical_resolution = RES_MAP.get(physical_model, "")
    _add_pair(replacements, physical_model, model)
    _add_pair(replacements, DEVICE_NAMES.get(physical_model), display_name or model)
    _add_pair(replacements, physical_resolution, resolution)
    if physical_resolution:
        p_width, p_height = physical_resolution.split("x", 1)
        _add_pair(replacements, f"{p_height}x{p_width}", resolution_reverse)
    real_ios = str(system.get("ProductVersion") or "")
    _add_pair(replacements, real_ios, ios)
    _add_pair(replacements, real_ios.replace(".", "_"), ios.replace(".", "_"))
    _add_pair(replacements, system.get("ProductBuildVersion"), build)

    stale_model = str(stale.get("deviceModel") or "")
    stale_ios = str(stale.get("iosVersion") or "")
    stale_resolution = RES_MAP.get(stale_model, "")
    _add_pair(replacements, stale_model, model)
    _add_pair(replacements, stale.get("deviceHardwareModel"), hardware)
    _add_pair(replacements, stale.get("deviceDisplayName"), display_name or model)
    _add_pair(replacements, stale_ios, ios)
    _add_pair(replacements, stale_ios.replace(".", "_"), ios.replace(".", "_"))
    _add_pair(replacements, parse_build(stale.get("iosVersionBuild"), required=False), build)
    _add_pair(replacements, stale_resolution, resolution)
    if stale_resolution:
        s_width, s_height = stale_resolution.split("x", 1)
        _add_pair(replacements, f"{s_height}x{s_width}", resolution_reverse)

    bad_markers: list[str] = []
    for old, _new in replacements:
        if old not in allowed and old not in bad_markers:
            bad_markers.append(old)
    identity = {
        "model": model,
        "hardware": hardware,
        "display_name": display_name,
        "ios": ios,
        "build": build,
        "resolution": resolution,
    }
    snapshot_id = hashlib.sha256(
        json.dumps(identity, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()[:16]
    return Snapshot(
        model=model,
        hardware=hardware,
        display_name=display_name,
        ios=ios,
        build=build,
        resolution=resolution,
        bad_markers=tuple(bad_markers),
        replacements=tuple(replacements),
        snapshot_id=snapshot_id,
        data_root=data_root,
        source_path=source_path,
    )


def assert_choicy_isolated(remote: Remote) -> str:
    candidates = (
        "/var/mobile/Library/Preferences/com.opa334.choicyprefs.plist",
        "/var/jb/var/mobile/Library/Preferences/com.opa334.choicyprefs.plist",
    )
    errors: list[str] = []
    for path in candidates:
        try:
            prefs = remote.read_plist(path)
        except Exception as exc:
            errors.append(f"{path}: {type(exc).__name__}")
            continue
        app = prefs.get("appSettings", {}).get(BUNDLE_ID, {})
        denied = list(app.get("deniedTweaks", []) or [])
        denied += list(app.get("globalDeniedTweaks", []) or [])
        denied_names = {str(name).strip().lower() for name in denied}
        if app.get("tweakInjectionDisabled") is not False:
            raise RuntimeError("Choicy disables tweak injection for Instagram")
        if not denied_names.intersection({"crane", "cranesb", "cranesupport"}):
            raise RuntimeError("Choicy must deny Crane/CraneSB/CraneSupport for Instagram")
        if denied_names.intersection({"igghostguard", "ig ghost guard"}):
            raise RuntimeError("Choicy currently denies IGGhostGuard")
        return path
    raise RuntimeError("Choicy preferences unavailable: " + "; ".join(errors))


def assert_no_overlap(
    remote: Remote, *, allow_iguafix_overlap: bool = False
) -> list[str]:
    command = (
        f"find {REAL_TWEAK_LOAD_DIR} -maxdepth 1 "
        "-type f -iname 'IGUAFix*.dylib' -print 2>/dev/null"
    )
    _code, output, _error = remote.command(command)
    active = sorted(line.strip() for line in output.splitlines() if line.strip())
    if active and not allow_iguafix_overlap:
        raise RuntimeError(f"active IGUAFix overlap found: {output.strip()}")
    return active


TOOLKIT_PACKAGE_ID = "com.langtoi.iostoolkit"


def guard_package_installed(remote: Remote) -> tuple[bool, str]:
    code, version, _error = remote.command(
        f"dpkg-query -W -f='${{Version}}' {PACKAGE_ID} 2>/dev/null"
    )
    if code == 0 and version.strip() == PACKAGE_VERSION:
        return True, f"{PACKAGE_ID}={version.strip()}"
    code, info, _error = remote.command(
        "dpkg-query -W -f='${Status}|${Provides}|${Version}' "
        f"{TOOLKIT_PACKAGE_ID} 2>/dev/null"
    )
    if code == 0 and "install ok installed" in info and PACKAGE_ID in info:
        version = info.rsplit("|", 1)[-1].strip()
        return True, f"{TOOLKIT_PACKAGE_ID}={version}"
    return False, ""


def classify_guard_files(
    enabled_dylib: bool,
    enabled_filter: bool,
    disabled_dylib: bool,
    disabled_filter: bool,
) -> str:
    if enabled_dylib and enabled_filter and not disabled_dylib and not disabled_filter:
        return "enabled"
    if disabled_dylib and disabled_filter and not enabled_dylib and not enabled_filter:
        return "disabled"
    raise RuntimeError(
        "guard files are in a partial/conflicting state: "
        f"enabled_dylib={enabled_dylib} enabled_filter={enabled_filter} "
        f"disabled_dylib={disabled_dylib} disabled_filter={disabled_filter}"
    )


def guard_install_state(remote: Remote) -> str:
    installed, _provider = guard_package_installed(remote)
    if not installed:
        raise RuntimeError(
            f"guard not installed: neither {PACKAGE_ID}=={PACKAGE_VERSION} nor "
            f"{TOOLKIT_PACKAGE_ID} (Provides {PACKAGE_ID}) is present"
        )
    state = classify_guard_files(
        remote.exists(INSTALLED_DYLIB),
        remote.exists(INSTALLED_FILTER),
        remote.exists(DISABLED_DYLIB),
        remote.exists(DISABLED_FILTER),
    )
    filter_path = INSTALLED_FILTER if state == "enabled" else DISABLED_FILTER
    filter_plist = remote.read_plist(filter_path)
    bundles = filter_plist.get("Filter", {}).get("Bundles", [])
    if bundles != [BUNDLE_ID]:
        raise RuntimeError(f"guard filter scope mismatch: {bundles!r}")
    return state


def assert_guard_installed(remote: Remote) -> None:
    state = guard_install_state(remote)
    if state != "enabled":
        raise RuntimeError("guard is disabled; run the enable command first")


def set_guard_enabled(remote: Remote, enabled: bool) -> str:
    state = guard_install_state(remote)
    target = "enabled" if enabled else "disabled"
    if state == target:
        return state
    if enabled:
        # Restore the filter first and dylib last. A partial failure therefore
        # cannot leave a loadable dylib without its intended filter.
        command = (
            f"mv {shlex.quote(DISABLED_FILTER)} {shlex.quote(INSTALLED_FILTER)} && "
            f"mv {shlex.quote(DISABLED_DYLIB)} {shlex.quote(INSTALLED_DYLIB)}"
        )
    else:
        # Remove the loadable dylib first. The app is already closed by every
        # caller, so no PID can retain a half-toggled runtime.
        command = (
            f"mv {shlex.quote(INSTALLED_DYLIB)} {shlex.quote(DISABLED_DYLIB)} && "
            f"mv {shlex.quote(INSTALLED_FILTER)} {shlex.quote(DISABLED_FILTER)}"
        )
    code, output, error = remote.sudo(command)
    if code != 0:
        raise RuntimeError(f"cannot toggle guard {target}: {(output + error).strip()}")
    final_state = guard_install_state(remote)
    if final_state != target:
        raise RuntimeError(f"toggle verification failed: expected={target} got={final_state}")
    return final_state


def snapshot_id_from_global_bytes(raw: bytes) -> str:
    prefs = plistlib.loads(raw)
    if not isinstance(prefs, dict):
        raise RuntimeError("Global Ghost plist is not a dictionary")
    model = str(prefs.get("deviceModel") or "").strip()
    identity = {
        "model": model,
        "hardware": str(prefs.get("deviceHardwareModel") or "").strip(),
        "display_name": str(prefs.get("deviceDisplayName") or "").strip(),
        "ios": str(prefs.get("iosVersion") or "").strip(),
        "build": parse_build(prefs.get("iosVersionBuild")),
        "resolution": RES_MAP.get(model, ""),
    }
    if not all(identity.values()):
        raise RuntimeError(f"Global Ghost identity is incomplete: {identity!r}")
    return hashlib.sha256(
        json.dumps(identity, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()[:16]


def list_instagram_crashes(remote: Remote) -> set[str]:
    _code, output, _error = remote.command(
        "find /var/mobile/Library/Logs/CrashReporter -type f "
        "-name 'Instagram-*.ips*' "
        "-print 2>/dev/null"
    )
    return {line.strip() for line in output.splitlines() if line.strip()}


def status_path(data_root: str) -> str:
    return f"{data_root}/{STATUS_RELATIVE_PATH}"


def snapshot_path(data_root: str) -> str:
    return f"{data_root}/{SNAPSHOT_RELATIVE_PATH}"


def process_matches_status(remote: Remote, status: dict[str, Any]) -> bool:
    pid = str(int(status.get("pid", 0) or 0))
    if pid == "0":
        return False
    return int(pid) in live_instagram_pids(remote)


def live_instagram_pids(remote: Remote) -> list[int]:
    # AutoTouch execute() supplies a procursus-only PATH which does not include
    # the stock iOS /bin directory. A relative `ps` therefore reports not found
    # and used to create a false pid_not_live_instagram failure even while the
    # guarded process was alive.
    _code, output, _error = remote.command(f"{IOS_PS} aux 2>/dev/null")
    pids: list[int] = []
    for line in output.splitlines():
        fields = line.split(None, 10)
        if len(fields) > 1 and "Instagram.app/Instagram" in line:
            try:
                pids.append(int(fields[1]))
            except ValueError:
                continue
    return sorted(set(pids))


def validate_status(
    remote: Remote,
    status: dict[str, Any],
    snapshot_id: str,
    *,
    minimum_requests: int,
    require_all_getters: bool,
) -> list[str]:
    problems: list[str] = []
    calls = int(status.get("calls", 0) or 0)
    ua_reads = int(status.get("ua_reads", 0) or 0)
    requests_without_ua = int(status.get("requests_without_ua", 0) or 0)
    getter_calls = int(status.get("getter_calls", 0) or 0)
    if status.get("guard_version") != GUARD_VERSION:
        problems.append("guard_version")
    if status.get("snapshot_id") != snapshot_id:
        problems.append("snapshot_id")
    if status.get("config_loaded") is not True:
        problems.append("config_not_loaded")
    if status.get("ready") is not True:
        problems.append("not_ready")
    if str(status.get("fatal_reason") or ""):
        problems.append(f"fatal:{status.get('fatal_reason')}")
    if int(status.get("getter_selectors", -1)) != 4:
        problems.append("getter_selectors")
    if int(status.get("getter_hooks", -1)) != 4:
        problems.append("getter_hooks")
    if int(status.get("tigon_hooks", -1)) != 1:
        problems.append("tigon_hooks")
    if status.get("target_bundle") != BUNDLE_ID:
        problems.append("target_bundle")
    if status.get("source_getters_required") is not True:
        problems.append("source_getters_required")
    if status.get("sysctl_enabled") is not True:
        problems.append("sysctl_not_enabled")
    if int(status.get("sysctl_hooks", -1)) != 1:
        problems.append("sysctl_hooks")
    if status.get("sysctl_scope") != "hw.product":
        problems.append("sysctl_scope")
    if int(status.get("sysctl_rewrites", 0)) <= 0:
        problems.append("sysctl_rewrites")
    if status.get("system_identity_verified") is not True:
        problems.append("system_identity_not_verified")
    if status.get("mobilegestalt_verified") is not True:
        problems.append("mobilegestalt_not_verified")
    if int(status.get("mobilegestalt_hooks", -1)) != 1:
        problems.append("mobilegestalt_hooks")
    if status.get("mobilegestalt_scope") != "ProductType":
        problems.append("mobilegestalt_scope")
    for key in ("sysctl_product_rewrites", "mobilegestalt_product_rewrites"):
        if int(status.get(key, 0)) <= 0:
            problems.append(key)
    # META 439 crashes before main when kern.osversion/ProductVersion/build
    # are rewritten.  The stable contract intentionally protects only the
    # ProductType surfaces and requires every disabled OS/build counter to
    # remain zero so a future build cannot silently broaden the hook again.
    for key in (
        "sysctl_build_rewrites",
        "sysctl_version_rewrites",
        "sysctl_mib_rewrites",
        "mobilegestalt_version_rewrites",
        "mobilegestalt_build_rewrites",
    ):
        if int(status.get(key, -1)) != 0:
            problems.append(key)
    if status.get("persistence_enabled") is not True:
        problems.append("persistence_enabled")
    if int(status.get("persistence_hooks", -1)) != 1:
        problems.append("persistence_hooks")
    if calls < minimum_requests:
        problems.append(f"calls<{minimum_requests}")
    if int(status.get("header_reads", -1)) != calls:
        problems.append("header_reads")
    if ua_reads <= 0:
        problems.append("ua_never_seen")
    if ua_reads + requests_without_ua != calls:
        problems.append("request_ua_accounting")
    if int(status.get("target_verified", -1)) != calls:
        problems.append("target_verified")
    if int(status.get("verified_requests", -1)) != calls:
        problems.append("verified_requests")
    if int(status.get("url_scanned", -1)) != calls:
        problems.append("url_scanned")
    if (
        int(status.get("rewrote", 0))
        + int(status.get("already_target", 0))
        + requests_without_ua
        != calls
    ):
        problems.append("request_rewrite_accounting")
    if getter_calls <= 0:
        problems.append("getter_calls")
    if int(status.get("getter_target_after", -1)) != getter_calls:
        problems.append("getter_target_after")
    if (
        int(status.get("getter_rewritten", 0))
        + int(status.get("getter_already_target", 0))
        != getter_calls
    ):
        problems.append("getter_rewrite_accounting")
    if require_all_getters:
        for key in GETTER_COUNTER_KEYS:
            if int(status.get(key, 0)) <= 0:
                problems.append(key)
    for key in (
        "getter_verify_fail",
        "getter_errors",
        "persistence_errors",
        "residual",
        "blocked",
        "errors",
    ):
        if int(status.get(key, -1)) != 0:
            problems.append(key)
    if not process_matches_status(remote, status):
        problems.append("pid_not_live_instagram")
    return problems


def read_live_status(remote: Remote, data_root: str) -> dict[str, Any] | None:
    try:
        return remote.read_plist(status_path(data_root))
    except Exception:
        return None


def wait_for_status(
    remote: Remote,
    data_root: str,
    snapshot_id: str,
    *,
    timeout: int,
    minimum_requests: int,
    require_all_getters: bool,
) -> tuple[dict[str, Any], list[str]]:
    deadline = time.monotonic() + timeout
    last: dict[str, Any] | None = None
    last_problems = ["status_missing"]
    while time.monotonic() <= deadline:
        status = read_live_status(remote, data_root)
        if status is not None:
            last = status
            last_problems = validate_status(
                remote,
                status,
                snapshot_id,
                minimum_requests=minimum_requests,
                require_all_getters=require_all_getters,
            )
            fatal = str(status.get("fatal_reason") or "")
            if not last_problems or fatal:
                return status, last_problems
        time.sleep(2)
    return last or {}, last_problems


def verify_warmup_window(
    remote: Remote,
    data_root: str,
    snapshot_id: str,
    *,
    duration: int,
    minimum_requests: int,
    stimulate_requests: bool = False,
    require_all_getters: bool = True,
) -> tuple[dict[str, Any], list[str], dict[str, Any]]:
    """Observe one guarded PID for a fixed window and enforce full coverage.

    The status file is process-local. Keeping the same PID and monotonic
    counters across the whole window proves that the four source getters and
    Tigon request entry were exercised by this launch, rather than accepting a
    stale status file or a short-lived process.
    """
    started = time.monotonic()
    deadline = started + duration
    samples = 0
    first_status: dict[str, Any] | None = None
    last_status: dict[str, Any] = {}
    last_problems = ["status_missing"]
    window_problems: set[str] = set()
    expected_pid = 0
    previous_calls: int | None = None
    previous_getter_calls: int | None = None
    nudge_count = 0
    last_nudge_at = -1000.0
    contract_closed_early = False
    nudge_urls = (
        "instagram://explore",
        "instagram://reels",
        "instagram://direct-inbox",
        "instagram://user?username=instagram",
        "instagram://",
    )

    while True:
        status = read_live_status(remote, data_root)
        samples += 1
        if status is None:
            window_problems.add("status_missing_during_warmup")
            last_problems = ["status_missing"]
        else:
            if first_status is None:
                first_status = dict(status)
                expected_pid = int(status.get("pid", 0) or 0)
            current_pid = int(status.get("pid", 0) or 0)
            if expected_pid and current_pid != expected_pid:
                window_problems.add("pid_changed_during_warmup")

            calls = int(status.get("calls", 0) or 0)
            getter_calls = int(status.get("getter_calls", 0) or 0)
            if previous_calls is not None and calls < previous_calls:
                window_problems.add("request_counter_regressed")
            if (
                previous_getter_calls is not None
                and getter_calls < previous_getter_calls
            ):
                window_problems.add("getter_counter_regressed")
            previous_calls = calls
            previous_getter_calls = getter_calls
            last_status = status
            last_problems = validate_status(
                remote,
                status,
                snapshot_id,
                minimum_requests=minimum_requests,
                require_all_getters=require_all_getters,
            )
            if str(status.get("fatal_reason") or ""):
                break

        now = time.monotonic()
        # Fast exit: validate_status() already accepts every counter it requires for
        # this PID, so the rest of the window would only re-prove the same facts.
        # The settle time keeps a launch that has not issued a request yet from
        # passing on an empty window.
        if (
            status is not None
            and not last_problems
            and now - started >= CONTRACT_SETTLE_SECONDS
        ):
            contract_closed_early = True
            break
        if (
            stimulate_requests
            and now - started >= 8.0
            and int(last_status.get("calls", 0) or 0) < minimum_requests
            and now - last_nudge_at >= 2.0
        ):
            URL = nudge_urls[nudge_count % len(nudge_urls)]
            remote.command(
                f"/var/jb/usr/bin/uiopen --url {shlex.quote(URL)} 2>&1",
                timeout=20,
            )
            nudge_count += 1
            last_nudge_at = now
        if now >= deadline:
            break
        time.sleep(min(2.0, max(0.0, deadline - now)))

    elapsed = max(0.0, time.monotonic() - started)
    if elapsed + 0.001 < duration and not contract_closed_early:
        window_problems.add("warmup_incomplete")
    problems = sorted(set(last_problems) | window_problems)
    initial = first_status or {}
    warmup = {
        "requested_seconds": duration,
        "contract_closed_early": contract_closed_early,
        "elapsed_seconds": round(elapsed, 3),
        "samples": samples,
        "pid": expected_pid,
        "same_pid": "pid_changed_during_warmup" not in window_problems,
        "initial_calls": int(initial.get("calls", 0) or 0),
        "final_calls": int(last_status.get("calls", 0) or 0),
        "new_calls": max(
            0,
            int(last_status.get("calls", 0) or 0)
            - int(initial.get("calls", 0) or 0),
        ),
        "initial_getter_calls": int(initial.get("getter_calls", 0) or 0),
        "final_getter_calls": int(last_status.get("getter_calls", 0) or 0),
        "new_getter_calls": max(
            0,
            int(last_status.get("getter_calls", 0) or 0)
            - int(initial.get("getter_calls", 0) or 0),
        ),
        "request_nudges": nudge_count,
        "getter_paths": {
            key: int(last_status.get(key, 0) or 0) for key in GETTER_COUNTER_KEYS
        },
        "all_getters_seen": all(
            int(last_status.get(key, 0) or 0) > 0 for key in GETTER_COUNTER_KEYS
        ),
        "local_runtime_verified": not problems,
        "server_session_verified": False,
        "server_session_note": (
            "Accounts Center session labels are server-side and require the "
            "separate session-check command after a protected login"
        ),
    }
    return last_status, problems, warmup


def install_package(remote: Remote, deb: Path, manifest: dict[str, Any]) -> None:
    remote_deb = f"/var/mobile/Media/{DEFAULT_DEB.name}"
    remote.upload(deb, remote_deb)
    remote_hash = hashlib.sha256(remote.read_bytes(remote_deb)).hexdigest()
    if remote_hash != manifest.get("deb_sha256"):
        raise RuntimeError("uploaded deb hash mismatch")
    code, output, error = remote.sudo(f"dpkg -i {shlex.quote(remote_deb)}", timeout=120)
    if code != 0:
        raise RuntimeError(f"dpkg install failed: {(output + error).strip()}")
    code, version, error = remote.command(
        f"dpkg-query -W -f='${{Version}}' {PACKAGE_ID} 2>/dev/null"
    )
    if code != 0 or version.strip() != PACKAGE_VERSION:
        raise RuntimeError(f"installed package version mismatch: {version.strip()} {error.strip()}")
    if not remote.exists(INSTALLED_DYLIB) or not remote.exists(INSTALLED_FILTER):
        raise RuntimeError("installed tweak files are missing")
    expected_dylib = manifest.get("dylib_sha256")
    if expected_dylib:
        installed_hash = hashlib.sha256(remote.read_bytes(INSTALLED_DYLIB)).hexdigest()
        if installed_hash != expected_dylib:
            raise RuntimeError("installed dylib hash mismatch")
    code, output, error = remote.sudo(
        f"rm -f {shlex.quote(DISABLED_DYLIB)} {shlex.quote(DISABLED_FILTER)}"
    )
    if code != 0:
        raise RuntimeError(f"cannot clear disabled package copies: {(output + error).strip()}")
    if guard_install_state(remote) != "enabled":
        raise RuntimeError("package install did not leave the guard enabled")


def stop_instagram(remote: Remote) -> None:
    remote.command(f"/var/jb/usr/bin/killall {PROCESS_NAME} 2>/dev/null || true")
    time.sleep(2)
    remote.command(f"/var/jb/usr/bin/killall -9 {PROCESS_NAME} 2>/dev/null || true")


def launch_instagram(remote: Remote) -> None:
    # On the target rootless build, uiopen --bundleid returns 0 while
    # runningboard creates no process. Opening Instagram's registered URL
    # scheme crosses the foreground-app boundary and produces the guarded PID.
    code, output, error = remote.command(
        f"/var/jb/usr/bin/uiopen --url {INSTAGRAM_URL} 2>&1", timeout=20
    )
    if code != 0:
        raise RuntimeError(f"uiopen failed: {(output + error).strip()}")


def spawn_instagram_no_attach(ip: str) -> int:
    """Force a suspended spawn then resume it without attaching any script."""
    try:
        import frida
    except ImportError as exc:
        raise RuntimeError("Frida client unavailable for launch-only fallback") from exc
    device = frida.get_device_manager().add_remote_device(f"{ip}:27042")
    pid = int(device.spawn([BUNDLE_ID]))
    device.resume(pid)
    return pid


def launch_guarded_and_wait(
    remote: Remote,
    device: DeviceSpec,
    data_root: str,
    snapshot_id: str,
    *,
    startup_timeout: int,
    minimum_requests: int,
    allow_frida_launch: bool,
) -> tuple[dict[str, Any], list[str], dict[str, Any] | None]:
    uiopen_error = ""
    try:
        launch_instagram(remote)
    except Exception as exc:
        uiopen_error = f"{type(exc).__name__}: {exc}"

    launch_deadline = time.monotonic() + min(8, startup_timeout)
    while time.monotonic() < launch_deadline:
        if read_live_status(remote, data_root) is not None:
            break
        time.sleep(1)

    fallback: dict[str, Any] | None = None
    if read_live_status(remote, data_root) is None:
        if not allow_frida_launch:
            detail = f" ({uiopen_error})" if uiopen_error else ""
            raise RuntimeError(
                "uiopen produced no guarded PID; open Instagram manually "
                f"and run check{detail}"
            )
        stop_instagram(remote)
        fallback_pid = spawn_instagram_no_attach(device.ip)
        fallback = {
            "kind": "frida_spawn_resume_no_attach",
            "pid": fallback_pid,
        }
    status, problems = wait_for_status(
        remote,
        data_root,
        snapshot_id,
        timeout=startup_timeout,
        minimum_requests=minimum_requests,
        require_all_getters=False,
    )
    return status, problems, fallback


def apply_one(
    device: DeviceSpec,
    *,
    deb: Path,
    manifest: dict[str, Any],
    startup_timeout: int,
    minimum_requests: int,
    warmup_seconds: int = DEFAULT_WARMUP_SECONDS,
    stage_only: bool,
    allow_frida_launch: bool,
    allow_iguafix_overlap: bool = False,
    fresh_container_bootstrap: bool = False,
) -> dict[str, Any]:
    result: dict[str, Any] = {"ip": device.ip, "action": "apply", "ok": False}
    try:
        with Remote(device) as remote:
            assert_choicy_isolated(remote)
            overlap = assert_no_overlap(
                remote, allow_iguafix_overlap=allow_iguafix_overlap
            )
            if overlap:
                result["iguafix_overlap"] = overlap
            # Close the old PID before snapshot/install. A process launched
            # before package injection must never stay online during apply.
            stop_instagram(remote)
            crashes_before = list_instagram_crashes(remote)
            snapshot = collect_snapshot(remote)
            result["snapshot"] = snapshot.public_payload()
            payload = plistlib.dumps(snapshot.plist_payload(), fmt=plistlib.FMT_BINARY)
            remote.write_atomic(snapshot_path(snapshot.data_root), payload)
            if remote.exists(status_path(snapshot.data_root)):
                remote.sftp.remove(status_path(snapshot.data_root))
            already_installed, provider = guard_package_installed(remote)
            if already_installed:
                guard_state = guard_install_state(remote)
                payload_path = (
                    INSTALLED_DYLIB if guard_state == "enabled" else DISABLED_DYLIB
                )
                expected_dylib = manifest.get("dylib_sha256")
                if expected_dylib:
                    installed_hash = hashlib.sha256(
                        remote.read_bytes(payload_path)
                    ).hexdigest()
                    if installed_hash != expected_dylib:
                        raise RuntimeError(
                            "installed/provider guard dylib does not match built artifact"
                        )
                if guard_state == "disabled":
                    set_guard_enabled(remote, True)
                assert_guard_installed(remote)
                result["installed_version"] = provider
            else:
                install_package(remote, deb, manifest)
                result["installed_version"] = PACKAGE_VERSION
            result["runtime_verified"] = False
            if stage_only:
                result.update(
                    {
                        "ok": True,
                        "staged_only": True,
                        "coverage": "package and frozen snapshot staged; run check after Instagram opens",
                    }
                )
                return result
            stop_instagram(remote)
            status, problems, fallback = launch_guarded_and_wait(
                remote,
                device,
                snapshot.data_root,
                snapshot.snapshot_id,
                startup_timeout=startup_timeout,
                minimum_requests=1,
                allow_frida_launch=allow_frida_launch,
            )
            if fallback:
                result["launch_fallback"] = fallback
            status, problems, warmup = verify_warmup_window(
                remote,
                snapshot.data_root,
                snapshot.snapshot_id,
                duration=warmup_seconds,
                minimum_requests=minimum_requests,
                stimulate_requests=True,
                require_all_getters=not fresh_container_bootstrap,
            )
            new_crashes = sorted(list_instagram_crashes(remote) - crashes_before)
            if new_crashes:
                problems.append("new_instagram_ips")
            result.update(
                {
                    "status": status,
                    "warmup": warmup,
                    "problems": sorted(set(problems)),
                    "new_crashes": new_crashes,
                    "coverage_mode": (
                        "fresh_container_bootstrap"
                        if fresh_container_bootstrap
                        else "authenticated_full"
                    ),
                    "minimum_requests_required": minimum_requests,
                    "all_getters_required": not fresh_container_bootstrap,
                    "full_authenticated_coverage": (
                        int(status.get("calls", 0) or 0) >= 100
                        and all(
                            int(status.get(key, 0) or 0) > 0
                            for key in GETTER_COUNTER_KEYS
                        )
                    ),
                    "coverage": (
                        (
                            "four IGUserAgent hooks installed plus every observed "
                            "IGTigon request audited"
                            if fresh_container_bootstrap
                            else "four IGUserAgent source getters plus "
                            "IGTigonNetworkLayer request entry"
                        )
                        + "; pure-C ProductType/OS surfaces self-verified; "
                        "no encrypted-wire claim"
                    ),
                }
            )
            result["ok"] = not result["problems"]
            result["runtime_verified"] = result["ok"]
            if not result["ok"]:
                stop_instagram(remote)
    except Exception as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
        try:
            with Remote(device) as cleanup:
                stop_instagram(cleanup)
        except Exception:
            pass
    return result


def check_one(
    device: DeviceSpec,
    *,
    duration: int,
    minimum_requests: int,
    require_all_getters: bool,
    allow_iguafix_overlap: bool = False,
) -> dict[str, Any]:
    result: dict[str, Any] = {"ip": device.ip, "action": "check", "ok": False}
    try:
        with Remote(device) as remote:
            assert_choicy_isolated(remote)
            overlap = assert_no_overlap(
                remote, allow_iguafix_overlap=allow_iguafix_overlap
            )
            if overlap:
                result["iguafix_overlap"] = overlap
            assert_guard_installed(remote)
            data_root = find_data_root(remote)
            config = remote.read_plist(snapshot_path(data_root))
            snapshot_id = str(config.get("snapshot_id") or "")
            if not snapshot_id:
                raise RuntimeError("frozen snapshot is missing or invalid")
            # Read canonical Global Ghost once. A clean old snapshot is still
            # the wrong result after the operator selects a new device.
            current_source_snapshot_id = current_snapshot_id(remote, data_root)
            crashes_before = list_instagram_crashes(remote)
            deadline = time.monotonic() + duration
            status: dict[str, Any] = {}
            problems = ["status_missing"]
            while True:
                current = read_live_status(remote, data_root)
                if current is not None:
                    status = current
                    problems = validate_status(
                        remote,
                        status,
                        snapshot_id,
                        minimum_requests=minimum_requests,
                        require_all_getters=require_all_getters,
                    )
                if time.monotonic() >= deadline:
                    break
                if str(status.get("fatal_reason") or ""):
                    break
                time.sleep(2)
            new_crashes = sorted(list_instagram_crashes(remote) - crashes_before)
            if new_crashes:
                problems.append("new_instagram_ips")
            if current_source_snapshot_id != snapshot_id:
                problems.append("snapshot_stale_reapply")
            result.update(
                {
                    "snapshot": {
                        key: config.get(key)
                        for key in (
                            "snapshot_id", "model", "hardware", "display_name",
                            "ios", "build", "resolution",
                        )
                    },
                    "status": status,
                    "problems": sorted(set(problems)),
                    "new_crashes": new_crashes,
                }
            )
            result["ok"] = not result["problems"]
    except Exception as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
    return result


def _normalized_ui_text(value: object) -> str:
    return re.sub(r"\s+", " ", str(value or "").replace("’", "'")).strip().casefold()


def analyze_login_activity_ocr(
    texts: list[str], expected_device: str
) -> dict[str, Any]:
    normalized_lines = [_normalized_ui_text(text) for text in texts if str(text).strip()]
    flat = " ".join(normalized_lines)
    page_detected = any(
        marker in flat
        for marker in (
            "account login activity",
            "where you're logged in",
            "you're currently logged in on these devices",
            "recent logins",
        )
    )

    candidates = sorted(set(DEVICE_NAMES.values()), key=len, reverse=True)
    observed = [
        name for name in candidates if _normalized_ui_text(name) in flat
    ]
    # Avoid reporting "iPhone 12 Pro" as a second device when OCR contains
    # the longer label "iPhone 12 Pro Max".
    observed = [
        name
        for name in observed
        if not any(
            name != other
            and _normalized_ui_text(name) in _normalized_ui_text(other)
            for other in observed
        )
    ]
    expected_seen = _normalized_ui_text(expected_device) in flat
    expected_is_this_device = any(
        "this device" in " ".join(normalized_lines[index : index + 4])
        for index, line in enumerate(normalized_lines)
        if _normalized_ui_text(expected_device) in line
    )
    if expected_seen and expected_device not in observed:
        observed.append(expected_device)
    observed.sort()

    no_other_devices = "no logins for this account on other devices" in flat
    no_recent_logins = "no logins for this account on iphone" in flat
    problems: list[str] = []
    if not page_detected:
        problems.append("login_activity_page_not_detected")
    elif not expected_seen:
        problems.append("server_session_device_mismatch")
    elif not expected_is_this_device:
        problems.append("expected_device_not_marked_current")
    return {
        "page_detected": page_detected,
        "expected_device": expected_device,
        "expected_device_seen": expected_seen,
        "expected_device_is_this_device": expected_is_this_device,
        "observed_devices": observed,
        "this_device_marker_seen": "this device" in flat,
        "no_other_devices": no_other_devices,
        "no_recent_logins_for_open_device": no_recent_logins,
        "scope": "active and recent server sessions shown by Accounts Center, not full login history",
        "problems": problems,
    }


def read_autotouch_ocr(ip: str, *, port: int, timeout: int) -> list[str]:
    host = f"[{ip}]" if ":" in ip and not ip.startswith("[") else ip
    lua = (
        "local ok,r=pcall(ocr,{method=OCR_METHOD.IOS_VISION,"
        "languages={\"en-US\"},correct=true,timeout=8}); "
        "if ok then return r else error(tostring(r)) end"
    )
    payload = json.dumps({"action": "RUNLUA", "data": lua}).encode("utf-8")
    request = urllib.request.Request(
        f"http://{host}:{port}/",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read()
    except (OSError, urllib.error.URLError) as exc:
        raise RuntimeError(f"AutoTouch OCR server unavailable: {exc}") from exc
    try:
        decoded = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeError("AutoTouch OCR server returned invalid JSON") from exc
    if not isinstance(decoded, dict) or decoded.get("success") is not True:
        raise RuntimeError(f"AutoTouch OCR failed: {decoded!r}")
    rows = decoded.get("data")
    if not isinstance(rows, list):
        raise RuntimeError("AutoTouch OCR response has no data array")
    return [
        str(row.get("text") or "")
        for row in rows
        if isinstance(row, dict) and str(row.get("text") or "").strip()
    ]


def session_check_one(
    device: DeviceSpec, *, autotouch_port: int, autotouch_timeout: int
) -> dict[str, Any]:
    """Compare the protected snapshot with the currently open Accounts Center page."""
    result: dict[str, Any] = {
        "ip": device.ip,
        "action": "session-check",
        "ok": False,
    }
    try:
        with Remote(device) as remote:
            assert_guard_installed(remote)
            data_root = find_data_root(remote)
            config = remote.read_plist(snapshot_path(data_root))
            snapshot_id = str(config.get("snapshot_id") or "")
            expected_device = str(config.get("display_name") or "").strip()
            if not snapshot_id or not expected_device:
                raise RuntimeError("frozen snapshot is missing identity fields")
            current_source_snapshot_id = current_snapshot_id(remote, data_root)
            status = read_live_status(remote, data_root) or {}
            runtime_problems = validate_status(
                remote,
                status,
                snapshot_id,
                minimum_requests=1,
                require_all_getters=True,
            )

        texts = read_autotouch_ocr(
            device.ip,
            port=autotouch_port,
            timeout=autotouch_timeout,
        )
        server_session = analyze_login_activity_ocr(texts, expected_device)
        problems = list(runtime_problems) + list(server_session["problems"])
        if current_source_snapshot_id != snapshot_id:
            problems.append("snapshot_stale_reapply")
        result.update(
            {
                "snapshot_id": snapshot_id,
                "snapshot_current": current_source_snapshot_id == snapshot_id,
                "expected_device": expected_device,
                "status": status,
                "server_session": server_session,
                "server_session_verified": not server_session["problems"],
                "problems": sorted(set(problems)),
                "note": (
                    "Read-only OCR check. Open Accounts Center > Password and "
                    "security > Where you're logged in before running this command."
                ),
            }
        )
        result["ok"] = not result["problems"]
    except Exception as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
    return result


def state_one(device: DeviceSpec) -> dict[str, Any]:
    result: dict[str, Any] = {"ip": device.ip, "action": "state", "ok": False}
    try:
        with Remote(device) as remote:
            state = guard_install_state(remote)
            data_root = find_data_root(remote)
            config = remote.read_plist(snapshot_path(data_root))
            snapshot_id = str(config.get("snapshot_id") or "")
            current_source_snapshot_id = current_snapshot_id(remote, data_root)
            status = read_live_status(remote, data_root) or {}
            live_pids = live_instagram_pids(remote)
            status_pid = int(status.get("pid", 0) or 0)
            protected = bool(
                state == "enabled"
                and status.get("ready") is True
                and not str(status.get("fatal_reason") or "")
                and status.get("snapshot_id") == snapshot_id
                and status_pid in live_pids
            )
            result.update(
                {
                    "ok": True,
                    "guard_state": state,
                    "enabled": state == "enabled",
                    "snapshot_id": snapshot_id,
                    "current_snapshot_id": current_source_snapshot_id,
                    "snapshot_current": snapshot_id == current_source_snapshot_id,
                    "instagram_pids": live_pids,
                    "instagram_protected": protected,
                    "status": status,
                }
            )
    except Exception as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
    return result


def disable_one(device: DeviceSpec) -> dict[str, Any]:
    result: dict[str, Any] = {"ip": device.ip, "action": "disable", "ok": False}
    try:
        with Remote(device) as remote:
            stop_instagram(remote)
            state = set_guard_enabled(remote, False)
            live_pids = live_instagram_pids(remote)
            if live_pids:
                raise RuntimeError(f"Instagram remained running after disable: {live_pids}")
            result.update(
                {
                    "ok": True,
                    "guard_state": state,
                    "enabled": False,
                    "instagram_pids": [],
                    "note": "Instagram was closed before disabling and was not relaunched",
                }
            )
    except Exception as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
        try:
            with Remote(device) as cleanup:
                stop_instagram(cleanup)
        except Exception:
            pass
    return result


def enable_one(
    device: DeviceSpec,
    *,
    startup_timeout: int,
    minimum_requests: int,
    warmup_seconds: int = DEFAULT_WARMUP_SECONDS,
    no_launch: bool,
    allow_frida_launch: bool,
    allow_iguafix_overlap: bool = False,
) -> dict[str, Any]:
    result: dict[str, Any] = {"ip": device.ip, "action": "enable", "ok": False}
    try:
        with Remote(device) as remote:
            stop_instagram(remote)
            assert_choicy_isolated(remote)
            overlap = assert_no_overlap(
                remote, allow_iguafix_overlap=allow_iguafix_overlap
            )
            if overlap:
                result["iguafix_overlap"] = overlap
            initial_state = guard_install_state(remote)
            data_root = find_data_root(remote)
            config = remote.read_plist(snapshot_path(data_root))
            snapshot_id = str(config.get("snapshot_id") or "")
            current_source_snapshot_id = current_snapshot_id(remote, data_root)
            result.update(
                {
                    "initial_state": initial_state,
                    "snapshot_id": snapshot_id,
                    "current_snapshot_id": current_source_snapshot_id,
                }
            )
            if not snapshot_id or snapshot_id != current_source_snapshot_id:
                if initial_state == "enabled":
                    set_guard_enabled(remote, False)
                raise RuntimeError(
                    "frozen snapshot does not match current Global Ghost; "
                    "guard was left disabled, run apply"
                )
            state = set_guard_enabled(remote, True)
            result.update({"guard_state": state, "enabled": True})
            if no_launch:
                result.update(
                    {
                        "ok": True,
                        "runtime_verified": False,
                        "instagram_protected": False,
                        "note": "guard enabled; Instagram remains closed until opened manually",
                    }
                )
                return result

            crashes_before = list_instagram_crashes(remote)
            path = status_path(data_root)
            if remote.exists(path):
                remote.sftp.remove(path)
            status, problems, fallback = launch_guarded_and_wait(
                remote,
                device,
                data_root,
                snapshot_id,
                startup_timeout=startup_timeout,
                minimum_requests=1,
                allow_frida_launch=allow_frida_launch,
            )
            status, problems, warmup = verify_warmup_window(
                remote,
                data_root,
                snapshot_id,
                duration=warmup_seconds,
                minimum_requests=minimum_requests,
                stimulate_requests=True,
            )
            new_crashes = sorted(list_instagram_crashes(remote) - crashes_before)
            if new_crashes:
                problems.append("new_instagram_ips")
            result.update(
                {
                    "status": status,
                    "warmup": warmup,
                    "problems": sorted(set(problems)),
                    "new_crashes": new_crashes,
                    "runtime_verified": not problems,
                    "instagram_protected": not problems,
                }
            )
            if fallback:
                result["launch_fallback"] = fallback
            result["ok"] = not result["problems"]
            if not result["ok"]:
                stop_instagram(remote)
    except Exception as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
        try:
            with Remote(device) as cleanup:
                stop_instagram(cleanup)
        except Exception:
            pass
    return result


def remove_one(device: DeviceSpec, *, keep_snapshot: bool) -> dict[str, Any]:
    result: dict[str, Any] = {"ip": device.ip, "action": "remove", "ok": False}
    try:
        with Remote(device) as remote:
            stop_instagram(remote)
            code, output, error = remote.sudo(f"dpkg -r {PACKAGE_ID}", timeout=120)
            message = output + error
            if (
                code != 0
                and "is not installed" not in message
                and "isn't installed" not in message
            ):
                raise RuntimeError(f"dpkg remove failed: {(output + error).strip()}")
            code, output, error = remote.sudo(
                f"rm -f {shlex.quote(DISABLED_DYLIB)} {shlex.quote(DISABLED_FILTER)}"
            )
            if code != 0:
                raise RuntimeError(
                    f"cannot remove disabled package copies: {(output + error).strip()}"
                )
            if not keep_snapshot:
                data_root = find_data_root(remote)
                for path in (snapshot_path(data_root), status_path(data_root)):
                    try:
                        remote.sftp.remove(path)
                    except OSError:
                        pass
            result["ok"] = True
    except Exception as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
    return result


def load_devices(args: argparse.Namespace) -> list[DeviceSpec]:
    default_password = args.password
    rows: list[tuple[str, str]] = []
    for ip in args.ip or []:
        rows.append((ip.strip(), default_password))
    if args.inventory:
        for raw_line in Path(args.inventory).read_text(encoding="utf-8-sig").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            if "," in line:
                ip, password = [part.strip() for part in line.split(",", 1)]
            else:
                ip, password = line, default_password
            rows.append((ip, password))
    if not rows:
        rows.append(("192.168.1.37", default_password))
    result: list[DeviceSpec] = []
    seen: set[str] = set()
    for ip, password in rows:
        if not re.fullmatch(r"[A-Za-z0-9_.:-]+", ip):
            raise RuntimeError(f"invalid device address: {ip!r}")
        if ip in seen:
            continue
        seen.add(ip)
        result.append(DeviceSpec(ip=ip, username=args.user, password=password))
    return result


def run_fleet(
    devices: list[DeviceSpec],
    worker: Callable[[DeviceSpec], dict[str, Any]],
    parallel: int,
) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(parallel, len(devices))) as pool:
        futures = {pool.submit(worker, device): device for device in devices}
        for future in concurrent.futures.as_completed(futures):
            device = futures[future]
            try:
                result = future.result()
            except Exception as exc:
                result = {
                    "ip": device.ip,
                    "ok": False,
                    "error": f"{type(exc).__name__}: {exc}",
                }
            results.append(result)
            state = "PASS" if result.get("ok") else "FAIL"
            status = result.get("status", {})
            snapshot_id = (
                result.get("snapshot", {}).get("snapshot_id")
                or result.get("snapshot_id")
                or "-"
            )
            detail = (
                f"snapshot={snapshot_id} calls={status.get('calls', 0)} "
                f"getters={status.get('getter_calls', 0)}"
            )
            if "guard_state" in result:
                detail = (
                    f"guard={result['guard_state']} snapshot={snapshot_id} "
                    f"protected={result.get('instagram_protected', False)}"
                )
            if result.get("error"):
                detail = str(result["error"])
            elif result.get("problems"):
                detail += f" problems={','.join(result['problems'])}"
            print(f"[{state}] {device.ip} {detail}", flush=True)
    return sorted(results, key=lambda item: str(item.get("ip", "")))


def add_device_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--ip", action="append", help="device IP; repeatable")
    parser.add_argument("--inventory", help="UTF-8 file containing IP or IP,password")
    parser.add_argument("--user", default="mobile")
    parser.add_argument(
        "--password", default=os.environ.get("IG_IPHONE_PASSWORD", "alpine")
    )
    parser.add_argument("--parallel", type=int, default=8)
    parser.add_argument("--report", help="write aggregate JSON report")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Persistent on-device Instagram Ghost apply/check CLI"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("build", help="build the rootless package with Theos")

    apply_parser = subparsers.add_parser(
        "apply", help="freeze Global Ghost, install guard and relaunch Instagram"
    )
    add_device_arguments(apply_parser)
    apply_parser.add_argument("--deb", type=Path, default=DEFAULT_DEB)
    apply_parser.add_argument("--rebuild", action="store_true")
    apply_parser.add_argument("--startup-timeout", type=int, default=45)
    apply_parser.add_argument(
        "--warmup-seconds",
        type=int,
        default=DEFAULT_WARMUP_SECONDS,
        help="fixed post-launch verification window (default: 30)",
    )
    apply_parser.add_argument(
        "--min-requests", type=int, default=DEFAULT_MIN_REQUESTS
    )
    apply_parser.add_argument(
        "--stage-only",
        action="store_true",
        help="install/freeze without opening Instagram; useful for fleet rollout",
    )
    apply_parser.add_argument(
        "--no-frida-launch-fallback",
        action="store_true",
        help="do not use launch-only Frida spawn when uiopen creates no PID",
    )
    apply_parser.add_argument(
        "--allow-iguafix-overlap",
        action="store_true",
        help="explicitly allow a separately verified active IGUAFix hook chain",
    )
    apply_parser.add_argument(
        "--fresh-container-bootstrap",
        action="store_true",
        help=(
            "allow logged-out fresh-container coverage: require observed request "
            "accounting and installed getter hooks, not authenticated MQTT traffic"
        ),
    )

    check_parser = subparsers.add_parser(
        "check", help="read on-device hook/request counters without injecting"
    )
    add_device_arguments(check_parser)
    check_parser.add_argument("--duration", type=int, default=0)
    check_parser.add_argument("--min-requests", type=int, default=1)
    check_parser.add_argument("--require-all-getters", action="store_true")
    check_parser.add_argument("--allow-iguafix-overlap", action="store_true")

    enable_parser = subparsers.add_parser(
        "enable", help="enable persistent injection, relaunch and verify Instagram"
    )
    add_device_arguments(enable_parser)
    enable_parser.add_argument("--startup-timeout", type=int, default=45)
    enable_parser.add_argument(
        "--warmup-seconds",
        type=int,
        default=DEFAULT_WARMUP_SECONDS,
        help="fixed post-launch verification window (default: 30)",
    )
    enable_parser.add_argument(
        "--min-requests", type=int, default=DEFAULT_MIN_REQUESTS
    )
    enable_parser.add_argument(
        "--no-launch",
        action="store_true",
        help="enable the guard but leave Instagram closed",
    )
    enable_parser.add_argument(
        "--no-frida-launch-fallback",
        action="store_true",
        help="do not use launch-only Frida spawn when uiopen creates no PID",
    )
    enable_parser.add_argument("--allow-iguafix-overlap", action="store_true")

    disable_parser = subparsers.add_parser(
        "disable", help="close Instagram and persistently disable guard injection"
    )
    add_device_arguments(disable_parser)

    state_parser = subparsers.add_parser(
        "state", help="show enabled/disabled, snapshot and live protection state"
    )
    add_device_arguments(state_parser)

    session_parser = subparsers.add_parser(
        "session-check",
        help="compare the open Accounts Center login-activity page with the snapshot",
    )
    add_device_arguments(session_parser)
    session_parser.add_argument(
        "--autotouch-port", type=int, default=DEFAULT_AUTOTOUCH_PORT
    )
    session_parser.add_argument("--autotouch-timeout", type=int, default=15)

    remove_parser = subparsers.add_parser("remove", help="rollback the on-device guard")
    add_device_arguments(remove_parser)
    remove_parser.add_argument("--keep-snapshot", action="store_true")

    args = parser.parse_args()
    for name in (
        "parallel",
        "startup_timeout",
        "warmup_seconds",
        "min_requests",
        "duration",
        "autotouch_port",
        "autotouch_timeout",
    ):
        if hasattr(args, name) and int(getattr(args, name)) < (1 if name != "duration" else 0):
            parser.error(f"--{name.replace('_', '-')} is out of range")
    if hasattr(args, "autotouch_port") and args.autotouch_port > 65535:
        parser.error("--autotouch-port is out of range")
    return args


def main() -> int:
    args = parse_args()
    if args.command == "build":
        try:
            deb, manifest = build_package()
        except Exception as exc:
            print(f"[BUILD-FAIL] {type(exc).__name__}: {exc}", file=sys.stderr)
            return 2
        print(f"[BUILD-PASS] {deb}")
        print(f"[SHA256] deb={manifest['deb_sha256']} dylib={manifest['dylib_sha256']}")
        return 0

    try:
        devices = load_devices(args)
        if args.command == "apply":
            deb = args.deb.expanduser().resolve()
            if args.rebuild:
                deb, manifest = build_package()
            elif deb.is_file():
                manifest = load_manifest(deb)
            else:
                # On-device toolkit builds can provide the already-installed
                # guard without shipping a standalone deb next to this module.
                manifest = {}
            worker = lambda device: apply_one(
                device,
                deb=deb,
                manifest=manifest,
                startup_timeout=args.startup_timeout,
                minimum_requests=args.min_requests,
                warmup_seconds=args.warmup_seconds,
                stage_only=args.stage_only,
                allow_frida_launch=not args.no_frida_launch_fallback,
                allow_iguafix_overlap=args.allow_iguafix_overlap,
                fresh_container_bootstrap=args.fresh_container_bootstrap,
            )
        elif args.command == "check":
            worker = lambda device: check_one(
                device,
                duration=args.duration,
                minimum_requests=args.min_requests,
                require_all_getters=args.require_all_getters,
                allow_iguafix_overlap=args.allow_iguafix_overlap,
            )
        elif args.command == "enable":
            worker = lambda device: enable_one(
                device,
                startup_timeout=args.startup_timeout,
                minimum_requests=args.min_requests,
                warmup_seconds=args.warmup_seconds,
                no_launch=args.no_launch,
                allow_frida_launch=not args.no_frida_launch_fallback,
                allow_iguafix_overlap=args.allow_iguafix_overlap,
            )
        elif args.command == "disable":
            worker = disable_one
        elif args.command == "state":
            worker = state_one
        elif args.command == "session-check":
            worker = lambda device: session_check_one(
                device,
                autotouch_port=args.autotouch_port,
                autotouch_timeout=args.autotouch_timeout,
            )
        else:
            worker = lambda device: remove_one(
                device, keep_snapshot=args.keep_snapshot
            )
        results = run_fleet(devices, worker, args.parallel)
        if args.report:
            report_path = Path(args.report).expanduser().resolve()
            report_path.parent.mkdir(parents=True, exist_ok=True)
            report_path.write_text(
                json.dumps(results, indent=2, ensure_ascii=False) + "\n",
                encoding="utf-8",
            )
            print(f"[REPORT] {report_path}")
        return 0 if all(item.get("ok") for item in results) else 1
    except Exception as exc:
        print(f"[FAIL] {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
