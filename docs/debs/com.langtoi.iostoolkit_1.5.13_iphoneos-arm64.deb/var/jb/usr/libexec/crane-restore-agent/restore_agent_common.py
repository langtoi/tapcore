#!/var/jb/usr/bin/python3
import json
import os
import plistlib
import shutil
import socket
import subprocess
import time
import uuid
import zipfile


DEFAULT_APP_KEY = "threads"
TARGET_CONTAINER = "taoacc"
JOBS_ROOT = "/var/mobile/Documents/restore_jobs"
CONFIG_PATH = "/var/jb/var/mobile/Library/Preferences/com.langtoi.crane-restore-config.json"
TASK_PATH = "/var/jb/var/mobile/Library/Preferences/com.langtoi.crane-task.plist"
TASK_LOG_PATH = "/var/jb/var/mobile/Library/Preferences/com.langtoi.crane-task.log"
LEGACY_TASK_PATH = "/var/jb/var/mobile/Library/Preferences/com.codex.crane-task.plist"
LEGACY_TASK_LOG_PATH = "/var/jb/var/mobile/Library/Preferences/com.codex.crane-task.log"
CRANE_PREFS_PATH = "/var/jb/var/mobile/Library/Preferences/com.opa334.craneprefs.plist"
PYTHON_BIN = "/var/jb/usr/bin/python3"
SH_BIN = "/var/jb/usr/bin/sh"
UNZIP_BIN = "/var/jb/usr/bin/unzip"
CP_BIN = "/var/jb/usr/bin/cp"
UIOPEN_BIN = "/var/jb/usr/bin/uiopen"
ZIP_BIN = "/var/jb/usr/bin/zip"
AGENT_STATE_PATH = os.path.join(JOBS_ROOT, ".agent_state.json")
RESTORE_LOG_WAIT_SECONDS = 25.0
DEFAULT_RESTORE_SHARE_SUBPATH = "Threads/ACCTH"
DEFAULT_BACKUP_SHARE_SUBPATH = "Threads/ACCTH"
SMB_LIVEFILES_ROOT = "/var/mobile/Library/LiveFiles/com.apple.filesystems.smbclientd"
AUTOTOUCH_SCRIPTS_DIR = "/var/mobile/Library/AutoTouch/Scripts"
AUTOTOUCH_ROOT_DIR = "/var/mobile/Library/AutoTouch"
AUTOTOUCH_JB_SCRIPTS_DIR = "/var/jb/var/mobile/Library/AutoTouch/Scripts"
AUTOTOUCH_JB_ROOT_DIR = "/var/jb/var/mobile/Library/AutoTouch"
HTTPD_BIND_HOST = "0.0.0.0"
HTTPD_CHECK_HOST = "127.0.0.1"
HTTPD_PORT = 9102
HTTPD_PID_PATH = "/var/jb/var/mobile/Library/Caches/crane-restore-httpd.pid"
HTTPD_LOG_PATH = "/var/jb/var/mobile/Library/Logs/crane-restore-httpd.log"
GHOST_PREFS_FILENAME = "com.sgwc.ghostprefs.plist"
GHOST_STAGE_DIR = "__langtoi__"
GHOST_SNAPSHOT_FILENAME = "ghost_snapshot.plist"
GHOST_META_FILENAME = "ghost_meta.json"
GHOST_SCHEMA_VERSION = 1

APP_PROFILES = {
    "threads": {
        "app_id": "com.burbn.barcelona",
        "container_name": TARGET_CONTAINER,
        "restore_share_subpath": "Threads/ACCTH",
        "backup_share_subpath": "Threads/ACCTH",
        "ghost_enabled": True,
        "username_plist_paths": [
            "Library/Preferences/com.burbn.barcelona.plist",
        ],
    },
    "instagram": {
        "app_id": "com.burbn.instagram",
        "container_name": TARGET_CONTAINER,
        "restore_share_subpath": "Instagram/ACCIG",
        "backup_share_subpath": "Instagram/ACCIG",
        "ghost_enabled": True,
        "username_plist_paths": [
            "Library/Preferences/com.burbn.instagram.plist",
        ],
    },
    "reddit": {
        "app_id": "com.reddit.Reddit",
        "container_name": TARGET_CONTAINER,
        "restore_share_subpath": "Reddit/ACCRD",
        "backup_share_subpath": "Reddit/ACCRD",
        "ghost_enabled": True,
        "username_plist_paths": [
            "Library/Preferences/com.reddit.Reddit.plist",
        ],
    },
}

APP_ID = APP_PROFILES[DEFAULT_APP_KEY]["app_id"]


def now_ts():
    return time.time()


def ensure_dir(path):
    os.makedirs(path, exist_ok=True)


def iso_now():
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())


def run_shell(command, check=True, capture_output=True):
    return subprocess.run(
        [SH_BIN, "-lc", command],
        check=check,
        text=True,
        capture_output=capture_output,
    )


S_IFMT = 0o170000
S_IFLNK = 0o120000


def zip_directory(stage_root, output_archive):
    """Archive a directory, falling back to Python when zip(1) is absent.

    zip/unzip are separate Procursus packages this deb neither ships nor depends
    on, so a phone that was restored comes back without them and the backup died
    at `zip ... returned non-zero exit status 127`.  The external binary stays
    the preferred path — it is what every working phone has been using — and
    Python only covers the gap.
    """
    if os.path.exists(ZIP_BIN):
        run_shell(f'cd "{stage_root}" && {ZIP_BIN} -rq "{output_archive}" .')
        return
    with zipfile.ZipFile(output_archive, "w", zipfile.ZIP_DEFLATED) as zf:
        for directory, dir_names, file_names in os.walk(stage_root):
            for name in sorted(dir_names) + sorted(file_names):
                full = os.path.join(directory, name)
                relative = os.path.relpath(full, stage_root)
                try:
                    # write() keeps the unix mode in external_attr and follows
                    # symlinks, which is what `zip -rq` does by default.
                    zf.write(full, relative)
                except (OSError, ValueError):
                    continue


def unzip_archive(archive_path, destination):
    """Extract an archive, falling back to Python when unzip(1) is absent."""
    if os.path.exists(UNZIP_BIN):
        run_shell(f'{UNZIP_BIN} -oq "{archive_path}" -d "{destination}"')
        return
    with zipfile.ZipFile(archive_path) as zf:
        for info in zf.infolist():
            target = os.path.join(destination, info.filename)
            mode = (info.external_attr >> 16) & 0xFFFF
            if (mode & S_IFMT) == S_IFLNK:
                ensure_dir(os.path.dirname(target))
                remove_if_exists(target)
                os.symlink(zf.read(info).decode("utf-8", "replace"), target)
                continue
            if info.is_dir():
                ensure_dir(target)
                continue
            ensure_dir(os.path.dirname(target))
            with zf.open(info) as source, open(target, "wb") as handle:
                shutil.copyfileobj(source, handle)
            if mode & 0o7777:
                os.chmod(target, mode & 0o7777)


def read_json(path, default=None):
    if not os.path.exists(path):
        return {} if default is None else default
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def write_json(path, data):
    tmp_path = f"{path}.tmp"
    ensure_dir(os.path.dirname(path))
    with open(tmp_path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2, sort_keys=True)
    os.replace(tmp_path, path)


def read_plist(path):
    with open(path, "rb") as fh:
        return plistlib.load(fh)


def write_plist(path, data, fmt=plistlib.FMT_BINARY):
    with open(path, "wb") as fh:
        plistlib.dump(data, fh, fmt=fmt)


def write_task_plist(data, fmt=plistlib.FMT_XML):
    for path in (TASK_PATH, LEGACY_TASK_PATH):
        write_plist(path, data, fmt=fmt)


def remove_if_exists(path):
    try:
        os.remove(path)
    except FileNotFoundError:
        pass


def clear_task_logs():
    for path in (TASK_LOG_PATH, LEGACY_TASK_LOG_PATH):
        remove_if_exists(path)


def clear_task_files():
    for path in (TASK_PATH, LEGACY_TASK_PATH, TASK_LOG_PATH, LEGACY_TASK_LOG_PATH):
        remove_if_exists(path)


def read_task_log():
    last = ""
    for path in (TASK_LOG_PATH, LEGACY_TASK_LOG_PATH):
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as fh:
                text = fh.read()
                if text:
                    last = text
        except FileNotFoundError:
            continue
    return last


def task_path_exists():
    return os.path.exists(TASK_PATH) or os.path.exists(LEGACY_TASK_PATH)


def job_dir(job_id):
    return os.path.join(JOBS_ROOT, job_id)


def job_paths(job_id):
    base = job_dir(job_id)
    return {
        "base": base,
        "archive": os.path.join(base, "input.cranect"),
        "output_archive": os.path.join(base, "output.cranect"),
        "job_json": os.path.join(base, "job.json"),
        "status_json": os.path.join(base, "status.json"),
        "restore_log": os.path.join(base, "restore.log"),
        "unpack": os.path.join(base, "unpack"),
        "stage": os.path.join(base, "stage"),
        "post_dump": os.path.join(base, "post_keychain_dump.plist"),
    }


def append_log(tracked_job_id, line):
    paths = job_paths(tracked_job_id)
    ensure_dir(paths["base"])
    text = f"[{iso_now()}] {line}\n"
    with open(paths["restore_log"], "a", encoding="utf-8") as fh:
        fh.write(text)


def update_status(tracked_job_id, **updates):
    paths = job_paths(tracked_job_id)
    ensure_dir(paths["base"])
    current = read_json(paths["status_json"], default={})
    current.update(updates)
    current["updated_at"] = now_ts()
    write_json(paths["status_json"], current)
    return current


def set_stage(tracked_job_id, stage, **extra):
    append_log(tracked_job_id, f"stage={stage}")
    payload = {"stage": stage}
    payload.update(extra)
    return update_status(tracked_job_id, **payload)


def error_text(exc):
    return str(exc) if str(exc) else exc.__class__.__name__


def normalize_share_subpath(value, fallback):
    cleaned = str(value or fallback).strip().strip("/")
    return cleaned or fallback


def default_config():
    return {
        "apps": {
            app_key: {
                "app_id": profile["app_id"],
                "container_name": profile["container_name"],
                "restore_share_subpath": profile["restore_share_subpath"],
                "backup_share_subpath": profile["backup_share_subpath"],
            }
            for app_key, profile in APP_PROFILES.items()
        }
    }


def merge_legacy_config(data):
    merged = default_config()
    if not isinstance(data, dict):
        return merged
    apps = data.get("apps")
    if isinstance(apps, dict):
        for app_key, profile in apps.items():
            if app_key not in merged["apps"] or not isinstance(profile, dict):
                continue
            merged["apps"][app_key].update(profile)
    legacy_share = data.get("share_subpath")
    if legacy_share:
        merged["apps"]["threads"]["restore_share_subpath"] = legacy_share
        merged["apps"]["threads"]["backup_share_subpath"] = legacy_share
    return merged


def load_config():
    merged = merge_legacy_config(read_json(CONFIG_PATH, default={}))
    for app_key, profile in merged["apps"].items():
        defaults = APP_PROFILES.get(app_key, {})
        profile["app_id"] = str(profile.get("app_id") or defaults.get("app_id") or "").strip()
        profile["container_name"] = str(profile.get("container_name") or defaults.get("container_name") or TARGET_CONTAINER).strip()
        profile["restore_share_subpath"] = normalize_share_subpath(
            profile.get("restore_share_subpath"),
            defaults.get("restore_share_subpath") or DEFAULT_RESTORE_SHARE_SUBPATH,
        )
        profile["backup_share_subpath"] = normalize_share_subpath(
            profile.get("backup_share_subpath"),
            defaults.get("backup_share_subpath") or DEFAULT_BACKUP_SHARE_SUBPATH,
        )
    return merged


def save_config(updates):
    current = load_config()
    if updates:
        deep_update(current, updates)
    write_json(CONFIG_PATH, current)
    return load_config()


def deep_update(target, updates):
    for key, value in (updates or {}).items():
        if isinstance(value, dict) and isinstance(target.get(key), dict):
            deep_update(target[key], value)
        else:
            target[key] = value


def nested_update_from_key(path_key, value):
    parts = [part for part in str(path_key or "").split(".") if part]
    if not parts:
        raise ValueError("config key is empty")
    if len(parts) == 1 and parts[0] == "share_subpath":
        return {
            "apps": {
                "threads": {
                    "restore_share_subpath": value,
                    "backup_share_subpath": value,
                }
            }
        }
    if len(parts) != 3 or parts[0] != "apps" or parts[1] not in APP_PROFILES:
        supported = "|".join(sorted(APP_PROFILES.keys()))
        raise ValueError(f"config key must be apps.<{supported}>.<field>")
    app_key = parts[1]
    field = parts[2]
    valid_fields = {"restore_share_subpath", "backup_share_subpath", "container_name"}
    if field not in valid_fields:
        raise ValueError("only app share subpaths or container_name are supported")
    payload = {"apps": {app_key: {field: value}}}
    return payload


def get_app_profile(app_key):
    normalized = str(app_key or DEFAULT_APP_KEY).strip().lower() or DEFAULT_APP_KEY
    config = load_config()
    if normalized not in config["apps"]:
        raise ValueError(f"unsupported app: {normalized}")
    profile = dict(APP_PROFILES.get(normalized, {}))
    profile.update(config["apps"][normalized])
    profile["app_key"] = normalized
    profile["app_id"] = str(profile.get("app_id") or "").strip()
    profile["container_name"] = str(profile.get("container_name") or TARGET_CONTAINER).strip()
    if not profile["app_id"]:
        raise ValueError(f"app profile missing app_id: {normalized}")
    return profile


def make_job_id(prefix="restore"):
    return f"{prefix}_{int(now_ts() * 1000)}_{uuid.uuid4().hex[:6]}"


def get_active_job_id():
    state = read_json(AGENT_STATE_PATH, default={})
    current_job = str(state.get("job_id") or "").strip()
    running = bool(state.get("running"))
    pid = state.get("pid")
    if running and current_job and pid:
        try:
            os.kill(int(pid), 0)
            return current_job
        except Exception:
            pass
    return ""


def get_latest_job_id():
    for name in list_known_jobs():
        return name
    return ""


def kickstart_agent():
    # STABILITY LOCK (2026-05-30):
    # This fast-path dispatch removed queue/launchd jitter and stabilized restore latency
    # to ~5s on repeated runs for the same archive.
    # Do NOT change this behavior unless explicitly requested by the operator.
    # Fast-path dispatch: run first queued job immediately when no active job is running.
    active_job = get_active_job_id()
    if not active_job:
        queued = list_queued_jobs()
        if queued:
            subprocess.Popen(
                ["/var/jb/usr/bin/crane-restore-agentctl", "run", "--job-id", queued[0]],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                close_fds=True,
            )
            return
    for label in (
        "user/501/com.langtoi.crane-restore-agent",
        "system/com.langtoi.crane-restore-agent",
    ):
        run_shell(f"/var/jb/usr/bin/launchctl kickstart -k {label}", check=False)


def validate_job_payload(payload):
    if not isinstance(payload, dict):
        raise ValueError("job.json must be an object")
    if str(payload.get("job_id") or "").strip() == "":
        raise ValueError("job_id is required")
    job_type = str(payload.get("job_type") or "restore").strip().lower()
    if job_type not in ("restore", "backup"):
        raise ValueError("job_type must be restore or backup")
    app_key = str(payload.get("app_key") or DEFAULT_APP_KEY).strip().lower()
    profile = get_app_profile(app_key)
    payload["job_type"] = job_type
    payload["app_key"] = app_key
    payload["app_id"] = profile["app_id"]
    payload["target_container"] = str(payload.get("target_container") or profile["container_name"] or TARGET_CONTAINER).strip()
    if not payload["target_container"]:
        raise ValueError("target_container is required")
    if job_type == "restore":
        archive_path = str(payload.get("archive_path") or "").strip()
        if not archive_path:
            raise ValueError("archive_path is required")
    return payload


def load_job(job_id):
    payload = read_json(job_paths(job_id)["job_json"], default=None)
    return validate_job_payload(payload)


def write_job(payload):
    payload = validate_job_payload(dict(payload))
    paths = job_paths(payload["job_id"])
    ensure_dir(paths["base"])
    write_json(paths["job_json"], payload)
    return payload


def enqueue_job(
    job_id,
    app_key,
    job_type="restore",
    archive_path="",
    open_app_after_restore=False,
    verify_post_restore=False,
    target_container="",
):
    ensure_dir(JOBS_ROOT)
    profile = get_app_profile(app_key)
    payload = {
        "job_id": job_id,
        "job_type": job_type,
        "app_key": profile["app_key"],
        "app_id": profile["app_id"],
        "target_container": str(target_container or profile["container_name"]).strip(),
        "archive_path": archive_path,
        "open_app_after_restore": bool(open_app_after_restore),
        "verify_post_restore": bool(verify_post_restore),
    }
    paths = job_paths(job_id)
    if job_type == "restore" and not os.path.exists(paths["archive"]):
        raise FileNotFoundError(f"archive not found: {paths['archive']}")
    write_job(payload)
    status = {
        "job_id": job_id,
        "job_type": job_type,
        "app_key": profile["app_key"],
        "app_id": profile["app_id"],
        "archive_path": archive_path,
        "target_container": str(payload["target_container"]),
        "running": False,
        "success": False,
        "stage": "queued",
        "error": "",
        "elapsed_s": 0.0,
        "created_at": now_ts(),
        "updated_at": now_ts(),
    }
    write_json(paths["status_json"], status)
    # The job directory must be writable by mobile. The keychain dump is written
    # by the Crane bridge running as mobile inside Preferences, so a job created
    # by a root process (the HTTP daemon, if it was started under sudo) leaves a
    # root-owned directory the bridge cannot write into — which surfaces much
    # later and very confusingly as "Timed out waiting for dump file".
    run_shell(f'chown -R mobile:mobile "{paths["base"]}" 2>/dev/null || true', check=False)
    append_log(job_id, "queued")
    return status


def list_queued_jobs():
    ensure_dir(JOBS_ROOT)
    queued = []
    for name in os.listdir(JOBS_ROOT):
        base = os.path.join(JOBS_ROOT, name)
        if not os.path.isdir(base) or name.startswith("."):
            continue
        paths = job_paths(name)
        if not os.path.exists(paths["job_json"]):
            continue
        status = read_json(paths["status_json"], default={})
        stage = status.get("stage") or ""
        running = bool(status.get("running"))
        if running or stage != "queued":
            continue
        try:
            queued.append((os.path.getmtime(paths["job_json"]), name))
        except OSError:
            continue
    queued.sort()
    return [name for _, name in queued]


def list_known_jobs():
    ensure_dir(JOBS_ROOT)
    jobs = []
    for name in os.listdir(JOBS_ROOT):
        base = os.path.join(JOBS_ROOT, name)
        if not os.path.isdir(base) or name.startswith("."):
            continue
        paths = job_paths(name)
        if not os.path.exists(paths["status_json"]):
            continue
        try:
            jobs.append((os.path.getmtime(paths["status_json"]), name))
        except OSError:
            continue
    jobs.sort(reverse=True)
    return [name for _, name in jobs]


def write_agent_state(**data):
    ensure_dir(JOBS_ROOT)
    payload = dict(data)
    payload["updated_at"] = now_ts()
    write_json(AGENT_STATE_PATH, payload)


def clear_agent_state():
    try:
        os.remove(AGENT_STATE_PATH)
    except FileNotFoundError:
        pass


def is_pid_running(pid):
    if not pid:
        return False
    try:
        os.kill(int(pid), 0)
        return True
    except Exception:
        return False


def terminate_pid(pid, grace_seconds=5.0):
    if not is_pid_running(pid):
        return False
    try:
        os.kill(int(pid), 15)
    except Exception:
        pass
    deadline = time.time() + grace_seconds
    while time.time() < deadline:
        if not is_pid_running(pid):
            return True
        time.sleep(0.2)
    try:
        os.kill(int(pid), 9)
    except Exception:
        pass
    time.sleep(0.2)
    return not is_pid_running(pid)


def mark_job_error(job_id, error_code, message):
    if not job_id:
        return
    paths = job_paths(job_id)
    if not os.path.exists(paths["status_json"]):
        return
    append_log(job_id, message)
    set_stage(
        job_id,
        "error",
        running=False,
        success=False,
        error=error_code,
    )


def recover_stale_agent_state():
    state = read_json(AGENT_STATE_PATH, default={})
    job_id = str(state.get("job_id") or "").strip()
    pid = state.get("pid")
    if not job_id or not state.get("running"):
        clear_agent_state()
        return {"recovered": False, "job_id": job_id, "pid": pid}
    if is_pid_running(pid):
        return {"recovered": False, "job_id": job_id, "pid": pid}
    clear_task_files()
    mark_job_error(job_id, "stale_agent_state", "stale agent state recovered after dead pid")
    clear_agent_state()
    return {"recovered": True, "job_id": job_id, "pid": pid}


def remove_all_job_dirs():
    ensure_dir(JOBS_ROOT)
    removed = []
    for name in os.listdir(JOBS_ROOT):
        base = os.path.join(JOBS_ROOT, name)
        if name.startswith("."):
            try:
                os.remove(base)
            except IsADirectoryError:
                shutil.rmtree(base, ignore_errors=True)
            except FileNotFoundError:
                pass
            continue
        if os.path.isdir(base):
            shutil.rmtree(base, ignore_errors=True)
            removed.append(name)
    return removed


def hard_reset_runtime(active_job_id="", active_pid=0, clear_http_log=False):
    stopped_active_pid = bool(active_pid and terminate_pid(active_pid))
    run_shell("pkill -f '/var/jb/usr/bin/crane-restore-agentctl run' 2>/dev/null || true", check=False)
    run_shell("pkill -f '/var/jb/usr/bin/crane-restore-agentd' 2>/dev/null || true", check=False)
    run_shell("killall Preferences cfprefsd 2>/dev/null || true", check=False)
    clear_task_files()
    clear_agent_state()
    removed_jobs = remove_all_job_dirs()
    remove_if_exists(HTTPD_PID_PATH)
    if clear_http_log:
        remove_if_exists(HTTPD_LOG_PATH)
    return {
        "stopped_active_pid": stopped_active_pid,
        "stopped_job_id": str(active_job_id or "").strip(),
        "removed_jobs": removed_jobs,
        "http_log_cleared": bool(clear_http_log),
    }


def discover_smb_share_root(share_subpath):
    subpath = normalize_share_subpath(share_subpath, DEFAULT_RESTORE_SHARE_SUBPATH)
    parts = [part for part in subpath.split("/") if part]
    if not parts:
        raise ValueError("share_subpath is empty")
    if not os.path.isdir(SMB_LIVEFILES_ROOT):
        raise FileNotFoundError(f"SMB livefiles root not found: {SMB_LIVEFILES_ROOT}")
    first = parts[0]
    rest = parts[1:]
    candidates = []
    for name in sorted(os.listdir(SMB_LIVEFILES_ROOT)):
        if not name.endswith(first):
            continue
        candidate = os.path.join(SMB_LIVEFILES_ROOT, name, *rest)
        if os.path.isdir(candidate):
            candidates.append(candidate)
    if not candidates:
        raise FileNotFoundError(f"No SMB share matches subpath: {subpath}")
    return candidates[0]


def find_latest_archive_for_username(app_key, username):
    profile = get_app_profile(app_key)
    username = str(username or "").strip()
    if not username:
        raise ValueError("username is required")
    source_roots = [
        AUTOTOUCH_SCRIPTS_DIR,
        AUTOTOUCH_ROOT_DIR,
        AUTOTOUCH_JB_SCRIPTS_DIR,
        AUTOTOUCH_JB_ROOT_DIR,
    ]
    existing_roots = [p for p in source_roots if os.path.isdir(p)]
    if not existing_roots:
        raise FileNotFoundError(f"AutoTouch directories not found: {source_roots}")
    uname = username.lower()
    matches = []
    for source_root in existing_roots:
        for name in os.listdir(source_root):
            low = name.lower()
            if not low.endswith(".cranect"):
                continue
            stem = low[:-8]
            if not stem.startswith(uname):
                continue
            next_char = stem[len(uname):len(uname) + 1]
            if next_char and next_char not in ("_", ".", "-"):
                continue
            full = os.path.join(source_root, name)
            try:
                matches.append((os.path.getmtime(full), name, full, source_root))
            except OSError:
                continue
    if not matches:
        raise FileNotFoundError(f"No .cranect file found for username {username} in {existing_roots}")
    matches.sort(reverse=True)
    _, selected_name, selected_path, selected_root = matches[0]
    return {
        "app_key": profile["app_key"],
        "app_id": profile["app_id"],
        "username": username,
        "share_subpath": profile["restore_share_subpath"],
        "source_mode": "local_scripts_webdav",
        "source_root": selected_root,
        "selected_file": selected_name,
        "source_path": selected_path,
        "size_bytes": os.path.getsize(selected_path),
    }


def stage_archive_from_source(job_id, source_path):
    paths = job_paths(job_id)
    ensure_dir(paths["base"])
    started = now_ts()
    shutil.copy2(source_path, paths["archive"])
    elapsed = round(now_ts() - started, 3)
    return {
        "archive_path": paths["archive"],
        "copy_s": elapsed,
        "size_bytes": os.path.getsize(paths["archive"]),
    }


def start_restore_for_username(
    app_key,
    username,
    open_app_after_restore=False,
    verify_post_restore=False,
    target_container="",
):
    active_job_id = get_active_job_id()
    if active_job_id:
        raise RuntimeError(f"another job is already active: {active_job_id}")
    match = find_latest_archive_for_username(app_key, username)
    job_id = make_job_id(f"{match['app_key']}_restore")
    staged = stage_archive_from_source(job_id, match["source_path"])
    status = enqueue_job(
        job_id=job_id,
        app_key=match["app_key"],
        job_type="restore",
        archive_path=staged["archive_path"],
        open_app_after_restore=bool(open_app_after_restore),
        verify_post_restore=bool(verify_post_restore),
        target_container=target_container,
    )
    update_status(
        job_id,
        selected_file=match["selected_file"],
        source_path=match["source_path"],
        source_mode=match.get("source_mode") or "local_scripts_webdav",
        source_root=match["source_root"],
        share_subpath=match["share_subpath"],
        size_bytes=staged["size_bytes"],
        copy_s=staged["copy_s"],
    )
    kickstart_agent()
    return {
        "success": True,
        "job_id": job_id,
        "job_type": "restore",
        "app_key": match["app_key"],
        "username": username,
        "selected_file": match["selected_file"],
        "source_path": match["source_path"],
        "source_mode": match.get("source_mode") or "local_scripts_webdav",
        "source_root": match["source_root"],
        "archive_path": staged["archive_path"],
        "share_subpath": match["share_subpath"],
        "copy_s": staged["copy_s"],
        "size_bytes": staged["size_bytes"],
        "status": status,
    }


def start_backup_for_app(app_key, target_container=""):
    active_job_id = get_active_job_id()
    if active_job_id:
        raise RuntimeError(f"another job is already active: {active_job_id}")
    profile = get_app_profile(app_key)
    job_id = make_job_id(f"{profile['app_key']}_backup")
    status = enqueue_job(
        job_id=job_id,
        app_key=profile["app_key"],
        job_type="backup",
        target_container=target_container,
    )
    update_status(
        job_id,
        share_subpath=profile["backup_share_subpath"],
    )
    kickstart_agent()
    return {
        "success": True,
        "job_id": job_id,
        "job_type": "backup",
        "app_key": profile["app_key"],
        "share_subpath": profile["backup_share_subpath"],
        "status": status,
    }


def is_tcp_port_open(host, port, timeout_seconds=0.25):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout_seconds)
    try:
        return sock.connect_ex((host, int(port))) == 0
    finally:
        sock.close()


def read_archive_info(archive_path):
    with zipfile.ZipFile(archive_path) as zf:
        return plistlib.loads(zf.read("Info.plist"))


def get_archive_device_id(archive_info, fallback):
    return str(
        archive_info.get("deviceIdentifierForVendor")
        or archive_info.get("containerIdentifier")
        or fallback
    )


def get_app_kill_command(app_id):
    if app_id == "com.burbn.barcelona":
        return "killall Threads 2>/dev/null || true"
    if app_id == "com.burbn.instagram":
        return "killall Instagram 2>/dev/null || true"
    if app_id == "com.reddit.Reddit":
        return "killall Reddit 2>/dev/null || true"
    return ""


def quiesce_app_for_backup(job_id, app_id, settle_seconds=2.0):
    """Close the app and flush cfprefsd before the container is staged.

    An app's preferences live in cfprefsd's memory while it runs, so a live copy
    can miss Library/Preferences/<bundle>.plist entirely.  That file is the only
    source of the account username (last-logged-in-account-dict), so backing up a
    running app produced an empty username and an archive with no preferences at
    all.  Closing the app hands its pending writes to cfprefsd; killing cfprefsd
    then flushes them to disk.  Same order prepare_remote_container already uses.

    It also makes the archive self-consistent: sqlite/WAL files are no longer
    copied while the app is writing to them.
    """
    set_stage(job_id, "quiesce_app")
    app_kill_command = get_app_kill_command(app_id)
    if app_kill_command:
        run_shell(app_kill_command, check=False)
    run_shell("killall cfprefsd 2>/dev/null || true", check=False)
    if settle_seconds > 0:
        time.sleep(settle_seconds)
    append_log(job_id, f"quiesce_app app_id={app_id} settle_s={settle_seconds}")


def diagnose_missing_username(profile, stage_root, container_is_active=True):
    """Explain an empty username so /status can be read without SSHing in."""
    if not container_is_active:
        # Live preferences were deliberately not overlaid, so the plist can only
        # be whatever the Crane slot happened to hold.
        return "container_not_active"
    app_root = os.path.join(stage_root, profile["app_id"])
    for relative_path in profile.get("username_plist_paths") or []:
        plist_path = os.path.join(app_root, relative_path)
        if not os.path.exists(plist_path):
            continue
        try:
            data = read_plist(plist_path)
        except Exception:
            return "prefs_plist_unreadable"
        if not isinstance(data, dict):
            return "prefs_plist_unreadable"
        if not signed_in_owner(data):
            return "no_logged_in_account"
        account = data.get("last-logged-in-account-dict") or {}
        raw = str((account or {}).get("username") or "").strip()
        if not raw or raw.lower() in USERNAME_PLACEHOLDERS:
            # Signed in, but the app has not cached the name in preferences.
            return "username_not_in_preferences"
        return "username_field_empty"
    return "prefs_plist_missing"


def prepare_remote_container(job_id, app_id, target_name, archive_device_id):
    set_stage(job_id, "prepare_remote")
    temp_name = f"{target_name}__tmp__{int(now_ts() * 1000)}"
    app_kill_command = get_app_kill_command(app_id)
    if app_kill_command:
        run_shell(app_kill_command, check=False)
    run_shell("killall cfprefsd 2>/dev/null || true", check=False)
    run_shell(f'crane-cli delete {app_id} {target_name} >/dev/null 2>&1 || true', check=False)
    run_shell(f'crane-cli delete {app_id} {temp_name} >/dev/null 2>&1 || true', check=False)
    run_shell(f'crane-cli create {app_id} {temp_name}')

    prefs = read_plist(CRANE_PREFS_PATH)
    app = prefs.setdefault(f"appSettings_{app_id}", {})
    containers = app.setdefault("Containers", [])
    target = None
    for item in containers:
        if item.get("name") == temp_name:
            target = item
            break
    if not target or not target.get("identifier"):
        raise RuntimeError(f"Cannot find created temp container id for {temp_name}")

    target_id = str(target["identifier"]).strip()
    target["customDeviceIdentifier"] = archive_device_id
    target["useContainerIdentifierAsDeviceIdentifier"] = False
    if "notificationsAllowed" not in target:
        target["notificationsAllowed"] = False
    app["activeContainer"] = target_id
    write_plist(CRANE_PREFS_PATH, prefs, fmt=plistlib.FMT_BINARY)
    run_shell("killall cfprefsd 2>/dev/null || true", check=False)

    update_status(
        job_id,
        temp_container_name=temp_name,
        target_container_id=target_id,
    )
    append_log(job_id, f"temp_container={temp_name} target_container_id={target_id}")
    return temp_name, target_id


def unzip_archive(job_id, archive_path):
    paths = job_paths(job_id)
    set_stage(job_id, "unzip_archive")
    shutil.rmtree(paths["unpack"], ignore_errors=True)
    ensure_dir(paths["unpack"])
    unzip_archive(archive_path, paths["unpack"])
    return paths["unpack"]


def resolve_root_targets(job_id, root_identifiers, target_container_id):
    set_stage(job_id, "resolve_roots")
    resolved = {}
    for base in (
        "/var/mobile/Containers/Data/Application",
        "/var/mobile/Containers/Data/PluginKitPlugin",
        "/var/mobile/Containers/Shared/AppGroup",
    ):
        if not os.path.isdir(base):
            continue
        for entry in os.listdir(base):
            candidate = os.path.join(base, entry)
            meta = os.path.join(candidate, ".com.apple.mobile_container_manager.metadata.plist")
            if not os.path.exists(meta):
                continue
            try:
                pl = read_plist(meta)
            except Exception:
                continue
            ident = pl.get("MCMMetadataIdentifier")
            if ident in root_identifiers and ident not in resolved:
                resolved[ident] = os.path.join(candidate, "Library", "___Crane_Containers", target_container_id)
    missing = [ident for ident in root_identifiers if ident not in resolved]
    if missing:
        raise RuntimeError("Cannot resolve roots on device: " + ", ".join(missing))
    return resolved


def discover_container_roots(container_id):
    resolved = {}
    for base in (
        "/var/mobile/Containers/Data/Application",
        "/var/mobile/Containers/Data/PluginKitPlugin",
        "/var/mobile/Containers/Shared/AppGroup",
    ):
        if not os.path.isdir(base):
            continue
        for entry in os.listdir(base):
            candidate = os.path.join(base, entry)
            slot = os.path.join(candidate, "Library", "___Crane_Containers", container_id)
            meta = os.path.join(candidate, ".com.apple.mobile_container_manager.metadata.plist")
            if not os.path.isdir(slot) or not os.path.exists(meta):
                continue
            try:
                pl = read_plist(meta)
            except Exception:
                continue
            ident = str(pl.get("MCMMetadataIdentifier") or "").strip()
            if ident and ident not in resolved:
                resolved[ident] = candidate
    if not resolved:
        raise RuntimeError(f"Cannot resolve live roots on device for container: {container_id}")
    return resolved


def copy_root_data(job_id, unpack_root, resolved):
    set_stage(job_id, "copy_data")
    for root_id, target_path in resolved.items():
        src_path = os.path.join(unpack_root, root_id)
        shutil.rmtree(target_path, ignore_errors=True)
        ensure_dir(target_path)
        if os.path.isdir(src_path):
            run_shell(f'{CP_BIN} -R "{src_path}/." "{target_path}/"')
        run_shell(f'chown -R mobile:mobile "{target_path}" 2>/dev/null || true', check=False)
    run_shell(f'chown -R mobile:mobile "{job_paths(job_id)["base"]}" 2>/dev/null || true', check=False)


def read_active_container_id(app_id):
    """Container id Crane currently has active for this app, or ''."""
    try:
        prefs = read_plist(CRANE_PREFS_PATH)
    except Exception:
        return ""
    app = prefs.get(f"appSettings_{app_id}") or {}
    return str(app.get("activeContainer") or "").strip()


def preference_candidates(profile, roots, container_id):
    """Every copy of the app's preference plist on disk, newest first.

    Which side is live depends on the container's age, and BOTH occur in normal
    use:

    * a container that has been in use keeps its plist in the Crane slot, and the
      app's real root holds a stale copy — on some phones naming a different
      account entirely;
    * a container that was just deleted and recreated has no plist in the slot at
      all, and the live one sits in the app's real root.

    Assuming either side is authoritative gets the wrong account. Compare them.
    """
    found = {}
    for root_path in roots.values():
        for relative_path in profile.get("username_plist_paths") or []:
            for candidate in (
                os.path.join(
                    root_path, "Library", "___Crane_Containers", container_id, relative_path
                ),
                os.path.join(root_path, relative_path),
            ):
                if not os.path.isfile(candidate):
                    continue
                try:
                    found[candidate] = os.path.getmtime(candidate)
                except OSError:
                    continue
    return [path for path, _ in sorted(found.items(), key=lambda kv: kv[1], reverse=True)]


def read_username_live(profile, roots, container_id):
    """Username from the newest preference plist that shows a signed-in account.

    A real owner FbID is the proof that an account is signed in; the username
    string alone is not. Both failure modes were observed:

    * a real account whose username field held the placeholder "Instagram user";
    * a logged-out container whose stale plist still carried the name of the
      account that used to be signed in, two weeks after it was signed out.

    Naming an archive after the second case is a lie — the archive holds no
    account at all — so a username is only accepted together with a real owner
    id. With none, the caller falls back to the container name.
    """
    for path in preference_candidates(profile, roots, container_id):
        try:
            name = read_username_from_plist_data(read_plist(path))
        except Exception:
            continue
        if name:
            return name
    return ""


def copy_live_preferences(job_id, stage_root, roots):
    """Bring the app's real-root preferences into the stage when they are newer.

    Preferences are written by cfprefsd, which Crane does not redirect, so for a
    freshly recreated container the live plist is in the app's real root and the
    Crane slot has none at all. For a container that has been in use it is the
    other way round, and the real root is stale — sometimes by days, naming a
    different account. Copying either way unconditionally archives the wrong
    account, so compare file by file and let the newer copy win.

    Only valid for the container Crane has ACTIVE: for any other container the
    real-root plists belong to whichever account is active instead.
    """
    copied = 0
    for root_id, root_path in roots.items():
        src_prefs = os.path.join(root_path, "Library", "Preferences")
        if not os.path.isdir(src_prefs):
            continue
        dst_prefs = os.path.join(stage_root, root_id, "Library", "Preferences")
        ensure_dir(dst_prefs)
        for name in os.listdir(src_prefs):
            source = os.path.join(src_prefs, name)
            if not os.path.isfile(source):
                continue
            target = os.path.join(dst_prefs, name)
            try:
                if os.path.exists(target) and os.path.getmtime(target) >= os.path.getmtime(source):
                    continue
                shutil.copy2(source, target)
                copied += 1
            except OSError:
                continue
    append_log(job_id, f"live_preferences newer_files={copied} roots={len(roots)}")


def copy_live_root_data(job_id, stage_root, roots, container_id, live_preferences=False):
    set_stage(job_id, "copy_data")
    for root_id, root_path in roots.items():
        src_path = os.path.join(root_path, "Library", "___Crane_Containers", container_id)
        dst_path = os.path.join(stage_root, root_id)
        shutil.rmtree(dst_path, ignore_errors=True)
        ensure_dir(dst_path)
        if os.path.isdir(src_path):
            run_shell(f'{CP_BIN} -R "{src_path}/." "{dst_path}/"')
    if live_preferences:
        # After the Crane copy, so a newer real-root plist can still win.
        copy_live_preferences(job_id, stage_root, roots)
    run_shell(f'chown -R mobile:mobile "{job_paths(job_id)["base"]}" 2>/dev/null || true', check=False)


def wait_for_task_log(required_parts, timeout_seconds):
    deadline = now_ts() + timeout_seconds
    last_log = ""
    while now_ts() < deadline:
        last_log = read_task_log()
        if all(part in last_log for part in required_parts):
            return last_log
        time.sleep(1.0)
    raise RuntimeError("Timed out waiting for restore log:\n" + last_log)


def run_keychain_restore(job_id, app_id, target_container_id, unpack_root):
    set_stage(job_id, "restore_keychain")
    # STABILITY LOCK (2026-05-30):
    # Retry-once logic handles intermittent Preferences/task-log timing gaps that caused
    # sporadic "Timed out waiting for restore log" failures.
    # Do NOT remove or alter retry semantics unless explicitly requested by the operator.
    task = {
        "mode": "restore",
        "app_id": app_id,
        "container_id": target_container_id,
        "path": os.path.join(unpack_root, "Keychain.plist"),
    }
    last_exc = None
    for attempt in (1, 2):
        write_task_plist(task, fmt=plistlib.FMT_XML)
        clear_task_logs()
        run_shell("killall Preferences cfprefsd 2>/dev/null || true", check=False)
        run_shell(f"{UIOPEN_BIN} --bundleid com.apple.Preferences")
        try:
            return wait_for_task_log(["restore-sent", "task:done success=1"], RESTORE_LOG_WAIT_SECONDS)
        except Exception as exc:
            last_exc = exc
            append_log(job_id, f"restore_keychain_retry attempt={attempt} error={error_text(exc)}")
            if attempt == 1:
                # Let Preferences restart cleanly before final retry.
                time.sleep(1.0)
                continue
            raise
    if last_exc:
        raise last_exc


def dump_keychain(job_id, app_id, target_container_id, dump_path):
    set_stage(job_id, "dump_keychain")
    task = {
        "mode": "dump",
        "app_id": app_id,
        "container_id": target_container_id,
        "path": dump_path,
    }
    write_task_plist(task, fmt=plistlib.FMT_XML)
    clear_task_logs()
    remove_if_exists(dump_path)
    run_shell("killall Preferences cfprefsd 2>/dev/null || true", check=False)
    run_shell(f"{UIOPEN_BIN} --bundleid com.apple.Preferences")
    wait_deadline = now_ts() + RESTORE_LOG_WAIT_SECONDS
    while now_ts() < wait_deadline:
        if os.path.exists(dump_path):
            break
        time.sleep(1.0)
    if not os.path.exists(dump_path):
        raise RuntimeError(f"Timed out waiting for dump file: {dump_path}")
    wait_for_task_log(["task:done success=1"], RESTORE_LOG_WAIT_SECONDS)
    return read_plist(dump_path)


def compare_keychain_counts(archive_path, live_dump):
    with zipfile.ZipFile(archive_path) as zf:
        archive_kc = plistlib.loads(zf.read("Keychain.plist"))

    def counts(obj):
        return {key: len(value) for key, value in obj.items()}

    return {
        "archiveCounts": counts(archive_kc),
        "liveCounts": counts(live_dump),
    }


def switch_container(job_id, app_id, temp_name, target_name, open_app_after_restore):
    set_stage(job_id, "switch_container")
    run_shell(f'crane-cli delete {app_id} {target_name} >/dev/null 2>&1 || true', check=False)
    run_shell(f"crane-cli rename {app_id} {temp_name} {target_name}")
    run_shell(f"crane-cli switch {app_id} {target_name}")
    run_shell("killall cfprefsd 2>/dev/null || true", check=False)
    if open_app_after_restore:
        app_kill_command = get_app_kill_command(app_id)
        if app_kill_command:
            run_shell(app_kill_command, check=False)
            time.sleep(1.5)
        run_shell(f"{UIOPEN_BIN} --bundleid {app_id}")


def cleanup_job_artifacts(job_id, remove_archive_on_success=True):
    set_stage(job_id, "cleanup")
    paths = job_paths(job_id)
    shutil.rmtree(paths["unpack"], ignore_errors=True)
    shutil.rmtree(paths["stage"], ignore_errors=True)
    clear_task_files()
    remove_if_exists(paths["post_dump"])
    if remove_archive_on_success:
        remove_if_exists(paths["output_archive"])
    if remove_archive_on_success:
        remove_if_exists(paths["archive"])
    run_shell("killall Preferences cfprefsd 2>/dev/null || true", check=False)


def cleanup_failed_temp_container(app_id, temp_name):
    if not temp_name:
        return
    run_shell(f'crane-cli delete {app_id} {temp_name} >/dev/null 2>&1 || true', check=False)
    run_shell("killall cfprefsd 2>/dev/null || true", check=False)


def ensure_named_container_exists(app_id, container_name):
    prefs = read_plist(CRANE_PREFS_PATH)
    app = prefs.get(f"appSettings_{app_id}") or {}
    for item in app.get("Containers", []):
        if item.get("name") == container_name and str(item.get("identifier") or "").strip():
            return True
    run_shell(f'crane-cli create {app_id} {container_name} >/dev/null 2>&1 || true', check=False)
    run_shell("killall cfprefsd 2>/dev/null || true", check=False)
    return True


def read_container_state(app_id, container_name):
    ensure_named_container_exists(app_id, container_name)
    prefs = read_plist(CRANE_PREFS_PATH)
    app = prefs.get(f"appSettings_{app_id}") or {}
    for item in app.get("Containers", []):
        if item.get("name") == container_name:
            container_id = str(item.get("identifier") or "").strip()
            if not container_id:
                break
            return {
                "container_id": container_id,
                "device_identifier": str(item.get("customDeviceIdentifier") or container_id).strip() or container_id,
            }
    raise RuntimeError(f"Cannot find container {container_name} for app {app_id}")


# What the apps write into last-logged-in-account-dict when no account is signed
# in. Accepting these as a username named archives after a placeholder and, worse,
# reported success with a username for a container that holds no account at all.
USERNAME_PLACEHOLDERS = {
    "instagram user",
    "threads user",
    "reddit user",
    "user",
    "unknown",
}


def normalize_username(value):
    text = str(value or "").strip()
    if text.lower() in USERNAME_PLACEHOLDERS:
        return ""
    return text


def signed_in_owner(data):
    """Owner FbID of the account signed in to these preferences, or ''.

    The username field is not evidence on its own: a logged-out container keeps
    the name of the account that used to be signed in (seen two weeks later),
    and a signed-in one sometimes holds the placeholder "Instagram user". The
    owner id is what actually tracks the session.

    Only kFBQPLLoggingPolicyLastKnownOwnerFbID tracks the current session.
    kFBQPLLoggingPolicyAccountModelsOwnerFbIDsKey is a history of every account
    the app has seen and keeps real ids long after sign-out: a container logged
    out two weeks earlier still listed five of them, so reading it as proof of a
    session named the archive after an account that was no longer there.
    """
    if not isinstance(data, dict):
        return ""
    owner = str(data.get("kFBQPLLoggingPolicyLastKnownOwnerFbID") or "").strip()
    return owner if owner and owner != "0" else ""


def read_username_from_plist_data(data):
    if not isinstance(data, dict):
        return ""
    if not signed_in_owner(data):
        return ""
    account = data.get("last-logged-in-account-dict") or {}
    if not isinstance(account, dict):
        return ""
    return normalize_username(account.get("username"))


def read_username_from_stage(profile, stage_root):
    app_root = os.path.join(stage_root, profile["app_id"])
    for relative_path in profile.get("username_plist_paths") or []:
        plist_path = os.path.join(app_root, relative_path)
        if not os.path.exists(plist_path):
            continue
        try:
            data = read_plist(plist_path)
        except Exception:
            continue
        username = read_username_from_plist_data(data)
        if username:
            return username
    return ""


def read_username_from_archive(profile, archive_path):
    if not os.path.exists(archive_path):
        return ""
    try:
        with zipfile.ZipFile(archive_path) as zf:
            for relative_path in profile.get("username_plist_paths") or []:
                member_path = f"{profile['app_id']}/{relative_path}"
                try:
                    data = plistlib.loads(zf.read(member_path))
                except Exception:
                    continue
                username = read_username_from_plist_data(data)
                if username:
                    return username
    except Exception:
        return ""
    return ""


def sanitize_file_part(value):
    text = (
        str(value or "")
        .strip()
        .replace("/", "_")
        .replace("\\", "_")
        .replace(":", "_")
    )
    # The archive name ends up in shell commands and in the callers' scripts, so
    # it must not contain whitespace: any caller that does not quote the path
    # silently breaks on it.
    return "_".join(text.split())


def format_backup_timestamp():
    return time.strftime("%m.%d.%Y_%H-%M-%S", time.localtime())


def ghost_stage_dir(stage_root):
    return os.path.join(stage_root, GHOST_STAGE_DIR)


def ghost_snapshot_stage_path(stage_root):
    return os.path.join(ghost_stage_dir(stage_root), GHOST_SNAPSHOT_FILENAME)


def ghost_meta_stage_path(stage_root):
    return os.path.join(ghost_stage_dir(stage_root), GHOST_META_FILENAME)


def find_latest_global_ghost_prefs():
    base = "/var/mobile/Containers/Data/Application"
    if not os.path.isdir(base):
        return ""
    matches = []
    for entry in os.listdir(base):
        candidate = os.path.join(base, entry, "Documents", GHOST_PREFS_FILENAME)
        if os.path.isfile(candidate):
            matches.append(candidate)
    if not matches:
        return ""
    matches.sort(key=lambda p: os.path.getmtime(p), reverse=True)
    return matches[0]


def find_container_ghost_prefs(container_id):
    base = "/var/mobile/Containers/Data/Application"
    if not os.path.isdir(base):
        return ""
    matches = []
    for entry in os.listdir(base):
        candidate = os.path.join(
            base,
            entry,
            "Library",
            "___Crane_Containers",
            container_id,
            "Documents",
            GHOST_PREFS_FILENAME,
        )
        if os.path.isfile(candidate):
            matches.append(candidate)
    if not matches:
        return ""
    matches.sort(key=lambda p: os.path.getmtime(p), reverse=True)
    return matches[0]


def find_stage_ghost_prefs(stage_root, profile):
    direct = os.path.join(stage_root, profile["app_id"], "Documents", GHOST_PREFS_FILENAME)
    if os.path.isfile(direct):
        return direct
    for root, _dirs, files in os.walk(stage_root):
        if GHOST_PREFS_FILENAME in files and os.path.basename(root) == "Documents":
            return os.path.join(root, GHOST_PREFS_FILENAME)
    return ""


def ghost_verify_failures(data):
    if not isinstance(data, dict):
        return ["invalid_plist"]
    failures = []
    if not str(data.get("deviceModel") or "").strip():
        failures.append("deviceModel")
    if not str(data.get("iosVersion") or "").strip():
        failures.append("iosVersion")
    if not bool(data.get("enableGhost")):
        failures.append("enableGhost")
    spoof_keys = [k for k in data.keys() if str(k).startswith("enableSpoof")]
    if spoof_keys and not all(bool(data.get(k)) for k in spoof_keys):
        failures.append("enableSpoof*")
    return failures


def write_ghost_snapshot(stage_root, profile, container_id):
    if not bool(profile.get("ghost_enabled", True)):
        return {"included": False, "source_mode": "disabled", "reason_code": "GHOST_DISABLED"}
    source_path = find_stage_ghost_prefs(stage_root, profile)
    source_mode = "container"
    if not source_path:
        source_path = find_latest_global_ghost_prefs()
        source_mode = "global"
    if not source_path or not os.path.isfile(source_path):
        return {"included": False, "source_mode": "none", "reason_code": "GHOST_PREFS_NOT_FOUND"}

    ghost_dir = ghost_stage_dir(stage_root)
    ensure_dir(ghost_dir)
    snapshot_path = ghost_snapshot_stage_path(stage_root)
    shutil.copy2(source_path, snapshot_path)
    meta = {
        "schema_version": GHOST_SCHEMA_VERSION,
        "app_key": profile["app_key"],
        "bundle_id": profile["app_id"],
        "source_mode": source_mode,
        "source_path": source_path,
        "container_id": container_id,
        "timestamp": iso_now(),
    }
    write_json(ghost_meta_stage_path(stage_root), meta)
    return {"included": True, "source_mode": source_mode, "source_path": source_path, "meta": meta}


def load_ghost_snapshot_from_unpack(unpack_root):
    snapshot_path = ghost_snapshot_stage_path(unpack_root)
    if not os.path.isfile(snapshot_path):
        return None, None
    meta_path = ghost_meta_stage_path(unpack_root)
    meta = {}
    if os.path.isfile(meta_path):
        try:
            meta = read_json(meta_path, default={})
        except Exception:
            meta = {}
    return snapshot_path, meta


def apply_ghost_snapshot_after_switch(profile, target_container_id, unpack_root):
    snapshot_path, meta = load_ghost_snapshot_from_unpack(unpack_root)
    if not snapshot_path:
        return {
            "attempted": False,
            "success": False,
            "reason_code": "GHOST_SNAPSHOT_NOT_FOUND",
        }
    try:
        snap_data = read_plist(snapshot_path)
    except Exception as exc:
        return {
            "attempted": True,
            "success": False,
            "reason_code": "GHOST_SNAPSHOT_INVALID",
            "error": error_text(exc),
        }

    target_path = find_container_ghost_prefs(target_container_id)
    target_mode = "container"
    if not target_path:
        target_path = find_latest_global_ghost_prefs()
        target_mode = "global"
    if not target_path:
        return {
            "attempted": True,
            "success": False,
            "reason_code": "GHOST_TARGET_NOT_FOUND",
        }

    try:
        write_plist(target_path, snap_data, fmt=plistlib.FMT_BINARY)
        run_shell(f'chown mobile:mobile "{target_path}" 2>/dev/null || true', check=False)
        failures = ghost_verify_failures(read_plist(target_path))
        if failures:
            return {
                "attempted": True,
                "success": False,
                "reason_code": "GHOST_VERIFY_FAILED",
                "failed_keys": failures,
                "target_path": target_path,
                "target_mode": target_mode,
                "meta": meta,
            }
        return {
            "attempted": True,
            "success": True,
            "reason_code": "",
            "target_path": target_path,
            "target_mode": target_mode,
            "meta": meta,
        }
    except Exception as exc:
        return {
            "attempted": True,
            "success": False,
            "reason_code": "GHOST_APPLY_FAILED",
            "error": error_text(exc),
            "target_path": target_path,
            "target_mode": target_mode,
            "meta": meta,
        }


def create_backup_info(profile, container_id, device_identifier, roots):
    return {
        "applicationIdentifier": profile["app_id"],
        "containerIdentifier": container_id,
        "containerName": profile["container_name"],
        "deviceIdentifierForVendor": device_identifier,
        "rootIdentifiers": list(roots.keys()),
        "originalPaths": roots,
    }


def write_backup_stage_info(stage_root, info):
    write_plist(os.path.join(stage_root, "Info.plist"), info, fmt=plistlib.FMT_XML)


def build_backup_archive(job_id, stage_root):
    set_stage(job_id, "zip_archive")
    output_archive = job_paths(job_id)["output_archive"]
    remove_if_exists(output_archive)
    zip_directory(stage_root, output_archive)
    if not os.path.exists(output_archive):
        raise RuntimeError(f"backup archive not created: {output_archive}")
    return output_archive


def copy_backup_to_share(job_id, source_archive, share_root, filename):
    set_stage(job_id, "copy_to_share")
    ensure_dir(share_root)
    target_path = os.path.join(share_root, filename)
    shutil.copy2(source_archive, target_path)
    return {
        "output_filename": filename,
        "output_path": target_path,
        "size_bytes": os.path.getsize(target_path),
    }


def copy_backup_to_scripts(job_id, source_archive, filename):
    set_stage(job_id, "copy_to_scripts")
    ensure_dir(AUTOTOUCH_SCRIPTS_DIR)
    target_path = os.path.join(AUTOTOUCH_SCRIPTS_DIR, filename)
    shutil.copy2(source_archive, target_path)
    run_shell(f'chown mobile:mobile "{target_path}" 2>/dev/null || true', check=False)
    return {
        "output_filename": filename,
        "output_path": target_path,
        "size_bytes": os.path.getsize(target_path),
    }


def run_restore_job(job_id):
    job = load_job(job_id)
    profile = get_app_profile(job["app_key"])
    paths = job_paths(job_id)
    archive_path = paths["archive"]
    if archive_path != job["archive_path"]:
        raise RuntimeError("archive_path in job.json must point to input.cranect inside the job directory")
    if not os.path.exists(archive_path):
        raise FileNotFoundError(f"archive not found: {archive_path}")

    started_at = now_ts()
    update_status(
        job_id,
        job_id=job_id,
        job_type="restore",
        app_key=profile["app_key"],
        app_id=profile["app_id"],
        archive_path=archive_path,
        target_container=profile["container_name"],
        running=True,
        success=False,
        error="",
        started_at=started_at,
        elapsed_s=0.0,
        share_subpath=profile["restore_share_subpath"],
        ghost_restore_attempted=False,
        ghost_restore_success=False,
        ghost_reason_code="",
    )
    append_log(job_id, f"start restore job_id={job_id}")
    source_path = str(read_json(paths["status_json"], default={}).get("source_path") or "")

    temp_name = ""
    try:
        archive_info = read_archive_info(archive_path)
        archive_device_id = get_archive_device_id(archive_info, profile["container_name"])
        temp_name, target_container_id = prepare_remote_container(
            job_id,
            profile["app_id"],
            profile["container_name"],
            archive_device_id,
        )
        unpack_root = unzip_archive(job_id, archive_path)
        resolved = resolve_root_targets(job_id, archive_info.get("rootIdentifiers") or [], target_container_id)
        copy_root_data(job_id, unpack_root, resolved)
        run_keychain_restore(job_id, profile["app_id"], target_container_id, unpack_root)

        verification = None
        if job.get("verify_post_restore"):
            live_dump = dump_keychain(job_id, profile["app_id"], target_container_id, paths["post_dump"])
            verification = compare_keychain_counts(archive_path, live_dump)

        switch_container(
            job_id,
            profile["app_id"],
            temp_name,
            profile["container_name"],
            bool(job.get("open_app_after_restore")),
        )
        ghost_result = apply_ghost_snapshot_after_switch(profile, target_container_id, unpack_root)
        if ghost_result.get("attempted"):
            update_status(
                job_id,
                ghost_restore_attempted=True,
                ghost_restore_success=bool(ghost_result.get("success")),
                ghost_reason_code=str(ghost_result.get("reason_code") or ""),
            )
            if ghost_result.get("success"):
                append_log(job_id, f"ghost_restore success target={ghost_result.get('target_path')}")
            else:
                append_log(job_id, f"ghost_restore warning reason={ghost_result.get('reason_code')} detail={ghost_result}")
        else:
            update_status(
                job_id,
                ghost_restore_attempted=False,
                ghost_restore_success=False,
                ghost_reason_code=str(ghost_result.get("reason_code") or ""),
            )
            append_log(job_id, f"ghost_restore skipped reason={ghost_result.get('reason_code')}")
        cleanup_job_artifacts(job_id, remove_archive_on_success=True)
        source_deleted = False
        source_delete_error = ""
        if source_path and source_path.startswith(AUTOTOUCH_SCRIPTS_DIR + "/"):
            try:
                remove_if_exists(source_path)
                source_deleted = True
            except Exception as exc:
                source_delete_error = error_text(exc)
        elapsed = round(now_ts() - started_at, 3)
        set_stage(
            job_id,
            "done",
            running=False,
            success=True,
            error="",
            elapsed_s=elapsed,
            verification=verification,
            target_container_id=target_container_id,
            ghost_restore_attempted=bool(ghost_result.get("attempted")),
            ghost_restore_success=bool(ghost_result.get("success")),
            ghost_reason_code=str(ghost_result.get("reason_code") or ""),
            source_deleted=source_deleted,
            source_delete_error=source_delete_error,
        )
        append_log(job_id, f"done elapsed_s={elapsed}")
        return True
    except Exception as exc:
        cleanup_failed_temp_container(profile["app_id"], temp_name)
        try:
            cleanup_job_artifacts(job_id, remove_archive_on_success=False)
        except Exception:
            pass
        elapsed = round(now_ts() - started_at, 3)
        source_deleted = False
        source_delete_error = ""
        if source_path and source_path.startswith(AUTOTOUCH_SCRIPTS_DIR + "/"):
            try:
                remove_if_exists(source_path)
                source_deleted = True
            except Exception as exc2:
                source_delete_error = error_text(exc2)
        message = error_text(exc)
        append_log(job_id, f"error {message}")
        set_stage(
            job_id,
            "error",
            running=False,
            success=False,
            error=message,
            elapsed_s=elapsed,
            source_deleted=source_deleted,
            source_delete_error=source_delete_error,
        )
        return False


def run_backup_job(job_id):
    job = load_job(job_id)
    profile = get_app_profile(job["app_key"])
    paths = job_paths(job_id)
    started_at = now_ts()
    update_status(
        job_id,
        job_id=job_id,
        job_type="backup",
        app_key=profile["app_key"],
        app_id=profile["app_id"],
        archive_path="",
        target_container=profile["container_name"],
        running=True,
        success=False,
        error="",
        started_at=started_at,
        elapsed_s=0.0,
        share_subpath=profile["backup_share_subpath"],
        ghost_backup_included=False,
        ghost_reason_code="",
        username="",
        username_source="",
        username_reason="",
    )
    append_log(job_id, f"start backup job_id={job_id}")
    try:
        container = read_container_state(profile["app_id"], profile["container_name"])
        container_id = container["container_id"]
        roots = discover_container_roots(container_id)
        # Must run before anything is staged: a running app keeps its
        # preferences (and the account username) inside cfprefsd, not on disk.
        quiesce_app_for_backup(job_id, profile["app_id"])
        stage_root = paths["stage"]
        shutil.rmtree(stage_root, ignore_errors=True)
        ensure_dir(stage_root)
        dump_keychain(job_id, profile["app_id"], container_id, os.path.join(stage_root, "Keychain.plist"))
        # cfprefsd is not redirected by Crane, so the live preferences of the
        # ACTIVE container sit in the app's real root, not in its Crane slot.
        # Never overlay them for an inactive container: they belong to whichever
        # account is active.
        container_is_active = read_active_container_id(profile["app_id"]) == container_id
        append_log(job_id, f"container_is_active={container_is_active}")
        copy_live_root_data(
            job_id, stage_root, roots, container_id,
            live_preferences=container_is_active,
        )
        ghost_snapshot = write_ghost_snapshot(stage_root, profile, container_id)
        update_status(
            job_id,
            ghost_backup_included=bool(ghost_snapshot.get("included")),
            ghost_reason_code=str(ghost_snapshot.get("reason_code") or ""),
        )
        if ghost_snapshot.get("included"):
            append_log(job_id, f"ghost_backup included source={ghost_snapshot.get('source_mode')} path={ghost_snapshot.get('source_path')}")
        else:
            append_log(job_id, f"ghost_backup skipped reason={ghost_snapshot.get('reason_code')}")
        set_stage(job_id, "write_info")
        info = create_backup_info(profile, container_id, container["device_identifier"], roots)
        write_backup_stage_info(stage_root, info)
        username = read_username_from_stage(profile, stage_root)
        username_source = "stage" if username else ""
        if not username:
            # Last resort before falling back to the container name (which is
            # what produced archives called taoacc_<date>.cranect): read the
            # container's live plist on disk directly.
            username = read_username_live(profile, roots, container_id)
            username_source = "live_container" if username else ""
        safe_name = sanitize_file_part(username or profile["container_name"] or profile["app_key"])
        output_name = f"{safe_name}_{format_backup_timestamp()}.cranect"
        archive_path = build_backup_archive(job_id, stage_root)
        archive_username = read_username_from_archive(profile, archive_path)
        if archive_username:
            username = archive_username
            username_source = "archive"
            safe_name = sanitize_file_part(username or profile["container_name"] or profile["app_key"])
            output_name = f"{safe_name}_{format_backup_timestamp()}.cranect"
        username_reason = "" if username else diagnose_missing_username(
            profile, stage_root, container_is_active)
        if not username:
            append_log(job_id, f"username not found reason={username_reason}")
        copied = copy_backup_to_scripts(job_id, archive_path, output_name)
        cleanup_job_artifacts(job_id, remove_archive_on_success=True)
        elapsed = round(now_ts() - started_at, 3)
        set_stage(
            job_id,
            "done",
            running=False,
            success=True,
            error="",
            elapsed_s=elapsed,
            output_filename=copied["output_filename"],
            output_path=copied["output_path"],
            size_bytes=copied["size_bytes"],
            username=username,
            username_source=username_source,
            username_reason=username_reason,
            container_is_active=container_is_active,
            ghost_backup_included=bool(ghost_snapshot.get("included")),
            ghost_reason_code=str(ghost_snapshot.get("reason_code") or ""),
        )
        append_log(job_id, f"done elapsed_s={elapsed} output={copied['output_path']}")
        return True
    except Exception as exc:
        try:
            cleanup_job_artifacts(job_id, remove_archive_on_success=False)
        except Exception:
            pass
        elapsed = round(now_ts() - started_at, 3)
        message = error_text(exc)
        append_log(job_id, f"error {message}")
        set_stage(
            job_id,
            "error",
            running=False,
            success=False,
            error=message,
            elapsed_s=elapsed,
        )
        return False


def run_job(job_id):
    job = load_job(job_id)
    if job["job_type"] == "backup":
        return run_backup_job(job_id)
    return run_restore_job(job_id)
