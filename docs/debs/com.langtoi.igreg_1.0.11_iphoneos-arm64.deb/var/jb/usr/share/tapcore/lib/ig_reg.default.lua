-- ================================================================
-- Auto-generated from Tao_IG_backup.xml by IGReg bas2lua.js
-- Compiled at : 2026-11-28T05:55:34.520Z
-- Source hash : cd164a7855f24d7b
-- Functions   : OnApplicationStart, MAIN, Proxy_set, taotaikhoan, API_GMAIL, reg_2
-- Stats       : 6 functions, 104 labels, 1000 steps
-- ================================================================
local BAS = require("bas_runtime")
local PROG = {
  meta = { source = "Tao_IG_backup.xml", hash = "cd164a7855f24d7b", compiled_at = "2026-11-28T05:55:34.520Z" },
  functions = {}
}

-- -------- Function: OnApplicationStart (6 steps, 0 labels) --------
do
  local steps = {}
  local labels = {  };
  ;(function()
    steps[1] = { line = 15030, sec = "", fn = function(B, V, PROG)
      B.pset("basglobal", "DEM_ACC", B.json_stringify(0))
    end }
    steps[2] = { line = 15036, sec = "", fn = function(B, V, PROG)
      B.pset("basglobal", "ACC_CHECK", B.json_stringify(false))
    end }
    steps[3] = { line = 15042, sec = "", fn = function(B, V, PROG)
      B.pset("basglobal", "EXCHANGE_STATE", B.json_stringify(false))
    end }
    steps[4] = { line = 15048, sec = "", fn = function(B, V, PROG)
      B.pset("basglobal", "ACCESS_LOCK", B.json_stringify(false))
    end }
    steps[5] = { line = 15054, sec = "", fn = function(B, V, PROG)
      B.pset("basglobal", "LOCK", B.json_stringify(false))
    end }
    steps[6] = { line = 15060, sec = "", fn = function(B, V, PROG)
      B.pset("basglobal", "CHECK_CAPTION", B.json_stringify(B.NULL))
    end }
  end)()
  PROG.functions["OnApplicationStart"] = { name = "OnApplicationStart", steps = steps, labels = labels }
end

-- -------- Function: MAIN (46 steps, 4 labels) --------
do
  local steps = {}
  local labels = { ["MAIN"] = 3, ["label name 1290"] = 20, ["label name 6220"] = 32, ["RA_MAIN"] = 32 };
  ;(function()
    steps[1] = { line = 15514, sec = "", fn = function(B, V, PROG)
      V.VAR_THREAD_INDEX = B.thread_number()
    end }
    steps[2] = { line = 15519, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_588837 = B.rs("Type Proxy", false, false)
      V.VAR_TYPE_PROXY = V.RESOURCE_588837
    end }
    steps[3] = { line = 15531, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_558953 = B.rs("Type Proxy", false, false)
      V.VAR_TYPE_PROXY = V.RESOURCE_558953
    end }
    steps[4] = { line = 15538, sec = "", fn = function(B, V, PROG)
      V.VAR_RESOURCE_IP = B.rpick("IP Iphone")
    end }
    steps[5] = { line = 15543, sec = "", fn = function(B, V, PROG)
      V.VAR_RESOURCE_PROXY = B.rpick("Proxy")
    end }
    steps[6] = { line = 15548, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_VER_GOONED = false
      V.VAR_COUNT_HOAN_THANH = 0
      V.VAR_COUNT_POST = 0
    end }
    steps[7] = { line = 15555, sec = "", fn = function(B, V, PROG)
      V.VAR_IP_IPHONE = B.arr_get(V.VAR_RESOURCE_IP, (B.num(V.VAR_THREAD_INDEX) - B.num(1)))
    end }
    steps[8] = { line = 15560, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_579318 = B.rs("Choose Proxy", false, false)
    end }
    steps[9] = { line = 15560, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_579318, "Grid")) then return 11 end
    end }
    steps[10] = { line = 15567, sec = "", fn = function(B, V, PROG)
      V.VAR_PROXY_RAW = B.arr_get(V.VAR_RESOURCE_PROXY, (B.num(V.VAR_THREAD_INDEX) - B.num(1)))
    end }
    steps[11] = { line = 15575, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_508327 = B.rs("Function", false, false)
    end }
    steps[12] = { line = 15575, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_508327, "Check Acc")) then return 14 end
    end }
    steps[13] = { line = 15582, sec = "", fn = function(B, V, PROG)
      B.exec_fn(PROG, "check_acc", V)
    end }
    steps[14] = { line = 15591, sec = "", fn = function(B, V, PROG)
      V.VAR_IP_IPHONE = B.trim(V.VAR_IP_IPHONE)
    end }
    steps[15] = { line = 15596, sec = "", fn = function(B, V, PROG)
      V.VAR_IP_GOC = V.VAR_IP_IPHONE
    end }
    steps[16] = { line = 15601, sec = "", fn = function(B, V, PROG)
      V.VAR_IS_STARTS_WITH = B.starts_with(V.VAR_IP_IPHONE, "http://")
    end }
    steps[17] = { line = 15606, sec = "", fn = function(B, V, PROG)
      if not B.truthy((not B.truthy(V.VAR_IS_STARTS_WITH))) then return 19 end
    end }
    steps[18] = { line = 15611, sec = "", fn = function(B, V, PROG)
      V.VAR_IP_IPHONE = B.add("http://", V.VAR_IP_IPHONE)
    end }
    steps[19] = { line = 15619, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("cyan"), ["en"] = (B.add("IP IPHONE: ", V.VAR_IP_GOC)), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[20] = { op = "try_begin", line = 15629, end_pc = 22 }
    steps[21] = { line = 15642, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":8080/control/start_playing?path=/sv.lua"), "GET", nil, "", nil)
    end }
    steps[22] = { op = "try_end", line = 15629 }
    steps[23] = { line = 15651, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 25 end
    end }
    steps[24] = { line = 15656, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 1290")
    end }
    steps[25] = { line = 15664, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_371018 = B.rs("Function", false, false)
    end }
    steps[26] = { line = 15664, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_371018, "Tạo Tài Khoản")) then return 28 end
    end }
    steps[27] = { line = 15671, sec = "", fn = function(B, V, PROG)
      return B.goto_label("RA_MAIN")
    end }
    steps[28] = { line = 15679, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_898786 = B.rs("Function", false, false)
    end }
    steps[29] = { line = 15679, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_898786, "Lấy lại tài khoản lỗi")) then return 31 end
    end }
    steps[30] = { line = 15686, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 6220")
    end }
    steps[31] = { line = 15694, sec = "", fn = function(B, V, PROG)
      B.exec_fn(PROG, "doc_DB", V)
    end }
    steps[32] = { line = 15710, sec = "", fn = function(B, V, PROG)
      B.exec_fn(PROG, "Proxy_set", V)
    end }
    steps[33] = { line = 15716, sec = "", fn = function(B, V, PROG)
      B.new_http_client()
    end }
    steps[34] = { line = 15722, sec = "mở sever", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":8080/control/start_playing?path=/sv.lua"), "GET", nil, "", nil)
    end }
    steps[35] = { line = 15728, sec = "", fn = function(B, V, PROG)
      B.sleep(1000)
    end }
    steps[36] = { line = 15733, sec = "thoát", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"\r\nkeyDown(KEY_TYPE.HOME_BUTTON);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\nusleep(100000);\r\nkeyDown(KEY_TYPE.HOME_BUTTON);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\n\r\nusleep(1000000); -- Chờ trình đa nhiệm hiện lên\r\n\r\n\r\ntouchDown(2, 863.20, 1705.23);\r\nusleep(20971.08);\r\ntouchMove(2, 853.59, 1693.71);\r\nusleep(7650.71);\r\ntouchMove(2, 847.84, 1663.90);\r\nusleep(8916.21);\r\ntouchMove(2, 837.26, 1615.80);\r\nusleep(7537.67);\r\ntouchMove(2, 833.43, 1551.34);\r\nusleep(9207.75);\r\ntouchMove(2, 833.43, 1464.74);\r\nusleep(7576.25);\r\ntouchMove(2, 833.43, 1360.85);\r\nusleep(8914.58);\r\ntouchMove(2, 851.68, 1232.91);\r\nusleep(7765.42);\r\ntouchMove(2, 882.39, 1095.34);\r\nusleep(8979.46);\r\ntouchMove(2, 928.48, 983.75);\r\nusleep(7767.67);\r\ntouchMove(2, 958.25, 911.60);\r\nusleep(9061.50);\r\ntouchUp(2, 964.02, 905.84);\r\nusleep(462425.08);\r\n\r\ntouchDown(2, 759.50, 1614.83);\r\nusleep(12281.17);\r\ntouchMove(2, 759.50, 1578.26);\r\nusleep(8606.88);\r\ntouchMove(2, 760.46, 1499.38);\r\nusleep(7841.33);\r\ntouchMove(2, 777.75, 1386.83);\r\nusleep(9069.29);\r\ntouchMove(2, 810.38, 1258.89);\r\nusleep(7597.33);\r\ntouchMove(2, 852.62, 1112.66);\r\nusleep(9040.38);\r\ntouchMove(2, 903.52, 1008.77);\r\nusleep(7585.71);\r\ntouchMove(2, 935.21, 942.38);\r\nusleep(9383.00);\r\ntouchUp(2, 940.96, 936.62);\r\n\r\n\r\n\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[37] = { line = 15739, sec = "HOME", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"\r\n\r\nkeyDown(KEY_TYPE.HOME_BUTTON);\r\nusleep(138611.00);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\nusleep(217773.00);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\nusleep(772038.29);\r\n\r\nkeyDown(KEY_TYPE.HOME_BUTTON);\r\nusleep(217682.00);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\nusleep(138650.21);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\n\r\n\r\n\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[38] = { line = 15745, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[39] = { line = 15750, sec = "Tắt VPN", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"return execute('/var/jb/usr/bin/shadowrocket-proxy-vpn off')\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[40] = { line = 15756, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[41] = { line = 15761, sec = "Bật VPN", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"return execute('/var/jb/usr/bin/shadowrocket-proxy-vpn on')\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[42] = { line = 15767, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[43] = { line = 15772, sec = "HOME", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"\r\n\r\nkeyDown(KEY_TYPE.HOME_BUTTON);\r\nusleep(138611.00);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\nusleep(217773.00);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\nusleep(772038.29);\r\n\r\nkeyDown(KEY_TYPE.HOME_BUTTON);\r\nusleep(217682.00);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\nusleep(138650.21);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\n\r\n\r\n\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[44] = { line = 15778, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_423225 = B.rs("Function", false, false)
    end }
    steps[45] = { line = 15778, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_423225, "Tạo Tài Khoản")) then return 47 end
    end }
    steps[46] = { line = 15785, sec = "", fn = function(B, V, PROG)
      B.exec_fn(PROG, "taotaikhoan", V)
    end }
  end)()
  PROG.functions["MAIN"] = { name = "MAIN", steps = steps, labels = labels }
end

-- -------- Function: Proxy_set (60 steps, 6 labels) --------
do
  local steps = {}
  local labels = { ["label name 6060"] = 4, ["label name 5681"] = 6, ["label name 9230"] = 20, ["label name 3987"] = 23, ["label name 6603"] = 25, ["label name 6929"] = 56 };
  ;(function()
    steps[1] = { line = 15073, sec = "", fn = function(B, V, PROG)
      do local fi = B.json_parse(B.native_fileinfo(B.rinfo("Proxy", "Location"))) or {}; V.VAR_FILEINFO_EXISTS = fi.exists; V.VAR_FILEINFO_SIZE = fi.size; V.VAR_FILEINFO_BASE_DIRECTORY = fi.directory or ""; V.VAR_FILEINFO_IS_DIRECTORY = fi.is_directory; V.VAR_FILEINFO_LAST_MODIFIED = fi.last_modified end
    end }
    steps[2] = { line = 15083, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_FILEINFO_BASE_DIRECTORY, "")) then return 4 end
    end }
    steps[3] = { line = 15088, sec = "", fn = function(B, V, PROG)
      V.VAR_FILEINFO_BASE_DIRECTORY = B.project_directory()
    end }
    steps[4] = { line = 15101, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_307761 = B.rs("Choose Proxy", false, false)
    end }
    steps[5] = { line = 15101, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_307761, "9proxy")) then return 13 end
    end }
    steps[6] = { op = "try_begin", line = 15113, end_pc = 8 }
    steps[7] = { line = 15126, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_912871 = B.rs("Proxy", true, true)
      do local csv_res = B.csv_parse(V.RESOURCE_912871, "|")
      V.VAR_LIST_WITH_ITEMS = csv_res
      V.VAR_PROXY = B.avoid_nilb(csv_res[1], "")
      V.VAR_LINK_CHANG = B.avoid_nilb(csv_res[2], "")
      end
    end }
    steps[8] = { op = "try_end", line = 15113 }
    steps[9] = { line = 15139, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 13 end
    end }
    steps[10] = { line = 15144, sec = "", fn = function(B, V, PROG)
      B.reload("Proxy")
    end }
    steps[11] = { line = 15149, sec = "", fn = function(B, V, PROG)
      B.log("Đã reload")
    end }
    steps[12] = { line = 15154, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5681")
    end }
    steps[13] = { line = 15165, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_889799 = B.rs("Choose Proxy", false, false)
    end }
    steps[14] = { line = 15165, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_889799, "Grid")) then return 20 end
    end }
    steps[15] = { line = 15172, sec = "", fn = function(B, V, PROG)
      do local csv_res = B.csv_parse(V.VAR_PROXY_RAW, "|")
      V.VAR_LIST_WITH_ITEMS = csv_res
      V.VAR_PROXY = B.avoid_nilb(csv_res[1], "")
      V.VAR_LINK_CHANG = B.avoid_nilb(csv_res[2], "")
      end
    end }
    steps[16] = { line = 15180, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(V.VAR_LINK_CHANG, "GET", nil, "", nil)
    end }
    steps[17] = { line = 15186, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[18] = { line = 15192, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 400)) then return 20 end
    end }
    steps[19] = { line = 15197, sec = "", fn = function(B, V, PROG)
      B.die("Proxy Hết Hạn")
    end }
    steps[20] = { line = 15213, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_887020 = B.rs("Choose Proxy", false, false)
    end }
    steps[21] = { line = 15213, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_887020, "Mard")) then return 23 end
    end }
    steps[22] = { line = 15220, sec = "US", fn = function(B, V, PROG)
      V.VAR_PROXY = B.emb_mars_proxy("ultra.marsproxies.com:44445:lvknjneroitjogijdsfie:MS45Ho4ewT_country-us_session-aor5pxwf_lifetime-168h")
    end }
    steps[23] = { line = 15234, sec = "", fn = function(B, V, PROG)
      do local csv_res = B.csv_parse(V.VAR_PROXY, ":")
      V.VAR_LIST_WITH_ITEMS = csv_res
      V.VAR_IP_PPROXY = B.avoid_nilb(csv_res[1], "")
      V.VAR_PORT = B.avoid_nilb(csv_res[2], "")
      V.VAR_USER_PROXY = B.avoid_nilb(csv_res[3], "")
      V.VAR_PASS_PROXY = B.avoid_nilb(csv_res[4], "")
      end
    end }
    steps[24] = { line = 15244, sec = "", fn = function(B, V, PROG)
      do local h = B.proxy_parse(V.VAR_PROXY); local tp = tostring(V.VAR_TYPE_PROXY or "http"):lower(); if tp ~= "auto" then h.IsHttp = (tp == "http") end; B.switch_http_main(); B.http_set_proxy(h.server, h.Port, h.IsHttp, h.name, h.password) end
    end }
    steps[25] = { op = "try_begin", line = 15266, end_pc = 27 }
    steps[26] = { line = 15279, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request("http://ip.bablosoft.com", "GET", nil, "", nil)
    end }
    steps[27] = { op = "try_end", line = 15266 }
    steps[28] = { line = 15288, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 35 end
    end }
    steps[29] = { line = 15293, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_388065 = B.rs("Choose Proxy", false, false)
    end }
    steps[30] = { line = 15293, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_388065, "Grid")) then return 32 end
    end }
    steps[31] = { line = 15300, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 6603")
    end }
    steps[32] = { line = 15308, sec = "", fn = function(B, V, PROG)
      B.new_http_client()
    end }
    steps[33] = { line = 15314, sec = "", fn = function(B, V, PROG)
      B.log("STATUS: Proxy error try again")
    end }
    steps[34] = { line = 15319, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9230")
    end }
    steps[35] = { line = 15327, sec = "", fn = function(B, V, PROG)
      V.VAR_IP = B.http_content()
    end }
    steps[36] = { line = 15333, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_IP, "")) then return 38 end
    end }
    steps[37] = { line = 15338, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 3987")
    end }
    steps[38] = { line = 15346, sec = "", fn = function(B, V, PROG)
      V.VAR_IPINFO_VALID = true; V.VAR_IPINFO_COUNTRY = ""
    end }
    steps[39] = { line = 15360, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 6929")
    end }
    steps[40] = { op = "try_begin", line = 15365, end_pc = 42 }
    steps[41] = { line = 15378, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add("https://api12.scamalytics.com/v3/langtoibk/?key=895ed282528d9fb5a967043e607c2510a1adf3522b57a9ec1f3ba0a1487516ed&ip=", V.VAR_IP), "GET", nil, "", nil)
    end }
    steps[42] = { op = "try_end", line = 15365 }
    steps[43] = { line = 15387, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 45 end
    end }
    steps[44] = { line = 15392, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9230")
    end }
    steps[45] = { line = 15400, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[46] = { line = 15406, sec = "", fn = function(B, V, PROG)
      V.VAR_STATUS_IP = B.jpath_value(V.VAR_SAVED_CONTENT, ".status")
    end }
    steps[47] = { line = 15415, sec = "", fn = function(B, V, PROG)
      V.VAR_IP_COUNTRY_NAME = B.jpath_value(V.VAR_SAVED_CONTENT, ".maxmind_geolite2.ip_country_name")
    end }
    steps[48] = { line = 15424, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.sneq(V.VAR_IP_COUNTRY_NAME, "United States")) then return 51 end
    end }
    steps[49] = { line = 15429, sec = "", fn = function(B, V, PROG)
      B.log(B.add("IP_COUNTRY_NAME: ", V.VAR_IP_COUNTRY_NAME))
    end }
    steps[50] = { line = 15434, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9230")
    end }
  end)()
  ;(function()
    steps[51] = { line = 15442, sec = "", fn = function(B, V, PROG)
      V.VAR_SCAMALYTICS_SCORE = B.jpath_value(V.VAR_SAVED_CONTENT, ".scamalytics_score")
    end }
    steps[52] = { line = 15451, sec = "", fn = function(B, V, PROG)
      if not B.truthy((B.num(V.VAR_SCAMALYTICS_SCORE) > B.num(10))) then return 55 end
    end }
    steps[53] = { line = 15456, sec = "", fn = function(B, V, PROG)
      B.new_http_client()
    end }
    steps[54] = { line = 15462, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9230")
    end }
    steps[55] = { line = 15470, sec = "", fn = function(B, V, PROG)
      B.log(B.add("SCORE: ", V.VAR_SCAMALYTICS_SCORE))
    end }
    steps[56] = { line = 15480, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("gray"), ["en"] = (B.add("Proxy: IP: ", V.VAR_IP)), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[57] = { line = 15485, sec = "", fn = function(B, V, PROG)
      B.new_http_client()
    end }
    steps[58] = { line = 15491, sec = "mở sever", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":8080/control/start_playing?path=/sv.lua"), "GET", nil, "", nil)
    end }
    steps[59] = { line = 15497, sec = "MOVE", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add(B.add(B.add(B.add(B.add(B.add(B.add(B.add(B.add("{\r\n  \"action\": \"RUNLUA\",\r\n  \"data\": \"return execute('/var/jb/usr/bin/shadowrocket-proxy-set ", V.VAR_TYPE_PROXY), " "), V.VAR_IP_PPROXY), " "), V.VAR_PORT), " "), V.VAR_USER_PROXY), " "), V.VAR_PASS_PROXY), "')\"\r\n}\r\n"), "", B.add("custom/", ("application/json")))
    end }
    steps[60] = { line = 15503, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
  end)()
  PROG.functions["Proxy_set"] = { name = "Proxy_set", steps = steps, labels = labels }
end

-- -------- Function: taotaikhoan (789 steps, 80 labels) --------
do
  local steps = {}
  local labels = { ["label name 7129"] = 2, ["label name 6850"] = 11, ["label name 4048"] = 26, ["label name 8395"] = 26, ["label name 1813"] = 31, ["label name 7153"] = 31, ["label name 4767"] = 56, ["label name 2987"] = 56, ["label name 1886"] = 70, ["label name 3470"] = 75, ["label name 1400"] = 75, ["label name 5435"] = 102, ["label name 7123"] = 116, ["label name 6546"] = 127, ["label name 305"] = 136, ["label name 2968"] = 151, ["label name 1281"] = 160, ["label name 5646"] = 161, ["label name 7267"] = 161, ["label name 9106"] = 167, ["label name 4489"] = 172, ["label name 9788"] = 182, ["label name 6602"] = 200, ["label name 3893"] = 207, ["label name 9053"] = 218, ["label name 5544"] = 235, ["label name 7241"] = 266, ["label name 7818"] = 290, ["label name 1953"] = 305, ["label name 2995"] = 317, ["label name 1299"] = 317, ["label name 4834"] = 322, ["label name 572"] = 332, ["label name 1628"] = 332, ["label name 9237"] = 347, ["label name 5651"] = 355, ["label name 663"] = 362, ["label name 5770"] = 362, ["label name 9750"] = 369, ["label name 5253"] = 378, ["label name 9719"] = 388, ["label name 4121"] = 395, ["label name 8552"] = 402, ["label name 2439"] = 407, ["label name 3613"] = 415, ["label name 5483"] = 415, ["label name 5494"] = 434, ["label name 9745"] = 441, ["label name 7519"] = 455, ["label name 7904"] = 455, ["label name 8185"] = 455, ["label name 3673"] = 460, ["label name 5067"] = 475, ["label name 4452"] = 480, ["label name 402"] = 480, ["label name 6211"] = 486, ["label name 8623"] = 492, ["label name 8654"] = 519, ["label name 6882"] = 519, ["label name 403"] = 524, ["label name 3842"] = 528, ["label name 8912"] = 539, ["label name 397"] = 544, ["label name 8694"] = 567, ["label name 2612"] = 574, ["label name 9538"] = 580, ["label name 8538"] = 581, ["label name 8595"] = 586, ["label name 5957"] = 588, ["label name 4201"] = 600, ["label name 8329"] = 601, ["label name 4949"] = 632, ["label name 8032"] = 658, ["label name 1098"] = 664, ["label name 2802"] = 701, ["label name 6432"] = 711, ["label name 691"] = 730, ["label name 9334"] = 730, ["label name 4123"] = 749, ["label name 3885"] = 761 };
  ;(function()
    steps[1] = { line = 3269, sec = "", fn = function(B, V, PROG)
      V.VAR_LECH_SONG = 0
    end }
    steps[2] = { line = 3279, sec = "xóa container IG mới", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"return execute('/var/jb/usr/bin/crane-cli delete com.burbn.instagram taoacc')\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[3] = { line = 3285, sec = "tạo container IG mới", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"return execute('/var/jb/usr/bin/crane-cli create com.burbn.instagram taoacc')\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[4] = { line = 3291, sec = "Chuyển Qua IG mới", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"return execute('/var/jb/usr/bin/crane-cli switch com.burbn.instagram taoacc')\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[5] = { line = 3297, sec = "xóa threads taoacc", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"return execute('/var/jb/usr/bin/crane-cli delete com.burbn.barcelona taoacc')\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[6] = { line = 3303, sec = "tạo container threads", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"return execute('/var/jb/usr/bin/crane-cli create com.burbn.barcelona taoacc')\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[7] = { line = 3309, sec = "Chuyển Qua IG mới", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"return execute('/var/jb/usr/bin/crane-cli switch com.burbn.barcelona taoacc')\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[8] = { line = 3315, sec = "Fake Devices", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\"action\":\"RUNLUA\",\"data\":\"return execute('/var/jb/usr/bin/ghost_instagram')\"}", "", B.add("custom/", ("application/json")))
    end }
    steps[9] = { line = 3321, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[10] = { line = 3327, sec = "", fn = function(B, V, PROG)
      V.VAR_JOB_ID = B.jpath_value(V.VAR_SAVED_CONTENT, ".job_id")
    end }
    steps[11] = { line = 3341, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(B.add(B.add("http://", V.VAR_IP_GOC), ":9210/job?id="), V.VAR_JOB_ID), "GET", nil, "", nil)
    end }
    steps[12] = { line = 3347, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[13] = { line = 3353, sec = "", fn = function(B, V, PROG)
      V.VAR_STATE = B.jpath_value(V.VAR_SAVED_CONTENT, ".state")
    end }
    steps[14] = { line = 3362, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_STATE, "running")) then return 17 end
    end }
    steps[15] = { line = 3367, sec = "", fn = function(B, V, PROG)
      B.sleep(1000)
    end }
    steps[16] = { line = 3372, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 6850")
    end }
    steps[17] = { line = 3380, sec = "", fn = function(B, V, PROG)
      V.VAR_SUCCESS_CHECK_SPOOF = B.jpath_value(V.VAR_SAVED_CONTENT, ".verdict")
    end }
    steps[18] = { line = 3389, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SUCCESS_CHECK_SPOOF, "FAIL")) then return 21 end
    end }
    steps[19] = { line = 3394, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("red"), ["en"] = (B.add("STAGE: ", V.VAR_STAGE)), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[20] = { line = 3399, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7129")
    end }
    steps[21] = { line = 3407, sec = "", fn = function(B, V, PROG)
      V.VAR_DEVICEDISPLAYNAME = B.jpath_value(V.VAR_SAVED_CONTENT, ".display_name")
    end }
    steps[22] = { line = 3416, sec = "iosVersionBuild", fn = function(B, V, PROG)
      V.VAR_IOS = B.jpath_value(V.VAR_SAVED_CONTENT, ".ios")
    end }
    steps[23] = { line = 3425, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("brown"), ["en"] = (B.add(B.add(B.add("DEVICEDISPLAYNAME: ", V.VAR_DEVICEDISPLAYNAME), " || "), V.VAR_IOS)), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[24] = { line = 3430, sec = "", fn = function(B, V, PROG)
      B.sleep(1000)
    end }
    steps[25] = { line = 3435, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_USERNAME_LOI = 0
    end }
    steps[26] = { op = "try_begin", line = 3450, end_pc = 28 }
    steps[27] = { line = 3463, sec = "Vào IG", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"URL\",\r\n    \"data\": \"instagram://\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[28] = { op = "try_end", line = 3450 }
    steps[29] = { line = 3472, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 31 end
    end }
    steps[30] = { line = 3477, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8395")
    end }
    steps[31] = { op = "try_begin", line = 3495, end_pc = 33 }
    steps[32] = { line = 3508, sec = "Click Get started", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Get started\",\r\n    \"timeout\": 20,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[33] = { op = "try_end", line = 3495 }
    steps[34] = { line = 3517, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 36 end
    end }
    steps[35] = { line = 3522, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7153")
    end }
    steps[36] = { line = 3530, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[37] = { line = 3536, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 42 end
    end }
    steps[38] = { line = 3541, sec = "Create new account", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Create new account\",\r\n    \"timeout\": 20,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[39] = { line = 3547, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[40] = { line = 3553, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 42 end
    end }
    steps[41] = { line = 3558, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8395")
    end }
    steps[42] = { line = 3569, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_863384 = B.rs("Shop API", false, false)
    end }
    steps[43] = { line = 3569, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_863384, "Smspool")) then return 49 end
    end }
    steps[44] = { line = 3576, sec = "", fn = function(B, V, PROG)
      B.sleep(5000)
    end }
    steps[45] = { line = 3581, sec = "Mobile number", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Mobile number\",\r\n    \"timeout\": 15,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[46] = { line = 3587, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 3470")
    end }
    steps[47] = { line = 3592, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_666547 = B.rs("Type", false, false)
    end }
    steps[48] = { line = 3592, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_666547, "Phone")) then return 49 end
    end }
    steps[49] = { line = 3605, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_179279 = B.rs("Shop API", false, false)
    end }
    steps[50] = { line = 3605, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_179279, "Smsbower")) then return 56 end
    end }
  end)()
  ;(function()
    steps[51] = { line = 3612, sec = "", fn = function(B, V, PROG)
      B.sleep(5000)
    end }
    steps[52] = { line = 3617, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_666547 = B.rs("Type", false, false)
    end }
    steps[53] = { line = 3617, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_666547, "Phone")) then return 56 end
    end }
    steps[54] = { line = 3624, sec = "Mobile number", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Mobile number\",\r\n    \"timeout\": 15,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[55] = { line = 3630, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 3470")
    end }
    steps[56] = { op = "try_begin", line = 3651, end_pc = 58 }
    steps[57] = { line = 3664, sec = "Click Sign up with email", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Sign up with email\",\r\n    \"timeout\": 25,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[58] = { op = "try_end", line = 3651 }
    steps[59] = { line = 3673, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 61 end
    end }
    steps[60] = { line = 3678, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 2987")
    end }
    steps[61] = { line = 3686, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[62] = { line = 3692, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 69 end
    end }
    steps[63] = { line = 3697, sec = "check what's your birthaday", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Birthday\",\r\n    \"timeout\": 5,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[64] = { line = 3703, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[65] = { line = 3709, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 67 end
    end }
    steps[66] = { line = 3714, sec = "", fn = function(B, V, PROG)
      B.fail_user("Giao diện mới , bỏ qua")
    end }
    steps[67] = { line = 3722, sec = "Click Refresh", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Refresh\",\r\n    \"timeout\": 10,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[68] = { line = 3728, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 4767")
    end }
    steps[69] = { line = 3736, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[70] = { op = "try_begin", line = 3746, end_pc = 72 }
    steps[71] = { line = 3759, sec = "Click Email", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Email\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[72] = { op = "try_end", line = 3746 }
    steps[73] = { line = 3768, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 75 end
    end }
    steps[74] = { line = 3773, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 1886")
    end }
    steps[75] = { line = 3791, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_429990 = B.rs("Shop API", false, false)
    end }
    steps[76] = { line = 3791, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_429990, "Smsbower")) then return 100 end
    end }
    steps[77] = { line = 3798, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_478128 = B.rs("Type", false, false)
    end }
    steps[78] = { line = 3798, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_478128, "Phone")) then return 80 end
    end }
    steps[79] = { line = 3805, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request("https://smsbower.page/stubs/handler_api.php?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&action=getNumber&service=ig&country=36&providerIds=2524", "GET", nil, "", nil)
    end }
    steps[80] = { line = 3814, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_792310 = B.rs("Type", false, false)
    end }
    steps[81] = { line = 3814, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_792310, "ICloud")) then return 83 end
    end }
    steps[82] = { line = 3821, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request("https://smsbower.page/api/mail/getActivation?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&service=ig&domain=icloud.com", "GET", nil, "", nil)
    end }
    steps[83] = { line = 3830, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_324276 = B.rs("Type", false, false)
    end }
    steps[84] = { line = 3830, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_324276, "Mail")) then return 86 end
    end }
    steps[85] = { line = 3837, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request("https://smsbower.page/api/mail/getActivation?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&service=ig&domain=gmail.com", "GET", nil, "", nil)
    end }
    steps[86] = { line = 3846, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[87] = { line = 3852, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_478128 = B.rs("Type", false, false)
    end }
    steps[88] = { line = 3852, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_478128, "Phone")) then return 93 end
    end }
    steps[89] = { line = 3859, sec = "", fn = function(B, V, PROG)
      do local csv_res = B.csv_parse(V.VAR_SAVED_CONTENT, ":")
      V.VAR_ACCESS_NUMBER = B.avoid_nilb(csv_res[1], "")
      V.VAR_MAILID = B.avoid_nilb(csv_res[2], "")
      V.VAR_EMAIL = B.avoid_nilb(csv_res[3], "")
      end
    end }
    steps[90] = { line = 3879, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_ACCESS_NUMBER, "NO_NUMBERS")) then return 92 end
    end }
    steps[91] = { line = 3884, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("brown"), ["en"] = ("NO_NUMBERS"), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[92] = { line = 3892, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5646")
    end }
    steps[93] = { line = 3900, sec = "", fn = function(B, V, PROG)
      V.VAR_STATUS_GET_MAIL = B.jpath_value(V.VAR_SAVED_CONTENT, "status")
    end }
    steps[94] = { line = 3909, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_STATUS_GET_MAIL, 0)) then return 98 end
    end }
    steps[95] = { line = 3914, sec = "", fn = function(B, V, PROG)
      B.log(V.VAR_SAVED_CONTENT)
    end }
    steps[96] = { line = 3919, sec = "", fn = function(B, V, PROG)
      B.sleep(5000)
    end }
    steps[97] = { line = 3924, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 1400")
    end }
    steps[98] = { line = 3932, sec = "", fn = function(B, V, PROG)
      V.VAR_EMAIL = B.jpath_value(V.VAR_SAVED_CONTENT, "mail")
    end }
    steps[99] = { line = 3941, sec = "", fn = function(B, V, PROG)
      V.VAR_MAILID = B.jpath_value(V.VAR_SAVED_CONTENT, "mailId")
    end }
    steps[100] = { line = 3953, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_145744 = B.rs("Shop API", false, false)
    end }
  end)()
  ;(function()
    steps[101] = { line = 3953, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_145744, "API Icloud")) then return 134 end
    end }
    steps[102] = { op = "try_begin", line = 3965, end_pc = 104 }
    steps[103] = { line = 3978, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request("https://65.108.34.108.sslip.io/mail", ("POST"), "", "X-API-Key: uwbefowenfwenfoenfoiwfoiwnfowe33879dsfdkjn", B.add("custom/", ("application/json")))
    end }
    steps[104] = { op = "try_end", line = 3965 }
    steps[105] = { line = 3987, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 108 end
    end }
    steps[106] = { line = 3992, sec = "", fn = function(B, V, PROG)
      B.log(B.add("Error occurred : ", V.VAR_LAST_ERROR))
    end }
    steps[107] = { line = 3997, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5435")
    end }
    steps[108] = { line = 4005, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[109] = { line = 4011, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 502)) then return 112 end
    end }
    steps[110] = { line = 4016, sec = "", fn = function(B, V, PROG)
      B.log(V.VAR_SAVED_STATUS)
    end }
    steps[111] = { line = 4021, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5435")
    end }
    steps[112] = { line = 4029, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 503)) then return 123 end
    end }
    steps[113] = { line = 4034, sec = "", fn = function(B, V, PROG)
      V._loop_4034_112 = B.num(B.parse_int(1)) - 1
    end }
    steps[114] = { line = 4034, sec = "", fn = function(B, V, PROG)
      V._loop_4034_112 = V._loop_4034_112 + 1; V.VAR_CYCLE_INDEX = V._loop_4034_112; if V.VAR_CYCLE_INDEX > B.num(B.parse_int(120)) then return 122 end
    end }
    steps[115] = { line = 4041, sec = "", fn = function(B, V, PROG)
      B.sleep(5000)
    end }
    steps[116] = { op = "try_begin", line = 4051, end_pc = 118 }
    steps[117] = { line = 4064, sec = "Click Email", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Email\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[118] = { op = "try_end", line = 4051 }
    steps[119] = { line = 4073, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 121 end
    end }
    steps[120] = { line = 4078, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7123")
    end }
    steps[121] = { line = 4034, sec = "", fn = function(B, V, PROG)
      return 114
    end }
    steps[122] = { line = 4089, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5435")
    end }
    steps[123] = { line = 4097, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[124] = { line = 4103, sec = "", fn = function(B, V, PROG)
      V.VAR_EMAIL = B.jpath_value(V.VAR_SAVED_CONTENT, "mail")
    end }
    steps[125] = { line = 4112, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_EMAIL, "")) then return 134 end
    end }
    steps[126] = { line = 4117, sec = "", fn = function(B, V, PROG)
      B.log("Không có mail đợi tiếp")
    end }
    steps[127] = { op = "try_begin", line = 4127, end_pc = 129 }
    steps[128] = { line = 4140, sec = "Click Email", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Email\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[129] = { op = "try_end", line = 4127 }
    steps[130] = { line = 4149, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 132 end
    end }
    steps[131] = { line = 4154, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 6546")
    end }
    steps[132] = { line = 4162, sec = "", fn = function(B, V, PROG)
      B.sleep(10000)
    end }
    steps[133] = { line = 4167, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5435")
    end }
    steps[134] = { line = 4178, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_699008 = B.rs("Shop API", false, false)
    end }
    steps[135] = { line = 4178, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_699008, "Smspool")) then return 146 end
    end }
    steps[136] = { line = 4190, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request("https://api.smspool.net/purchase/sms?key=D8z4oRcYIsoo7aIcWPS0tvnUo2h0YOgl&country=9&service=457", "GET", nil, "", nil)
    end }
    steps[137] = { line = 4196, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[138] = { line = 4202, sec = "", fn = function(B, V, PROG)
      V.VAR_SUCCESS = B.jpath_value(V.VAR_SAVED_CONTENT, "success")
    end }
    steps[139] = { line = 4211, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SUCCESS, 0)) then return 143 end
    end }
    steps[140] = { line = 4216, sec = "", fn = function(B, V, PROG)
      B.log(V.VAR_SAVED_CONTENT)
    end }
    steps[141] = { line = 4221, sec = "", fn = function(B, V, PROG)
      B.sleep(10000)
    end }
    steps[142] = { line = 4226, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 305")
    end }
    steps[143] = { line = 4234, sec = "", fn = function(B, V, PROG)
      V.VAR_EMAIL = B.jpath_value(V.VAR_SAVED_CONTENT, "number")
    end }
    steps[144] = { line = 4243, sec = "", fn = function(B, V, PROG)
      V.VAR_ORDERID = B.jpath_value(V.VAR_SAVED_CONTENT, "orderid")
    end }
    steps[145] = { line = 4252, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 1281")
    end }
    steps[146] = { line = 4260, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_862269 = B.rs("Shop API", false, false)
    end }
    steps[147] = { line = 4260, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_862269, "ShopMail999")) then return 149 end
    end }
    steps[148] = { line = 4267, sec = "", fn = function(B, V, PROG)
      B.exec_fn(PROG, "API_GMAIL", V)
    end }
    steps[149] = { line = 4276, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_322183 = B.rs("Shop API", false, false)
    end }
    steps[150] = { line = 4276, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_322183, "Hotmail")) then return 158 end
    end }
  end)()
  ;(function()
    steps[151] = { line = 4288, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request("https://www.shopvia1s.net/api/buy_product?action=buyProduct&id=50510&amount=1&api_key=e0c3fd0c0070f1aebb42f894bdf1b957", "GET", nil, "", nil)
    end }
    steps[152] = { line = 4294, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[153] = { line = 4300, sec = "", fn = function(B, V, PROG)
      V.VAR_LIST_DATA = B.jpath_value(V.VAR_SAVED_CONTENT, ".data[0]")
    end }
    steps[154] = { line = 4309, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_LIST_DATA, "")) then return 157 end
    end }
    steps[155] = { line = 4314, sec = "", fn = function(B, V, PROG)
      B.log(V.VAR_SAVED_CONTENT)
    end }
    steps[156] = { line = 4319, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 2968")
    end }
    steps[157] = { line = 4327, sec = "", fn = function(B, V, PROG)
      do local csv_res = B.csv_parse(V.VAR_LIST_DATA, "|")
      V.VAR_LIST_WITH_ITEMS = csv_res
      V.VAR_EMAIL = B.avoid_nilb(csv_res[1], "")
      V.VAR_PASSMAIL = B.avoid_nilb(csv_res[2], "")
      V.VAR_REFRESH_TOKEN = B.avoid_nilb(csv_res[3], "")
      V.VAR_CLIENT_ID = B.avoid_nilb(csv_res[4], "")
      end
    end }
    steps[158] = { line = 4340, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_391586 = B.rs("Shop API", false, false)
    end }
    steps[159] = { line = 4340, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_391586, "CloneNha")) then return 160 end
    end }
    steps[160] = { line = 4355, sec = "", fn = function(B, V, PROG)
      B.log(V.VAR_EMAIL)
    end }
    steps[161] = { op = "try_begin", line = 4370, end_pc = 163 }
    steps[162] = { line = 4383, sec = "Pate Text", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{ \"action\": \"TEXT\", \"data\": \"", V.VAR_EMAIL), "\" }"), "", B.add("custom/", ("application/json")))
    end }
    steps[163] = { op = "try_end", line = 4370 }
    steps[164] = { line = 4392, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 166 end
    end }
    steps[165] = { line = 4397, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7267")
    end }
    steps[166] = { line = 4405, sec = "", fn = function(B, V, PROG)
      B.sleep(3000)
    end }
    steps[167] = { op = "try_begin", line = 4415, end_pc = 169 }
    steps[168] = { line = 4428, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[169] = { op = "try_end", line = 4415 }
    steps[170] = { line = 4437, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 172 end
    end }
    steps[171] = { line = 4442, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9106")
    end }
    steps[172] = { op = "try_begin", line = 4455, end_pc = 174 }
    steps[173] = { line = 4468, sec = "chekc Email required", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Email required.\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[174] = { op = "try_end", line = 4455 }
    steps[175] = { line = 4477, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 177 end
    end }
    steps[176] = { line = 4482, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 4489")
    end }
    steps[177] = { line = 4490, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[178] = { line = 4496, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 181 end
    end }
    steps[179] = { line = 4501, sec = "chekc Email required", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Email required.\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": -200,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[180] = { line = 4507, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5646")
    end }
    steps[181] = { line = 4515, sec = "check Enter the confirmation code", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Enter the confirmation code\",\r\n    \"timeout\": 10,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[182] = { op = "try_begin", line = 4526, end_pc = 184 }
    steps[183] = { line = 4539, sec = "check Enter the confirmation code", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Enter the confirmation code\",\r\n    \"timeout\": 3,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[184] = { op = "try_end", line = 4526 }
    steps[185] = { line = 4548, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 187 end
    end }
    steps[186] = { line = 4553, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9788")
    end }
    steps[187] = { line = 4561, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[188] = { line = 4567, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 213 end
    end }
    steps[189] = { line = 4572, sec = "Click pass", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n  \"action\": \"COLOR\",\r\n  \"script\": \"const [result, error] = findColors({\r\n    colors: [\r\n        { color: 13832496, x: 0, y: 0 },\r\n        { color: 13832496, x: 1, y: 15 },\r\n        { color: 16777215, x: 13, y: 6 }\r\n    ],\r\n    // count: 30,\r\n    // region: null,\r\n    // debug: false,\r\n    // rightToLeft: false,\r\n    // bottomToTop: false\r\n})\r\n\r\n\r\n\",\r\n  \"mode\": \"check\",\r\n  \"timeout\": 5,\r\n  \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[190] = { line = 4578, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[191] = { line = 4584, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 196 end
    end }
    steps[192] = { line = 4589, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_396878 = B.rs("Shop API", false, false)
    end }
    steps[193] = { line = 4589, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_396878, "Smsbower")) then return 195 end
    end }
    steps[194] = { line = 4596, sec = "HỦy mail", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(B.add("https://smsbower.page/api/mail/setStatus?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&id=", V.VAR_MAILID), "&status=2"), "GET", nil, "", nil)
    end }
    steps[195] = { line = 4605, sec = "", fn = function(B, V, PROG)
      B.fail_user("Mail Lỗi Đỏ")
    end }
    steps[196] = { line = 4613, sec = "Click We restrict certain", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"We restrict certain\",\r\n    \"timeout\": 5,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[197] = { line = 4619, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[198] = { line = 4625, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 200 end
    end }
    steps[199] = { line = 4630, sec = "", fn = function(B, V, PROG)
      B.fail_user("Mail Lỗi")
    end }
    steps[200] = { op = "try_begin", line = 4643, end_pc = 202 }
  end)()
  ;(function()
    steps[201] = { line = 4656, sec = "Click Refresh", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Refresh\",\r\n    \"timeout\": 3,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[202] = { op = "try_end", line = 4643 }
    steps[203] = { line = 4665, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 205 end
    end }
    steps[204] = { line = 4670, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 6602")
    end }
    steps[205] = { line = 4678, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[206] = { line = 4684, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 212 end
    end }
    steps[207] = { op = "try_begin", line = 4694, end_pc = 209 }
    steps[208] = { line = 4707, sec = "Click Email", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Email\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[209] = { op = "try_end", line = 4694 }
    steps[210] = { line = 4716, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 212 end
    end }
    steps[211] = { line = 4721, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 3893")
    end }
    steps[212] = { line = 4732, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5646")
    end }
    steps[213] = { line = 4740, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("cyan"), ["en"] = ("Check OTP"), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[214] = { line = 4745, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_OTP = 0
    end }
    steps[215] = { line = 4750, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_429990 = B.rs("Shop API", false, false)
    end }
    steps[216] = { line = 4750, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_429990, "Smsbower")) then return 263 end
    end }
    steps[217] = { line = 4757, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_OTP = 0
    end }
    steps[218] = { line = 4767, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_792310 = B.rs("Type", false, false)
    end }
    steps[219] = { line = 4767, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_792310, "ICloud")) then return 233 end
    end }
    steps[220] = { line = 4774, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add("https://smsbower.page/api/mail/getCode?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&mailId=", V.VAR_MAILID), "GET", nil, "", nil)
    end }
    steps[221] = { line = 4780, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[222] = { line = 4786, sec = "", fn = function(B, V, PROG)
      V.VAR_STATUS_CHECK_MAIL = B.jpath_value(V.VAR_SAVED_CONTENT, "status")
    end }
    steps[223] = { line = 4795, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_STATUS_CHECK_MAIL, 0)) then return 232 end
    end }
    steps[224] = { line = 4800, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_OTP = B.add(B.parse_int(V.VAR_CHECK_OTP), B.parse_int(1))
    end }
    steps[225] = { line = 4805, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_CHECK_OTP, 12)) then return 230 end
    end }
    steps[226] = { line = 4810, sec = "HỦy mail", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(B.add("https://smsbower.page/api/mail/setStatus?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&id=", V.VAR_MAILID), "&status=2"), "GET", nil, "", nil)
    end }
    steps[227] = { line = 4816, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[228] = { line = 4822, sec = "", fn = function(B, V, PROG)
      B.log(V.VAR_SAVED_CONTENT)
    end }
    steps[229] = { line = 4827, sec = "", fn = function(B, V, PROG)
      B.fail_user("Không về code")
    end }
    steps[230] = { line = 4835, sec = "", fn = function(B, V, PROG)
      B.sleep(5000)
    end }
    steps[231] = { line = 4840, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9053")
    end }
    steps[232] = { line = 4848, sec = "", fn = function(B, V, PROG)
      V.VAR_OTP = B.jpath_value(V.VAR_SAVED_CONTENT, "code")
    end }
    steps[233] = { line = 4860, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_113412 = B.rs("Type", false, false)
    end }
    steps[234] = { line = 4860, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_113412, "Phone")) then return 247 end
    end }
    steps[235] = { line = 4872, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add("https://smsbower.page/stubs/handler_api.php?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&action=getStatus&id=", V.VAR_MAILID), "GET", nil, "", nil)
    end }
    steps[236] = { line = 4878, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[237] = { line = 4884, sec = "", fn = function(B, V, PROG)
      do local csv_res = B.csv_parse(V.VAR_SAVED_CONTENT, ":")
      V.VAR_STATUS_CHECK = B.avoid_nilb(csv_res[1], "")
      V.VAR_OTP = B.avoid_nilb(csv_res[2], "")
      end
    end }
    steps[238] = { line = 4899, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_STATUS_CHECK, "STATUS_WAIT_CODE")) then return 247 end
    end }
    steps[239] = { line = 4904, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_OTP = B.add(B.parse_int(V.VAR_CHECK_OTP), B.parse_int(1))
    end }
    steps[240] = { line = 4909, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_CHECK_OTP, 20)) then return 245 end
    end }
    steps[241] = { line = 4914, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add("https://smsbower.page/stubs/handler_api.php?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&action=setStatus&status=8&id=", V.VAR_MAILID), "GET", nil, "", nil)
    end }
    steps[242] = { line = 4920, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[243] = { line = 4926, sec = "", fn = function(B, V, PROG)
      B.log(V.VAR_SAVED_CONTENT)
    end }
    steps[244] = { line = 4931, sec = "", fn = function(B, V, PROG)
      B.fail_user("Không về CODE")
    end }
    steps[245] = { line = 4939, sec = "", fn = function(B, V, PROG)
      B.sleep(5000)
    end }
    steps[246] = { line = 4944, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5544")
    end }
    steps[247] = { line = 4955, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_812711 = B.rs("Type", false, false)
    end }
    steps[248] = { line = 4955, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_812711, "Mail")) then return 263 end
    end }
    steps[249] = { line = 4962, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add("https://smsbower.page/api/mail/getCode?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&mailId=", V.VAR_MAILID), "GET", nil, "", nil)
    end }
    steps[250] = { line = 4968, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
  end)()
  ;(function()
    steps[251] = { line = 4974, sec = "", fn = function(B, V, PROG)
      V.VAR_STATUS_CHECK_MAIL = B.jpath_value(V.VAR_SAVED_CONTENT, "status")
    end }
    steps[252] = { line = 4983, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_STATUS_CHECK_MAIL, 0)) then return 261 end
    end }
    steps[253] = { line = 4988, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_OTP = B.add(B.parse_int(V.VAR_CHECK_OTP), B.parse_int(1))
    end }
    steps[254] = { line = 4993, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_CHECK_OTP, 12)) then return 259 end
    end }
    steps[255] = { line = 4998, sec = "HỦy mail", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(B.add("https://smsbower.page/api/mail/setStatus?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&id=", V.VAR_MAILID), "&status=2"), "GET", nil, "", nil)
    end }
    steps[256] = { line = 5004, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[257] = { line = 5010, sec = "", fn = function(B, V, PROG)
      B.log(V.VAR_SAVED_CONTENT)
    end }
    steps[258] = { line = 5015, sec = "", fn = function(B, V, PROG)
      B.fail_user("Không về code")
    end }
    steps[259] = { line = 5023, sec = "", fn = function(B, V, PROG)
      B.sleep(5000)
    end }
    steps[260] = { line = 5028, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9053")
    end }
    steps[261] = { line = 5036, sec = "HỦy mail", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(B.add("https://smsbower.page/api/mail/setStatus?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&id=", V.VAR_MAILID), "&status=3"), "GET", nil, "", nil)
    end }
    steps[262] = { line = 5042, sec = "", fn = function(B, V, PROG)
      V.VAR_OTP = B.jpath_value(V.VAR_SAVED_CONTENT, "code")
    end }
    steps[263] = { line = 5057, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_625060 = B.rs("Shop API", false, false)
    end }
    steps[264] = { line = 5057, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_625060, "API Icloud")) then return 285 end
    end }
    steps[265] = { line = 5064, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_OTP_COUNT = 0
    end }
    steps[266] = { op = "try_begin", line = 5074, end_pc = 268 }
    steps[267] = { line = 5087, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request("https://65.108.34.108.sslip.io/code", ("POST"), B.add(B.add("{\r\n  \"mail\": \"", V.VAR_EMAIL), "\"\r\n}"), "X-API-Key: uwbefowenfwenfoenfoiwfoiwnfowe33879dsfdkjn", B.add("custom/", ("application/json")))
    end }
    steps[268] = { op = "try_end", line = 5074 }
    steps[269] = { line = 5096, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 272 end
    end }
    steps[270] = { line = 5101, sec = "", fn = function(B, V, PROG)
      B.log(B.add("Error occurred : ", V.VAR_LAST_ERROR))
    end }
    steps[271] = { line = 5106, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7241")
    end }
    steps[272] = { line = 5114, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[273] = { line = 5120, sec = "", fn = function(B, V, PROG)
      if not B.truthy((B.truthy(B.eq(V.VAR_SAVED_STATUS, 429)) and (B.eq(V.VAR_SAVED_STATUS, 429)) or (B.eq(V.VAR_SAVED_STATUS, 503)))) then return 277 end
    end }
    steps[274] = { line = 5125, sec = "Đợi pass", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 1,\r\n     \"ex\": true,\r\n    \"offset\": -200,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[275] = { line = 5131, sec = "", fn = function(B, V, PROG)
      B.sleep(20000)
    end }
    steps[276] = { line = 5136, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7241")
    end }
    steps[277] = { line = 5144, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[278] = { line = 5150, sec = "", fn = function(B, V, PROG)
      V.VAR_OTP = B.jpath_value(V.VAR_SAVED_CONTENT, ".code")
    end }
    steps[279] = { line = 5159, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_OTP, B.NULL)) then return 285 end
    end }
    steps[280] = { line = 5164, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_OTP_COUNT = B.add(B.parse_int(V.VAR_CHECK_OTP_COUNT), B.parse_int(1))
    end }
    steps[281] = { line = 5169, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_CHECK_OTP_COUNT, 7)) then return 283 end
    end }
    steps[282] = { line = 5174, sec = "", fn = function(B, V, PROG)
      B.fail_user("Không Về Code")
    end }
    steps[283] = { line = 5182, sec = "", fn = function(B, V, PROG)
      B.sleep(5000)
    end }
    steps[284] = { line = 5187, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7241")
    end }
    steps[285] = { line = 5198, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_730559 = B.rs("Shop API", false, false)
    end }
    steps[286] = { line = 5198, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_730559, "CloneNha")) then return 287 end
    end }
    steps[287] = { line = 5208, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_239223 = B.rs("Shop API", false, false)
    end }
    steps[288] = { line = 5208, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_239223, "ShopMail999")) then return 299 end
    end }
    steps[289] = { line = 5215, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_OTP = 0
    end }
    steps[290] = { line = 5225, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add("https://api.shopgmail9999.com/api/ApiV2/CheckOtp?apikey=3ada3340e0d481e83e9c0167bdee4533&orderid=", V.VAR_ORDERID), "GET", nil, "", nil)
    end }
    steps[291] = { line = 5231, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[292] = { line = 5237, sec = "", fn = function(B, V, PROG)
      V.VAR_OTP = B.jpath_value(V.VAR_SAVED_CONTENT, "..otp")
    end }
    steps[293] = { line = 5246, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_OTP, "")) then return 299 end
    end }
    steps[294] = { line = 5251, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_OTP = B.add(B.parse_int(V.VAR_CHECK_OTP), B.parse_int(1))
    end }
    steps[295] = { line = 5256, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_CHECK_OTP, 50)) then return 297 end
    end }
    steps[296] = { line = 5261, sec = "", fn = function(B, V, PROG)
      return B.goto_label("RA_MAIN")
    end }
    steps[297] = { line = 5269, sec = "", fn = function(B, V, PROG)
      B.sleep(3000)
    end }
    steps[298] = { line = 5274, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7818")
    end }
    steps[299] = { line = 5285, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_831866 = B.rs("Shop API", false, false)
    end }
    steps[300] = { line = 5285, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_831866, "Hotmail")) then return 302 end
    end }
  end)()
  ;(function()
    steps[301] = { line = 5292, sec = "", fn = function(B, V, PROG)
      V.VAR_LINK = B.emb_hotmail_read(V.VAR_LIST_DATA)
    end }
    steps[302] = { line = 5301, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_506317 = B.rs("Shop API", false, false)
    end }
    steps[303] = { line = 5301, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_506317, "Smspool")) then return 316 end
    end }
    steps[304] = { line = 5308, sec = "", fn = function(B, V, PROG)
      B.sleep(10000)
    end }
    steps[305] = { line = 5318, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add("https://api.smspool.net/sms/check?key=D8z4oRcYIsoo7aIcWPS0tvnUo2h0YOgl&orderid=", V.VAR_ORDERID), "GET", nil, "", nil)
    end }
    steps[306] = { line = 5324, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[307] = { line = 5330, sec = "", fn = function(B, V, PROG)
      V.VAR_STATUS_SMS = B.jpath_value(V.VAR_SAVED_CONTENT, "status")
    end }
    steps[308] = { line = 5339, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_STATUS_SMS, 1)) then return 315 end
    end }
    steps[309] = { line = 5344, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_OTP = B.add(B.parse_int(V.VAR_CHECK_OTP), B.parse_int(1))
    end }
    steps[310] = { line = 5349, sec = "", fn = function(B, V, PROG)
      B.log(B.add("Check OTP ", V.VAR_CHECK_OTP))
    end }
    steps[311] = { line = 5354, sec = "", fn = function(B, V, PROG)
      B.sleep(10000)
    end }
    steps[312] = { line = 5359, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_CHECK_OTP, 7)) then return 314 end
    end }
    steps[313] = { line = 5364, sec = "", fn = function(B, V, PROG)
      B.fail_user("Không về OTP")
    end }
    steps[314] = { line = 5372, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 1953")
    end }
    steps[315] = { line = 5380, sec = "", fn = function(B, V, PROG)
      V.VAR_OTP = B.jpath_value(V.VAR_SAVED_CONTENT, "sms")
    end }
    steps[316] = { line = 5392, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("cyan"), ["en"] = (B.add("Code: ", V.VAR_OTP)), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[317] = { op = "try_begin", line = 5407, end_pc = 319 }
    steps[318] = { line = 5420, sec = "Pate Text", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{ \"action\": \"TEXT\", \"data\": \"", V.VAR_OTP), "\" }"), "", B.add("custom/", ("application/json")))
    end }
    steps[319] = { op = "try_end", line = 5407 }
    steps[320] = { line = 5429, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 322 end
    end }
    steps[321] = { line = 5434, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 1299")
    end }
    steps[322] = { op = "try_begin", line = 5447, end_pc = 324 }
    steps[323] = { line = 5460, sec = "Đợi pass", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Code is required.\",\r\n    \"timeout\": 5,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[324] = { op = "try_end", line = 5447 }
    steps[325] = { line = 5469, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 327 end
    end }
    steps[326] = { line = 5474, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 4834")
    end }
    steps[327] = { line = 5482, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[328] = { line = 5488, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 331 end
    end }
    steps[329] = { line = 5493, sec = "Đợi pass", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Code is required.\",\r\n    \"timeout\": 5,\r\n     \"ex\": false,\r\n    \"offset\": -100,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[330] = { line = 5499, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 2995")
    end }
    steps[331] = { line = 5507, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_CODE_LOI = 0
    end }
    steps[332] = { op = "try_begin", line = 5522, end_pc = 334 }
    steps[333] = { line = 5535, sec = "check Enter the confirmation code", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Enter the confirmation code\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[334] = { op = "try_end", line = 5522 }
    steps[335] = { line = 5544, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 337 end
    end }
    steps[336] = { line = 5549, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 1628")
    end }
    steps[337] = { line = 5557, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[338] = { line = 5563, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 361 end
    end }
    steps[339] = { line = 5568, sec = "Đợi pass", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Code is required.\",\r\n    \"timeout\": 5,\r\n     \"ex\": false,\r\n    \"offset\": -100,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[340] = { line = 5574, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[341] = { line = 5580, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 343 end
    end }
    steps[342] = { line = 5585, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 2995")
    end }
    steps[343] = { line = 5593, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_CODE_LOI = B.add(B.parse_int(V.VAR_CHECK_CODE_LOI), B.parse_int(1))
    end }
    steps[344] = { line = 5598, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_CHECK_CODE_LOI, 10)) then return 346 end
    end }
    steps[345] = { line = 5603, sec = "", fn = function(B, V, PROG)
      B.fail_user("Không tới nổi trang PASS")
    end }
    steps[346] = { line = 5611, sec = "", fn = function(B, V, PROG)
      B.sleep(5000)
    end }
    steps[347] = { op = "try_begin", line = 5621, end_pc = 349 }
    steps[348] = { line = 5634, sec = "check code correctly", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"confirmation code correctly.\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[349] = { op = "try_end", line = 5621 }
    steps[350] = { line = 5643, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 352 end
    end }
  end)()
  ;(function()
    steps[351] = { line = 5648, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9237")
    end }
    steps[352] = { line = 5656, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[353] = { line = 5662, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 355 end
    end }
    steps[354] = { line = 5667, sec = "", fn = function(B, V, PROG)
      B.fail_user("Code hết hạn")
    end }
    steps[355] = { op = "try_begin", line = 5680, end_pc = 357 }
    steps[356] = { line = 5693, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[357] = { op = "try_end", line = 5680 }
    steps[358] = { line = 5702, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 360 end
    end }
    steps[359] = { line = 5707, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5651")
    end }
    steps[360] = { line = 5715, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 572")
    end }
    steps[361] = { line = 5723, sec = "", fn = function(B, V, PROG)
      V.VAR_PASSWORD = B.random_string(12, "abcdefghijklmnopqrstuvwxyz0123456789")
    end }
    steps[362] = { op = "try_begin", line = 5738, end_pc = 364 }
    steps[363] = { line = 5751, sec = "Đợi pass", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Password\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[364] = { op = "try_end", line = 5738 }
    steps[365] = { line = 5760, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 367 end
    end }
    steps[366] = { line = 5765, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5770")
    end }
    steps[367] = { line = 5773, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[368] = { line = 5779, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 413 end
    end }
    steps[369] = { op = "try_begin", line = 5789, end_pc = 371 }
    steps[370] = { line = 5802, sec = "Full name", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Full name\",\r\n    \"timeout\": 7,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[371] = { op = "try_end", line = 5789 }
    steps[372] = { line = 5811, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 374 end
    end }
    steps[373] = { line = 5816, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9750")
    end }
    steps[374] = { line = 5824, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[375] = { line = 5830, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 378 end
    end }
    steps[376] = { line = 5835, sec = "", fn = function(B, V, PROG)
      V.VAR_LECH_SONG = true
    end }
    steps[377] = { line = 5840, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 4452")
    end }
    steps[378] = { op = "try_begin", line = 5853, end_pc = 380 }
    steps[379] = { line = 5866, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 2,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[380] = { op = "try_end", line = 5853 }
    steps[381] = { line = 5875, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 383 end
    end }
    steps[382] = { line = 5880, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5253")
    end }
    steps[383] = { line = 5888, sec = "check what's your birthaday", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"what's your birthday?\",\r\n    \"timeout\": 2,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[384] = { line = 5894, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[385] = { line = 5900, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 387 end
    end }
    steps[386] = { line = 5905, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7519")
    end }
    steps[387] = { line = 5913, sec = "", fn = function(B, V, PROG)
      B.log("Tiếp tục đợi pass")
    end }
    steps[388] = { op = "try_begin", line = 5923, end_pc = 390 }
    steps[389] = { line = 5936, sec = "How old are you", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"How old are you?\",\r\n    \"timeout\": 2,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[390] = { op = "try_end", line = 5923 }
    steps[391] = { line = 5945, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 393 end
    end }
    steps[392] = { line = 5950, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9719")
    end }
    steps[393] = { line = 5958, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[394] = { line = 5964, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 412 end
    end }
    steps[395] = { op = "try_begin", line = 5974, end_pc = 397 }
    steps[396] = { line = 5987, sec = "How old are you", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"How old are you?\",\r\n    \"timeout\": 2,\r\n     \"ex\": false,\r\n    \"offset\": 200,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[397] = { op = "try_end", line = 5974 }
    steps[398] = { line = 5996, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 400 end
    end }
    steps[399] = { line = 6001, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 4121")
    end }
    steps[400] = { line = 6009, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
  end)()
  ;(function()
    steps[401] = { line = 6014, sec = "Pate Text", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{ \"action\": \"TEXT\", \"data\": \"20\" }", "", B.add("custom/", ("application/json")))
    end }
    steps[402] = { op = "try_begin", line = 6025, end_pc = 404 }
    steps[403] = { line = 6038, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 2,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[404] = { op = "try_end", line = 6025 }
    steps[405] = { line = 6047, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 407 end
    end }
    steps[406] = { line = 6052, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8552")
    end }
    steps[407] = { op = "try_begin", line = 6065, end_pc = 409 }
    steps[408] = { line = 6078, sec = "Click OK", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"OK\",\r\n    \"timeout\": 7,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[409] = { op = "try_end", line = 6065 }
    steps[410] = { line = 6087, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 412 end
    end }
    steps[411] = { line = 6092, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 2439")
    end }
    steps[412] = { line = 6103, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 663")
    end }
    steps[413] = { line = 6111, sec = "Pate Text", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{ \"action\": \"TEXT\", \"data\": \"", V.VAR_PASSWORD), "\" }"), "", B.add("custom/", ("application/json")))
    end }
    steps[414] = { line = 6117, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("cyan"), ["en"] = (B.add("Pass: ", V.VAR_PASSWORD)), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[415] = { op = "try_begin", line = 6132, end_pc = 417 }
    steps[416] = { line = 6145, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[417] = { op = "try_end", line = 6132 }
    steps[418] = { line = 6154, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 420 end
    end }
    steps[419] = { line = 6159, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5483")
    end }
    steps[420] = { line = 6167, sec = "", fn = function(B, V, PROG)
      B.sleep(4000)
    end }
    steps[421] = { line = 6172, sec = "Đợi pass", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Password\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[422] = { line = 6178, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[423] = { line = 6184, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 441 end
    end }
    steps[424] = { line = 6189, sec = "", fn = function(B, V, PROG)
      B.log("Click lại NEXT pass")
    end }
    steps[425] = { line = 6194, sec = "Click Refresh", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Refresh\",\r\n    \"timeout\": 10,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[426] = { line = 6200, sec = "Confirm you're human to", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Confirm you're human to\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[427] = { line = 6206, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[428] = { line = 6212, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 430 end
    end }
    steps[429] = { line = 6217, sec = "", fn = function(B, V, PROG)
      B.fail_user("Die")
    end }
    steps[430] = { line = 6225, sec = "Password required", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Password cannot be empty.\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[431] = { line = 6231, sec = "", fn = function(B, V, PROG)
      V.VAR_PASS_EMPTY = B.http_status()
    end }
    steps[432] = { line = 6237, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_PASS_EMPTY) then return 440 end
    end }
    steps[433] = { line = 6242, sec = "Password required", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Password cannot be empty.\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": -150,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[434] = { op = "try_begin", line = 6253, end_pc = 436 }
    steps[435] = { line = 6266, sec = "Click pass", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n  \"action\": \"COLOR\",\r\n  \"script\": \"const [result, error] = findColors({\r\n    colors: [\r\n        { color: 13832496, x: 0, y: 0 },\r\n        { color: 13832496, x: 1, y: 16 },\r\n        { color: 13832496, x: 15, y: 26 },\r\n        { color: 13832496, x: 27, y: -7 }\r\n    ],\r\n    // count: 30,\r\n    // region: null,\r\n    // debug: false,\r\n    // rightToLeft: false,\r\n    // bottomToTop: false\r\n})\r\n\r\n\r\n\",\r\n  \"mode\": \"click\",\r\n  \"timeout\": 5,\r\n  \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[436] = { op = "try_end", line = 6253 }
    steps[437] = { line = 6275, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 439 end
    end }
    steps[438] = { line = 6280, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5494")
    end }
    steps[439] = { line = 6288, sec = "Pate Text", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{ \"action\": \"TEXT\", \"data\": \"", V.VAR_PASSWORD), "\" }"), "", B.add("custom/", ("application/json")))
    end }
    steps[440] = { line = 6297, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 3613")
    end }
    steps[441] = { op = "try_begin", line = 6310, end_pc = 443 }
    steps[442] = { line = 6323, sec = "check what's your birthaday", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"what's your birthday?\",\r\n    \"timeout\": 15,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[443] = { op = "try_end", line = 6310 }
    steps[444] = { line = 6332, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 446 end
    end }
    steps[445] = { line = 6337, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9745")
    end }
    steps[446] = { line = 6345, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[447] = { line = 6351, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 455 end
    end }
    steps[448] = { line = 6356, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_USERNAME_LOI = B.add(B.parse_int(V.VAR_CHECK_USERNAME_LOI), B.parse_int(1))
    end }
    steps[449] = { line = 6361, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_CHECK_USERNAME_LOI, 10)) then return 453 end
    end }
    steps[450] = { line = 6366, sec = "", fn = function(B, V, PROG)
      do local len = B.arr_len(V.VAR_NAME_LIST); if len > 0 then local r = math.random(0, len - 1); V.VAR_NAME_GET = B.arr_get(V.VAR_NAME_LIST, r); B.arr_splice(V.VAR_NAME_LIST, r, 1) else V.VAR_NAME_GET = nil end end
    end }
  end)()
  ;(function()
    steps[451] = { line = 6375, sec = "", fn = function(B, V, PROG)
      V.VAR_USERNAME = B.jpath_value(V.VAR_NAME_GET, "username")
    end }
    steps[452] = { line = 6384, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 403")
    end }
    steps[453] = { line = 6392, sec = "Not now", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Not now\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[454] = { line = 6398, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9538")
    end }
    steps[455] = { op = "try_begin", line = 6421, end_pc = 457 }
    steps[456] = { line = 6434, sec = "check what's your birthaday", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"what's your birthday?\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 400,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[457] = { op = "try_end", line = 6421 }
    steps[458] = { line = 6443, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 460 end
    end }
    steps[459] = { line = 6448, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8185")
    end }
    steps[460] = { op = "try_begin", line = 6461, end_pc = 462 }
    steps[461] = { line = 6474, sec = "Chọn ngày tháng năm sinh", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"local dw, dh = 1125, 2436\\r\\nif type(getScreenSize) == \\\"function\\\" then\\r\\n  local ok, sw, sh = pcall(getScreenSize)\\r\\n  if ok and tonumber(sw) and tonumber(sh) and sw > 0 and sh > 0 then dw, dh = sw, sh end\\r\\nend\\r\\nlocal sx, sy = 1125 / dw, 2436 / dh\\r\\n\\r\\nlocal function flick(fid, rx, ry0, ry1, steps, step_us, pause_us)\\r\\n  touchDown(fid, rx, ry0)\\r\\n  usleep(20000)\\r\\n  for i = 1, steps do\\r\\n    touchMove(fid, rx, ry0 + (ry1 - ry0) * (i / steps))\\r\\n    usleep(step_us)\\r\\n  end\\r\\n  touchUp(fid, rx, ry1)\\r\\n  usleep(pause_us)\\r\\nend\\r\\n\\r\\nlocal yearX, pickY = 827, 1988\\r\\nlocal okOcr, items = pcall(ocr, {level = \\\"fast\\\"})\\r\\nif okOcr and type(items) == \\\"table\\\" then\\r\\n  local ys = {}\\r\\n  for _, it in ipairs(items) do\\r\\n    local txt = tostring(it.text or \\\"\\\")\\r\\n    local r = it.rectangle\\r\\n    if r and r.topLeft and r.topRight and r.bottomLeft and r.topLeft.y > dh * 0.55 then\\r\\n      local yr = txt:match(\\\"^(20[0-3]%d)$\\\") or txt:match(\\\"^(19%d%d)$\\\")\\r\\n      if yr then\\r\\n        local cx = ((r.topLeft.x + r.topRight.x) / 2) * sx\\r\\n        local cy = ((r.topLeft.y + r.bottomLeft.y) / 2) * sy\\r\\n        ys[#ys + 1] = {yr = tonumber(yr), x = cx, y = cy}\\r\\n      end\\r\\n    end\\r\\n  end\\r\\n  if #ys > 0 then\\r\\n    table.sort(ys, function(a, b) return a.y < b.y end)\\r\\n    local mid = ys[math.ceil(#ys / 2)]\\r\\n    yearX = mid.x\\r\\n    if mid.y > 1750 and mid.y < 2250 then pickY = mid.y end\\r\\n  end\\r\\nend\\r\\n\\r\\nlocal topY = math.max(1750, pickY - 220)\\r\\nlocal botY = math.min(2260, pickY + 230)\\r\\nflick(1, yearX, topY, botY, 10, 12000, 180000)\\r\\nflick(2, yearX, topY, botY, 10, 13000, 220000)\\r\\nflick(3, 614, botY, topY, 9, 13000, 180000)\\r\\nflick(4, 356, botY, topY, 10, 13000, 200000)\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[462] = { op = "try_end", line = 6461 }
    steps[463] = { line = 6483, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 465 end
    end }
    steps[464] = { line = 6488, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 3673")
    end }
    steps[465] = { line = 6496, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[466] = { line = 6501, sec = "check 2010", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"2010\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[467] = { line = 6507, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[468] = { line = 6513, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 470 end
    end }
    steps[469] = { line = 6518, sec = "check 2010", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"2005\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[470] = { line = 6527, sec = "check ", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"2026\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 400,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[471] = { line = 6533, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[472] = { line = 6539, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 475 end
    end }
    steps[473] = { line = 6544, sec = "", fn = function(B, V, PROG)
      B.log("Chọn lại ngày tháng")
    end }
    steps[474] = { line = 6549, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7904")
    end }
    steps[475] = { op = "try_begin", line = 6562, end_pc = 477 }
    steps[476] = { line = 6575, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[477] = { op = "try_end", line = 6562 }
    steps[478] = { line = 6584, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 480 end
    end }
    steps[479] = { line = 6589, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5067")
    end }
    steps[480] = { line = 6607, sec = "", fn = function(B, V, PROG)
      V.VAR_LIST_NAME = B.emb_girly_names({firstNames={"Anneliese","Aurelie","Camellia","Carina","Celestia","Clarissa","Clementine","Colette","Cordelia","Cosette","Delphine","Dulcie","Emmeline","Estelle","Evangeline","Evelina","Felicity","Fleur","Francesca","Georgiana","Ginevra","Isadora","Jolie","Juliet","Lavinia","Lilibet","Lisette","Lucille","Lucienne","Madeleine","Magnolia","Marceline","Margaux","Marigold","Mirabelle","Nicolette","Opaline","Ottilie","Primrose","Rosalind","Rosette","Seraphina","Sylvie","Tallulah","Thalia","Theodora","Valerie","Vivienne","Addie","Ainsley","Allie","Amie","Andie","Annie","Ashlyn","Averie","Bambi","Birdie","Bonnie","Bree","Bridget","Callie","Camryn","Carly","Carrie","Cassie","Cece","Celia","Charlie","Chelsea","Cherie","Cici","Coralie","Courtney","Dani","Darcy","Dolly","Edie","Elaina","Eliana","Elise","Elodie","Emery","Emmie","Erin","Essie","Evie","Flora","Gemma","Gigi","Goldie","Gracie","Hallie","Hattie","Heidi","Hollie","Honey","Izzy","Jamie","Jenna","Jessie","Josie","Joy","Kacie","Katie","Kayla","Kaylee","Kelsey","Kendra","Kiki","Lacey","Lainey","Laurel","Lauren","Lexie","Libby","Lillie","Lizzie","Lottie","Lucie","Lulu","Mabel","Maddie","Maggie","Maisie","Mallory","Marnie","Megan","Melanie","Mollie","Molly","Nadia","Nellie","Nikki","Nola","Pearl","Penny","Pippa","Pixie","Poppy","Posie","Rachel","Remi","Romy","Rosie","Roxie","Sadie","Shelby","Sunny","Sydney","Tessa","Tia","Tiffany","Tilly","Tori","Vanessa","Wendy","Winnie","Amber","April","Azalea","Blossom","Briar","Clover","Coral","Dahlia","Eden","Fern","Freesia","Harmony","Hazel","Holly","Iris","Ivory","Ivy","Jade","Juniper","Lavender","Lilac","Lotus","Maple","Meadow","Opal","Orchid","Peach","Peony","Petal","Posey","Rosemary","Saffron","Scarlet","Sky","Summer","Tulip","Vanilla","Velvet","Wisteria","Zinnia"},lastNames={"smith","johnson","williams","brown","jones","garcia","miller","davis","martinez","lopez","wilson","anderson","taylor","thomas","moore","jackson","martin","lee","thompson","white","harris","clark","lewis","robinson","walker","young","allen","king","wright","scott","hill","green","adams","baker","nelson","carter","mitchell","perez","roberts","turner","phillips","campbell","parker","evans","edwards","collins","stewart","morris","rogers","reed","cook","morgan","bell","murphy","bailey","rivera","cooper","richardson","cox","howard","ward","torres","peterson","gray","ramirez","james","watson","brooks","kelly","sanders","price","bennett","wood","barnes","ross","henderson","coleman","jenkins","perry","powell","long","patterson","hughes","flores","washington","butler","simmons","foster","bryant","alexander","russell","griffin","hayes","myers","ford","hamilton","graham","sullivan","wallace","woods","cole","west","jordan","owens","reynolds","fisher","ellis","harrison","gibson","mcdonald","cruz","marshall","ortiz","gomez","murray","freeman","wells","webb","simpson","stevens","tucker","porter","hunter","hicks","crawford","henry","boyd","mason","morales","kennedy","warren","dixon","ramos","reyes","burns","gordon","shaw","holmes","rice","robertson"},girlyWords={"matcha","latte","pilates","skincare","bakery","florals","roses","tulips","coffee","books","bakes","paints","creates","designs","glow","aesthetic","vibes","daily","diary","journal","studio","nails","lashes","beauty","bridal","style","fashion","vintage","thrift","yoga","wellness","travel","wander","sunsets","goldenhour","pastel","coquette","sparkle","honey","peach","angel","babe","girl","muse","era","world","club","life","irl","notes","xo","xoxo"},locations={"nyc","la","miami","nashville","austin","dallas","chicago","seattle","boston","charleston","scottsdale","denver","atlanta","sanfran","london","paris","402","212","310","305","512","615"},targetCount=50})
    end }
    steps[481] = { line = 6613, sec = "", fn = function(B, V, PROG)
      V.VAR_NAME_LIST = B.jpath_change_format(V.VAR_LIST_NAME, "json")
    end }
    steps[482] = { line = 6622, sec = "", fn = function(B, V, PROG)
      do local len = B.arr_len(V.VAR_NAME_LIST); if len > 0 then local r = math.random(0, len - 1); V.VAR_NAME_GET = B.arr_get(V.VAR_NAME_LIST, r); B.arr_splice(V.VAR_NAME_LIST, r, 1) else V.VAR_NAME_GET = nil end end
    end }
    steps[483] = { line = 6631, sec = "", fn = function(B, V, PROG)
      V.VAR_NAME = B.jpath_value(V.VAR_NAME_GET, "name")
    end }
    steps[484] = { line = 6640, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_NAME, "")) then return 486 end
    end }
    steps[485] = { line = 6645, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 402")
    end }
    steps[486] = { op = "try_begin", line = 6658, end_pc = 488 }
    steps[487] = { line = 6671, sec = "", fn = function(B, V, PROG)
      V.VAR_USERNAME = B.jpath_value(V.VAR_NAME_GET, "username")
    end }
    steps[488] = { op = "try_end", line = 6658 }
    steps[489] = { line = 6683, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 491 end
    end }
    steps[490] = { line = 6688, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 6211")
    end }
    steps[491] = { line = 6696, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_NAME = 0
    end }
    steps[492] = { line = 6706, sec = "Full name", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Full name\",\r\n    \"timeout\": 20,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[493] = { line = 6712, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[494] = { line = 6718, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 508 end
    end }
    steps[495] = { line = 6723, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_NAME = B.add(B.parse_int(V.VAR_CHECK_NAME), B.parse_int(1))
    end }
    steps[496] = { line = 6728, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_CHECK_NAME, 5)) then return 498 end
    end }
    steps[497] = { line = 6733, sec = "", fn = function(B, V, PROG)
      return B.goto_label("MAIN")
    end }
    steps[498] = { line = 6741, sec = "", fn = function(B, V, PROG)
      B.log("Tiếp tục đợi NaME")
    end }
    steps[499] = { line = 6746, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Enter the confirmation code\",\r\n    \"timeout\": 10,\r\n     \"ex\": false,\r\n    \"offset\": 600,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[500] = { line = 6752, sec = "Đợi pass", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Password\",\r\n    \"timeout\": 2,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
  end)()
  ;(function()
    steps[501] = { line = 6758, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[502] = { line = 6764, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 506 end
    end }
    steps[503] = { line = 6769, sec = "Pate Text", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{ \"action\": \"TEXT\", \"data\": \"", V.VAR_PASSWORD), "\" }"), "", B.add("custom/", ("application/json")))
    end }
    steps[504] = { line = 6775, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[505] = { line = 6781, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5957")
    end }
    steps[506] = { line = 6789, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[507] = { line = 6795, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8623")
    end }
    steps[508] = { line = 6803, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[509] = { line = 6808, sec = "Pate Text", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{ \"action\": \"TEXT\", \"data\": \"", V.VAR_NAME), "\" }"), "", B.add("custom/", ("application/json")))
    end }
    steps[510] = { line = 6814, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("gray"), ["en"] = (B.add("Điền Full Name : ", V.VAR_NAME)), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[511] = { line = 6819, sec = "Add your details", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Add your details\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[512] = { line = 6825, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS_1 = B.http_status()
    end }
    steps[513] = { line = 6831, sec = "Edit how you'll appear on", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Edit how you'll appear on\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[514] = { line = 6837, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[515] = { line = 6843, sec = "", fn = function(B, V, PROG)
      if not B.truthy((B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) and (B.eq(V.VAR_SAVED_STATUS, 200)) or (B.eq(V.VAR_SAVED_STATUS_1, 200)))) then return 519 end
    end }
    steps[516] = { line = 6848, sec = "", fn = function(B, V, PROG)
      B.sleep(5000)
    end }
    steps[517] = { line = 6853, sec = "Click Username", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Username\",\r\n    \"timeout\": 10,\r\n    \"ex\": true,\r\n    \"offsetX\": 200,\r\n\"offsetY\": 200,\r\n    \"action\": \"click4\",\r\n    \"region\": {\r\n        \"x\": 21.13,\r\n        \"y\": 555.63,\r\n        \"width\": 1059.51,\r\n        \"height\": 371.83\r\n    },\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[518] = { line = 6859, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8912")
    end }
    steps[519] = { op = "try_begin", line = 6877, end_pc = 521 }
    steps[520] = { line = 6890, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[521] = { op = "try_end", line = 6877 }
    steps[522] = { line = 6899, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 524 end
    end }
    steps[523] = { line = 6904, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 6882")
    end }
    steps[524] = { line = 6917, sec = "Create a username", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Create a username\",\r\n    \"timeout\": 25,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[525] = { line = 6923, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[526] = { line = 6929, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 537 end
    end }
    steps[527] = { line = 6934, sec = "", fn = function(B, V, PROG)
      B.log("Click Next lại Full Name")
    end }
    steps[528] = { op = "try_begin", line = 6944, end_pc = 530 }
    steps[529] = { line = 6957, sec = "Click i agree", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"including ads\",\r\n    \"timeout\": 5,\r\n    \"ex\": false,\r\n    \"offset\": 100,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[530] = { op = "try_end", line = 6944 }
    steps[531] = { line = 6966, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 533 end
    end }
    steps[532] = { line = 6971, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 3842")
    end }
    steps[533] = { line = 6979, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[534] = { line = 6985, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 536 end
    end }
    steps[535] = { line = 6990, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 4201")
    end }
    steps[536] = { line = 6998, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8654")
    end }
    steps[537] = { line = 7006, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 539 end
    end }
    steps[538] = { line = 7011, sec = "Click Username", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Username\",\r\n    \"timeout\": 10,\r\n    \"ex\": true,\r\n    \"offsetX\": 50,\r\n\"offsetY\": 50,\r\n    \"action\": \"click3\",\r\n    \"region\": {\r\n        \"x\": 21.13,\r\n        \"y\": 555.63,\r\n        \"width\": 1059.51,\r\n        \"height\": 371.83\r\n    },\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[539] = { line = 7025, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[540] = { line = 7030, sec = "", fn = function(B, V, PROG)
      V.VAR_USERNAME = B.trim(V.VAR_USERNAME)
    end }
    steps[541] = { line = 7035, sec = "Dán username", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{ \"action\": \"TEXT\", \"data\": \"", V.VAR_USERNAME), "\" }"), "", B.add("custom/", ("application/json")))
    end }
    steps[542] = { line = 7041, sec = "", fn = function(B, V, PROG)
      B.sleep(5000)
    end }
    steps[543] = { line = 7046, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_USER = 0
    end }
    steps[544] = { op = "try_begin", line = 7056, end_pc = 546 }
    steps[545] = { line = 7069, sec = "Check acc ", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n  \"action\": \"COLOR\",\r\n  \"script\": \"findColors({ colors: [ {color: 6842990, x: 0, y: 0}, {color: 16777215, x: 1, y: -19}, {color: 16777215, x: 22, y: -3}, {color: 16777215, x: 4, y: 25}, {color: 6842990, x: -19, y: 21}, {color: 13832496, x: 63, y: 0} ] })\",\r\n  \"mode\": \"check\",\r\n  \"timeout\": 3,\r\n  \"region\": [1000, 480, 242, 200]\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[546] = { op = "try_end", line = 7056 }
    steps[547] = { line = 7078, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 549 end
    end }
    steps[548] = { line = 7083, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 397")
    end }
    steps[549] = { line = 7091, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[550] = { line = 7097, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 563 end
    end }
  end)()
  ;(function()
    steps[551] = { line = 7102, sec = "Is not available", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Is not available\",\r\n    \"timeout\": 5,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[552] = { line = 7108, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[553] = { line = 7114, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 562 end
    end }
    steps[554] = { line = 7119, sec = "", fn = function(B, V, PROG)
      V.VAR_NAME_GET = B.arr_get(V.VAR_NAME_LIST, 0)
    end }
    steps[555] = { line = 7125, sec = "", fn = function(B, V, PROG)
      V.VAR_USERNAME = B.jpath_value(V.VAR_NAME_GET, "username")
    end }
    steps[556] = { line = 7134, sec = "Edit how you'll appear on", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Edit how you'll appear on\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[557] = { line = 7140, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[558] = { line = 7146, sec = "", fn = function(B, V, PROG)
      if not B.truthy((B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) and (B.eq(V.VAR_SAVED_STATUS, 200)) or (B.eq(V.VAR_SAVED_STATUS_1, 200)))) then return 561 end
    end }
    steps[559] = { line = 7151, sec = "Click Username", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Username\",\r\n    \"timeout\": 10,\r\n    \"ex\": true,\r\n    \"offsetX\": 550,\r\n\"offsetY\": 200,\r\n    \"action\": \"click3\",\r\n    \"region\": {\r\n        \"x\": 21.13,\r\n        \"y\": 555.63,\r\n        \"width\": 1059.51,\r\n        \"height\": 371.83\r\n    },\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[560] = { line = 7157, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8912")
    end }
    steps[561] = { line = 7165, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 403")
    end }
    steps[562] = { line = 7173, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 403")
    end }
    steps[563] = { line = 7181, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("yellow"), ["en"] = (B.add("Đã lấy được username: ", V.VAR_USERNAME)), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[564] = { line = 7186, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_USERNAME_LOI = 0
    end }
    steps[565] = { line = 7191, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS_1, 200)) then return 580 end
    end }
    steps[566] = { line = 7196, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("gray"), ["en"] = ("Giao diện khác"), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[567] = { op = "try_begin", line = 7206, end_pc = 569 }
    steps[568] = { line = 7219, sec = "Accept and continue", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Accept and continue\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[569] = { op = "try_end", line = 7206 }
    steps[570] = { line = 7228, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 572 end
    end }
    steps[571] = { line = 7233, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8694")
    end }
    steps[572] = { line = 7241, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[573] = { line = 7247, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 579 end
    end }
    steps[574] = { op = "try_begin", line = 7257, end_pc = 576 }
    steps[575] = { line = 7270, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[576] = { op = "try_end", line = 7257 }
    steps[577] = { line = 7279, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 579 end
    end }
    steps[578] = { line = 7284, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 2612")
    end }
    steps[579] = { line = 7295, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8595")
    end }
    steps[580] = { line = 7308, sec = "", fn = function(B, V, PROG)
      B.sleep(3000)
    end }
    steps[581] = { op = "try_begin", line = 7318, end_pc = 583 }
    steps[582] = { line = 7331, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[583] = { op = "try_end", line = 7318 }
    steps[584] = { line = 7340, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 586 end
    end }
    steps[585] = { line = 7345, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8538")
    end }
    steps[586] = { line = 7358, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_LECH_SONG) then return 588 end
    end }
    steps[587] = { line = 7363, sec = "", fn = function(B, V, PROG)
      B.exec_fn(PROG, "reg_2", V)
    end }
    steps[588] = { line = 7377, sec = "click Not now", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Not now\",\r\n    \"timeout\": 5,\r\n    \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[589] = { line = 7383, sec = "Click i agree", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"including ads\",\r\n    \"timeout\": 10,\r\n    \"ex\": false,\r\n    \"offset\": 100,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[590] = { line = 7389, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[591] = { line = 7395, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 600 end
    end }
    steps[592] = { line = 7400, sec = "Click Female", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Female\",\r\n    \"timeout\": 3,\r\n    \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[593] = { line = 7406, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[594] = { line = 7412, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 597 end
    end }
    steps[595] = { line = 7417, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[596] = { line = 7423, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5957")
    end }
    steps[597] = { line = 7431, sec = "Allow", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Don't Allow\",\r\n    \"timeout\": 3,\r\n    \"ex\": false,\r\n    \"offset\": -200,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[598] = { line = 7437, sec = "Click i agree", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"including ads\",\r\n    \"timeout\": 3,\r\n    \"ex\": false,\r\n    \"offset\": 100,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[599] = { line = 7443, sec = "Already have an account?", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Already have an account?\",\r\n    \"timeout\": 10,\r\n    \"ex\": false,\r\n    \"offset\": -200,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[600] = { line = 7457, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_IGREG = 0
    end }
  end)()
  ;(function()
    steps[601] = { line = 7467, sec = "check Agree to instagram's terms", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Agree to instagram's terms\",\r\n    \"timeout\": 3,\r\n    \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[602] = { line = 7473, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[603] = { line = 7479, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 619 end
    end }
    steps[604] = { line = 7484, sec = "", fn = function(B, V, PROG)
      if not B.truthy((B.truthy(B.eq(V.VAR_CHECK_IGREG, 1)) and (B.eq(V.VAR_CHECK_IGREG, 1)) or (B.eq(V.VAR_CHECK_IGREG, 8)))) then return 606 end
    end }
    steps[605] = { line = 7489, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("brown"), ["en"] = ("Check I agree"), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[606] = { line = 7497, sec = "Click i agree", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"including ads\",\r\n    \"timeout\": 3,\r\n    \"ex\": false,\r\n    \"offset\": 100,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[607] = { line = 7503, sec = "Already have an account?", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Already have an account?\",\r\n    \"timeout\": 3,\r\n    \"ex\": false,\r\n    \"offset\": -200,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[608] = { line = 7509, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_IGREG = B.add(B.parse_int(V.VAR_CHECK_IGREG), B.parse_int(1))
    end }
    steps[609] = { line = 7514, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_CHECK_IGREG, 10)) then return 611 end
    end }
    steps[610] = { line = 7519, sec = "", fn = function(B, V, PROG)
      B.fail_user("Tạo Lỗi")
    end }
    steps[611] = { line = 7527, sec = "check An unexpected error occurred.", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"An unexpected error\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[612] = { line = 7533, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS_LOI1 = B.http_status()
    end }
    steps[613] = { line = 7539, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Try Again Later\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[614] = { line = 7545, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[615] = { line = 7551, sec = "", fn = function(B, V, PROG)
      if not B.truthy((B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) and (B.eq(V.VAR_SAVED_STATUS, 200)) or (B.eq(V.VAR_SAVED_STATUS_LOI1, 200)))) then return 617 end
    end }
    steps[616] = { line = 7556, sec = "", fn = function(B, V, PROG)
      B.fail_user("Acc Lỗi")
    end }
    steps[617] = { line = 7564, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[618] = { line = 7570, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8329")
    end }
    steps[619] = { line = 7578, sec = "Click threads", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Skip\",\r\n    \"timeout\": 10,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[620] = { line = 7584, sec = "", fn = function(B, V, PROG)
      B.sleep(5000)
    end }
    steps[621] = { line = 7589, sec = "Review the setting for", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"access your device?\",\r\n    \"timeout\": 5,\r\n    \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[622] = { line = 7595, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS_ALLOW = B.http_status()
    end }
    steps[623] = { line = 7601, sec = "Review the setting for", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Review the settings for\",\r\n    \"timeout\": 5,\r\n    \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[624] = { line = 7607, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[625] = { line = 7613, sec = "", fn = function(B, V, PROG)
      if not B.truthy((B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) and (B.eq(V.VAR_SAVED_STATUS, 200)) or (B.eq(V.VAR_SAVED_STATUS_ALLOW, 200)))) then return 632 end
    end }
    steps[626] = { line = 7618, sec = "Ấn Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 2,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[627] = { line = 7624, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[628] = { line = 7629, sec = "Not now", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Not now\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[629] = { line = 7635, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[630] = { line = 7640, sec = "Ấn Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 2,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[631] = { line = 7646, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8032")
    end }
    steps[632] = { op = "try_begin", line = 7659, end_pc = 634 }
    steps[633] = { line = 7672, sec = "We could't creare an", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"We were not able to sign you up\",\r\n    \"timeout\": 5,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[634] = { op = "try_end", line = 7659 }
    steps[635] = { line = 7681, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 637 end
    end }
    steps[636] = { line = 7686, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 4949")
    end }
    steps[637] = { line = 7694, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS_CHECK1 = B.http_status()
    end }
    steps[638] = { line = 7700, sec = "check Create a profile that", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Create a profile that\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[639] = { line = 7706, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[640] = { line = 7712, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 642 end
    end }
    steps[641] = { line = 7717, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8032")
    end }
    steps[642] = { line = 7725, sec = "Try Again Later", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Try Again Later\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[643] = { line = 7731, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS_CHECK = B.http_status()
    end }
    steps[644] = { line = 7737, sec = "Confirm you're human to", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Confirm you're human to\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[645] = { line = 7743, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[646] = { line = 7749, sec = "", fn = function(B, V, PROG)
      if not B.truthy((B.truthy((B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) and (B.eq(V.VAR_SAVED_STATUS, 200)) or (B.eq(V.VAR_SAVED_STATUS_CHECK, 200)))) and ((B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) and (B.eq(V.VAR_SAVED_STATUS, 200)) or (B.eq(V.VAR_SAVED_STATUS_CHECK, 200)))) or (B.eq(V.VAR_SAVED_STATUS_CHECK1, 200)))) then return 648 end
    end }
    steps[647] = { line = 7754, sec = "", fn = function(B, V, PROG)
      B.fail_user("Die")
    end }
    steps[648] = { line = 7762, sec = "check An unexpected error occurred.", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"An unexpected error occurred.\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[649] = { line = 7768, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUSLOI22 = B.http_status()
    end }
    steps[650] = { line = 7774, sec = "Check Lỗi username", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Incorrect Username\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
  end)()
  ;(function()
    steps[651] = { line = 7780, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[652] = { line = 7786, sec = "", fn = function(B, V, PROG)
      if not B.truthy((B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) and (B.eq(V.VAR_SAVED_STATUS, 200)) or (B.eq(V.VAR_SAVED_STATUSLOI22, 200)))) then return 654 end
    end }
    steps[653] = { line = 7791, sec = "", fn = function(B, V, PROG)
      B.fail_user("Acc Erro")
    end }
    steps[654] = { line = 7799, sec = "Ấn Continue", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Skip\",\r\n    \"timeout\": 2,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[655] = { line = 7805, sec = "Ấn Continue", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Done\",\r\n    \"timeout\": 2,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[656] = { line = 7811, sec = "Ấn Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 2,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[657] = { line = 7817, sec = "Not now", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Not now\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[658] = { line = 7828, sec = "thoát", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"appKill('com.burbn.instagram');\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[659] = { line = 7834, sec = "thoát", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"\r\n\r\n\r\nkeyDown(KEY_TYPE.HOME_BUTTON);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\nusleep(100000);\r\nkeyDown(KEY_TYPE.HOME_BUTTON);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\n\r\nusleep(1000000); -- Chờ trình đa nhiệm hiện lên\r\ntouchDown(2, 657.62, 1719.02);\r\nusleep(32964.38);\r\ntouchMove(2, 652.98, 1684.71);\r\nusleep(16640.54);\r\ntouchMove(2, 652.98, 1630.93);\r\nusleep(17161.38);\r\ntouchMove(2, 657.62, 1543.76);\r\nusleep(16059.67);\r\ntouchMove(2, 675.30, 1436.19);\r\nusleep(17233.92);\r\ntouchMove(2, 704.14, 1300.78);\r\nusleep(16385.67);\r\ntouchMove(2, 743.21, 1156.11);\r\nusleep(16619.38);\r\ntouchMove(2, 784.13, 1023.49);\r\nusleep(16505.12);\r\ntouchUp(2, 830.64, 884.40);\r\nusleep(1534120.96);\r\n\r\ntouchDown(2, 335.79, 1452.88);\r\nusleep(50798.58);\r\ntouchMove(2, 339.51, 1394.45);\r\nusleep(16426.42);\r\ntouchMove(2, 339.51, 1348.06);\r\nusleep(16482.00);\r\ntouchMove(2, 336.71, 1284.09);\r\nusleep(16739.75);\r\ntouchMove(2, 336.71, 1210.83);\r\nusleep(16337.58);\r\ntouchMove(2, 336.71, 1118.09);\r\nusleep(16935.46);\r\ntouchMove(2, 351.60, 980.82);\r\nusleep(16911.62);\r\ntouchMove(2, 387.87, 793.51);\r\nusleep(15941.33);\r\ntouchUp(2, 430.66, 600.60);\r\n\r\n\r\n\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[660] = { line = 7840, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 691")
    end }
    steps[661] = { line = 7845, sec = "", fn = function(B, V, PROG)
      V.VAR_2FA = ""
    end }
    steps[662] = { line = 7850, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 1098")
    end }
    steps[663] = { line = 7855, sec = "", fn = function(B, V, PROG)
      V.VAR_NEW_RECORD_ID = B.db_add_record({2, V.VAR_USERNAME, 3, V.VAR_PASSWORD, 4, "", 5, "", 6, "", 7, "", 8, ""})
    end }
    steps[664] = { line = 7868, sec = "", fn = function(B, V, PROG)
      B.sleep(3000)
    end }
    steps[665] = { line = 7873, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9334")
    end }
    steps[666] = { line = 7878, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_923741 = B.rs("Add Profile", false, false)
    end }
    steps[667] = { line = 7878, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.RESOURCE_923741) then return 692 end
    end }
    steps[668] = { line = 7885, sec = "Xóa toàn bộ ảnh", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"clearSystemAlbum();\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[669] = { line = 7891, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_637586 = B.rs("Path IMG", true, false)
      V.VAR_PATH_ANH = V.RESOURCE_637586
    end }
    steps[670] = { line = 7898, sec = "Send IMG", fn = function(B, V, PROG)
      B.emb_upload_photo(V.VAR_PATH_ANH)
    end }
    steps[671] = { line = 7904, sec = "Vào IG", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{\r\n    \"action\": \"URL\",\r\n    \"data\": \"https://www.instagram.com/", V.VAR_USERNAME), "\"\r\n}"), "", B.add("custom/", ("application/json")))
    end }
    steps[672] = { line = 7910, sec = "Not now", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Not now\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[673] = { line = 7916, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[674] = { line = 7921, sec = "Vào IG", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"URL\",\r\n    \"data\": \"https://www.instagram.com/accounts/edit/\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[675] = { line = 7927, sec = "Vào IG", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"URL\",\r\n    \"data\": \"https://www.instagram.com/accounts/edit/\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[676] = { line = 7933, sec = "Not now", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Not now\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[677] = { line = 7939, sec = "BIO", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Bio\",\r\n    \"timeout\": 15,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[678] = { line = 7945, sec = "", fn = function(B, V, PROG)
      V.VAR_TEMPLATE_BIO = [[18 🎀 Norman, OK
      OU student 📚
      add me on snap 👻 emeliexorylx
      
      18 ✨ OKC, Oklahoma
      freshman · coffee & country music ☕🎶
      snap me 👻 emeliewarylx
      
      19 🌸 Tulsa, OK
      psych major 📖 sweet but savage 🌶️
      let's talk on snap 👻 emelievalinx
      
      19 💕 Stillwater, Oklahoma
      OSU 🧡 lake days 🌊
      sc: emeliexorylx 👻
      
      20 🦋 OKC 🤠
      student · gym & tacos 🌮
      hmu on snap 👻 emeliewarylx
      
      20 💋 Norman, OK
      come say hi, I don't bite 😈
      snapchat 👻 emelievalinx
      
      21 🖤 OKC, Oklahoma
      OU senior 📚 road trips 🚗
      add my snap 👻 emeliexorylx
      
      21 💅 Tulsa, OK
      bet you can't handle me 😉
      snap me 👻 emeliewarylx
      
      22 💕 OKC 🤠
      nurse 🩺 coffee addict ☕
      find me on snap 👻 emelievalinx
      
      22 ✨ Norman, Oklahoma
      barista · hiking & sunsets 🌅
      snap 👻 emeliexorylx
      
      23 🖤 Edmond, OK
      dental assistant 🦷 trouble in the best way 😘
      add me on snap 👻 emeliewarylx
      
      23 🌸 OKC 🤠
      teacher 📚 weekend lake trips 🌊
      snap me 👻 emelievalinx
      
      24 💅 Tulsa, Oklahoma
      realtor 🏡 spoil me 💋
      sc: emeliexorylx 👻
      
      24 🌶️ Norman, OK
      esthetician ✨ a lil shy, a lot flirty 😉
      let's talk on snap 👻 emeliewarylx
      
      25 💕 Broken Arrow, OK
      hairstylist 💇‍♀️ easy to fall for 🖤
      add my snap 👻 emelievalinx
      
      25 😉 Moore, Oklahoma
      nurse 🩺 sweet tea & sunsets 🌅
      snapchat 👻 emeliexorylx
      
      19 🎶 Lawton, OK
      student 📚 your favorite trouble 😈
      snap me 👻 emeliewarylx
      
      20 🌅 OKC 🤠
      yoga · coffee · dog mom 🐶
      hmu on snap 👻 emelievalinx
      
      21 💋 Norman, Oklahoma
      OU senior 🎓 spoil me a little 💅
      add me on snap 👻 emeliexorylx
      
      22 🌸 Stillwater, OK
      barista · country concerts 👢
      sc: emeliewarylx 👻
      
      18 ✨ Edmond, OK
      student 📚 sweet but savage 🌶️
      snap me 👻 emelievalinx
      
      23 🖤 OKC, Oklahoma
      esthetician ✨ beach trips & tacos 🌮
      find me on snap 👻 emeliexorylx
      
      24 😏 Tulsa, OK
      server 🍷 bet you've never met a girl like me
      add my snap 👻 emeliewarylx
      
      20 💕 Norman 🤠 Oklahoma
      OSU student 🧡 painting & late drives 🎨
      snapchat 👻 emelievalinx
      
      25 🌶️ Norman, OK
      dental hygienist 🦷 come find out 😉
      snap me 👻 emeliexorylx
      
      19 🦋 OKC 🤠
      student · gym & coffee ☕
      let's talk on snap 👻 emeliewarylx
      
      21 💅 Tulsa, Oklahoma
      student 📚 low key your dream girl 💋
      add me on snap 👻 emelievalinx
      
      22 🌸 Edmond, OK
      nanny 🧸 hiking & horseback riding 🐎
      sc: emeliexorylx 👻
      
      23 💋 Moore, OK
      nurse 🩺 flirty with a soft spot 🖤
      snap me 👻 emeliewarylx
      
      18 🎀 Norman 🤠 Oklahoma
      OU freshman 📚 catch me if you can 😜
      hmu on snap 👻 emelievalinx
      
      20 😈 OKC, OK
      student 🎓 sweet talk gets you everywhere 💋
      add my snap 👻 emeliexorylx
      
      25 💕 Tulsa, Oklahoma
      realtor 🏡 road trips & country music 🎶
      snapchat 👻 emeliewarylx
      
      21 🌅 Stillwater, OK
      OSU 🧡 gym + tacos + chaos 🌮
      snap me 👻 emelievalinx
      
      22 🖤 OKC 🤠
      barista ☕ your new favorite distraction 😏
      find me on snap 👻 emeliexorylx
      
      19 🌸 Broken Arrow, OK
      student 📚 dancing & sunsets 🌅
      add me on snap 👻 emeliewarylx
      
      23 💅 Edmond, Oklahoma
      teacher 📚 spoil me & see what happens 💋
      sc: emelievalinx 👻
      
      24 🌶️ Tulsa, OK
      vet tech 🐾 a lil shy, a lot flirty 😉
      snap me 👻 emeliexorylx
      
      20 ✨ Norman, OK
      OU sophomore 🎓 coffee & country drives ☕
      let's talk on snap 👻 emeliewarylx
      
      18 💕 OKC, Oklahoma
      student 📚 Oklahoma girl through & through 🤠
      add my snap 👻 emelievalinx
      
      25 🖤 OKC, OK
      nurse 🩺 easy to love, hard to forget 💋
      snapchat 👻 emeliexorylx
      
      21 🌸 Moore, OK
      student 🎓 thrift hauls & taco runs 🌮
      snap me 👻 emeliewarylx
      
      24 💅 Tulsa, Oklahoma
      esthetician 🤎 come spoil your new fav girl
      hmu on snap 👻 emelievalinx
      
      22 💕 OKC 🤠
      hairstylist 💇‍♀️ sunsets & slow dances 🌅
      add me on snap 👻 emeliexorylx
      
      19 🦋 Norman, OK
      freshman year & flirty energy 💋
      sc: emeliewarylx 👻
      
      23 😏 Tulsa, OK
      server 🍷 bet I'm cuter than your ex 😜
      snap me 👻 emelievalinx
      ]]
    end }
    steps[679] = { line = 7953, sec = "", fn = function(B, V, PROG)
      V.VAR_BIO = B.emb_random_bio(V.VAR_TEMPLATE_BIO)
    end }
    steps[680] = { line = 7959, sec = "Pate Text", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{ \"action\": \"TEXT\", \"data\": \"", V.VAR_BIO), "\" }"), "", B.add("custom/", ("application/json")))
    end }
    steps[681] = { line = 7965, sec = "", fn = function(B, V, PROG)
      B.sleep(1000)
    end }
    steps[682] = { line = 7970, sec = "Not now", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Done\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[683] = { line = 7976, sec = "", fn = function(B, V, PROG)
      B.sleep(1000)
    end }
    steps[684] = { line = 7981, sec = "Edit profile", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Edit profile\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 200,\r\n    \"offsetX\": -50,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[685] = { line = 7987, sec = "", fn = function(B, V, PROG)
      B.sleep(1000)
    end }
    steps[686] = { line = 7992, sec = "Choose from library", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Choose from library\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[687] = { line = 7998, sec = "", fn = function(B, V, PROG)
      B.sleep(3000)
    end }
    steps[688] = { line = 8003, sec = "Check Library", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Library\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[689] = { line = 8009, sec = "Vuốt xuống", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"\r\ntouchDown(2, 669.24, 494.11);\r\nusleep(28886.71);\r\ntouchMove(2, 665.39, 503.73);\r\nusleep(8632.04);\r\ntouchMove(2, 664.43, 526.82);\r\nusleep(8050.88);\r\ntouchMove(2, 658.68, 553.76);\r\nusleep(8750.00);\r\ntouchMove(2, 654.84, 587.44);\r\nusleep(8065.50);\r\ntouchMove(2, 646.20, 626.88);\r\nusleep(8936.29);\r\ntouchMove(2, 642.36, 677.84);\r\nusleep(7362.96);\r\ntouchMove(2, 640.43, 734.60);\r\nusleep(8992.62);\r\ntouchMove(2, 639.47, 789.46);\r\nusleep(7613.46);\r\ntouchMove(2, 639.47, 857.74);\r\nusleep(9093.75);\r\ntouchMove(2, 639.47, 913.54);\r\nusleep(7695.17);\r\ntouchMove(2, 639.47, 975.09);\r\nusleep(9014.83);\r\ntouchMove(2, 642.36, 1025.12);\r\nusleep(7675.88);\r\ntouchMove(2, 648.11, 1073.22);\r\nusleep(8909.79);\r\ntouchMove(2, 650.03, 1110.76);\r\nusleep(7627.92);\r\ntouchMove(2, 651.95, 1145.37);\r\nusleep(9058.33);\r\ntouchMove(2, 652.91, 1172.32);\r\nusleep(7718.92);\r\ntouchMove(2, 652.91, 1197.33);\r\nusleep(8960.62);\r\ntouchMove(2, 652.91, 1227.14);\r\nusleep(7636.38);\r\ntouchMove(2, 654.84, 1255.99);\r\nusleep(9082.38);\r\ntouchMove(2, 657.72, 1290.63);\r\nusleep(7676.88);\r\ntouchMove(2, 661.55, 1323.34);\r\nusleep(9473.58);\r\ntouchUp(2, 667.32, 1329.10);\r\n\r\n\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[690] = { line = 8015, sec = "Not now", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Done\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[691] = { line = 8021, sec = "Edit profile", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Edit profile\",\r\n    \"timeout\": 15,\r\n     \"ex\": true,\r\n    \"offset\": 200,\r\n    \"offsetX\": -50,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[692] = { line = 8030, sec = "Vào IG", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"URL\",\r\n    \"data\": \"instagram://settings\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[693] = { line = 8036, sec = "Not now", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Not now\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[694] = { line = 8042, sec = "Accounts Center", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Accounts Center\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[695] = { line = 8048, sec = "Accounts Center", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Accounts Center\",\r\n    \"timeout\": 15,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[696] = { line = 8054, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[697] = { line = 8060, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 700 end
    end }
    steps[698] = { line = 8065, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("purple"), ["en"] = ("Không vào được 2FA"), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[699] = { line = 8070, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9334")
    end }
    steps[700] = { line = 8078, sec = "Password and security", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Password and security\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
  end)()
  ;(function()
    steps[701] = { line = 8089, sec = "Password and security", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Password and security\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[702] = { line = 8095, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[703] = { line = 8101, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 707 end
    end }
    steps[704] = { line = 8106, sec = "Password and security", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Not now\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[705] = { line = 8112, sec = "Accounts Center", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Accounts Center\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[706] = { line = 8118, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 2802")
    end }
    steps[707] = { line = 8126, sec = "Two-factor authentication", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Two-factor authentication\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[708] = { line = 8132, sec = "Instagram", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Instagram\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[709] = { line = 8138, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[710] = { line = 8144, sec = "Copy key", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Copy key\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[711] = { line = 8155, sec = "Copy key", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Copy key\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[712] = { line = 8161, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[713] = { line = 8166, sec = "", fn = function(B, V, PROG)
      V.VAR_CLIPBOARD_TEXT = B.emb_read_pasteboard()
    end }
    steps[714] = { line = 8172, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_CLIPBOARD_TEXT, "")) then return 717 end
    end }
    steps[715] = { line = 8177, sec = "", fn = function(B, V, PROG)
      B.log("Code 2FA Rỗng")
    end }
    steps[716] = { line = 8182, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 6432")
    end }
    steps[717] = { line = 8190, sec = "", fn = function(B, V, PROG)
      local s = V.VAR_CLIPBOARD_TEXT
      local result = (B.str(s):gsub("%s+", ""))
      V.VAR_2FA = result
    end }
    steps[718] = { line = 8197, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add("https://2fa.live/tok/", V.VAR_2FA), "GET", nil, "", nil)
    end }
    steps[719] = { line = 8203, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[720] = { line = 8209, sec = "", fn = function(B, V, PROG)
      V.VAR_TOKEN = B.jpath_value(V.VAR_SAVED_CONTENT, "token")
    end }
    steps[721] = { line = 8218, sec = "Enter code", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Enter code\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[722] = { line = 8224, sec = "", fn = function(B, V, PROG)
      B.log(V.VAR_2FA)
    end }
    steps[723] = { line = 8229, sec = "Click Enter Code", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n  \"action\": \"COLOR\",\r\n  \"script\": \"const [result, error] = findColors({\r\n    colors: [\r\n        { color: 15527149, x: 0, y: 0 },\r\n        { color: 6711922, x: 45, y: 2 },\r\n        { color: 6711922, x: 19, y: 0 },\r\n        { color: 8290696, x: 45, y: -9 }\r\n    ],\r\n    // count: 30,\r\n    // region: null,\r\n    // debug: false,\r\n    // rightToLeft: false,\r\n    // bottomToTop: false\r\n})\r\n\r\n\",\r\n  \"mode\": \"click\",\r\n  \"timeout\": 10,\r\n  \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[724] = { line = 8235, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[725] = { line = 8240, sec = "Pate Text", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{ \"action\": \"TEXT\", \"data\": \"", V.VAR_TOKEN), "\" }"), "", B.add("custom/", ("application/json")))
    end }
    steps[726] = { line = 8246, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[727] = { line = 8252, sec = "Click Done", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Done\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[728] = { line = 8258, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[729] = { line = 8263, sec = "", fn = function(B, V, PROG)
      B.db_update_record(V.VAR_NEW_RECORD_ID, {4, V.VAR_2FA})
    end }
    steps[730] = { line = 8287, sec = "Vào IG", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"URL\",\r\n    \"data\": \"instagram://\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[731] = { line = 8293, sec = "", fn = function(B, V, PROG)
      B.sleep(3000)
    end }
    steps[732] = { line = 8298, sec = "HOME", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\"action\":\"RUNLUA\",\"data\":\"return execute('/var/jb/usr/local/bin/ghost-sso-bridge')\"}", "", B.add("custom/", ("application/json")))
    end }
    steps[733] = { line = 8304, sec = "Click Username", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{\r\n    \"text\": \"", V.VAR_USERNAME), "\",\r\n    \"timeout\": 10,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}"), "", B.add("custom/", ("application/json")))
    end }
    steps[734] = { line = 8310, sec = "Not now", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Not now\",\r\n    \"timeout\": 20,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[735] = { line = 8316, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[736] = { line = 8322, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 741 end
    end }
    steps[737] = { line = 8327, sec = "set up your experience", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Privacy\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[738] = { line = 8333, sec = "ấn Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[739] = { line = 8339, sec = "Join Threads", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Join Threads\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[740] = { line = 8345, sec = "", fn = function(B, V, PROG)
      B.log("Quay lại ấn Not now")
    end }
    steps[741] = { line = 8353, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[742] = { line = 8358, sec = "Click Done", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Follow all\",\r\n    \"timeout\": 5,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[743] = { line = 8364, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[744] = { line = 8369, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_914458 = B.rs("Kiểu Lưu", false, false)
    end }
    steps[745] = { line = 8369, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_914458, "Đẩy File Backup")) then return 770 end
    end }
    steps[746] = { line = 8376, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":9102/backup-now"), ("POST"), "{\r\n  \"selector\": \"both\",\r\n  \"format\": \"ghostpair\",\r\n  \"target_container\": \"taoacc\",\r\n  \"target_ig\": \"taoacc\",\r\n  \"target_th\": \"taoacc\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[747] = { line = 8382, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[748] = { line = 8388, sec = "", fn = function(B, V, PROG)
      V.VAR_JOB_ID = B.jpath_value(V.VAR_SAVED_CONTENT, ".job_id")
    end }
    steps[749] = { line = 8402, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(B.add(V.VAR_IP_IPHONE, ":9102/status?job_id="), V.VAR_JOB_ID), "GET", nil, "", nil)
    end }
    steps[750] = { line = 8408, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
  end)()
  ;(function()
    steps[751] = { line = 8414, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_SUCCESS = B.jpath_value(V.VAR_SAVED_CONTENT, ".running")
    end }
    steps[752] = { line = 8423, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_CHECK_SUCCESS) then return 755 end
    end }
    steps[753] = { line = 8428, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[754] = { line = 8433, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 4123")
    end }
    steps[755] = { line = 8441, sec = "", fn = function(B, V, PROG)
      V.VAR_USERNAME_GET = B.jpath_value(V.VAR_SAVED_CONTENT, ".username")
    end }
    steps[756] = { line = 8450, sec = "", fn = function(B, V, PROG)
      V.VAR_OUTPUT_PATH = B.jpath_value(V.VAR_SAVED_CONTENT, ".output_path")
    end }
    steps[757] = { line = 8459, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("cyan"), ["en"] = (B.add(B.add(B.add("Username: ", V.VAR_USERNAME_GET), " ||OUTPUT_PATH: "), V.VAR_OUTPUT_PATH)), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[758] = { line = 8464, sec = "Bắt đầu upload", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":8080/api/backup_upload"), ("POST"), B.add(B.add(B.add(B.add(B.add(B.add("{\r\n  \"url\": \"https://panel.65.109.22.234.sslip.io/api/v1/upload/account\",\r\n  \"api_key\": \"tpi_i87y87ufzaxDEn0aQpBuK52k0jkpN-I2\",\r\n  \"file_path\": \"", V.VAR_OUTPUT_PATH), "\",\r\n  \"username\": \""), V.VAR_USERNAME_GET), "\",\r\n  \"password\": \""), V.VAR_PASSWORD), "\",\r\n  \"2fa\": \"\",\r\n  \"delete_after\": true,\r\n  \"async\": true\r\n}"), "", B.add("custom/", ("application/json")))
    end }
    steps[759] = { line = 8470, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[760] = { line = 8476, sec = "", fn = function(B, V, PROG)
      V.VAR_JOB_ID = B.jpath_value(V.VAR_SAVED_CONTENT, ".job_id")
    end }
    steps[761] = { line = 8490, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(B.add(V.VAR_IP_IPHONE, ":8080/api/backup_upload/status?job_id="), V.VAR_JOB_ID), "GET", nil, "", nil)
    end }
    steps[762] = { line = 8496, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[763] = { line = 8502, sec = "", fn = function(B, V, PROG)
      V.VAR_STAGE = B.jpath_value(V.VAR_SAVED_CONTENT, ".stage")
    end }
    steps[764] = { line = 8511, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_STAGE, "uploading")) then return 767 end
    end }
    steps[765] = { line = 8516, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[766] = { line = 8521, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 3885")
    end }
    steps[767] = { line = 8529, sec = "", fn = function(B, V, PROG)
      V.VAR_UPLOAD_RESPONSE = B.jpath_value(V.VAR_SAVED_CONTENT, ".upload_response")
    end }
    steps[768] = { line = 8538, sec = "", fn = function(B, V, PROG)
      V.VAR_UPLOAD_RESPONSE = B.jpath_change_format(V.VAR_UPLOAD_RESPONSE, "string")
    end }
    steps[769] = { line = 8547, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("orange"), ["en"] = (B.add("Upload_response: ", V.VAR_UPLOAD_RESPONSE)), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[770] = { line = 8555, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_845883 = B.rs("Kiểu Lưu", false, false)
    end }
    steps[771] = { line = 8555, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_845883, "Đẩy Cookie")) then return 782 end
    end }
    steps[772] = { line = 8562, sec = "xuất cookie", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add(B.add(B.add("{\"action\":\"RUNLUA\",\"data\":\"return execute('/var/jb/usr/local/bin/ghost-cookie-export --payload --username ", V.VAR_USERNAME), " --proxy "), V.VAR_PROXY), "')\"}"), "", B.add("custom/", ("application/json")))
    end }
    steps[773] = { line = 8568, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[774] = { line = 8574, sec = "", fn = function(B, V, PROG)
      V.VAR_DATA = B.jpath_value(V.VAR_SAVED_CONTENT, ".data.accounts[0]")
    end }
    steps[775] = { line = 8583, sec = "", fn = function(B, V, PROG)
      V.VAR_DATA_SEND = B.jpath_change_format(V.VAR_DATA, "string")
    end }
    steps[776] = { line = 8592, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request("https://panel.65.109.22.234.sslip.io/api/v1/import/accounts", ("POST"), V.VAR_DATA_SEND, "Authorization: Bearer tpi_i87y87ufzaxDEn0aQpBuK52k0jkpN-I2", B.add("custom/", ("application/json")))
    end }
    steps[777] = { line = 8598, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[778] = { line = 8604, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("cyan"), ["en"] = (V.VAR_SAVED_CONTENT), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[779] = { line = 8609, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[780] = { line = 8615, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.sneq(V.VAR_SAVED_STATUS, 202)) then return 782 end
    end }
    steps[781] = { line = 8620, sec = "", fn = function(B, V, PROG)
      B.fail_user("Lỗi gửi Acc")
    end }
    steps[782] = { line = 8631, sec = "HOME", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"\r\n\r\nkeyDown(KEY_TYPE.HOME_BUTTON);\r\nusleep(138611.00);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\nusleep(217773.00);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\nusleep(772038.29);\r\n\r\nkeyDown(KEY_TYPE.HOME_BUTTON);\r\nusleep(217682.00);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\nusleep(138650.21);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\n\r\n\r\n\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[783] = { line = 8637, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("blue"), ["en"] = (B.add(B.add(B.add("[INFO] Tổng: ", B.json_parse((B.truthy(B.pget("basglobal", "DEM_ACC")) and (B.pget("basglobal", "DEM_ACC")) or ("\"\"")))), " || Username: "), V.VAR_USERNAME)), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[784] = { line = 8642, sec = "", fn = function(B, V, PROG)
      B.pset("basglobal", "DEM_ACC", B.add(B.parse_int(B.json_parse((B.truthy(B.pget("basglobal", "DEM_ACC")) and (B.pget("basglobal", "DEM_ACC")) or ("0")))), B.parse_int(1)))
    end }
    steps[785] = { line = 8647, sec = "", fn = function(B, V, PROG)
      do local ts = os.date("[%H:%M:%S]"); local mess = "<b>" .. ts .. " Thread #" .. tostring(B.thread_number()) .. " : </b>" .. B.str(B.add(B.add(B.add(B.add(B.add("Thành công: ", B.json_parse((B.truthy(B.pget("basglobal", "DEM_ACC")) and (B.pget("basglobal", "DEM_ACC")) or ("\"\"")))), " || IPHONE: "), V.VAR_IP_GOC), "  || https://www.threads.com/@"), V.VAR_USERNAME)); local url = "https://api.telegram.org/bot6385162686:AAGx4qwiX1aV_WRGGynjfW8AQBOwsls2qGg/sendMessage?chat_id=1344289139&text=" .. B.encode_uri(mess) .. "&parse_mode=HTML"; B.switch_http_internal(); B.http_request(url, "GET", nil, nil, nil); B.switch_http_main() end
    end }
    steps[786] = { line = 8672, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_541705 = B.rs("Tạo Tối Đa", false, false)
    end }
    steps[787] = { line = 8672, sec = "", fn = function(B, V, PROG)
      if not B.truthy((B.num(B.json_parse((B.truthy(B.pget("basglobal", "DEM_ACC")) and (B.pget("basglobal", "DEM_ACC")) or ("\"\"")))) >= B.num(V.RESOURCE_541705))) then return 789 end
    end }
    steps[788] = { line = 8679, sec = "", fn = function(B, V, PROG)
      B.die("Xong")
    end }
    steps[789] = { line = 8687, sec = "", fn = function(B, V, PROG)
      B.success(B.add("Tạo acc thành công: ", V.VAR_USERNAME))
    end }
  end)()
  PROG.functions["taotaikhoan"] = { name = "taotaikhoan", steps = steps, labels = labels }
end

-- -------- Function: API_GMAIL (15 steps, 1 labels) --------
do
  local steps = {}
  local labels = { ["label name 3575"] = 9 };
  ;(function()
    steps[1] = { line = 3148, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request("https://smsbower.page/api/mail/getActivation?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&service=ot&domain=gmail.com", "GET", nil, "", nil)
    end }
    steps[2] = { line = 3154, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[3] = { line = 3160, sec = "", fn = function(B, V, PROG)
      V.VAR_STATUS_GET_MAIL = B.jpath_value(V.VAR_SAVED_CONTENT, "status")
    end }
    steps[4] = { line = 3169, sec = "", fn = function(B, V, PROG)
      V.VAR_EMAIL = B.jpath_value(V.VAR_SAVED_CONTENT, "mail")
    end }
    steps[5] = { line = 3178, sec = "", fn = function(B, V, PROG)
      V.VAR_MAILID = B.jpath_value(V.VAR_SAVED_CONTENT, "mailId")
    end }
    steps[6] = { line = 3187, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add("https://smsbower.page/api/mail/getCode?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&mailId=", V.VAR_MAILID), "GET", nil, "", nil)
    end }
    steps[7] = { line = 3193, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[8] = { line = 3199, sec = "", fn = function(B, V, PROG)
      V.VAR_STATUS_CHECK_MAIL = B.jpath_value(V.VAR_SAVED_CONTENT, "status")
    end }
    steps[9] = { line = 3213, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request("https://api.shopgmail9999.com/api/ApiV2/CreateOrder?apikey=3ada3340e0d481e83e9c0167bdee4533&service=instagram&getpass=false", "GET", nil, "", nil)
    end }
    steps[10] = { line = 3219, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[11] = { line = 3225, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.sneq(V.VAR_SAVED_STATUS, 200)) then return 13 end
    end }
    steps[12] = { line = 3230, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 3575")
    end }
    steps[13] = { line = 3238, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[14] = { line = 3244, sec = "", fn = function(B, V, PROG)
      V.VAR_ORDERID = B.jpath_value(V.VAR_SAVED_CONTENT, ".orderid")
    end }
    steps[15] = { line = 3253, sec = "", fn = function(B, V, PROG)
      V.VAR_EMAIL = B.jpath_value(V.VAR_SAVED_CONTENT, ".email")
    end }
  end)()
  PROG.functions["API_GMAIL"] = { name = "API_GMAIL", steps = steps, labels = labels }
end

-- -------- Function: reg_2 (84 steps, 13 labels) --------
do
  local steps = {}
  local labels = { ["label name 7922"] = 2, ["label name 9709"] = 2, ["label name 6991"] = 7, ["label name 5274"] = 14, ["label name 3625"] = 24, ["label name 6828"] = 31, ["label name 5884"] = 37, ["label name 471"] = 43, ["label name 7838"] = 54, ["label name 1965"] = 59, ["label name 7594"] = 70, ["label name 3322"] = 75, ["label name 9629"] = 80 };
  ;(function()
    steps[1] = { line = 651, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_NEXT_PASS = 0
    end }
    steps[2] = { op = "try_begin", line = 666, end_pc = 4 }
    steps[3] = { line = 679, sec = "check what's your birthaday", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"what's your birthday?\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 400,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[4] = { op = "try_end", line = 666 }
    steps[5] = { line = 688, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 7 end
    end }
    steps[6] = { line = 693, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9709")
    end }
    steps[7] = { op = "try_begin", line = 706, end_pc = 9 }
    steps[8] = { line = 719, sec = "Chọn ngày tháng năm sinh", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"local dw, dh = 1125, 2436\\r\\nif type(getScreenSize) == \\\"function\\\" then\\r\\n  local ok, sw, sh = pcall(getScreenSize)\\r\\n  if ok and tonumber(sw) and tonumber(sh) and sw > 0 and sh > 0 then dw, dh = sw, sh end\\r\\nend\\r\\nlocal sx, sy = 1125 / dw, 2436 / dh\\r\\n\\r\\nlocal function flick(fid, rx, ry0, ry1, steps, step_us, pause_us)\\r\\n  touchDown(fid, rx, ry0)\\r\\n  usleep(20000)\\r\\n  for i = 1, steps do\\r\\n    touchMove(fid, rx, ry0 + (ry1 - ry0) * (i / steps))\\r\\n    usleep(step_us)\\r\\n  end\\r\\n  touchUp(fid, rx, ry1)\\r\\n  usleep(pause_us)\\r\\nend\\r\\n\\r\\nlocal yearX, pickY = 827, 1988\\r\\nlocal okOcr, items = pcall(ocr, {level = \\\"fast\\\"})\\r\\nif okOcr and type(items) == \\\"table\\\" then\\r\\n  local ys = {}\\r\\n  for _, it in ipairs(items) do\\r\\n    local txt = tostring(it.text or \\\"\\\")\\r\\n    local r = it.rectangle\\r\\n    if r and r.topLeft and r.topRight and r.bottomLeft and r.topLeft.y > dh * 0.55 then\\r\\n      local yr = txt:match(\\\"^(20[0-3]%d)$\\\") or txt:match(\\\"^(19%d%d)$\\\")\\r\\n      if yr then\\r\\n        local cx = ((r.topLeft.x + r.topRight.x) / 2) * sx\\r\\n        local cy = ((r.topLeft.y + r.bottomLeft.y) / 2) * sy\\r\\n        ys[#ys + 1] = {yr = tonumber(yr), x = cx, y = cy}\\r\\n      end\\r\\n    end\\r\\n  end\\r\\n  if #ys > 0 then\\r\\n    table.sort(ys, function(a, b) return a.y < b.y end)\\r\\n    local mid = ys[math.ceil(#ys / 2)]\\r\\n    yearX = mid.x\\r\\n    if mid.y > 1750 and mid.y < 2250 then pickY = mid.y end\\r\\n  end\\r\\nend\\r\\n\\r\\nlocal topY = math.max(1750, pickY - 220)\\r\\nlocal botY = math.min(2260, pickY + 230)\\r\\nflick(1, yearX, topY, botY, 10, 12000, 180000)\\r\\nflick(2, yearX, topY, botY, 10, 13000, 220000)\\r\\nflick(3, 614, botY, topY, 9, 13000, 180000)\\r\\nflick(4, 356, botY, topY, 10, 13000, 200000)\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[9] = { op = "try_end", line = 706 }
    steps[10] = { line = 728, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 12 end
    end }
    steps[11] = { line = 733, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 6991")
    end }
    steps[12] = { line = 741, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[13] = { line = 746, sec = "check ", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"2007\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[14] = { op = "try_begin", line = 757, end_pc = 16 }
    steps[15] = { line = 770, sec = "check ", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"March 22, 2026\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 400,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[16] = { op = "try_end", line = 757 }
    steps[17] = { line = 779, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 19 end
    end }
    steps[18] = { line = 784, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5274")
    end }
    steps[19] = { line = 792, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[20] = { line = 798, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 23 end
    end }
    steps[21] = { line = 803, sec = "", fn = function(B, V, PROG)
      B.log("Chọn lại ngày tháng")
    end }
    steps[22] = { line = 808, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7922")
    end }
    steps[23] = { line = 816, sec = "", fn = function(B, V, PROG)
      B.sleep(1000)
    end }
    steps[24] = { op = "try_begin", line = 826, end_pc = 26 }
    steps[25] = { line = 839, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[26] = { op = "try_end", line = 826 }
    steps[27] = { line = 848, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 29 end
    end }
    steps[28] = { line = 853, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 3625")
    end }
    steps[29] = { line = 861, sec = "", fn = function(B, V, PROG)
      B.sleep(4000)
    end }
    steps[30] = { line = 866, sec = "", fn = function(B, V, PROG)
      V.VAR_PASSWORD = B.random_string(12, "abcdefghijklmnopqrstuvwxyz0123456789")
    end }
    steps[31] = { op = "try_begin", line = 876, end_pc = 33 }
    steps[32] = { line = 889, sec = "Pate Text", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{ \"action\": \"TEXT\", \"data\": \"", V.VAR_PASSWORD), "\" }"), "", B.add("custom/", ("application/json")))
    end }
    steps[33] = { op = "try_end", line = 876 }
    steps[34] = { line = 898, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 36 end
    end }
    steps[35] = { line = 903, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 6828")
    end }
    steps[36] = { line = 911, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("cyan"), ["en"] = (B.add("Pass: ", V.VAR_PASSWORD)), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[37] = { op = "try_begin", line = 921, end_pc = 39 }
    steps[38] = { line = 934, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[39] = { op = "try_end", line = 921 }
    steps[40] = { line = 943, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 42 end
    end }
    steps[41] = { line = 948, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5884")
    end }
    steps[42] = { line = 956, sec = "", fn = function(B, V, PROG)
      B.sleep(4000)
    end }
    steps[43] = { op = "try_begin", line = 966, end_pc = 45 }
    steps[44] = { line = 979, sec = "Đợi pass", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Password\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[45] = { op = "try_end", line = 966 }
    steps[46] = { line = 988, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 48 end
    end }
    steps[47] = { line = 993, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 471")
    end }
    steps[48] = { line = 1001, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[49] = { line = 1007, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 85 end
    end }
    steps[50] = { line = 1012, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_NEXT_PASS = B.add(B.parse_int(V.VAR_CHECK_NEXT_PASS), B.parse_int(1))
    end }
  end)()
  ;(function()
    steps[51] = { line = 1017, sec = "", fn = function(B, V, PROG)
      if not B.truthy((B.num(V.VAR_CHECK_NEXT_PASS) >= B.num(5))) then return 53 end
    end }
    steps[52] = { line = 1022, sec = "", fn = function(B, V, PROG)
      B.fail_user("Lỗi Tạo")
    end }
    steps[53] = { line = 1030, sec = "", fn = function(B, V, PROG)
      B.log("Click lại NEXT pass")
    end }
    steps[54] = { op = "try_begin", line = 1040, end_pc = 56 }
    steps[55] = { line = 1053, sec = "Click Refresh", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Refresh\",\r\n    \"timeout\": 10,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[56] = { op = "try_end", line = 1040 }
    steps[57] = { line = 1062, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 59 end
    end }
    steps[58] = { line = 1067, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7838")
    end }
    steps[59] = { op = "try_begin", line = 1080, end_pc = 61 }
    steps[60] = { line = 1093, sec = "Confirm you're human to", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Confirm you're human to\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[61] = { op = "try_end", line = 1080 }
    steps[62] = { line = 1102, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 64 end
    end }
    steps[63] = { line = 1107, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 1965")
    end }
    steps[64] = { line = 1115, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[65] = { line = 1121, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 67 end
    end }
    steps[66] = { line = 1126, sec = "", fn = function(B, V, PROG)
      B.fail_user("Die")
    end }
    steps[67] = { line = 1134, sec = "Password required", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Password cannot be empty.\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[68] = { line = 1140, sec = "", fn = function(B, V, PROG)
      V.VAR_PASS_EMPTY = B.http_status()
    end }
    steps[69] = { line = 1146, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_PASS_EMPTY) then return 80 end
    end }
    steps[70] = { op = "try_begin", line = 1156, end_pc = 72 }
    steps[71] = { line = 1169, sec = "Password required", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Password cannot be empty.\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": -150,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[72] = { op = "try_end", line = 1156 }
    steps[73] = { line = 1178, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 75 end
    end }
    steps[74] = { line = 1183, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7594")
    end }
    steps[75] = { op = "try_begin", line = 1196, end_pc = 77 }
    steps[76] = { line = 1209, sec = "Pate Text", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{ \"action\": \"TEXT\", \"data\": \"", V.VAR_PASSWORD), "\" }"), "", B.add("custom/", ("application/json")))
    end }
    steps[77] = { op = "try_end", line = 1196 }
    steps[78] = { line = 1218, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 80 end
    end }
    steps[79] = { line = 1223, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 3322")
    end }
    steps[80] = { op = "try_begin", line = 1239, end_pc = 82 }
    steps[81] = { line = 1252, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[82] = { op = "try_end", line = 1239 }
    steps[83] = { line = 1261, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 85 end
    end }
    steps[84] = { line = 1266, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9629")
    end }
  end)()
  PROG.functions["reg_2"] = { name = "reg_2", steps = steps, labels = labels }
end

-- Entry point when executed standalone by TapCore
if not _G.__BAS_NO_AUTORUN then
  local B = BAS.new()
  B.run_program(PROG)
end
return PROG
