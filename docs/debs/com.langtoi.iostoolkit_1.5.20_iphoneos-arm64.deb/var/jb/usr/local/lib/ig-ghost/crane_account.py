#!/var/jb/usr/bin/python3
"""Active-container Instagram/Threads Crane account backup and restore.

Public commands are asynchronous:

    crane-restore account-backup [both|instagram|threads] --output PATH
    crane-restore account-restore [both|instagram|threads] --archive FILE
    crane-restore status JOB_ID

The workflow never creates, deletes, renames, or switches a Crane container.
The user selects a clean active target before restore; the active UUID is
pinned throughout the job.
"""

from __future__ import annotations

import argparse
import contextlib
import fcntl
import hashlib
import json
import os
import plistlib
import pwd
import re
import shutil
import signal
import sqlite3
import subprocess
import sys
import tempfile
import time
import uuid
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Iterable, Optional

import crane_account_archive as archive


ENGINE_VERSION = "1.0"
TOOLKIT_VERSION = "1.0.80"
DEFAULT_SELECTOR = "both"
DEFAULT_VERIFY_SECONDS = 45
GHOST_PLIST = "com.sgwc.ghostprefs.plist"
CRANE_RELATIVE_ROOT = "Library/___Crane_Containers"
IG_PREFS_RELATIVE = "Library/Preferences/com.burbn.instagram.plist"
THREADS_PREFS_RELATIVE = "Library/Preferences/com.burbn.barcelona.plist"
IG_SEED_MARKER_RELATIVE = (
    "Library/Preferences/com.langtoi.igghostguard.container-seed.plist"
)
THREADS_IDENTITY_MARKER_RELATIVE = (
    "Library/Preferences/com.langtoi.threadsghostguard.container-identity.plist"
)
IG_SNAPSHOT_RELATIVE = (
    "Library/Preferences/com.langtoi.igghostguard.snapshot.plist"
)
IG_STATUS_RELATIVE = "Library/Caches/com.langtoi.igghostguard.status.plist"
THREADS_SNAPSHOT_RELATIVE = (
    "Library/Preferences/com.langtoi.threadsghostguard.snapshot.plist"
)
THREADS_STATUS_RELATIVE = (
    "Library/Caches/com.langtoi.threadsghostguard.status.plist"
)
RUNTIME_RELATIVE_PATHS = (
    IG_SEED_MARKER_RELATIVE,
    THREADS_IDENTITY_MARKER_RELATIVE,
    IG_SNAPSHOT_RELATIVE,
    IG_STATUS_RELATIVE,
    THREADS_SNAPSHOT_RELATIVE,
    THREADS_STATUS_RELATIVE,
)
APP_INFO = {
    "instagram": {
        "bundle_id": "com.burbn.instagram",
        "process": "Instagram",
        "preferences": IG_PREFS_RELATIVE,
        "launch": ("--bundleid", "com.burbn.instagram"),
    },
    "threads": {
        "bundle_id": "com.burbn.barcelona",
        "process": "Threads",
        "preferences": THREADS_PREFS_RELATIVE,
        "launch": ("--url", "barcelona://"),
    },
}


class AccountError(RuntimeError):
    def __init__(
        self,
        code: str,
        message: str,
        *,
        stage: str,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.stage = stage
        self.details = details or {}


@dataclass(frozen=True)
class WorkflowPaths:
    data_roots: tuple[str, ...] = (
        "/var/mobile/Containers/Data/Application",
        "/var/mobile/Containers/Data/PluginKitPlugin",
        "/var/mobile/Containers/Shared/AppGroup",
    )
    bundle_root: str = "/var/containers/Bundle/Application"
    crane_prefs_candidates: tuple[str, ...] = (
        "/var/jb/var/mobile/Library/Preferences/com.opa334.craneprefs.plist",
        "/var/mobile/Library/Preferences/com.opa334.craneprefs.plist",
    )
    crane_cli: str = "/var/jb/usr/bin/crane-cli"
    shell: str = "/var/jb/usr/bin/sh"
    uiopen: str = "/var/jb/usr/bin/uiopen"
    killall: str = "/var/jb/usr/bin/killall"
    ps: str = "/bin/ps"
    jobs_root: str = "/var/mobile/Library/Logs/crane-account/jobs"
    work_root: str = "/var/mobile/Library/Caches/crane-account"
    global_lock: str = "/var/mobile/Library/Caches/com.langtoi.crane-account.lock"
    latest_job: str = "/var/mobile/Library/Logs/crane-account/latest.json"
    default_output: str = "/var/mobile/Documents/GhostBackups"
    global_profile: str = (
        "/var/mobile/Library/Preferences/Ghost/com.sgwc.ghostprefs.plist"
    )
    task_paths: tuple[str, ...] = (
        "/var/jb/var/mobile/Library/Preferences/com.langtoi.crane-task.plist",
        "/var/jb/var/mobile/Library/Preferences/com.codex.crane-task.plist",
    )
    task_log_paths: tuple[str, ...] = (
        "/var/jb/var/mobile/Library/Preferences/com.langtoi.crane-task.log",
        "/var/jb/var/mobile/Library/Preferences/com.codex.crane-task.log",
    )
    restore_wait_seconds: float = 30.0


DEFAULT_PATHS = WorkflowPaths()


@dataclass(frozen=True)
class ActiveContainer:
    app_key: str
    bundle_id: str
    identifier: str
    name: str
    crane_device_identifier: str
    app_root: str
    root: str

    @property
    def profile_path(self) -> str:
        return os.path.join(self.root, "Documents", GHOST_PLIST)

    @property
    def parent_profile_path(self) -> str:
        return os.path.join(self.app_root, "Documents", GHOST_PLIST)

    @property
    def preferences_path(self) -> str:
        return os.path.join(
            self.root, str(APP_INFO[self.app_key]["preferences"])
        )


class CommandRunner:
    def run(
        self,
        command: Iterable[str],
        *,
        timeout: float = 60,
        input_text: str | None = None,
    ) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            list(command),
            input=input_text,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )


def _now() -> float:
    return time.time()


def _atomic_write(path: str, raw: bytes, mode: int = 0o600) -> None:
    parent = os.path.dirname(path) or "."
    os.makedirs(parent, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".crane-account-", dir=parent)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, mode)
        with contextlib.suppress(KeyError, PermissionError):
            mobile = pwd.getpwnam("mobile")
            os.chown(temporary, mobile.pw_uid, mobile.pw_gid)
        os.replace(temporary, path)
    except Exception:
        with contextlib.suppress(OSError):
            os.remove(temporary)
        raise


def _write_json(path: str, value: dict[str, Any]) -> None:
    _atomic_write(
        path,
        (
            json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True)
            + "\n"
        ).encode("utf-8"),
    )


def _read_json(path: str, default: Any = None) -> Any:
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default


def _read_plist(path: str) -> dict[str, Any]:
    with open(path, "rb") as handle:
        value = plistlib.load(handle)
    if not isinstance(value, dict):
        raise ValueError(f"plist root is not a dictionary: {path}")
    return value


def _write_plist(path: str, value: dict[str, Any], mode: int = 0o600) -> None:
    _atomic_write(path, plistlib.dumps(value, fmt=plistlib.FMT_BINARY), mode)


def _read_bytes(path: str) -> bytes:
    with open(path, "rb") as handle:
        return handle.read()


def _sha256_path(path: str) -> str:
    return archive.sha256_file(path) if os.path.isfile(path) else ""


def _selector_apps(selector: str) -> tuple[str, ...]:
    normalized = str(selector or DEFAULT_SELECTOR).strip().lower()
    if normalized not in archive.VALID_SELECTORS:
        raise AccountError(
            "selector_invalid",
            f"Unsupported selector: {selector}",
            stage="validate_arguments",
        )
    return (
        ("instagram", "threads")
        if normalized == "both"
        else (normalized,)
    )


def _read_crane_prefs(paths: WorkflowPaths) -> tuple[str, dict[str, Any]]:
    for candidate in paths.crane_prefs_candidates:
        if not os.path.isfile(candidate):
            continue
        try:
            return candidate, _read_plist(candidate)
        except Exception as exc:
            raise AccountError(
                "crane_preferences_invalid",
                "Crane preferences cannot be read",
                stage="resolve_active",
                details={"path": candidate, "error": type(exc).__name__},
            ) from exc
    raise AccountError(
        "crane_preferences_missing",
        "Crane preferences are unavailable",
        stage="resolve_active",
    )


def _find_primary_app_root(bundle_id: str, paths: WorkflowPaths) -> str:
    application_root = paths.data_roots[0]
    if not os.path.isdir(application_root):
        raise AccountError(
            "application_root_missing",
            "Application data root is unavailable",
            stage="resolve_active",
            details={"root": application_root},
        )
    for entry in sorted(os.listdir(application_root)):
        candidate = os.path.join(application_root, entry)
        metadata = os.path.join(
            candidate, ".com.apple.mobile_container_manager.metadata.plist"
        )
        if not os.path.isfile(metadata):
            continue
        with contextlib.suppress(Exception):
            if _read_plist(metadata).get("MCMMetadataIdentifier") == bundle_id:
                return candidate
    raise AccountError(
        "application_container_missing",
        f"No application data container exists for {bundle_id}",
        stage="resolve_active",
    )


def _parse_crane_cli_active(output: str) -> str:
    for line in output.splitlines():
        match = re.match(r"^\s*\*\s*\[([^]]+)\]", line)
        if match:
            return match.group(1).strip().upper()
    return ""


def resolve_active_container(
    app_key: str,
    *,
    paths: WorkflowPaths = DEFAULT_PATHS,
    runner: Optional[CommandRunner] = None,
    require_profile: bool = True,
) -> ActiveContainer:
    runner = runner or CommandRunner()
    bundle_id = str(APP_INFO[app_key]["bundle_id"])
    _prefs_path, prefs = _read_crane_prefs(paths)
    settings = prefs.get(f"appSettings_{bundle_id}") or {}
    identifier = str(settings.get("activeContainer") or "").strip().upper()
    if (
        not identifier
        or identifier == "DEFAULT"
        or not re.fullmatch(r"[A-F0-9-]{36}", identifier)
    ):
        raise AccountError(
            "active_container_missing",
            f"A named Crane container is not active for {bundle_id}",
            stage="resolve_active",
        )
    entry: dict[str, Any] = {}
    for candidate in settings.get("Containers") or []:
        if str((candidate or {}).get("identifier") or "").strip().upper() == identifier:
            entry = dict(candidate)
            break
    if not entry:
        raise AccountError(
            "active_container_missing",
            "The active Crane UUID has no container metadata",
            stage="resolve_active",
            details={"app": app_key, "container_id": identifier},
        )
    if paths.crane_cli and os.path.isfile(paths.crane_cli):
        completed = runner.run([paths.crane_cli, "list", bundle_id], timeout=20)
        cli_identifier = (
            _parse_crane_cli_active(completed.stdout)
            if completed.returncode == 0
            else ""
        )
        if cli_identifier != identifier:
            raise AccountError(
                "active_container_unverified",
                "Crane preferences and crane-cli disagree",
                stage="resolve_active",
                details={
                    "app": app_key,
                    "preferences": identifier,
                    "crane_cli": cli_identifier,
                    "returncode": completed.returncode,
                },
            )
    app_root = _find_primary_app_root(bundle_id, paths)
    root = os.path.join(app_root, CRANE_RELATIVE_ROOT, identifier)
    if not os.path.isdir(root):
        raise AccountError(
            "active_container_not_materialized",
            "The active Crane slot does not exist on disk",
            stage="resolve_active",
            details={"app": app_key, "path": root},
        )
    result = ActiveContainer(
        app_key=app_key,
        bundle_id=bundle_id,
        identifier=identifier,
        name=str(entry.get("name") or "").strip(),
        crane_device_identifier=str(
            entry.get("customDeviceIdentifier") or identifier
        ).strip(),
        app_root=app_root,
        root=root,
    )
    if require_profile and not os.path.isfile(result.profile_path):
        raise AccountError(
            "active_profile_missing",
            "The active Crane container has no Ghost profile",
            stage="resolve_active",
            details={"app": app_key, "path": result.profile_path},
        )
    return result


def assert_same_active(
    expected: ActiveContainer,
    *,
    paths: WorkflowPaths,
    runner: CommandRunner,
    stage: str,
    require_profile: bool = False,
) -> ActiveContainer:
    current = resolve_active_container(
        expected.app_key,
        paths=paths,
        runner=runner,
        require_profile=require_profile,
    )
    if current.identifier != expected.identifier:
        raise AccountError(
            "active_container_changed",
            "A selected Crane container changed during the job",
            stage=stage,
            details={
                "app": expected.app_key,
                "expected": expected.identifier,
                "actual": current.identifier,
            },
        )
    return current


def discover_container_roots(
    container_id: str,
    *,
    paths: WorkflowPaths = DEFAULT_PATHS,
) -> dict[str, str]:
    resolved: dict[str, str] = {}
    for base in paths.data_roots:
        if not os.path.isdir(base):
            continue
        for entry in sorted(os.listdir(base)):
            parent = os.path.join(base, entry)
            slot = os.path.join(parent, CRANE_RELATIVE_ROOT, container_id)
            metadata = os.path.join(
                parent, ".com.apple.mobile_container_manager.metadata.plist"
            )
            if not os.path.isdir(slot) or not os.path.isfile(metadata):
                continue
            try:
                identifier = str(
                    _read_plist(metadata).get("MCMMetadataIdentifier") or ""
                ).strip()
            except Exception:
                continue
            if identifier and identifier not in resolved:
                resolved[identifier] = parent
    if not resolved:
        raise AccountError(
            "container_roots_missing",
            "No virtualized roots were found for the active Crane UUID",
            stage="resolve_roots",
            details={"container_id": container_id},
        )
    return resolved


def installed_app_version(
    bundle_id: str,
    *,
    paths: WorkflowPaths = DEFAULT_PATHS,
) -> dict[str, str]:
    if not os.path.isdir(paths.bundle_root):
        raise AccountError(
            "application_bundle_root_missing",
            "Installed application bundle root is unavailable",
            stage="preflight",
        )
    for identifier in sorted(os.listdir(paths.bundle_root)):
        parent = os.path.join(paths.bundle_root, identifier)
        if not os.path.isdir(parent):
            continue
        for child in sorted(os.listdir(parent)):
            if not child.endswith(".app"):
                continue
            info_path = os.path.join(parent, child, "Info.plist")
            if not os.path.isfile(info_path):
                continue
            with contextlib.suppress(Exception):
                info = _read_plist(info_path)
                if info.get("CFBundleIdentifier") == bundle_id:
                    return {
                        "short_version": str(
                            info.get("CFBundleShortVersionString") or ""
                        ),
                        "bundle_version": str(info.get("CFBundleVersion") or ""),
                    }
    raise AccountError(
        "application_bundle_missing",
        f"Installed app bundle cannot be found for {bundle_id}",
        stage="preflight",
    )


def _live_pids(
    process_name: str,
    *,
    paths: WorkflowPaths,
    runner: CommandRunner,
) -> list[int]:
    completed = runner.run(
        [paths.ps, "-ax", "-o", "pid=", "-o", "command="], timeout=20
    )
    if completed.returncode != 0:
        return []
    marker = f"/{process_name}.app/{process_name}"
    result: list[int] = []
    for line in completed.stdout.splitlines():
        if marker not in line:
            continue
        with contextlib.suppress(ValueError, IndexError):
            result.append(int(line.strip().split(None, 1)[0]))
    return sorted(set(result))


def stop_app(
    app_key: str,
    *,
    paths: WorkflowPaths,
    runner: CommandRunner,
) -> None:
    process = str(APP_INFO[app_key]["process"])
    runner.run([paths.killall, process], timeout=10)
    time.sleep(0.75)
    runner.run([paths.killall, "-9", process], timeout=10)
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        if not _live_pids(process, paths=paths, runner=runner):
            return
        time.sleep(0.25)
    pids = _live_pids(process, paths=paths, runner=runner)
    if pids:
        raise AccountError(
            "app_stop_failed",
            f"{process} remained running",
            stage="stop_apps",
            details={"app": app_key, "pids": pids},
        )


def _load_preferences(active: ActiveContainer) -> dict[str, Any]:
    if not os.path.isfile(active.preferences_path):
        return {}
    try:
        return _read_plist(active.preferences_path)
    except Exception as exc:
        raise AccountError(
            "account_preferences_invalid",
            "Account preferences cannot be parsed",
            stage="validate_account",
            details={
                "app": active.app_key,
                "path": active.preferences_path,
                "error": type(exc).__name__,
            },
        ) from exc


def capture_account_marker(active: ActiveContainer) -> dict[str, Any]:
    return archive.account_marker(active.app_key, _load_preferences(active))


def validate_instagram_seed_marker(
    active: ActiveContainer, identity: dict[str, Any]
) -> dict[str, Any]:
    path = os.path.join(active.root, IG_SEED_MARKER_RELATIVE)
    try:
        marker = _read_plist(path)
    except Exception as exc:
        raise AccountError(
            "source_seed_marker_invalid",
            "Instagram seed marker is missing or unreadable",
            stage="validate_source",
            details={"path": path, "error": type(exc).__name__},
        ) from exc
    marker_id = str(marker.get("container_id") or "").strip().upper()
    marker_hash = str(marker.get("profile_sha256") or "")
    marker_raw = marker.get("profile_data")
    raw_hash = (
        archive.sha256_bytes(marker_raw)
        if isinstance(marker_raw, bytes)
        else ""
    )
    if (
        marker.get("seeded") is not True
        or marker_id != active.identifier
        or marker_hash != identity["profile_sha256"]
        or raw_hash != identity["profile_sha256"]
    ):
        raise AccountError(
            "source_seed_marker_invalid",
            "Instagram seed marker does not describe its active profile",
            stage="validate_source",
            details={
                "path": path,
                "expected_container_id": active.identifier,
                "marker_container_id": marker_id,
                "expected_profile_sha256": identity["profile_sha256"],
                "marker_profile_sha256": marker_hash,
                "marker_data_sha256": raw_hash,
            },
        )
    return {
        "path": path,
        "container_id": marker_id,
        "profile_sha256": marker_hash,
    }


def _remove_task_files(paths: WorkflowPaths) -> None:
    for path in (*paths.task_paths, *paths.task_log_paths):
        with contextlib.suppress(FileNotFoundError):
            os.remove(path)


def _latest_task_log(paths: WorkflowPaths) -> str:
    latest = ""
    for path in paths.task_log_paths:
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as handle:
                value = handle.read()
            if value:
                latest = value
        except FileNotFoundError:
            continue
    return latest


def _write_keychain_task(
    value: dict[str, Any],
    *,
    paths: WorkflowPaths,
) -> None:
    raw = plistlib.dumps(value, fmt=plistlib.FMT_XML)
    for path in paths.task_paths:
        _atomic_write(path, raw, 0o600)


def _launch_preferences(
    *,
    paths: WorkflowPaths,
    runner: CommandRunner,
) -> None:
    runner.run([paths.killall, "Preferences"], timeout=10)
    runner.run([paths.killall, "cfprefsd"], timeout=10)
    launched = runner.run(
        [paths.uiopen, "--bundleid", "com.apple.Preferences"], timeout=20
    )
    if launched.returncode != 0:
        raise AccountError(
            "preferences_launch_failed",
            "Preferences could not be opened for the Crane keychain bridge",
            stage="keychain",
            details={"stderr": launched.stderr.strip()[-300:]},
        )


def dump_keychain(
    active: ActiveContainer,
    output_path: str,
    *,
    paths: WorkflowPaths,
    runner: CommandRunner,
) -> dict[str, Any]:
    _remove_task_files(paths)
    with contextlib.suppress(FileNotFoundError):
        os.remove(output_path)
    _write_keychain_task(
        {
            "mode": "dump",
            "app_id": active.bundle_id,
            "container_id": active.identifier,
            "path": output_path,
        },
        paths=paths,
    )
    _launch_preferences(paths=paths, runner=runner)
    deadline = time.monotonic() + max(5.0, paths.restore_wait_seconds)
    last_log = ""
    while time.monotonic() < deadline:
        last_log = _latest_task_log(paths)
        if os.path.isfile(output_path) and "task:done success=1" in last_log:
            break
        time.sleep(0.5)
    else:
        _remove_task_files(paths)
        raise AccountError(
            "keychain_dump_failed",
            "Timed out waiting for Crane keychain dump",
            stage="keychain",
            details={"app": active.app_key, "log_tail": last_log[-500:]},
        )
    try:
        fingerprint = archive.read_keychain_fingerprint(output_path)
    finally:
        _remove_task_files(paths)
    return fingerprint


def restore_keychain(
    active: ActiveContainer,
    input_path: str,
    *,
    paths: WorkflowPaths,
    runner: CommandRunner,
) -> None:
    if not os.path.isfile(input_path):
        raise AccountError(
            "keychain_archive_missing",
            "Archive keychain section is unavailable",
            stage="restore_keychain",
            details={"app": active.app_key, "path": input_path},
        )
    _remove_task_files(paths)
    _write_keychain_task(
        {
            "mode": "restore",
            "app_id": active.bundle_id,
            "container_id": active.identifier,
            "path": input_path,
        },
        paths=paths,
    )
    _launch_preferences(paths=paths, runner=runner)
    deadline = time.monotonic() + max(5.0, paths.restore_wait_seconds)
    last_log = ""
    while time.monotonic() < deadline:
        last_log = _latest_task_log(paths)
        if "restore-sent" in last_log and "task:done success=1" in last_log:
            _remove_task_files(paths)
            return
        time.sleep(0.5)
    _remove_task_files(paths)
    raise AccountError(
        "keychain_restore_failed",
        "Timed out waiting for Crane keychain restore",
        stage="restore_keychain",
        details={"app": active.app_key, "log_tail": last_log[-500:]},
    )


def _copy_tree(
    source: str,
    destination: str,
    *,
    portable_roots: Optional[dict[str, str]] = None,
) -> None:
    shutil.rmtree(destination, ignore_errors=True)
    os.makedirs(destination, mode=0o700, exist_ok=True)
    if not os.path.isdir(source):
        return
    for name in sorted(os.listdir(source)):
        src = os.path.join(source, name)
        dst = os.path.join(destination, name)
        if os.path.islink(src):
            os.symlink(os.readlink(src), dst)
        elif os.path.isdir(src):
            shutil.copytree(src, dst, symlinks=True)
        else:
            shutil.copy2(src, dst, follow_symlinks=False)
    _normalize_copied_symlinks(
        source,
        destination,
        portable_roots=portable_roots,
    )


def _normalize_copied_symlinks(
    source: str,
    destination: str,
    *,
    portable_roots: Optional[dict[str, str]] = None,
) -> None:
    """Keep links portable across the declared roots of one Crane container."""

    source_absolute = os.path.abspath(source)
    destination_absolute = os.path.abspath(destination)
    declared = portable_roots or {
        source_absolute: destination_absolute,
    }
    root_pairs = sorted(
        (
            (os.path.abspath(source_root), os.path.abspath(target_root))
            for source_root, target_root in declared.items()
        ),
        key=lambda pair: len(pair[0]),
        reverse=True,
    )
    links: list[str] = []
    for directory, dirs, files in os.walk(destination, followlinks=False):
        for name in (*dirs, *files):
            candidate = os.path.join(directory, name)
            if os.path.islink(candidate):
                links.append(candidate)
        dirs[:] = [
            name
            for name in dirs
            if not os.path.islink(os.path.join(directory, name))
        ]

    for copied_link in sorted(links):
        relative = os.path.relpath(copied_link, destination)
        source_link = os.path.join(source_absolute, relative)
        target = os.readlink(copied_link)
        if os.path.isabs(target):
            source_target = os.path.abspath(os.path.normpath(target))
        else:
            source_target = os.path.abspath(
                os.path.normpath(
                    os.path.join(os.path.dirname(source_link), target)
                )
            )

        mapped_target = ""
        for source_root, target_root in root_pairs:
            try:
                contained = os.path.commonpath(
                    (source_root, source_target)
                )
            except ValueError:
                contained = ""
            if contained != source_root:
                continue
            target_in_root = os.path.relpath(source_target, source_root)
            mapped_target = os.path.join(target_root, target_in_root)
            break
        if not mapped_target:
            raise AccountError(
                "source_symlink_external",
                (
                    "A Crane root contains a symbolic link outside the "
                    "selected container roots"
                ),
                stage="copy_data",
                details={"path": source_link, "target": target},
            )
        portable_target = os.path.relpath(
            mapped_target,
            os.path.dirname(copied_link),
        )
        os.remove(copied_link)
        os.symlink(portable_target, copied_link)


def _remove_runtime_artifacts(root: str) -> None:
    for relative in RUNTIME_RELATIVE_PATHS:
        path = os.path.join(root, relative)
        with contextlib.suppress(FileNotFoundError):
            os.remove(path)


def copy_live_roots_to_stage(
    active: ActiveContainer,
    stage_roots: str,
    *,
    paths: WorkflowPaths,
    strip_runtime: bool = True,
) -> dict[str, str]:
    roots = discover_container_roots(active.identifier, paths=paths)
    mapping: dict[str, str] = {}
    copy_roots: dict[str, str] = {}
    for root_id, parent in sorted(roots.items()):
        encoded = archive.encoded_root_name(root_id)
        source = os.path.join(
            parent, CRANE_RELATIVE_ROOT, active.identifier
        )
        destination = os.path.join(stage_roots, encoded)
        mapping[root_id] = encoded
        copy_roots[source] = destination
    for root_id, parent in sorted(roots.items()):
        encoded = mapping[root_id]
        source = os.path.join(parent, CRANE_RELATIVE_ROOT, active.identifier)
        destination = os.path.join(stage_roots, encoded)
        _copy_tree(
            source,
            destination,
            portable_roots=copy_roots,
        )
        if strip_runtime:
            _remove_runtime_artifacts(destination)
    if active.bundle_id not in mapping:
        raise AccountError(
            "primary_root_missing",
            "The selected app root was not included in the Crane snapshot",
            stage="copy_data",
            details={"app": active.app_key, "roots": sorted(mapping)},
        )
    return mapping


def resolve_restore_roots(
    root_ids: Iterable[str],
    active: ActiveContainer,
    *,
    paths: WorkflowPaths,
) -> dict[str, str]:
    wanted = set(root_ids)
    resolved: dict[str, str] = {}
    for base in paths.data_roots:
        if not os.path.isdir(base):
            continue
        for entry in sorted(os.listdir(base)):
            parent = os.path.join(base, entry)
            metadata = os.path.join(
                parent, ".com.apple.mobile_container_manager.metadata.plist"
            )
            if not os.path.isfile(metadata):
                continue
            with contextlib.suppress(Exception):
                identifier = str(
                    _read_plist(metadata).get("MCMMetadataIdentifier") or ""
                ).strip()
                if identifier in wanted and identifier not in resolved:
                    resolved[identifier] = os.path.join(
                        parent, CRANE_RELATIVE_ROOT, active.identifier
                    )
    missing = sorted(wanted - set(resolved))
    if missing:
        raise AccountError(
            "restore_roots_missing",
            "The target device lacks roots declared by the archive",
            stage="resolve_roots",
            details={"app": active.app_key, "missing": missing},
        )
    return resolved


def _chown_mobile(path: str) -> None:
    try:
        mobile = pwd.getpwnam("mobile")
    except KeyError:
        return
    for directory, dirs, files in os.walk(path):
        with contextlib.suppress(PermissionError):
            os.chown(directory, mobile.pw_uid, mobile.pw_gid)
        for name in (*dirs, *files):
            with contextlib.suppress(PermissionError, FileNotFoundError):
                os.chown(
                    os.path.join(directory, name), mobile.pw_uid, mobile.pw_gid
                )


def copy_archive_roots_to_active(
    app_key: str,
    active: ActiveContainer,
    manifest_app: dict[str, Any],
    unpack_root: str,
    *,
    paths: WorkflowPaths,
) -> None:
    roots = manifest_app.get("roots") or {}
    copy_staged_roots_to_active(
        active,
        roots,
        os.path.join(unpack_root, "Apps", app_key, "roots"),
        paths=paths,
        strip_runtime=True,
    )


def copy_staged_roots_to_active(
    active: ActiveContainer,
    roots: dict[str, str],
    staged_roots: str,
    *,
    paths: WorkflowPaths,
    strip_runtime: bool,
) -> None:
    resolved = resolve_restore_roots(roots.keys(), active, paths=paths)
    copy_roots = {
        os.path.join(staged_roots, encoded): resolved[root_id]
        for root_id, encoded in roots.items()
    }
    for root_id, encoded in sorted(roots.items()):
        source = os.path.join(staged_roots, encoded)
        destination = resolved[root_id]
        _copy_tree(
            source,
            destination,
            portable_roots=copy_roots,
        )
        if strip_runtime:
            _remove_runtime_artifacts(destination)
        _chown_mobile(destination)


def set_crane_device_identifier(
    active: ActiveContainer,
    device_identifier: str,
    *,
    paths: WorkflowPaths,
) -> None:
    value = str(device_identifier or "").strip()
    if not value:
        raise AccountError(
            "archive_device_identifier_missing",
            "Archive has no Crane deviceIdentifierForVendor",
            stage="restore_identity",
            details={"app": active.app_key},
        )
    prefs_path, prefs = _read_crane_prefs(paths)
    settings = prefs.get(f"appSettings_{active.bundle_id}") or {}
    if str(settings.get("activeContainer") or "").strip().upper() != active.identifier:
        raise AccountError(
            "active_container_changed",
            "Active container changed before Crane IDFV restore",
            stage="restore_identity",
            details={"app": active.app_key},
        )
    target: dict[str, Any] | None = None
    for item in settings.get("Containers") or []:
        if str((item or {}).get("identifier") or "").strip().upper() == active.identifier:
            target = item
            break
    if target is None:
        raise AccountError(
            "active_container_missing",
            "Active Crane metadata disappeared",
            stage="restore_identity",
            details={"app": active.app_key},
        )
    target["customDeviceIdentifier"] = value
    target["useContainerIdentifierAsDeviceIdentifier"] = False
    prefs[f"appSettings_{active.bundle_id}"] = settings
    _write_plist(prefs_path, prefs, 0o600)


def _identity_marker_payload(
    active: ActiveContainer,
    profile_raw: bytes,
    identity: dict[str, Any],
    *,
    standalone_threads: bool,
) -> dict[str, Any]:
    payload = {
        "schema": 1,
        "container_id": active.identifier,
        "container_name": active.name,
        "profile_sha256": identity["profile_sha256"],
        "profile_data": profile_raw,
        "model": identity["model"],
        "hardware": identity["hardware"],
        "display_name": identity["display_name"],
        "ios": identity["ios"],
        "build": identity["build"],
        "restored_at": _now(),
    }
    if standalone_threads:
        payload.update(
            {
                "assigned": True,
                "identity_mode": "archive_standalone",
            }
        )
    else:
        payload.update({"seeded": True, "seeded_at": _now()})
    return payload


def install_restored_identity(
    active: ActiveContainer,
    profile_raw: bytes,
    identity: dict[str, Any],
    *,
    mode: str,
) -> dict[str, Any]:
    if mode not in {
        "instagram_seed",
        "threads_standalone",
        "threads_pair",
    }:
        raise ValueError(f"invalid identity install mode: {mode}")
    os.makedirs(os.path.dirname(active.profile_path), exist_ok=True)
    _atomic_write(active.profile_path, profile_raw, 0o644)
    marker_path = ""
    if mode == "threads_standalone":
        _atomic_write(active.parent_profile_path, profile_raw, 0o644)
        marker_path = os.path.join(
            active.root, THREADS_IDENTITY_MARKER_RELATIVE
        )
        marker = _identity_marker_payload(
            active,
            profile_raw,
            identity,
            standalone_threads=True,
        )
        _write_plist(marker_path, marker, 0o644)
        with contextlib.suppress(FileNotFoundError):
            os.remove(os.path.join(active.root, IG_SEED_MARKER_RELATIVE))
    elif mode == "instagram_seed":
        marker_path = os.path.join(active.root, IG_SEED_MARKER_RELATIVE)
        marker = _identity_marker_payload(
            active,
            profile_raw,
            identity,
            standalone_threads=False,
        )
        _write_plist(marker_path, marker, 0o644)
        with contextlib.suppress(FileNotFoundError):
            os.remove(
                os.path.join(active.root, THREADS_IDENTITY_MARKER_RELATIVE)
            )
    else:
        _atomic_write(active.parent_profile_path, profile_raw, 0o644)
        for relative in (
            IG_SEED_MARKER_RELATIVE,
            THREADS_IDENTITY_MARKER_RELATIVE,
        ):
            with contextlib.suppress(FileNotFoundError):
                os.remove(os.path.join(active.root, relative))
    for relative in (
        IG_SNAPSHOT_RELATIVE,
        IG_STATUS_RELATIVE,
        THREADS_SNAPSHOT_RELATIVE,
        THREADS_STATUS_RELATIVE,
    ):
        with contextlib.suppress(FileNotFoundError):
            os.remove(os.path.join(active.root, relative))
    actual = _sha256_path(active.profile_path)
    if actual != identity["profile_sha256"]:
        raise AccountError(
            "identity_write_failed",
            "Restored Ghost profile hash does not match the archive",
            stage="restore_identity",
            details={
                "app": active.app_key,
                "expected": identity["profile_sha256"],
                "actual": actual,
            },
        )
    return {
        "profile_path": active.profile_path,
        "marker_path": marker_path,
        "profile_sha256": actual,
        "marker_container_id": active.identifier if marker_path else "",
        "identity_mode": mode,
    }


def _path_state(path: str) -> dict[str, Any]:
    return {
        "exists": os.path.isfile(path),
        "sha256": _sha256_path(path),
    }


def isolation_state(
    app_key: str,
    *,
    paths: WorkflowPaths,
    runner: CommandRunner,
) -> dict[str, Any]:
    active = resolve_active_container(
        app_key, paths=paths, runner=runner, require_profile=False
    )
    result = {
        "active_id": active.identifier,
        "profile": _path_state(active.profile_path),
        "parent_profile": _path_state(active.parent_profile_path),
    }
    if app_key == "instagram":
        result["global_profile"] = _path_state(paths.global_profile)
        result["seed_marker"] = _path_state(
            os.path.join(active.root, IG_SEED_MARKER_RELATIVE)
        )
    else:
        result["identity_marker"] = _path_state(
            os.path.join(active.root, THREADS_IDENTITY_MARKER_RELATIVE)
        )
    return result


def inactive_profile_hashes(active: ActiveContainer) -> dict[str, str]:
    crane_root = os.path.join(active.app_root, CRANE_RELATIVE_ROOT)
    result: dict[str, str] = {}
    if not os.path.isdir(crane_root):
        return result
    for identifier in sorted(os.listdir(crane_root)):
        if identifier.upper() == active.identifier:
            continue
        profile = os.path.join(crane_root, identifier, "Documents", GHOST_PLIST)
        if os.path.isfile(profile):
            result[identifier.upper()] = _sha256_path(profile)
    return result


def _remove_tree_runtime(stage_app_root: str) -> None:
    roots = os.path.join(stage_app_root, "roots")
    if not os.path.isdir(roots):
        return
    for encoded in os.listdir(roots):
        _remove_runtime_artifacts(os.path.join(roots, encoded))


def sanitize_archive_stage(
    app_key: str,
    stage_app_root: str,
    roots: dict[str, str],
    profile_raw: bytes,
    *,
    backup_root: str,
) -> dict[str, Any]:
    """Remove portable-runtime identity leaks from the copied archive only."""

    import ig_active_sanitize as sanitizer

    bundle_id = str(APP_INFO[app_key]["bundle_id"])
    encoded = roots.get(bundle_id)
    if not encoded:
        raise AccountError(
            "archive_primary_root_missing",
            "The staged archive has no primary application root",
            stage="sanitize_archive",
            details={"app": app_key},
        )
    primary = os.path.join(stage_app_root, "roots", encoded)
    identity = sanitizer.identity_from_profile(profile_raw)
    replacements = sanitizer.build_replacements(identity)
    removed_reports: list[str] = []
    for root_encoded in roots.values():
        staged_root = os.path.join(
            stage_app_root, "roots", root_encoded
        )
        reports = os.path.join(
            staged_root, "TerminationReporter", "TerminationReports"
        )
        if os.path.isdir(reports):
            shutil.rmtree(reports)
            removed_reports.append(reports)

    if app_key == "threads":
        report = sanitizer.sanitize_threads_scope(
            primary,
            "ARCHIVE-STAGE",
            profile_raw,
            backup_root=backup_root,
        )
        if report.get("success") is not True:
            raise AccountError(
                "archive_storage_residual",
                "Staged Threads data still contains a physical identity",
                stage="sanitize_archive",
                details={"app": app_key, "report": report},
            )
        return {
            "success": True,
            "app": app_key,
            "removed_termination_report_roots": len(removed_reports),
            "storage": report,
        }

    preferences = os.path.join(primary, IG_PREFS_RELATIVE)
    preference_changes = sanitizer.sanitize_preferences(
        preferences, replacements
    )
    fflogger = os.path.join(primary, "Documents/FFLogger.sql")
    fflogger_changes = sanitizer.sanitize_sqlite(
        fflogger, identity, replacements, "fflogger"
    )
    analytics = os.path.join(
        primary,
        "Library/Application Support/com.burbn.instagram/analytics/"
        "unified_micro_batch/FBAnalyticsUnifiedEventStore.sqlite",
    )
    analytics_changes = sanitizer.sanitize_sqlite(
        analytics, identity, replacements, "analytics"
    )
    crypto_changes = 0
    crypto_hits: list[dict[str, Any]] = []
    group_encoded = roots.get(sanitizer.INSTAGRAM_GROUP)
    if group_encoded:
        group_root = os.path.join(
            stage_app_root, "roots", group_encoded
        )
        for directory, _dirs, names in os.walk(group_root):
            for name in names:
                if not (
                    name.startswith("crypto_db_")
                    and name.endswith(".db")
                ):
                    continue
                path = os.path.join(directory, name)
                crypto_changes += sanitizer.sanitize_sqlite(
                    path, identity, replacements, "crypto"
                )
                connection = sqlite3.connect(path, timeout=10)
                try:
                    hits = sanitizer._logical_marker_hits(
                        connection,
                        tuple(old for old, _new in replacements),
                    )
                finally:
                    connection.close()
                if hits:
                    crypto_hits.append({"path": path, "hits": hits})

    fflogger_state = sanitizer.fflogger_guard_state(
        fflogger, identity, replacements
    )
    analytics_state = sanitizer.analytics_queue_state(
        analytics, identity, replacements
    )
    preference_hits = (
        sanitizer._marker_hits_in_file(preferences, replacements)
        if os.path.isfile(preferences)
        else []
    )
    success = (
        fflogger_state.get("success") is True
        and analytics_state.get("success") is True
        and not preference_hits
        and not crypto_hits
    )
    report = {
        "success": success,
        "app": app_key,
        "preference_changes": preference_changes,
        "fflogger_changes": fflogger_changes,
        "analytics_changes": analytics_changes,
        "crypto_changes": crypto_changes,
        "preference_hits": preference_hits,
        "crypto_hits": crypto_hits,
        "fflogger": fflogger_state,
        "analytics": analytics_state,
        "removed_termination_report_roots": len(removed_reports),
    }
    if not success:
        raise AccountError(
            "archive_storage_residual",
            "Staged Instagram data still contains a physical identity",
            stage="sanitize_archive",
            details={"app": app_key, "report": report},
        )
    return report


def _source_username(app_markers: dict[str, dict[str, Any]]) -> str:
    for key in ("instagram", "threads"):
        marker = app_markers.get(key) or {}
        values = marker.get("values") or {}
        if not isinstance(values, dict):
            continue
        for field in ("username", "analytics_app_uid", "last_known_owner_fbid"):
            value = str(values.get(field) or "").strip()
            if value:
                return re.sub(r"[^A-Za-z0-9_.-]+", "_", value)[:80]
    return "account"


def _resolve_output_path(
    requested: str,
    *,
    paths: WorkflowPaths,
    username: str,
    selector: str,
) -> str:
    value = os.path.abspath(str(requested or paths.default_output))
    if value.endswith(archive.ARCHIVE_EXTENSION):
        return value
    timestamp = time.strftime("%Y.%m.%d_%H-%M-%S", time.localtime())
    filename = f"{username}_{selector}_{timestamp}{archive.ARCHIVE_EXTENSION}"
    return os.path.join(value, filename)


def _copy_keychain_to_stage(
    source: str, stage_app_root: str
) -> str:
    destination = os.path.join(stage_app_root, "Keychain.plist")
    os.makedirs(stage_app_root, exist_ok=True)
    shutil.copy2(source, destination)
    os.chmod(destination, 0o600)
    return destination


def _app_manifest(
    active: ActiveContainer,
    roots: dict[str, str],
    marker: dict[str, Any],
    keychain_fingerprint: dict[str, Any],
    app_version: dict[str, str],
) -> dict[str, Any]:
    return {
        "bundle_id": active.bundle_id,
        "source_container_id": active.identifier,
        "source_container_name": active.name,
        "crane_device_identifier": active.crane_device_identifier,
        "app_version": app_version,
        "account_marker": marker,
        "keychain_fingerprint": keychain_fingerprint,
        "roots": roots,
    }


def run_backup(
    selector: str,
    output: str,
    *,
    job_id: str,
    work_dir: str,
    paths: WorkflowPaths = DEFAULT_PATHS,
    runner: Optional[CommandRunner] = None,
    update: Optional[Any] = None,
) -> dict[str, Any]:
    runner = runner or CommandRunner()
    update = update or (lambda **_kwargs: None)
    apps = _selector_apps(selector)
    active: dict[str, ActiveContainer] = {}
    inactive_before: dict[str, dict[str, str]] = {}
    markers: dict[str, dict[str, Any]] = {}
    identities: dict[str, dict[str, Any]] = {}
    raw_profiles: dict[str, bytes] = {}
    versions: dict[str, dict[str, str]] = {}
    keychain_fingerprints: dict[str, dict[str, Any]] = {}
    roots_by_app: dict[str, dict[str, str]] = {}
    archive_sanitize: dict[str, dict[str, Any]] = {}

    update(stage="resolve_active")
    for app_key in apps:
        item = resolve_active_container(
            app_key, paths=paths, runner=runner, require_profile=True
        )
        active[app_key] = item
        inactive_before[app_key] = inactive_profile_hashes(item)
        raw = _read_bytes(item.profile_path)
        raw_profiles[app_key] = raw
        identities[app_key] = archive.validate_ghost_profile(raw)
        if app_key == "instagram":
            validate_instagram_seed_marker(item, identities[app_key])
        marker = capture_account_marker(item)
        if marker.get("present") is not True:
            raise AccountError(
                "source_account_missing",
                "The selected source container has no authenticated account marker",
                stage="validate_source",
                details={"app": app_key, "container_id": item.identifier},
            )
        markers[app_key] = marker
        versions[app_key] = installed_app_version(
            item.bundle_id, paths=paths
        )
    if selector == "both":
        if (
            identities["instagram"]["profile_sha256"]
            != identities["threads"]["profile_sha256"]
        ):
            raise AccountError(
                "source_identity_mismatch",
                "Active Instagram and Threads do not share one profile",
                stage="validate_source",
                details={
                    key: value["profile_sha256"]
                    for key, value in identities.items()
                },
            )
        canonical_raw = raw_profiles["instagram"]
        canonical_identity = identities["instagram"]
    else:
        canonical_raw = raw_profiles[apps[0]]
        canonical_identity = identities[apps[0]]

    for app_key in apps:
        update(stage="stop_apps", current_app=app_key)
        stop_app(app_key, paths=paths, runner=runner)
        assert_same_active(
            active[app_key],
            paths=paths,
            runner=runner,
            stage="backup_after_stop",
            require_profile=True,
        )

    stage_root = os.path.join(work_dir, "stage")
    shutil.rmtree(stage_root, ignore_errors=True)
    os.makedirs(stage_root, mode=0o700, exist_ok=True)
    identity_path = os.path.join(stage_root, archive.IDENTITY_MEMBER)
    os.makedirs(os.path.dirname(identity_path), exist_ok=True)
    _atomic_write(identity_path, canonical_raw, 0o600)

    manifest_apps: dict[str, Any] = {}
    for app_key in apps:
        item = active[app_key]
        update(stage="dump_keychain", current_app=app_key)
        keychain_temp = os.path.join(work_dir, f"{app_key}-keychain.plist")
        keychain_fingerprints[app_key] = dump_keychain(
            item,
            keychain_temp,
            paths=paths,
            runner=runner,
        )
        assert_same_active(
            item,
            paths=paths,
            runner=runner,
            stage="backup_after_keychain",
            require_profile=True,
        )
        update(stage="copy_data", current_app=app_key)
        stage_app = os.path.join(stage_root, "Apps", app_key)
        roots_by_app[app_key] = copy_live_roots_to_stage(
            item,
            os.path.join(stage_app, "roots"),
            paths=paths,
        )
        _copy_keychain_to_stage(keychain_temp, stage_app)
        _remove_tree_runtime(stage_app)
        archive_sanitize[app_key] = sanitize_archive_stage(
            app_key,
            stage_app,
            roots_by_app[app_key],
            raw_profiles[app_key],
            backup_root=os.path.join(
                work_dir, "archive-sanitize-backups", app_key
            ),
        )
        manifest_apps[app_key] = _app_manifest(
            item,
            roots_by_app[app_key],
            markers[app_key],
            keychain_fingerprints[app_key],
            versions[app_key],
        )
        manifest_apps[app_key]["archive_storage_sanitized"] = True
        assert_same_active(
            item,
            paths=paths,
            runner=runner,
            stage="backup_after_copy",
            require_profile=True,
        )
        if _sha256_path(item.profile_path) != identities[app_key]["profile_sha256"]:
            raise AccountError(
                "source_profile_changed",
                "Source Ghost profile changed during backup",
                stage="validate_source",
                details={"app": app_key},
            )
        if inactive_profile_hashes(item) != inactive_before[app_key]:
            raise AccountError(
                "inactive_container_changed",
                "An inactive Crane profile changed during backup",
                stage="validate_isolation",
                details={"app": app_key},
            )

    username = _source_username(markers)
    output_path = _resolve_output_path(
        output,
        paths=paths,
        username=username,
        selector=selector,
    )
    manifest = {
        "created_at": _now(),
        "toolkit_version": TOOLKIT_VERSION,
        "engine_version": ENGINE_VERSION,
        "selection": selector,
        "identity": canonical_identity,
        "apps": manifest_apps,
    }
    update(stage="build_archive", output_path=output_path)
    built = archive.build_archive(stage_root, output_path, manifest)
    for app_key in apps:
        assert_same_active(
            active[app_key],
            paths=paths,
            runner=runner,
            stage="backup_complete",
            require_profile=True,
        )
        if inactive_profile_hashes(active[app_key]) != inactive_before[app_key]:
            raise AccountError(
                "inactive_container_changed",
                "An inactive Crane profile changed during backup",
                stage="validate_isolation",
                details={"app": app_key},
            )
    return {
        "success": True,
        "verdict": "PASS",
        "action": "account_backup",
        "job_id": job_id,
        "selection": selector,
        "identity": canonical_identity,
        "apps": {
            key: {
                "active_container": {
                    "id": active[key].identifier,
                    "name": active[key].name,
                },
                "account_marker": markers[key],
                "keychain_fingerprint": keychain_fingerprints[key],
                "root_count": len(roots_by_app[key]),
                "app_version": versions[key],
                "archive_storage_sanitize": archive_sanitize[key],
            }
            for key in apps
        },
        **{key: value for key, value in built.items() if key != "manifest"},
        "apps_left_closed": list(apps),
    }


def run_threads_standalone_verification(
    active: ActiveContainer,
    profile_raw: bytes,
    *,
    verify_seconds: int,
    paths: WorkflowPaths,
    runner: CommandRunner,
) -> dict[str, Any]:
    """Apply one archived identity to Threads without reading or writing IG."""

    if paths != DEFAULT_PATHS:
        raise AccountError(
            "standalone_test_paths_unsupported",
            "Standalone Threads runtime verification requires live device paths",
            stage="verify_runtime",
        )
    import ig_ghost_guard_cli as guard
    import threads_ghost_workflow as threads_workflow
    from ig_ghost_local import LocalRemote

    identity = archive.validate_ghost_profile(profile_raw)
    tw_paths = threads_workflow.DEFAULT_PATHS
    tw_runner = threads_workflow.CommandRunner()
    threads = threads_workflow.resolve_active_container(
        threads_workflow.THREADS_BUNDLE_ID,
        tw_paths,
        tw_runner,
        require_profile=True,
    )
    if threads.identifier != active.identifier:
        raise AccountError(
            "active_container_changed",
            "Threads active UUID changed before standalone verification",
            stage="verify_runtime",
            details={
                "expected": active.identifier,
                "actual": threads.identifier,
            },
        )
    threads_workflow._assert_guard_installed(tw_paths)
    previous_status: dict[str, Any] = {}
    status_path = os.path.join(active.root, THREADS_STATUS_RELATIVE)
    snapshot_path = os.path.join(active.root, THREADS_SNAPSHOT_RELATIVE)
    with contextlib.suppress(Exception):
        previous_status = _read_plist(status_path)
    previous_pid = int(previous_status.get("pid", 0) or 0)
    previous_launch_id = str(previous_status.get("launch_id") or "")
    previous_pids = _live_pids("Threads", paths=paths, runner=runner)
    if previous_pid <= 0 and previous_pids:
        previous_pid = previous_pids[-1]

    stop_app("threads", paths=paths, runner=runner)
    assert_same_active(
        active,
        paths=paths,
        runner=runner,
        stage="threads_standalone_before_snapshot",
        require_profile=True,
    )
    _atomic_write(active.profile_path, profile_raw, 0o644)
    _atomic_write(active.parent_profile_path, profile_raw, 0o644)

    original_bundle = guard.BUNDLE_ID
    try:
        guard.BUNDLE_ID = str(APP_INFO["threads"]["bundle_id"])
        device = guard.DeviceSpec(
            ip="localhost",
            username="mobile",
            password=os.environ.get("IG_IPHONE_PASSWORD", "alpine"),
        )
        snapshot = guard.collect_snapshot(LocalRemote(device)).plist_payload()
    finally:
        guard.BUNDLE_ID = original_bundle
    snapshot.update(
        {
            "schema": 1,
            "bundle_id": str(APP_INFO["threads"]["bundle_id"]),
            "source_path": active.profile_path,
            "created_at": _now(),
            "snapshot_id": identity["snapshot_id"],
        }
    )
    for key in (
        "model",
        "hardware",
        "display_name",
        "ios",
        "build",
        "resolution",
    ):
        if snapshot.get(key) != identity[key]:
            raise AccountError(
                "snapshot_identity_mismatch",
                "Standalone Threads snapshot does not match archive identity",
                stage="verify_runtime",
                details={
                    "field": key,
                    "expected": identity[key],
                    "actual": snapshot.get(key),
                },
            )
    with contextlib.suppress(FileNotFoundError):
        os.remove(status_path)
    with contextlib.suppress(FileNotFoundError):
        os.remove(snapshot_path)
    _write_plist(snapshot_path, snapshot, 0o644)
    runner.run([paths.killall, "cfprefsd"], timeout=10)
    try:
        storage_sanitize = threads_workflow._sanitize_active_storage(
            threads, profile_raw, tw_paths
        )
    except threads_workflow.WorkflowError as exc:
        raise AccountError(
            exc.code,
            str(exc),
            stage=exc.stage,
            details=exc.details,
        ) from exc
    crashes_before = threads_workflow._list_threads_crashes(tw_paths)

    launched = runner.run(
        [paths.uiopen, "--url", "barcelona://"], timeout=20
    )
    if launched.returncode != 0:
        raise AccountError(
            "threads_launch_failed",
            "Threads could not be launched",
            stage="verify_runtime",
            details={"stderr": launched.stderr.strip()[-300:]},
        )
    startup_deadline = time.monotonic() + 20
    status: dict[str, Any] = {}
    pid = 0
    launch_id = ""
    while time.monotonic() < startup_deadline:
        with contextlib.suppress(Exception):
            status = _read_plist(status_path)
        pid = int(status.get("pid", 0) or 0)
        launch_id = str(status.get("launch_id") or "")
        live = _live_pids("Threads", paths=paths, runner=runner)
        if (
            pid > 0
            and pid != previous_pid
            and pid not in previous_pids
            and launch_id
            and launch_id != previous_launch_id
            and pid in live
        ):
            break
        time.sleep(0.5)
    else:
        stop_app("threads", paths=paths, runner=runner)
        raise AccountError(
            "threads_guard_start_timeout",
            "Threads did not publish a fresh guarded PID",
            stage="verify_runtime",
        )

    started = time.monotonic()
    next_refresh = started + 8
    samples: list[dict[str, Any]] = []
    while time.monotonic() - started < max(1, verify_seconds):
        assert_same_active(
            active,
            paths=paths,
            runner=runner,
            stage="threads_standalone_warmup",
            require_profile=True,
        )
        try:
            current = _read_plist(status_path)
        except Exception as exc:
            stop_app("threads", paths=paths, runner=runner)
            raise AccountError(
                "threads_status_missing",
                "Threads guard status disappeared during warm-up",
                stage="verify_runtime",
                details={"error": type(exc).__name__},
            ) from exc
        current_pid = int(current.get("pid", 0) or 0)
        current_launch = str(current.get("launch_id") or "")
        if current_pid != pid or current_launch != launch_id:
            stop_app("threads", paths=paths, runner=runner)
            raise AccountError(
                "threads_runtime_changed",
                "Threads PID or launch id changed during warm-up",
                stage="verify_runtime",
                details={
                    "expected_pid": pid,
                    "actual_pid": current_pid,
                    "expected_launch_id": launch_id,
                    "actual_launch_id": current_launch,
                },
            )
        if pid not in _live_pids("Threads", paths=paths, runner=runner):
            raise AccountError(
                "threads_process_exited",
                "Guarded Threads process exited during warm-up",
                stage="verify_runtime",
            )
        status = current
        samples.append(
            {
                "elapsed": round(time.monotonic() - started, 3),
                "calls": int(status.get("calls", 0) or 0),
                "residual": int(status.get("residual", 0) or 0),
                "blocked": int(status.get("blocked", 0) or 0),
                "errors": int(status.get("errors", 0) or 0),
            }
        )
        if time.monotonic() >= next_refresh:
            runner.run([paths.uiopen, "--url", "barcelona://"], timeout=15)
            next_refresh += 8
        time.sleep(1)

    assert_same_active(
        active,
        paths=paths,
        runner=runner,
        stage="threads_standalone_after_warmup",
        require_profile=True,
    )
    problems = threads_workflow._status_problems(
        status, identity["snapshot_id"], 1
    )
    crashes_after = threads_workflow._list_threads_crashes(tw_paths)
    new_crashes = sorted(crashes_after - crashes_before)
    if new_crashes:
        problems.append("new_crash")
    if _sha256_path(active.profile_path) != identity["profile_sha256"]:
        problems.append("profile_changed")
    if _sha256_path(active.parent_profile_path) != identity["profile_sha256"]:
        problems.append("parent_profile_changed")
    try:
        storage_after_warmup = threads_workflow._scan_active_storage(
            threads, profile_raw
        )
    except threads_workflow.WorkflowError as exc:
        stop_app("threads", paths=paths, runner=runner)
        raise AccountError(
            exc.code,
            str(exc),
            stage=exc.stage,
            details=exc.details,
        ) from exc
    if problems:
        stop_app("threads", paths=paths, runner=runner)
        raise AccountError(
            "threads_runtime_verification_failed",
            "Standalone Threads runtime did not satisfy the guarded contract",
            stage="verify_runtime",
            details={
                "problems": sorted(set(problems)),
                "status": status,
                "new_crashes": new_crashes,
            },
        )
    return {
        "success": True,
        "verdict": "PASS",
        "identity_source": "archive",
        "active_container": {
            "id": active.identifier,
            "name": active.name,
        },
        "identity": identity,
        "storage_sanitize": storage_sanitize,
        "storage_after_warmup": storage_after_warmup,
        "snapshot": {
            key: snapshot.get(key)
            for key in (
                "snapshot_id",
                "model",
                "hardware",
                "display_name",
                "ios",
                "build",
                "resolution",
                "source_path",
                "created_at",
            )
        },
        "runtime": {
            "previous_pid": previous_pid,
            "pid": pid,
            "launch_id": launch_id,
            "new_launch_id": True,
            "same_pid_during_warmup": True,
            "minimum_warmup_seconds": verify_seconds,
            "requests": int(status.get("calls", 0) or 0),
            "request_accounting_closed": True,
            "residual": 0,
            "blocked": 0,
            "errors": 0,
            "new_crashes": [],
            "samples": samples,
        },
    }


def _validate_target_clean(
    active: ActiveContainer,
    marker: dict[str, Any],
    keychain: dict[str, Any],
) -> None:
    problems: list[str] = []
    if marker.get("present") is True:
        problems.append("account_marker_present")
    if int(keychain.get("total_items", 0) or 0) != 0:
        problems.append("keychain_not_empty")
    if problems:
        raise AccountError(
            "active_target_not_clean",
            "The active restore target contains an account or keychain items",
            stage="validate_target",
            details={
                "app": active.app_key,
                "container_id": active.identifier,
                "container_name": active.name,
                "problems": problems,
                "account_marker": marker,
                "keychain": keychain,
            },
        )


def _capture_rollback(
    active: ActiveContainer,
    rollback_root: str,
    keychain_path: str,
    *,
    paths: WorkflowPaths,
) -> dict[str, Any]:
    stage_app = os.path.join(rollback_root, active.app_key)
    os.makedirs(stage_app, mode=0o700, exist_ok=True)
    keychain_target = os.path.join(stage_app, "Keychain.plist")
    shutil.copy2(keychain_path, keychain_target)
    os.chmod(keychain_target, 0o600)
    roots = copy_live_roots_to_stage(
        active,
        os.path.join(stage_app, "roots"),
        paths=paths,
        strip_runtime=False,
    )
    external: dict[str, dict[str, Any]] = {}
    external_paths = {"parent_profile": active.parent_profile_path}
    if active.app_key == "instagram":
        external_paths["global_profile"] = paths.global_profile
    for name, source in external_paths.items():
        record = {
            "path": source,
            "existed": os.path.isfile(source),
            "backup": "",
        }
        if record["existed"]:
            destination = os.path.join(stage_app, f"{name}.backup")
            shutil.copy2(source, destination)
            os.chmod(destination, 0o600)
            record["backup"] = destination
        external[name] = record
    return {
        "roots": roots,
        "keychain_path": keychain_target,
        "crane_device_identifier": active.crane_device_identifier,
        "external": external,
    }


def _restore_rollback(
    active: ActiveContainer,
    rollback: dict[str, Any],
    *,
    paths: WorkflowPaths,
    runner: CommandRunner,
) -> dict[str, Any]:
    problems: list[str] = []
    try:
        copy_staged_roots_to_active(
            active,
            rollback["roots"],
            os.path.join(
                os.path.dirname(rollback["keychain_path"]), "roots"
            ),
            paths=paths,
            strip_runtime=False,
        )
    except Exception as exc:
        problems.append(f"data:{type(exc).__name__}:{exc}")
    try:
        set_crane_device_identifier(
            active,
            str(rollback["crane_device_identifier"]),
            paths=paths,
        )
    except Exception as exc:
        problems.append(f"idfv:{type(exc).__name__}:{exc}")
    try:
        restore_keychain(
            active,
            rollback["keychain_path"],
            paths=paths,
            runner=runner,
        )
    except Exception as exc:
        problems.append(f"keychain:{type(exc).__name__}:{exc}")
    for name, record in (rollback.get("external") or {}).items():
        try:
            path = str(record.get("path") or "")
            if record.get("existed"):
                backup = str(record.get("backup") or "")
                if not backup or not os.path.isfile(backup):
                    raise FileNotFoundError(backup)
                _atomic_write(path, _read_bytes(backup), 0o644)
            else:
                with contextlib.suppress(FileNotFoundError):
                    os.remove(path)
        except Exception as exc:
            problems.append(f"{name}:{type(exc).__name__}:{exc}")
    return {"success": not problems, "problems": problems}


def _runtime_verification(
    selector: str,
    active: dict[str, ActiveContainer],
    profile_raw: bytes,
    *,
    verify_seconds: int,
    paths: WorkflowPaths,
    runner: CommandRunner,
) -> dict[str, Any]:
    if paths != DEFAULT_PATHS:
        raise AccountError(
            "runtime_test_paths_unsupported",
            "Live runtime verification requires the installed device paths",
            stage="verify_runtime",
        )
    if selector == "both":
        import meta_ghost_workflow

        result = meta_ghost_workflow.run_force_meta(
            verification_mode="account_creation"
        )
    elif selector == "instagram":
        import ig_ghost_workflow

        result = ig_ghost_workflow.run_force_active(
            verification_mode="account_creation"
        )
    else:
        return run_threads_standalone_verification(
            active["threads"],
            profile_raw,
            verify_seconds=verify_seconds,
            paths=paths,
            runner=runner,
        )
    if result.get("success") is not True:
        raise AccountError(
            "runtime_verification_failed",
            "The guarded restore verification did not pass",
            stage="verify_runtime",
            details={"result": result},
        )
    return result


def run_restore(
    selector: str,
    archive_path: str,
    *,
    job_id: str,
    work_dir: str,
    verify_seconds: int = DEFAULT_VERIFY_SECONDS,
    allow_version_mismatch: bool = False,
    paths: WorkflowPaths = DEFAULT_PATHS,
    runner: Optional[CommandRunner] = None,
    update: Optional[Any] = None,
    runtime_verifier: Optional[Any] = None,
) -> dict[str, Any]:
    runner = runner or CommandRunner()
    update = update or (lambda **_kwargs: None)
    apps = _selector_apps(selector)
    update(stage="validate_archive")
    try:
        validated = archive.validate_archive(archive_path)
    except archive.ArchiveError as exc:
        raise AccountError(
            exc.code,
            str(exc),
            stage="validate_archive",
            details=exc.details,
        ) from exc
    manifest = validated["manifest"]
    manifest_apps = manifest.get("apps") or {}
    missing_sections = [key for key in apps if key not in manifest_apps]
    if missing_sections:
        raise AccountError(
            "archive_section_missing",
            "Archive does not contain every selected application",
            stage="validate_archive",
            details={"missing": missing_sections},
        )
    profile_raw = validated["identity_raw"]
    identity = validated["identity"]
    unpack_root = os.path.join(work_dir, "unpack")
    try:
        archive.extract_archive(archive_path, unpack_root)
    except archive.ArchiveError as exc:
        raise AccountError(
            exc.code,
            str(exc),
            stage="extract_archive",
            details=exc.details,
        ) from exc

    active: dict[str, ActiveContainer] = {}
    inactive_before: dict[str, dict[str, str]] = {}
    isolation_before: dict[str, Any] = {}
    other_apps = sorted(set(APP_INFO) - set(apps))
    for app_key in other_apps:
        isolation_before[app_key] = isolation_state(
            app_key, paths=paths, runner=runner
        )

    update(stage="resolve_active")
    for app_key in apps:
        item = resolve_active_container(
            app_key, paths=paths, runner=runner, require_profile=False
        )
        active[app_key] = item
        inactive_before[app_key] = inactive_profile_hashes(item)
        expected_version = manifest_apps[app_key].get("app_version") or {}
        actual_version = installed_app_version(item.bundle_id, paths=paths)
        if not allow_version_mismatch and actual_version != expected_version:
            raise AccountError(
                "app_version_mismatch",
                "Installed app version does not match the archive",
                stage="preflight",
                details={
                    "app": app_key,
                    "archive": expected_version,
                    "installed": actual_version,
                },
            )

    rollback_root = os.path.join(work_dir, "rollback")
    shutil.rmtree(rollback_root, ignore_errors=True)
    os.makedirs(rollback_root, mode=0o700, exist_ok=True)
    rollbacks: dict[str, dict[str, Any]] = {}
    mutated = False
    restored_keychains: dict[str, dict[str, Any]] = {}
    identity_results: dict[str, dict[str, Any]] = {}
    runtime_result: dict[str, Any] = {}
    try:
        for app_key in apps:
            update(stage="stop_apps", current_app=app_key)
            stop_app(app_key, paths=paths, runner=runner)
            assert_same_active(
                active[app_key],
                paths=paths,
                runner=runner,
                stage="restore_after_stop",
                require_profile=False,
            )

        for app_key in apps:
            item = active[app_key]
            update(stage="validate_target", current_app=app_key)
            target_keychain = os.path.join(
                work_dir, f"{app_key}-target-keychain.plist"
            )
            target_keychain_fingerprint = dump_keychain(
                item,
                target_keychain,
                paths=paths,
                runner=runner,
            )
            target_marker = capture_account_marker(item)
            _validate_target_clean(
                item, target_marker, target_keychain_fingerprint
            )
            rollbacks[app_key] = _capture_rollback(
                item,
                rollback_root,
                target_keychain,
                paths=paths,
            )
            assert_same_active(
                item,
                paths=paths,
                runner=runner,
                stage="restore_after_rollback",
                require_profile=False,
            )

        mutated = True
        for app_key in apps:
            item = active[app_key]
            update(stage="restore_data", current_app=app_key)
            copy_archive_roots_to_active(
                app_key,
                item,
                manifest_apps[app_key],
                unpack_root,
                paths=paths,
            )
            set_crane_device_identifier(
                item,
                str(
                    manifest_apps[app_key].get(
                        "crane_device_identifier"
                    )
                    or ""
                ),
                paths=paths,
            )
            if app_key == "instagram":
                mode = "instagram_seed"
            elif selector == "threads":
                mode = "threads_standalone"
            else:
                mode = "threads_pair"
            identity_results[app_key] = install_restored_identity(
                item, profile_raw, identity, mode=mode
            )
            archived_keychain = os.path.join(
                unpack_root, "Apps", app_key, "Keychain.plist"
            )
            update(stage="restore_keychain", current_app=app_key)
            restore_keychain(
                item,
                archived_keychain,
                paths=paths,
                runner=runner,
            )
            verify_dump = os.path.join(
                work_dir, f"{app_key}-restored-keychain.plist"
            )
            restored_keychains[app_key] = dump_keychain(
                item,
                verify_dump,
                paths=paths,
                runner=runner,
            )
            expected_keychain = manifest_apps[app_key].get(
                "keychain_fingerprint"
            ) or {}
            if (
                restored_keychains[app_key].get("sha256")
                != expected_keychain.get("sha256")
            ):
                raise AccountError(
                    "keychain_fingerprint_mismatch",
                    "Restored keychain does not match the archive",
                    stage="restore_keychain",
                    details={
                        "app": app_key,
                        "expected": expected_keychain,
                        "actual": restored_keychains[app_key],
                    },
                )
            actual_marker = capture_account_marker(item)
            if not archive.account_markers_match(
                manifest_apps[app_key].get("account_marker"),
                actual_marker,
            ):
                raise AccountError(
                    "account_marker_mismatch",
                    "Restored account marker does not match the archive",
                    stage="validate_account",
                    details={
                        "app": app_key,
                        "expected": manifest_apps[app_key].get(
                            "account_marker"
                        ),
                        "actual": actual_marker,
                    },
                )
            assert_same_active(
                item,
                paths=paths,
                runner=runner,
                stage="restore_after_data",
                require_profile=True,
            )

        update(stage="verify_runtime")
        verifier = runtime_verifier or _runtime_verification
        runtime_result = verifier(
            selector,
            active,
            profile_raw,
            verify_seconds=max(DEFAULT_VERIFY_SECONDS, int(verify_seconds)),
            paths=paths,
            runner=runner,
        )

        final_apps: dict[str, Any] = {}
        for app_key in apps:
            item = assert_same_active(
                active[app_key],
                paths=paths,
                runner=runner,
                stage="restore_complete",
                require_profile=True,
            )
            actual_profile_hash = _sha256_path(item.profile_path)
            if actual_profile_hash != identity["profile_sha256"]:
                raise AccountError(
                    "restored_profile_changed",
                    "Active profile changed after runtime verification",
                    stage="validate_runtime",
                    details={
                        "app": app_key,
                        "expected": identity["profile_sha256"],
                        "actual": actual_profile_hash,
                    },
                )
            current_marker = capture_account_marker(item)
            expected_marker = manifest_apps[app_key].get("account_marker")
            if not archive.account_markers_match(
                expected_marker, current_marker
            ):
                raise AccountError(
                    "account_marker_mismatch",
                    "Account marker changed during runtime verification",
                    stage="validate_runtime",
                    details={"app": app_key},
                )
            refreshed = resolve_active_container(
                app_key,
                paths=paths,
                runner=runner,
                require_profile=True,
            )
            expected_idfv = str(
                manifest_apps[app_key].get("crane_device_identifier") or ""
            )
            if refreshed.crane_device_identifier != expected_idfv:
                raise AccountError(
                    "crane_device_identifier_mismatch",
                    "Restored Crane IDFV changed",
                    stage="validate_runtime",
                    details={
                        "app": app_key,
                        "expected": expected_idfv,
                        "actual": refreshed.crane_device_identifier,
                    },
                )
            final_apps[app_key] = {
                "active_container": {
                    "id": item.identifier,
                    "name": item.name,
                },
                "profile_sha256": actual_profile_hash,
                "crane_device_identifier_verified": True,
                "account_marker": current_marker,
                "keychain_fingerprint": restored_keychains[app_key],
                "identity_restore": identity_results[app_key],
            }
            inactive_after = inactive_profile_hashes(item)
            if inactive_after != inactive_before[app_key]:
                raise AccountError(
                    "inactive_container_changed",
                    "An inactive Crane profile changed during restore",
                    stage="validate_isolation",
                    details={
                        "app": app_key,
                        "before": inactive_before[app_key],
                        "after": inactive_after,
                    },
                )

        isolation_after: dict[str, Any] = {}
        for app_key in other_apps:
            isolation_after[app_key] = isolation_state(
                app_key, paths=paths, runner=runner
            )
            if isolation_after[app_key] != isolation_before[app_key]:
                raise AccountError(
                    "unselected_app_changed",
                    "An unselected application changed during restore",
                    stage="validate_isolation",
                    details={
                        "app": app_key,
                        "before": isolation_before[app_key],
                        "after": isolation_after[app_key],
                    },
                )
        mutated = False
        return {
            "success": True,
            "verdict": "PASS",
            "action": "account_restore",
            "job_id": job_id,
            "selection": selector,
            "archive_path": os.path.abspath(archive_path),
            "archive_sha256": validated["archive_sha256"],
            "identity": identity,
            "apps": final_apps,
            "runtime": runtime_result,
            "verification_seconds": max(
                DEFAULT_VERIFY_SECONDS, int(verify_seconds)
            ),
            "unselected_apps_unchanged": True,
            "archive_preserved": os.path.isfile(archive_path),
        }
    except Exception as exc:
        if mutated:
            update(stage="rollback")
            rollback_results: dict[str, Any] = {}
            for app_key in reversed(apps):
                item = active.get(app_key)
                rollback = rollbacks.get(app_key)
                if not item or not rollback:
                    continue
                with contextlib.suppress(Exception):
                    stop_app(app_key, paths=paths, runner=runner)
                rollback_results[app_key] = _restore_rollback(
                    item,
                    rollback,
                    paths=paths,
                    runner=runner,
                )
            failed = {
                key: value
                for key, value in rollback_results.items()
                if value.get("success") is not True
            }
            if failed:
                raise AccountError(
                    "rollback_failed",
                    "Restore failed and target rollback was incomplete",
                    stage="rollback",
                    details={
                        "original_error": f"{type(exc).__name__}: {exc}",
                        "rollback": rollback_results,
                    },
                ) from exc
        raise


def _job_status_path(job_id: str, paths: WorkflowPaths) -> str:
    return os.path.join(paths.jobs_root, f"{job_id}.json")


def _job_spec_path(job_id: str, paths: WorkflowPaths) -> str:
    return os.path.join(paths.jobs_root, f"{job_id}.spec.json")


def _job_work_dir(job_id: str, paths: WorkflowPaths) -> str:
    return os.path.join(paths.work_root, job_id)


def _pid_alive(pid: Any) -> bool:
    try:
        os.kill(int(pid), 0)
        return int(pid) > 0
    except Exception:
        return False


def _update_job(
    job_id: str,
    paths: WorkflowPaths,
    **updates: Any,
) -> dict[str, Any]:
    current = _read_json(_job_status_path(job_id, paths), {}) or {}
    current.update(updates)
    current["job_id"] = job_id
    current["updated_at"] = _now()
    _write_json(_job_status_path(job_id, paths), current)
    _write_json(paths.latest_job, current)
    return current


def _active_account_job(paths: WorkflowPaths) -> dict[str, Any] | None:
    if not os.path.isdir(paths.jobs_root):
        return None
    for name in sorted(os.listdir(paths.jobs_root), reverse=True):
        if not name.endswith(".json") or name.endswith(".spec.json"):
            continue
        value = _read_json(os.path.join(paths.jobs_root, name), {}) or {}
        if value.get("state") in {"starting", "running"} and _pid_alive(
            value.get("pid")
        ):
            return value
    return None


def _new_job_id(action: str) -> str:
    return (
        f"ghostacct_{action}_{int(_now() * 1000)}_"
        f"{uuid.uuid4().hex[:8]}"
    )


def start_job(
    action: str,
    selector: str,
    *,
    output: str = "",
    archive_path: str = "",
    verify_seconds: int = DEFAULT_VERIFY_SECONDS,
    allow_version_mismatch: bool = False,
    paths: WorkflowPaths = DEFAULT_PATHS,
) -> tuple[dict[str, Any], int]:
    _selector_apps(selector)
    os.makedirs(paths.jobs_root, mode=0o700, exist_ok=True)
    os.makedirs(paths.work_root, mode=0o700, exist_ok=True)
    running = _active_account_job(paths)
    if running:
        return (
            {
                "accepted": False,
                "success": False,
                "error": "workflow_busy",
                "job_id": running.get("job_id"),
                "state": running.get("state"),
            },
            1,
        )
    if action == "restore" and not os.path.isfile(archive_path):
        return (
            {
                "accepted": False,
                "success": False,
                "error": "archive_missing",
                "archive_path": archive_path,
            },
            1,
        )
    job_id = _new_job_id(action)
    spec = {
        "job_id": job_id,
        "action": action,
        "selector": selector,
        "output": output,
        "archive_path": os.path.abspath(archive_path) if archive_path else "",
        "verify_seconds": max(DEFAULT_VERIFY_SECONDS, int(verify_seconds)),
        "allow_version_mismatch": bool(allow_version_mismatch),
        "created_at": _now(),
    }
    _write_json(_job_spec_path(job_id, paths), spec)
    initial = {
        "schema": 1,
        "accepted": True,
        "success": False,
        "verdict": "",
        "job_id": job_id,
        "action": f"account_{action}",
        "selection": selector,
        "state": "starting",
        "stage": "queued",
        "pid": 0,
        "started_at": _now(),
        "finished_at": 0,
        "elapsed_seconds": 0,
        "error": "",
    }
    _write_json(_job_status_path(job_id, paths), initial)
    _write_json(paths.latest_job, initial)
    command = [
        sys.executable,
        os.path.realpath(__file__),
        "_worker",
        job_id,
    ]
    process = subprocess.Popen(
        command,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
        close_fds=True,
    )
    current = _update_job(job_id, paths, pid=process.pid, state="running")
    response = {
        "accepted": True,
        "success": True,
        "job_id": job_id,
        "pid": process.pid,
        "action": current["action"],
        "selection": selector,
        "state": "running",
        "status_command": f"/var/jb/usr/bin/crane-restore status {job_id}",
        "status_path": _job_status_path(job_id, paths),
    }
    return response, 0


def run_worker(
    job_id: str,
    *,
    paths: WorkflowPaths = DEFAULT_PATHS,
) -> int:
    spec = _read_json(_job_spec_path(job_id, paths), None)
    if not isinstance(spec, dict):
        return 2
    started = _now()
    _update_job(
        job_id,
        paths,
        state="running",
        stage="lock",
        pid=os.getpid(),
        started_at=started,
    )
    os.makedirs(os.path.dirname(paths.global_lock), exist_ok=True)
    lock = open(paths.global_lock, "a+")
    acquired = False
    work_dir = _job_work_dir(job_id, paths)
    os.makedirs(work_dir, mode=0o700, exist_ok=True)

    def update(**values: Any) -> None:
        _update_job(job_id, paths, state="running", **values)

    try:
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            acquired = True
        except OSError as exc:
            raise AccountError(
                "workflow_busy",
                "Another Crane account job is already running",
                stage="lock",
            ) from exc
        action = str(spec.get("action") or "")
        selector = str(spec.get("selector") or DEFAULT_SELECTOR)
        if action == "backup":
            result = run_backup(
                selector,
                str(spec.get("output") or paths.default_output),
                job_id=job_id,
                work_dir=work_dir,
                paths=paths,
                update=update,
            )
        elif action == "restore":
            result = run_restore(
                selector,
                str(spec.get("archive_path") or ""),
                job_id=job_id,
                work_dir=work_dir,
                verify_seconds=int(
                    spec.get("verify_seconds") or DEFAULT_VERIFY_SECONDS
                ),
                allow_version_mismatch=bool(spec.get("allow_version_mismatch")),
                paths=paths,
                update=update,
            )
        else:
            raise AccountError(
                "action_invalid",
                f"Unknown account job action: {action}",
                stage="validate_arguments",
            )
        finished = _now()
        final_status = dict(result)
        final_status.pop("job_id", None)
        final_status.update(
            {
                "accepted": True,
                "state": "finished",
                "stage": "complete",
                "finished_at": finished,
                "elapsed_seconds": round(finished - started, 3),
                "error": "",
            }
        )
        _update_job(job_id, paths, **final_status)
        return 0
    except AccountError as exc:
        finished = _now()
        _update_job(
            job_id,
            paths,
            accepted=True,
            success=False,
            verdict="FAIL",
            state="finished",
            stage=exc.stage,
            error=exc.code,
            message=str(exc),
            problems=exc.details,
            finished_at=finished,
            elapsed_seconds=round(finished - started, 3),
        )
        return 1
    except archive.ArchiveError as exc:
        finished = _now()
        _update_job(
            job_id,
            paths,
            accepted=True,
            success=False,
            verdict="FAIL",
            state="finished",
            stage="archive",
            error=exc.code,
            message=str(exc),
            problems=exc.details,
            finished_at=finished,
            elapsed_seconds=round(finished - started, 3),
        )
        return 1
    except Exception as exc:
        finished = _now()
        _update_job(
            job_id,
            paths,
            accepted=True,
            success=False,
            verdict="FAIL",
            state="finished",
            stage="unexpected",
            error=type(exc).__name__,
            message=str(exc),
            finished_at=finished,
            elapsed_seconds=round(finished - started, 3),
        )
        return 1
    finally:
        _remove_task_files(paths)
        shutil.rmtree(work_dir, ignore_errors=True)
        if acquired:
            with contextlib.suppress(Exception):
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
        lock.close()


def read_job_status(
    job_id: str,
    *,
    paths: WorkflowPaths = DEFAULT_PATHS,
) -> tuple[dict[str, Any], int]:
    value = _read_json(_job_status_path(job_id, paths), None)
    if not isinstance(value, dict):
        return (
            {
                "success": False,
                "error": "job_not_found",
                "job_id": job_id,
            },
            1,
        )
    return value, 0


def _print_json(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="crane-restore")
    subparsers = parser.add_subparsers(dest="command", required=True)

    backup_parser = subparsers.add_parser("account-backup")
    backup_parser.add_argument(
        "selector",
        nargs="?",
        default=DEFAULT_SELECTOR,
        choices=sorted(archive.VALID_SELECTORS),
    )
    backup_parser.add_argument("--output", default=DEFAULT_PATHS.default_output)

    restore_parser = subparsers.add_parser("account-restore")
    restore_parser.add_argument(
        "selector",
        nargs="?",
        default=DEFAULT_SELECTOR,
        choices=sorted(archive.VALID_SELECTORS),
    )
    restore_parser.add_argument("--archive", required=True)
    restore_parser.add_argument(
        "--verify-seconds",
        type=int,
        default=DEFAULT_VERIFY_SECONDS,
    )
    restore_parser.add_argument(
        "--allow-version-mismatch",
        action="store_true",
        default=False,
    )

    status_parser = subparsers.add_parser("status")
    status_parser.add_argument("job_id")

    worker_parser = subparsers.add_parser("_worker")
    worker_parser.add_argument("job_id")
    return parser


def main(argv: Optional[list[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "account-backup":
        value, returncode = start_job(
            "backup",
            args.selector,
            output=args.output,
        )
    elif args.command == "account-restore":
        value, returncode = start_job(
            "restore",
            args.selector,
            archive_path=args.archive,
            verify_seconds=args.verify_seconds,
            allow_version_mismatch=bool(args.allow_version_mismatch),
        )
    elif args.command == "status":
        value, returncode = read_job_status(args.job_id)
    else:
        return run_worker(args.job_id)
    _print_json(value)
    return returncode


if __name__ == "__main__":
    raise SystemExit(main())
