----------------------------------------------------------------
-- TapCore BAS Standalone Runtime (bas_runtime.lua)
-- Runs BAS XML workflows compiled by bas2lua.js directly on iPhone
-- without a PC. Executes :3000 device actions in-process with exact
-- sv.lua OCR/COLOR/POINTS/RUNLUA/URL/TEXT semantics and routes
-- external HTTP/HTTPS (+ HTTP/SOCKS5 proxy) via TapCore httpRequest.
----------------------------------------------------------------
local json = require("json")
local ok_sock, socket = pcall(require, "socket")

local M = {}

-- Sentinel representing explicit JSON null (distinct from missing "" or Lua nil)
local NULL_VAL = setmetatable({}, {
    __tostring = function() return "null" end
})
M.NULL = NULL_VAL

local DATA_DIR = "/var/jb/var/mobile/Library/TapCore/Data"

local function now_sec()
    if ok_sock and socket and socket.gettime then return socket.gettime() end
    return os.time()
end

local function trim(s)
    return (tostring(s or "")):match("^%s*(.-)%s*$")
end

local function read_file(path)
    local f = io.open(path, "rb")
    if not f then return nil end
    local d = f:read("*a")
    f:close()
    return d
end

local function write_file_atomic(path, content)
    local tmp = path .. ".tmp"
    local f = io.open(tmp, "wb")
    if not f then
        f = io.open(path, "wb")
        if not f then return false end
        f:write(content)
        f:close()
        return true
    end
    f:write(content)
    f:close()
    os.rename(tmp, path)
    return true
end

----------------------------------------------------------------
-- JSON / VALUE HELPERS (JS-COMPATIBLE SEMANTICS)
----------------------------------------------------------------
local function is_json_null(v)
    return v == nil or v == NULL_VAL or (json.null ~= nil and v == json.null)
end

local function to_number(v)
    if type(v) == "number" then
        if v == v and v ~= math.huge and v ~= -math.huge then return v end
        return nil
    end
    if type(v) == "string" then
        local n = tonumber(v)
        if n and n == n and n ~= math.huge and n ~= -math.huge then return n end
    end
    return nil
end

local function parse_bool(v, def)
    if is_json_null(v) then return def end
    if type(v) == "boolean" then return v end
    if v == 1 or v == "1" or v == "true" then return true end
    if v == 0 or v == "0" or v == "false" then return false end
    return nil
end

-- Escape newlines/tabs inside JSON strings and strip trailing commas (from sv.lua)
local function fix_json(s)
    local out, n = {}, 0
    local inStr, esc = false, false
    for i = 1, #s do
        local c = s:sub(i, i)
        if inStr then
            if esc then esc = false
            elseif c == "\\" then esc = true
            elseif c == '"' then inStr = false
            elseif c == "\n" then c = "\\n"
            elseif c == "\r" then c = "\\r"
            elseif c == "\t" then c = "\\t"
            end
        elseif c == '"' then
            inStr = true
        elseif c == "," and s:find("^%s*[}%]]", i + 1) then
            c = ""
        end
        n = n + 1
        out[n] = c
    end
    return table.concat(out)
end

local function decode_json_lenient(raw)
    if type(raw) ~= "string" then return false, nil end
    local ok, data = pcall(json.decode, raw)
    if not ok then
        ok, data = pcall(json.decode, fix_json(raw))
    end
    return ok, data
end

----------------------------------------------------------------
-- LOCAL DEVICE ENGINE (EXACT PARITY WITH tapcore/scripts/sv.lua)
----------------------------------------------------------------
local TAP_HOLD_US          = 40000
local TOUCH_SETTLE_US      = 50000
local POLL_INTERVAL_S      = 0.03
local OCR_INTERVAL_S       = 0.08
local OCR_ACCURATE_AFTER_S = 1.5
local OCR_ACCURATE_GAP_S   = 6
local OCR_SETTLE_S         = 0.25
local OCR_SETTLE_PX        = 12

local SCRIPT_NULL = {}

local function dev_is_null(v)
    return v == nil or v == SCRIPT_NULL or is_json_null(v)
end

local function normalize_region(region)
    if dev_is_null(region) then return nil end
    if type(region) ~= "table" then return nil, "region must be an object or array" end
    local x = to_number(region.x or region[1])
    local y = to_number(region.y or region[2])
    local w = to_number(region.width or region[3])
    local h = to_number(region.height or region[4])
    if not x or not y or not w or not h or x < 0 or y < 0 or w <= 0 or h <= 0 then
        return nil, "region requires x/y >= 0 and width/height > 0"
    end
    return {x, y, w, h}
end

local function parse_find_colors_script(raw)
    if type(raw) ~= "string" or trim(raw) == "" then return nil, "script is empty" end
    if #raw > 262144 then return nil, "script exceeds 256 KiB" end
    local ok, result = pcall(function()
        local pos, kind, value = 1, nil, nil
        local vars = {}
        local function fail_p(msg) error(msg .. " at script byte " .. pos, 0) end
        local function next_tok()
            while pos <= #raw do
                local c, pair = raw:sub(pos, pos), raw:sub(pos, pos + 1)
                if c:match("%s") then
                    pos = pos + 1
                elseif pair == "--" then
                    local eq = raw:match("^%-%-%[(=*)%[", pos)
                    if eq then
                        local close = "]" .. eq .. "]"
                        local ending = raw:find(close, pos + 4 + #eq, true)
                        if not ending then fail_p("Unclosed comment") end
                        pos = ending + #close
                    else
                        pos = raw:find("[\r\n]", pos + 2) or (#raw + 1)
                    end
                elseif pair == "//" then
                    pos = raw:find("[\r\n]", pos + 2) or (#raw + 1)
                elseif pair == "/*" then
                    local ending = raw:find("*/", pos + 2, true)
                    if not ending then fail_p("Unclosed comment") end
                    pos = ending + 2
                else
                    break
                end
            end
            if pos > #raw then kind, value = "eof", nil; return end
            local c = raw:sub(pos, pos)
            if c == '"' or c == "'" then
                local quote, parts = c, {}
                pos = pos + 1
                while pos <= #raw do
                    c = raw:sub(pos, pos)
                    pos = pos + 1
                    if c == quote then kind, value = "string", table.concat(parts); return end
                    if c == "\\" then
                        local escaped = raw:sub(pos, pos)
                        local escapes = {n="\n", r="\r", t="\t", ['\\']='\\', ['"']='"', ["'"]="'", ['/']='/'}
                        if not escapes[escaped] then fail_p("Unsupported string escape") end
                        c = escapes[escaped]
                        pos = pos + 1
                    end
                    parts[#parts + 1] = c
                end
                fail_p("Unclosed string")
            end
            local rest = raw:sub(pos)
            local ident = rest:match("^[%a_$][%w_$]*")
            if ident then
                pos = pos + #ident
                kind, value = "identifier", ident
                return
            end
            local num = rest:match("^[+-]?0[xX][%da-fA-F]+")
                or rest:match("^[+-]?%d+%.?%d*[eE][+-]?%d+")
                or rest:match("^[+-]?%.%d+[eE][+-]?%d+")
                or rest:match("^[+-]?%d+%.?%d*")
                or rest:match("^[+-]?%.%d+")
            if num then
                pos = pos + #num
                kind, value = "number", to_number(num)
                if value == nil then fail_p("Invalid number") end
                return
            end
            pos = pos + 1
            kind, value = c, c
        end
        local function expect(tok)
            if kind ~= tok then fail_p("Expected '" .. tok .. "'") end
            next_tok()
        end
        local parse_val
        parse_val = function(depth)
            if depth > 8 then fail_p("Options nested too deeply") end
            if kind == "{" then
                next_tok()
                if kind == "number" or kind == "[" or kind == "{"
                    or (kind == "identifier" and (value == "true" or value == "false" or value == "nil" or value == "null")) then
                    local arr = {}
                    while kind ~= "}" do
                        arr[#arr + 1] = parse_val(depth + 1)
                        if kind ~= "," and kind ~= ";" then break end
                        next_tok()
                    end
                    expect("}")
                    return arr
                end
                local obj, seen = {}, {}
                while kind ~= "}" do
                    if kind ~= "identifier" and kind ~= "string" then fail_p("Expected object key") end
                    local k = value
                    if seen[k] then fail_p("Duplicate key " .. k) end
                    seen[k] = true
                    next_tok()
                    if kind ~= ":" and kind ~= "=" then fail_p("Expected ':' or '='") end
                    next_tok()
                    obj[k] = parse_val(depth + 1)
                    if kind ~= "," and kind ~= ";" then break end
                    next_tok()
                end
                expect("}")
                return obj
            elseif kind == "[" then
                next_tok()
                local arr = {}
                while kind ~= "]" do
                    arr[#arr + 1] = parse_val(depth + 1)
                    if kind ~= "," then break end
                    next_tok()
                end
                expect("]")
                return arr
            elseif kind == "number" or kind == "string" then
                local lit = value
                next_tok()
                return lit
            elseif kind == "identifier" then
                local lit
                if value == "true" then lit = true
                elseif value == "false" then lit = false
                elseif value == "null" or value == "nil" then lit = SCRIPT_NULL
                elseif vars[value] ~= nil then lit = vars[value]
                else fail_p("Unknown variable '" .. value .. "'") end
                next_tok()
                return lit
            end
            fail_p("Expected literal value")
        end
        local function attach_sample(options)
            local sc, sx, sy
            for c, x, y in raw:gmatch("([%+%-]?0[xX][%da-fA-F]+)%s*,%s*%(%s*([%+%-]?[%d%.]+)%s*,%s*([%+%-]?[%d%.]+)%s*%)") do
                sc, sx, sy = c, x, y
            end
            if not sc then
                for c, x, y in raw:gmatch("([%+%-]?%d+%.?%d*)%s*,%s*%(%s*([%+%-]?[%d%.]+)%s*,%s*([%+%-]?[%d%.]+)%s*%)") do
                    sc, sx, sy = c, x, y
                end
            end
            if sc then
                options.sample = { color = to_number(sc), x = to_number(sx), y = to_number(sy) }
            end
            return options
        end

        next_tok()
        local fname
        while kind ~= "eof" do
            if kind == "identifier" and (value == "findColors" or value == "findColor") then
                local n = value
                next_tok()
                if kind == "(" then fname = n; break end
            elseif kind == "identifier" then
                local n = value
                next_tok()
                if kind == "=" then
                    next_tok()
                    if kind == "{" or kind == "[" or kind == "number" or kind == "string" then
                        local okL, lit = pcall(parse_val, 0)
                        if okL then vars[n] = lit end
                    end
                end
            else
                next_tok()
            end
        end
        if not fname then fail_p("Missing findColors/findColor call") end
        next_tok()
        local args = {}
        while kind ~= ")" do
            args[#args + 1] = parse_val(0)
            if kind ~= "," then break end
            next_tok()
        end
        expect(")")
        if fname == "findColors" then
            local first = args[1]
            if #args == 1 and type(first) == "table" and first.colors ~= nil then return first end
            return {colors = first, count = args[2], region = args[3], debug = args[4],
                rightToLeft = args[5], bottomToTop = args[6]}
        end
        if type(args[1]) == "table" and not dev_is_null(args[1]) then
            local opts = args[1]
            opts.colors = {{color = opts.color, x = 0, y = 0}}
            opts.color = nil
            return attach_sample(opts)
        end
        return attach_sample({
            colors = {{color = args[1], x = 0, y = 0}},
            count = args[2], region = args[3], debug = args[4],
            rightToLeft = args[5], bottomToTop = args[6]
        })
    end)
    if not ok then return nil, tostring(result) end
    return result
end

local function color_close(a, b, tol)
    if a == b then return true end
    if not a or tol <= 0 then return false end
    for _ = 1, 3 do
        if math.abs(a % 256 - b % 256) > tol then return false end
        a, b = math.floor(a / 256), math.floor(b / 256)
    end
    return true
end

----------------------------------------------------------------
-- RUNTIME INSTANCE CONSTRUCTOR
----------------------------------------------------------------
function M.new(opts)
    opts = opts or {}
    local B = {}

    local get_now = opts.now or now_sec

    -- Native hardware bindings (injectable for unit testing)
    local hw = {
        touchDown        = opts.touchDown        or _G.touchDown,
        touchMove        = opts.touchMove        or _G.touchMove,
        touchUp          = opts.touchUp          or _G.touchUp,
        usleep           = opts.usleep           or _G.usleep,
        keyDown          = opts.keyDown          or _G.keyDown,
        keyUp            = opts.keyUp            or _G.keyUp,
        inputText        = opts.inputText        or _G.inputText,
        copyText         = opts.copyText         or _G.copyText,
        getColor         = opts.getColor         or _G.getColor,
        getColors        = opts.getColors        or _G.getColors,
        findColors       = opts.findColors       or _G.findColors,
        ocr              = opts.ocr              or _G.ocr,
        findImage        = opts.findImage        or _G.findImage,
        execute          = opts.execute          or _G.execute,
        openURL          = opts.openURL          or _G.openURL,
        rootDir          = opts.rootDir          or _G.rootDir,
        appKill          = opts.appKill          or _G.appKill,
        saveToSystemAlbum= opts.saveToSystemAlbum or _G.saveToSystemAlbum,
        clearSystemAlbum = opts.clearSystemAlbum or _G.clearSystemAlbum,
        httpRequest      = opts.httpRequest      or _G.httpRequest,
    }

    local data_dir     = opts.data_dir     or DATA_DIR
    local config_path  = opts.config_path  or (data_dir .. "/igreg_config.json")
    local state_path   = opts.state_path   or (data_dir .. "/igreg_state.json")
    local control_path = opts.control_path or (data_dir .. "/igreg_control.json")

    local ocrAccurateCost = 3.5
    local basglobal = {}

    -- HTTP client state (main + internal)
    local http_main = { status = 0, body = "", headers = {}, proxy = nil }
    local http_internal = { status = 0, body = "", headers = {}, proxy = nil }
    local active_http = http_main

    -- Runtime config & resources
    local config = {}
    local res_lists = {}
    local res_cursors = {}
    local local_wifi_ip = opts.local_ip or nil

    -- Live telemetry state
    local state = {
        running = true,
        started_at = os.time(),
        updated_at = os.time(),
        attempt = 0,
        success_count = 0,
        fail_count = 0,
        target_count = 1,
        current_fn = "",
        current_step = "Starting",
        current_line = 0,
        last_username = "",
        last_proxy = "",
        last_error = "",
        last_message = "",
        recent_accounts = {},
        finished_reason = "",
        stop_after_current = false,
        watchdog_resets = 0
    }
    local last_state_write = 0
    local attempt_started_at = nil
    local active_loop_deadline = nil

    local function get_attempt_timeout_s()
        if opts.attempt_timeout_s ~= nil then return tonumber(opts.attempt_timeout_s) or 0 end
        local vm = tonumber(config["Watchdog 1 Lượt (phút)"])
        if vm ~= nil then return vm * 60 end
        local vs = tonumber(config["Watchdog 1 Lượt (s)"])
        if vs ~= nil then return vs end
        return 600 -- 10 phút mặc định
    end

    local function get_loop_timeout_s()
        if opts.loop_timeout_s ~= nil then return tonumber(opts.loop_timeout_s) or 0 end
        local vm = tonumber(config["Watchdog Vòng Lặp (phút)"])
        if vm ~= nil then return vm * 60 end
        local vs = tonumber(config["Watchdog Vòng Lặp (s)"])
        if vs ~= nil then return vs end
        return 300 -- 5 phút mặc định
    end

    local function check_watchdog(ctx_label)
        if not attempt_started_at then return end
        local now = now_sec()
        local max_att = get_attempt_timeout_s()
        if max_att > 0 and (now - attempt_started_at) > max_att then
            error({
                __bas_signal = "watchdog",
                message = string.format("WATCHDOG: Quá %.0fs cho 1 lượt (tại %s)", max_att, tostring(ctx_label or state.current_step or "?"))
            }, 0)
        end
        if active_loop_deadline and now > active_loop_deadline then
            error({
                __bas_signal = "watchdog",
                message = string.format("WATCHDOG: Treo vòng lặp quá %.0fs (tại %s)", get_loop_timeout_s(), tostring(ctx_label or state.current_step or "?"))
            }, 0)
        end
    end

    local function read_soft_stop()
        if opts.disable_state_file then return false end
        local raw = read_file(control_path)
        if not raw or #raw == 0 then return false end
        local ok, ctl = decode_json_lenient(raw)
        if ok and type(ctl) == "table" and ctl.stop_after_current == true then
            return true
        end
        return false
    end

    local function clear_soft_stop()
        state.stop_after_current = false
        if opts.disable_state_file then return end
        write_file_atomic(control_path, '{"stop_after_current":false}')
    end

    local function save_state(force)
        if opts.disable_state_file then return end
        local t = now_sec()
        if not force and (t - last_state_write) < 0.8 then return end
        last_state_write = t
        state.updated_at = os.time()
        state.stop_after_current = read_soft_stop()
        local ok, enc = pcall(json.encode, state)
        if ok and enc then
            write_file_atomic(state_path, enc)
        end
    end

    local function detect_wifi_ip()
        if local_wifi_ip then return local_wifi_ip end
        if hw.httpRequest then
            local r = hw.httpRequest({ url = "http://127.0.0.1:8080/api/status", method = "GET", timeout = 3 })
            if r and r.ok and r.status == 200 then
                local ok, d = decode_json_lenient(r.body)
                if ok and type(d) == "table" and type(d.ip) == "string" and #d.ip > 0 then
                    local_wifi_ip = d.ip
                    return local_wifi_ip
                end
            end
        end
        local_wifi_ip = "127.0.0.1"
        return local_wifi_ip
    end

    local function split_nonempty_lines(raw)
        local out = {}
        if type(raw) == "table" then
            for _, v in ipairs(raw) do
                local t = trim(v)
                if #t > 0 then out[#out + 1] = t end
            end
        elseif type(raw) == "string" then
            for line in (raw .. "\n"):gmatch("([^\r\n]*)\r?\n") do
                local t = trim(line)
                if #t > 0 then out[#out + 1] = t end
            end
        end
        return out
    end

    function B.load_config()
        local loaded = nil
        if opts.config then
            loaded = opts.config
        else
            local raw = read_file(config_path)
            if raw then
                local ok, d = decode_json_lenient(raw)
                if ok and type(d) == "table" then loaded = d end
            end
        end
        loaded = loaded or {}
        local raw_max = tonumber(loaded["Tạo Tối Đa"] or loaded.max_accounts)
        if raw_max == nil then raw_max = 1 end
        config = {
            ["Threads"]      = tostring(loaded["Threads"] or loaded.threads or "1"),
            ["Function"]     = loaded["Function"] or loaded.func or "Tạo Tài Khoản",
            ["Tạo Tối Đa"]   = (raw_max <= 0) and 999999 or raw_max,
            ["IP Iphone"]    = trim(loaded["IP Iphone"] or loaded.ip_iphone or ""),
            ["Proxy"]        = loaded["Proxy"] or loaded.proxies or "",
            ["Choose Proxy"] = loaded["Choose Proxy"] or loaded.choose_proxy or "Grid",
            ["Type Proxy"]   = loaded["Type Proxy"] or loaded.type_proxy or "Socks5",
            ["Shop API"]     = loaded["Shop API"] or loaded.shop_api or "API Icloud",
            ["Type"]         = loaded["Type"] or loaded.shop_type or "Phone",
            ["Add Profile"]  = (loaded["Add Profile"] == true or loaded.add_profile == true),
            ["Path IMG"]     = loaded["Path IMG"] or loaded.path_img or "",
            ["List User"]    = loaded["List User"] or "",
            ["Snap"]         = loaded["Snap"] or "",
        }
        if type(loaded.extra_resources) == "table" then
            for k, v in pairs(loaded.extra_resources) do
                config[k] = v
            end
        end
        if config["IP Iphone"] == "" then
            config["IP Iphone"] = detect_wifi_ip()
        end
        res_lists["Proxy"]     = split_nonempty_lines(config["Proxy"])
        res_lists["IP Iphone"] = split_nonempty_lines(config["IP Iphone"])
        res_lists["List User"] = split_nonempty_lines(config["List User"])
        res_lists["Snap"]      = split_nonempty_lines(config["Snap"])
        res_cursors["Proxy"] = res_cursors["Proxy"] or 0
        state.target_count = raw_max <= 0 and 0 or raw_max
        save_state(true)
    end

    B.load_config()

    ------------------------------------------------------------
    -- BAS SLEEP / LOG / THREAD / RESOURCE PRIMITIVES
    ------------------------------------------------------------
    local function dev_usleep(us)
        if hw.usleep then
            local rem = math.floor(us + 0.5)
            while rem > 0 do
                check_watchdog("sleep")
                local chunk = rem > 500000 and 500000 or rem
                hw.usleep(chunk)
                rem = rem - chunk
            end
        end
    end

    function B.sleep(ms)
        local n = to_number(ms) or 0
        if n > 0 then dev_usleep(n * 1000) end
    end

    function B.log(msg)
        local s = B.str(msg)
        state.last_message = s
        print("[IGReg] " .. s)
        save_state(false)
    end

    function B.logger_log(obj)
        local msg = type(obj) == "table" and (obj.en or obj.ru or "") or tostring(obj or "")
        B.log(msg)
    end

    function B.thread_number()
        return 1
    end

    function B.set_step(fn_name, sec_name, line_no)
        state.current_fn = fn_name or ""
        if sec_name and #sec_name > 0 then
            state.current_step = sec_name
        end
        state.current_line = line_no or 0
        save_state(false)
    end

    function B.rpick(name)
        if res_lists[name] then
            local copy = {}
            for i, v in ipairs(res_lists[name]) do copy[i] = v end
            return copy
        end
        local val = config[name]
        if type(val) == "table" then return val end
        if type(val) == "string" and #val > 0 then return {val} end
        return {}
    end

    function B.rs(name, take_next, _not_reuse)
        if name == "Proxy" or name == "List User" then
            local list = res_lists[name] or {}
            if take_next then
                local idx = (res_cursors[name] or 0) + 1
                if idx > #list then
                    error("Resource '" .. tostring(name) .. "' is empty", 0)
                end
                res_cursors[name] = idx
                return list[idx]
            else
                return list[math.max(1, res_cursors[name] or 1)] or ""
            end
        elseif name == "Path IMG" then
            local p = config["Path IMG"]
            if type(p) == "string" and #p > 0 then return p end
            local dir = (hw.rootDir and hw.rootDir() or "/var/jb/var/mobile/Library/TapCore/Scripts") .. "/Avatars"
            if hw.execute then
                local out = hw.execute("ls -1 '" .. dir .. "' 2>/dev/null | head -n 1")
                local fn = trim(out)
                if #fn > 0 then return dir .. "/" .. fn end
            end
            return ""
        end
        local v = config[name]
        if v == nil then return "" end
        return v
    end

    function B.reload(name)
        if name == "Proxy" then
            res_lists["Proxy"] = split_nonempty_lines(config["Proxy"])
            res_cursors["Proxy"] = 0
        else
            res_cursors[name] = 0
        end
    end

    function B.rinfo(name, key)
        if key == "Location" then return config_path end
        return ""
    end

    function B.native_fileinfo(path)
        local f = io.open(path or "", "rb")
        local exists = (f ~= nil)
        local size = 0
        if f then
            size = f:seek("end") or 0
            f:close()
        end
        return json.encode({
            exists = exists,
            size = size,
            directory = data_dir,
            is_directory = false,
            last_modified = os.time()
        })
    end

    function B.project_directory()
        return data_dir
    end

    -- basglobal P / PSet
    function B.pset(ns, key, val)
        basglobal[ns .. ":" .. key] = tostring(val)
    end

    function B.pget(ns, key)
        return basglobal[ns .. ":" .. key]
    end

    ------------------------------------------------------------
    -- JS-COMPATIBLE OPERATORS & UTILITIES
    ------------------------------------------------------------
    function B.truthy(v)
        if v == nil or v == false or v == 0 or v == "" or v == NULL_VAL or (json.null ~= nil and v == json.null) then
            return false
        end
        return true
    end

    function B.str(v)
        if is_json_null(v) then return "" end
        if type(v) == "boolean" then return v and "true" or "false" end
        if type(v) == "number" then
            if v == math.floor(v) and math.abs(v) < 1e15 then
                return string.format("%d", v)
            end
            return tostring(v)
        end
        if type(v) == "table" then
            local ok, s = pcall(json.encode, v)
            return ok and s or ""
        end
        return tostring(v)
    end

    function B.num(v)
        if type(v) == "number" then return v end
        if type(v) == "boolean" then return v and 1 or 0 end
        if is_json_null(v) then return 0 end
        return tonumber(v) or 0
    end

    function B.add(a, b)
        if type(a) == "string" or type(b) == "string" then
            return B.str(a) .. B.str(b)
        end
        return B.num(a) + B.num(b)
    end

    function B.eq(a, b)
        if is_json_null(a) and is_json_null(b) then return true end
        if is_json_null(a) or is_json_null(b) then return false end
        if a == b then return true end
        if type(a) == "boolean" or type(b) == "boolean" then
            return B.num(a) == B.num(b)
        end
        local na, nb = to_number(a), to_number(b)
        if na ~= nil and nb ~= nil then return na == nb end
        return false
    end

    function B.neq(a, b) return not B.eq(a, b) end

    function B.seq(a, b)
        if is_json_null(a) and is_json_null(b) then return true end
        if type(a) ~= type(b) then return false end
        return a == b
    end

    function B.sneq(a, b) return not B.seq(a, b) end

    function B.parse_int(v)
        if type(v) == "number" then return math.floor(v) end
        if type(v) == "string" then
            local m = v:match("^%s*([+-]?%d+)")
            if m then return tonumber(m) or 0 end
        end
        return 0
    end

    function B.avoid_nilb(v, def)
        if is_json_null(v) or v == "" then return def end
        return v
    end

    function B.avoid_nil(v)
        if is_json_null(v) then return "" end
        return v
    end

    function B.trim(s)
        return trim(s)
    end

    function B.starts_with(s, prefix)
        s = B.str(s)
        prefix = B.str(prefix)
        return s:sub(1, #prefix) == prefix
    end

    function B.random_string(len, charset)
        len = B.parse_int(len)
        charset = (type(charset) == "string" and #charset > 0) and charset or "abcdefghijklmnopqrstuvwxyz0123456789"
        local out = {}
        local n = #charset
        for i = 1, len do
            local idx = math.random(1, n)
            out[i] = charset:sub(idx, idx)
        end
        return table.concat(out)
    end

    function B.rand(lo, hi)
        return math.random(B.parse_int(lo), B.parse_int(hi))
    end

    function B.csv_parse(str, sep)
        str = B.str(str)
        sep = sep or ":"
        local res = {}
        if #str == 0 then return res end
        local pos = 1
        while true do
            local s, e = str:find(sep, pos, true)
            if not s then
                res[#res + 1] = str:sub(pos)
                break
            end
            res[#res + 1] = str:sub(pos, s - 1)
            pos = e + 1
        end
        return res
    end

    function B.arr_get(arr, idx0)
        if type(arr) ~= "table" then return nil end
        return arr[B.parse_int(idx0) + 1]
    end

    function B.arr_len(arr)
        if type(arr) ~= "table" then return 0 end
        return #arr
    end

    function B.arr_splice(arr, idx0, count)
        if type(arr) ~= "table" then return end
        local start1 = B.parse_int(idx0) + 1
        local n = B.parse_int(count or 1)
        for _ = 1, n do
            if start1 >= 1 and start1 <= #arr then
                table.remove(arr, start1)
            end
        end
    end

    function B.encode_uri(s)
        s = B.str(s)
        return (s:gsub("([^%w%-_%.!~%*'%((%)])", function(c)
            return string.format("%%%02X", string.byte(c))
        end))
    end

    function B.json_parse(s)
        if type(s) ~= "string" or #trim(s) == 0 then return nil end
        local ok, d = decode_json_lenient(s)
        if ok then return d end
        return nil
    end

    function B.json_stringify(v)
        if is_json_null(v) then return "null" end
        if type(v) == "boolean" then return v and "true" or "false" end
        if type(v) == "number" then return B.str(v) end
        if type(v) == "string" then
            local ok, s = pcall(json.encode, {v})
            if ok and s then return s:sub(2, -2) end
            return '"' .. v:gsub('\\', '\\\\'):gsub('"', '\\"') .. '"'
        end
        local ok, s = pcall(json.encode, v)
        return ok and s or "null"
    end

    function B.proxy_parse(str)
        local parts = B.csv_parse(str, ":")
        return {
            server   = parts[1] or "",
            Port     = tonumber(parts[2]) or 0,
            name     = parts[3] or "",
            password = parts[4] or "",
            IsHttp   = true
        }
    end

    -- JPath.value supporting ".a.b[0]", "..key", "key" with BAS-compatible recursive fallback
    local function eval_direct_path(root, segs)
        local cur = root
        for _, seg in ipairs(segs) do
            if type(cur) ~= "table" then return nil, false end
            local key, idx = seg:match("^([^%[]+)%[(%d+)%]$")
            if key and idx then
                cur = cur[key]
                if type(cur) ~= "table" then return nil, false end
                cur = cur[tonumber(idx) + 1]
            else
                local only_idx = seg:match("^%[(%d+)%]$")
                if only_idx then
                    cur = cur[tonumber(only_idx) + 1]
                else
                    cur = cur[seg]
                end
            end
            if cur == nil then return nil, false end
        end
        return cur, true
    end

    -- Breadth-first recursive search matching BAS JPath behavior for ".job_id", ".display_name", ".ios", "..otp"
    local function bfs_find_path(root, segs)
        local queue = { root }
        local head = 1
        while head <= #queue do
            local node = queue[head]
            head = head + 1
            if type(node) == "table" then
                local val, ok = eval_direct_path(node, segs)
                if ok then return val, true end
                for _, child in pairs(node) do
                    if type(child) == "table" then
                        queue[#queue + 1] = child
                    end
                end
            end
        end
        return nil, false
    end

    function B.jpath_value(input, expr)
        local root = input
        if type(input) == "string" then
            local ok, d = decode_json_lenient(input)
            if not ok then return "" end
            root = d
        end
        if type(root) ~= "table" then return "" end
        expr = trim(expr)
        local force_deep = false
        if expr:sub(1, 2) == ".." then
            force_deep = true
            expr = expr:sub(3)
        else
            if expr:sub(1, 1) == "$" then expr = expr:sub(2) end
            if expr:sub(1, 1) == "." then
                force_deep = true
                expr = expr:sub(2)
            end
        end
        local segs = {}
        for seg in (expr .. "."):gmatch("([^%.]+)%.") do
            segs[#segs + 1] = seg
        end
        if #segs == 0 then return "" end

        local val, found = eval_direct_path(root, segs)
        if not found and (force_deep or #segs == 1) then
            val, found = bfs_find_path(root, segs)
        end
        if not found then return "" end
        if is_json_null(val) then return NULL_VAL end
        return val
    end

    function B.jpath_change_format(val, fmt)
        if fmt == "json" then
            if type(val) == "table" then return val end
            if type(val) == "string" then
                local ok, d = decode_json_lenient(val)
                if ok then return d end
            end
            return {}
        elseif fmt == "string" then
            if type(val) == "string" then return val end
            return B.json_stringify(val)
        end
        return val
    end

    ------------------------------------------------------------
    -- LOCAL DEVICE ACTIONS (IN-PROCESS REPLACEMENT FOR sv.lua)
    ------------------------------------------------------------
    local function dev_tap(x, y)
        hw.touchDown(0, x, y)
        dev_usleep(TAP_HOLD_US)
        hw.touchUp(0, x, y)
        dev_usleep(TOUCH_SETTLE_US)
    end

    local function dev_perform_action(x, y, actionType)
        if actionType == "hold" then
            hw.touchDown(0, x, y)
            dev_usleep(1500000)
            hw.touchUp(0, x, y)
            dev_usleep(TOUCH_SETTLE_US)
            return true
        end
        local count = actionType == "click" and 1
            or tonumber(type(actionType) == "string" and actionType:match("^click(%d+)$") or "")
        if not count or count < 1 then return false end
        for i = 1, count do
            dev_tap(x, y)
            if i < count then dev_usleep(150000) end
        end
        return true
    end

    local function dev_poll(timeout, fn, interval)
        local deadline = get_now() + timeout
        interval = interval or POLL_INTERVAL_S
        while true do
            check_watchdog("poll")
            local res = fn(deadline)
            if res ~= nil then return res end
            local rem = deadline - get_now()
            if rem <= 0 then return nil end
            dev_usleep(math.floor(math.min(interval, rem) * 1000000) + 1)
        end
    end

    local function dev_process_color(data)
        local parsed, err = parse_find_colors_script(data.script)
        if not parsed then return 400, json.encode({success=false, error=err or "Invalid script"}) end
        local input = parsed.colors
        if type(input) ~= "table" or #input == 0 then
            return 400, json.encode({success=false, error="colors must be nonempty"})
        end
        local colors = {}
        for i, item in ipairs(input) do
            local c = to_number(item.color or item[1])
            local x = to_number(item.x or item[2])
            local y = to_number(item.y or item[3])
            colors[i] = {c, x, y}
        end
        local function opt(k, def)
            if not dev_is_null(data[k]) then return data[k] end
            if not dev_is_null(parsed[k]) then return parsed[k] end
            return def
        end
        local region, rerr = normalize_region(opt("region"))
        if rerr then return 400, json.encode({success=false, error=rerr}) end
        local debug_f = parse_bool(opt("debug", false), false) or false
        local rtl = parse_bool(opt("rightToLeft", false), false) or false
        local btt = parse_bool(opt("bottomToTop", false), false) or false
        local timeout = dev_is_null(data.timeout) and 15 or (to_number(data.timeout) or 15)
        local offset  = dev_is_null(data.offset)  and 0 or (to_number(data.offset) or 0)
        local offsetX = dev_is_null(data.offsetX) and 0 or (to_number(data.offsetX) or 0)
        local offsetY = dev_is_null(data.offsetY) and 0 or (to_number(data.offsetY) or 0)
        local mode = dev_is_null(data.mode) and "check" or tostring(data.mode):lower()

        local sample = parsed.sample
        local found = dev_poll(timeout, function()
            if sample then
                local ac = to_number(hw.getColor(sample.x, sample.y))
                if ac == sample.color then return {sample.x, sample.y} end
                return nil
            end
            local res = hw.findColors(colors, 1, region, debug_f, rtl, btt)
            return type(res) == "table" and res[1] or nil
        end)
        if not found then
            return 404, '{"success":false,"error":"Not found"}'
        end
        local x, y = to_number(found[1]) + offsetX, to_number(found[2]) + offsetY + offset
        if dev_perform_action(x, y, mode) then dev_usleep(120000) end
        return 200, json.encode({success=true, x=x, y=y})
    end

    local function dev_process_points(data)
        local list = {}
        if type(data.points) == "table" then
            for i, p in ipairs(data.points) do list[i] = {p.color or p[1], p.x or p[2], p.y or p[3]} end
        elseif type(data.script) == "string" then
            for c, x, y in data.script:gmatch("(%w+)%s*,%s*%(%s*([%+%-]?[%d%.]+)%s*,%s*([%+%-]?[%d%.]+)%s*%)") do
                list[#list + 1] = {c, x, y}
            end
        end
        if #list < 2 then return 400, '{"success":false,"error":"Need >=2 points"}' end
        local pts, locs = {}, {}
        for i, p in ipairs(list) do
            pts[i] = {color = to_number(p[1]), x = to_number(p[2]), y = to_number(p[3])}
            locs[i] = {pts[i].x, pts[i].y}
        end
        local timeout   = dev_is_null(data.timeout)   and 5 or (to_number(data.timeout) or 5)
        local tolerance = dev_is_null(data.tolerance) and 0 or (to_number(data.tolerance) or 0)
        local offsetX   = dev_is_null(data.offsetX)   and 0 or (to_number(data.offsetX) or 0)
        local offsetY   = dev_is_null(data.offsetY)   and 0 or (to_number(data.offsetY) or 0)
        local mode      = dev_is_null(data.mode) and "check" or tostring(data.mode):lower()
        local found = dev_poll(timeout, function()
            local cols = hw.getColors(locs)
            if type(cols) ~= "table" then return nil end
            for i, p in ipairs(pts) do
                if not color_close(to_number(cols[i]), p.color, tolerance) then return nil end
            end
            return {pts[1].x, pts[1].y}
        end)
        if not found then return 404, '{"success":false,"error":"Not found"}' end
        local x, y = found[1] + offsetX, found[2] + offsetY
        if dev_perform_action(x, y, mode) then dev_usleep(120000) end
        return 200, json.encode({success=true, x=x, y=y})
    end

    local function dev_process_search(data)
        local timeout = to_number(data.timeout) or 15
        local region, rerr = normalize_region(data.region)
        if rerr then return 400, json.encode({success=false, error=rerr}) end
        local dx = to_number(data.offsetX) or 0
        local dy = (to_number(data.offsetY) or 0) + (to_number(data.offset) or 0)

        if data.image_path then
            local dir = hw.rootDir and hw.rootDir() or "/var/jb/var/mobile/Library/TapCore/Scripts"
            if dir:sub(-1) ~= "/" then dir = dir .. "/" end
            local full = dir .. "Screenshots/" .. (data.image_path:match(".*/(.+)$") or data.image_path)
            local threshold = to_number(data.threshold) or 0.9
            local hit = dev_poll(timeout, function()
                local ok, res = pcall(hw.findImage, full, 1, threshold, region, false, 1)
                return ok and type(res) == "table" and res[1] or nil
            end)
            if not hit then return 404, '{"success":false,"error":"Not found"}' end
            local x, y = hit[1] + dx, hit[2] + dy
            if dev_perform_action(x, y, data.action) then dev_usleep(500000) end
            return 200, json.encode({success=true, x=x, y=y})
        end

        if data.text then
            local word   = trim(tostring(data.text)):lower()
            local target = word:gsub("%s+", "")
            local exact  = data.ex == nil or data.ex == true
            local mode   = type(data.level) == "string" and data.level:lower() or "auto"
            local started, lastAcc = get_now(), -math.huge
            local willTouch = data.action == "hold" or
                (type(data.action) == "string" and data.action:match("^click%d*$") ~= nil)

            local function locate(deadline)
                local level = mode
                if level ~= "fast" and level ~= "accurate" then
                    local t = get_now()
                    if t - started >= OCR_ACCURATE_AFTER_S and t - lastAcc >= OCR_ACCURATE_GAP_S
                        and deadline - t >= ocrAccurateCost then
                        level, lastAcc = "accurate", t
                    else
                        level = "fast"
                    end
                end
                local t0 = get_now()
                local ok, results = pcall(hw.ocr, {level=level, languages={"en-US"},
                    correct=(level=="accurate"), region=region})
                if ok and level == "accurate" then ocrAccurateCost = math.max(1, get_now() - t0) end
                if not ok or type(results) ~= "table" then return nil, level end
                for _, item in ipairs(results) do
                    local text = item.text or ""
                    local cand = trim(text):lower():gsub("%s+", "")
                    local match = exact and (cand:sub(-#target) == target) or (cand:find(target, 1, true) ~= nil)
                    local r = item.rectangle
                    if match and r and r.topLeft and r.topRight and r.bottomLeft then
                        local line = text:lower()
                        local s, e = line:find(word, 1, true)
                        local x
                        if s and #line > 0 then
                            x = r.topLeft.x + ((s + e) / 2 - 1) * (r.topRight.x - r.topLeft.x) / #line
                        else
                            x = (r.topLeft.x + r.topRight.x) / 2
                        end
                        return {x + dx, (r.topLeft.y + r.bottomLeft.y) / 2 + dy}, level
                    end
                end
                return nil, level
            end

            local seen
            local hit = dev_poll(timeout, function(deadline)
                local pos, level = locate(deadline)
                if not pos then seen = nil; return nil end
                if not willTouch or level == "accurate" then return pos end
                local t = get_now()
                if not seen or math.abs(pos[1] - seen[1]) > OCR_SETTLE_PX
                    or math.abs(pos[2] - seen[2]) > OCR_SETTLE_PX then
                    seen = {pos[1], pos[2], t}
                    return nil
                end
                if t - seen[3] >= OCR_SETTLE_S or deadline - t <= OCR_INTERVAL_S then
                    return pos
                end
                return nil
            end, OCR_INTERVAL_S)
            if not hit and seen then hit = {seen[1], seen[2]} end
            if not hit then return 404, '{"success":false,"error":"Not found"}' end
            dev_perform_action(hit[1], hit[2], data.action)
            return 200, string.format('{"success":true,"x":%f,"y":%f}', hit[1], hit[2])
        end
        return 400, '{"success":false,"error":"Missing text/image"}'
    end

    local function dev_process_command(data, action)
        local payload = data.data
        if dev_is_null(payload) then return 400, '{"success":false,"error":"Missing data"}' end
        local res = {}
        local ok, result
        if action == "URL" then
            ok = pcall(hw.openURL, payload)
            res.message = ok and "URL opened" or "URL failed"
        elseif action == "TEXT" then
            local called, typed, how = pcall(hw.inputText, payload)
            ok = called and typed ~= false
            res.message = ok and "Text input" or ("Text failed: " .. tostring(how or typed))
        else -- RUNLUA
            local env = setmetatable({
                touchDown = hw.touchDown, touchMove = hw.touchMove, touchUp = hw.touchUp,
                usleep = dev_usleep, keyDown = hw.keyDown, keyUp = hw.keyUp,
                inputText = hw.inputText, copyText = hw.copyText,
                getColor = hw.getColor, getColors = hw.getColors, findColors = hw.findColors,
                ocr = hw.ocr, findImage = hw.findImage, execute = hw.execute,
                openURL = hw.openURL, rootDir = hw.rootDir, appKill = hw.appKill,
                saveToSystemAlbum = hw.saveToSystemAlbum, clearSystemAlbum = hw.clearSystemAlbum,
                tap = dev_tap, KEY_TYPE = _G.KEY_TYPE or { HOME_BUTTON = 0 }
            }, { __index = _G })
            ok, result = pcall(function()
                local fn, cerr = load(payload, "runlua", "t", env)
                if not fn then error("Compile failed: " .. tostring(cerr), 0) end
                return fn()
            end)
            if not ok then
                res.error = tostring(result)
            elseif type(result) == "table" then
                res.data = result
            elseif type(result) == "string" then
                local tr = trim(result)
                local first = tr:sub(1, 1)
                local dec_ok, val = false, nil
                if first == "{" or first == "[" then dec_ok, val = decode_json_lenient(tr) end
                if dec_ok then res.data = val else res.message = tr end
            elseif result ~= nil then
                res.message = tostring(result)
            end
        end
        res.success = ok
        return ok and 200 or 500, json.encode(res)
    end

    function B.device_post(raw_payload)
        local ok, data = decode_json_lenient(raw_payload)
        if not ok or type(data) ~= "table" then
            return 400, '{"success":false,"error":"Invalid JSON"}'
        end
        local act = type(data.action) == "string" and data.action:upper() or ""
        if act == "RUNLUA" or act == "URL" or act == "TEXT" then
            return dev_process_command(data, act)
        elseif act == "COLOR" or act == "FINDCOLOR" or act == "FINDCOLORS" then
            return dev_process_color(data)
        elseif act == "POINTS" then
            return dev_process_points(data)
        else
            return dev_process_search(data)
        end
    end

    ------------------------------------------------------------
    -- BAS HTTP CLIENT EMULATION (WITH LOCAL ROUTING)
    ------------------------------------------------------------
    function B.switch_http_main()
        active_http = http_main
    end

    function B.switch_http_internal()
        active_http = http_internal
    end

    function B.new_http_client()
        http_main.status = 0
        http_main.body = ""
        http_main.headers = {}
        http_main.proxy = nil
        active_http = http_main
    end

    local vpn_disabled_for_test = false

    function B.http_set_proxy(host, port, is_http, user, pass)
        if not host or #tostring(host) == 0 then
            active_http.proxy = nil
            return
        end
        -- On standalone iPhone, Shadowrocket VPN intercepts proxy hostnames as 198.18.0.x
        -- (nested proxy inside old proxy). Turn Shadowrocket OFF before testing the new proxy;
        -- MAIN turns it back ON right after Proxy_set configures shadowrocket-proxy-set.
        if not vpn_disabled_for_test and hw.execute then
            vpn_disabled_for_test = true
            pcall(hw.execute, "/var/jb/usr/bin/shadowrocket-proxy-vpn off")
            dev_usleep(1200000)
        end
        active_http.proxy = {
            type = is_http and "http" or "socks5",
            host = tostring(host),
            port = tonumber(port) or 0,
            user = tostring(user or ""),
            pass = tostring(pass or "")
        }
    end

    local function is_local_device_url(url)
        if type(url) ~= "string" then return false end
        local ip = config["IP Iphone"] or ""
        if url:find("^https?://127%.0%.0%.1:") or url:find("^https?://localhost:") then return true end
        if #ip > 0 and url:find("^https?://" .. ip:gsub("([%.%-])", "%%%1") .. ":") then return true end
        if local_wifi_ip and #local_wifi_ip > 0 and url:find("^https?://" .. local_wifi_ip:gsub("([%.%-])", "%%%1") .. ":") then return true end
        return false
    end

    local function rewrite_local_host(url)
        return (url:gsub("^(https?://)[^/:]+(:%d+)", "%1127.0.0.1%2"))
    end

    function B.http_request(url, method, body, headers, content_type)
        url = B.str(url)
        method = (method or "GET"):upper()

        -- 1. No-op for /control/start_playing?path=/sv.lua (we ARE already running inside TapCore!)
        if is_local_device_url(url) and url:find(":8080/control/start_playing", 1, true) then
            active_http.status = 200
            active_http.body = '{"status":"success","standalone":true}'
            active_http.headers = {}
            return
        end

        -- 2. In-process execution for :3000 (sv.lua commands)
        if is_local_device_url(url) and url:find(":3000", 1, true) then
            local status, resp = B.device_post(body or "")
            active_http.status = status
            active_http.body = resp or ""
            active_http.headers = {}
            return
        end

        -- 3. Local iPhone service (:9210, :9102, etc.) -> route to 127.0.0.1 without proxy
        local use_proxy = active_http.proxy
        if is_local_device_url(url) then
            url = rewrite_local_host(url)
            use_proxy = nil
        end

        local hdrs = {}
        if type(headers) == "string" and #trim(headers) > 0 then
            for line in (headers .. "\n"):gmatch("([^\r\n]*)\r?\n") do
                local k, v = line:match("^%s*([^:]+):%s*(.-)%s*$")
                if k then hdrs[k] = v end
            end
        elseif type(headers) == "table" then
            for k, v in pairs(headers) do hdrs[k] = tostring(v) end
        end
        if type(content_type) == "string" and #content_type > 0 then
            local ct = content_type:gsub("^custom/", "")
            if #ct > 0 and not hdrs["Content-Type"] and not hdrs["content-type"] then
                hdrs["Content-Type"] = ct
            end
        end

        local req_timeout = 35
        if url:find("/api/backup_upload", 1, true) then
            req_timeout = 240
        end
        local resp = hw.httpRequest({
            url = url,
            method = method,
            headers = hdrs,
            body = body,
            timeout = req_timeout,
            proxy = use_proxy
        })
        if not resp or not resp.ok then
            active_http.status = 0
            active_http.body = ""
            local err_msg = (resp and resp.error) or "HTTP request failed"
            if use_proxy then
                B.log("[HTTP Proxy Error] " .. tostring(use_proxy.type) .. "://" .. tostring(use_proxy.host) .. ":" .. tostring(use_proxy.port) .. " -> " .. tostring(err_msg))
            end
            error(err_msg, 0)
        end
        active_http.status = resp.status or 0
        active_http.body = resp.body or ""
        active_http.headers = resp.headers or {}
    end

    function B.http_status()
        return active_http.status or 0
    end

    function B.http_content()
        return active_http.body or ""
    end

    ------------------------------------------------------------
    -- EMBEDDED NODE.JS COMPATIBILITY HANDLERS
    ------------------------------------------------------------
    function B.emb_mars_proxy(template_str)
        -- Prefer user's pasted proxy from Web/App config if provided; fallback to XML template
        local list = res_lists["Proxy"] or {}
        local tpl = (list[1] and #list[1] > 0) and list[1]
            or (template_str and #template_str > 0 and template_str)
            or "ultra.marsproxies.com:44445:lvknjneroitjogijdsfie:MS45Ho4ewT_country-us_session-aor5pxwf_lifetime-168h"
        local rnd = B.random_string(8, "abcdefghijklmnopqrstuvwxyz0123456789")
        local out, replaced = tpl:gsub("session%-[a-zA-Z0-9]+", "session-" .. rnd)
        if replaced == 0 then
            out = tpl
        end
        return out
    end

    function B.emb_girly_names(spec)
        local firstNames = spec.firstNames or {"Anneliese","Clarissa","Colette","Delphine","Felicity","Juliet","Madeleine","Rosie","Sadie","Hazel","Ivy","Jade"}
        local lastNames = spec.lastNames or {"smith","johnson","williams","brown","jones","miller","davis","wilson","taylor","clark","walker","green"}
        local girlyWords = spec.girlyWords or {"matcha","latte","pilates","coffee","books","glow","aesthetic","vibes","daily","style","honey","peach"}
        local locations = spec.locations or {"nyc","la","miami","austin","dallas","chicago","seattle","boston","london","paris"}
        local middleInitials = spec.middleInitials or "abcdefghjklmnoprstvw"
        local targetCount = spec.targetCount or 50

        local function pick(arr) return arr[math.random(1, #arr)] end
        local function rint(a, b) return math.random(a, b) end
        local function rand_num()
            local k = math.random(1, 7)
            if k == 1 then return tostring(rint(1, 99))
            elseif k == 2 then return "0" .. tostring(rint(1, 9))
            elseif k == 3 then return tostring(rint(95, 99))
            elseif k == 4 then return "200" .. tostring(rint(0, 6))
            elseif k == 5 then return "199" .. tostring(rint(5, 9))
            elseif k == 6 then return tostring(rint(101, 999))
            else return tostring(rint(10, 12)) .. tostring(rint(10, 28)) end
        end

        local function gen_one(firstName)
            local f = firstName:lower()
            local l = pick(lastNames)
            local fInit = f:sub(1, 1)
            local lInit = l:sub(1, 1)
            local mi = math.random(1, #middleInitials)
            local mInit = middleInitials:sub(mi, mi)
            local num = rand_num()
            local word = pick(girlyWords)
            local loc = pick(locations)
            local p = math.random(1, 32)
            local u
            if p == 1 then u = f .. l
            elseif p == 2 then u = f .. "." .. l
            elseif p == 3 then u = f .. "_" .. l
            elseif p == 4 then u = f .. "." .. mInit .. "." .. l
            elseif p == 5 then u = f .. mInit .. l
            elseif p == 6 then u = f .. l .. num
            elseif p == 7 then u = f .. "." .. l .. "." .. num
            elseif p == 8 then u = f .. "_" .. l .. "_" .. num
            elseif p == 9 then u = f .. "_" .. l .. num
            elseif p == 10 then u = fInit .. l .. num
            elseif p == 11 then u = fInit .. "." .. l .. num
            elseif p == 12 then u = fInit .. "_" .. l .. "_" .. num
            elseif p == 13 then u = f .. lInit .. num
            elseif p == 14 then u = f .. "_" .. lInit .. num
            elseif p == 15 then u = "_" .. f .. l .. "_"
            elseif p == 16 then u = "_" .. f .. "." .. l .. "_"
            elseif p == 17 then u = f .. l .. "_"
            elseif p == 18 then u = f .. "_" .. l .. "_"
            elseif p == 19 then u = "__" .. f .. lInit .. "__"
            elseif p == 20 then u = "_." .. f .. "_" .. l .. "._"
            elseif p == 21 then u = f .. "." .. l .. "_"
            elseif p == 22 then u = f .. "." .. word
            elseif p == 23 then u = f .. "_" .. word
            elseif p == 24 then u = f .. word
            elseif p == 25 then u = f .. "." .. word .. "_" .. loc
            elseif p == 26 then u = word .. "by" .. f
            elseif p == 27 then u = f .. "in" .. loc
            elseif p == 28 then u = f .. "_" .. loc .. num
            elseif p == 29 then u = "its" .. f .. lInit
            elseif p == 30 then u = "heyits" .. f
            elseif p == 31 then u = "just" .. f .. "_" .. num
            else u = f .. f .. num end
            if #u > 30 then u = u:sub(1, 30):gsub("%.+$", "") end
            return u
        end

        local used, result = {}, {}
        for _ = 1, targetCount do
            local name = pick(firstNames)
            local u, attempts = nil, 0
            repeat
                u = gen_one(name)
                if attempts > 5 then
                    u = u:gsub("[_%.]+$", "") .. tostring(rint(10, 999))
                end
                attempts = attempts + 1
            until not used[u]
            used[u] = true
            result[#result + 1] = { name = name, username = u }
        end
        return result
    end

    function B.emb_hotmail_read(list_data)
        local parts = B.csv_parse(list_data, "|")
        local refresh_token, client_id = parts[3] or "", parts[4] or ""
        if #refresh_token == 0 or #client_id == 0 then return "ERROR" end
        local function get_tok(extra_scope)
            local body = "client_id=" .. B.encode_uri(client_id)
                .. "&refresh_token=" .. B.encode_uri(refresh_token)
                .. "&grant_type=refresh_token"
            if extra_scope then body = body .. "&scope=" .. B.encode_uri(extra_scope) end
            local r = hw.httpRequest({
                url = "https://login.microsoftonline.com/common/oauth2/v2.0/token",
                method = "POST",
                headers = { ["Content-Type"] = "application/x-www-form-urlencoded" },
                body = body,
                timeout = 25
            })
            if not r or not r.ok or r.status ~= 200 then return nil end
            local ok, d = decode_json_lenient(r.body)
            return ok and d and d.access_token or nil
        end
        local function fetch_msgs(base, tok)
            local all = {}
            for _, folder in ipairs({"inbox", "junkemail"}) do
                local r = hw.httpRequest({
                    url = base .. "/me/mailFolders/" .. folder .. "/messages?$top=10",
                    method = "GET",
                    headers = { Authorization = "Bearer " .. tok, Accept = "application/json" },
                    timeout = 25
                })
                if r and r.ok and r.status == 200 then
                    local ok, d = decode_json_lenient(r.body)
                    if ok and type(d) == "table" and type(d.value) == "table" then
                        for _, m in ipairs(d.value) do all[#all + 1] = m end
                    end
                end
            end
            return all
        end
        local tok = get_tok(nil)
        if not tok then return "ERROR" end
        local msgs = fetch_msgs("https://outlook.office.com/api/v2.0", tok)
        if #msgs == 0 then
            msgs = fetch_msgs("https://graph.microsoft.com/v1.0", tok)
        end
        if #msgs == 0 then
            local gtok = get_tok("https://graph.microsoft.com/Mail.Read openid profile")
            if gtok then msgs = fetch_msgs("https://graph.microsoft.com/v1.0", gtok) end
        end
        for _, m in ipairs(msgs) do
            local body = (m.Body and m.Body.Content) or (m.body and m.body.content) or ""
            local link = body:match("https://sys%.4chan%.org/signin%?action=verify&tkn=[a-zA-Z0-9]+")
            if link then return link end
        end
        return ""
    end

    function B.emb_random_bio(raw_text)
        local text = trim(raw_text)
        local profiles = {}
        local cur = {}
        for line in (text .. "\n"):gmatch("([^\r\n]*)\r?\n") do
            if trim(line) == "" then
                if #cur > 0 then
                    profiles[#profiles + 1] = table.concat(cur, "\n")
                    cur = {}
                end
            else
                cur[#cur + 1] = line
            end
        end
        if #cur > 0 then profiles[#profiles + 1] = table.concat(cur, "\n") end
        if #profiles == 0 then return "" end
        return profiles[math.random(1, #profiles)]
    end

    function B.emb_read_pasteboard()
        if not hw.execute then return "" end
        local out = hw.execute([[d=$(find /var/mobile/Library/Caches/com.apple.Pasteboard -mindepth 1 -maxdepth 1 -type d -exec ls -td {} + 2>/dev/null | head -n 1); f=$(find "$d" -maxdepth 1 -type f ! -name Manifest.plist 2>/dev/null | head -n 1); cat "$f" 2>/dev/null]])
        local last = ""
        for line in (tostring(out or "") .. "\n"):gmatch("([^\r\n]*)\r?\n") do
            local t = trim(line)
            if #t > 0 then last = t end
        end
        return last
    end

    function B.emb_upload_photo(path_input)
        local list = type(path_input) == "table" and path_input or { tostring(path_input or "") }
        for _, p in ipairs(list) do
            p = trim(p)
            if #p > 0 and hw.saveToSystemAlbum then
                pcall(hw.saveToSystemAlbum, p)
                B.sleep(800)
            end
        end
    end

    -- Local DB stub (persists created records into Data/igreg_accounts.json if DB action is unskipped)
    function B.db_add_record(cols)
        local id = tostring(os.time()) .. "_" .. tostring(math.random(1000, 9999))
        local rec = { id = id, created_at = os.time(), cols = cols }
        local path = data_dir .. "/igreg_accounts.json"
        local list = {}
        local raw = read_file(path)
        if raw then
            local ok, d = decode_json_lenient(raw)
            if ok and type(d) == "table" then list = d end
        end
        list[#list + 1] = rec
        local ok, enc = pcall(json.encode, list)
        if ok and enc then write_file_atomic(path, enc) end
        return id
    end

    function B.db_update_record(record_id, cols)
        local path = data_dir .. "/igreg_accounts.json"
        local raw = read_file(path)
        if not raw then return end
        local ok, list = decode_json_lenient(raw)
        if not ok or type(list) ~= "table" then return end
        for _, rec in ipairs(list) do
            if rec.id == record_id and type(rec.cols) == "table" then
                for k, v in pairs(cols) do rec.cols[k] = v end
                break
            end
        end
        local ok2, enc = pcall(json.encode, list)
        if ok2 and enc then write_file_atomic(path, enc) end
    end

    ------------------------------------------------------------
    -- BAS TERMINATION & CONTROL FLOW SIGNALS
    ------------------------------------------------------------
    function B.fail_user(msg)
        error({ __bas_signal = "fail_user", message = B.str(msg) }, 0)
    end

    function B.fail(msg)
        error({ __bas_signal = "fail", message = B.str(msg) }, 0)
    end

    function B.success(msg)
        error({ __bas_signal = "success", message = B.str(msg) }, 0)
    end

    function B.die(msg)
        error({ __bas_signal = "die", message = B.str(msg) }, 0)
    end

    function B.goto_label(target)
        return { __bas_goto = target }
    end

    ------------------------------------------------------------
    -- FLAT BASIC-BLOCK STATE-MACHINE EXECUTOR
    ------------------------------------------------------------
    function B.exec_fn(program, fn_name, V)
        local fn_def = program.functions[fn_name]
        if not fn_def then
            error("Function not found: " .. tostring(fn_name), 0)
        end
        local steps = fn_def.steps
        local labels = fn_def.labels or {}
        local n = #steps
        local pc = 1
        local try_stack = {}
        local max_pc_seen = 0
        local progress_ts = now_sec()
        local prev_loop_deadline = active_loop_deadline

        local function pop_exited_tries(target_pc)
            while #try_stack > 0 do
                local top = try_stack[#try_stack]
                if target_pc < top.start_pc or target_pc >= top.end_pc then
                    table.remove(try_stack)
                else
                    break
                end
            end
        end

        while pc >= 1 and pc <= n do
            local st = steps[pc]
            local now_t = now_sec()
            if pc > max_pc_seen then
                max_pc_seen = pc
                progress_ts = now_t
            end
            local loop_lim = get_loop_timeout_s()
            if loop_lim > 0 then
                local my_dl = progress_ts + loop_lim
                active_loop_deadline = (prev_loop_deadline and prev_loop_deadline < my_dl) and prev_loop_deadline or my_dl
            else
                active_loop_deadline = prev_loop_deadline
            end
            check_watchdog(string.format("%s:%s(L%s)", tostring(fn_name), tostring(st.sec or pc), tostring(st.line or 0)))

            if st.op == "try_begin" then
                V.VAR_WAS_ERROR = false
                V.VAR_LAST_ERROR = ""
                try_stack[#try_stack + 1] = { start_pc = pc, end_pc = st.end_pc }
                pc = pc + 1
            elseif st.op == "try_end" then
                if #try_stack > 0 and try_stack[#try_stack].end_pc == pc then
                    table.remove(try_stack)
                end
                pc = pc + 1
            else
                if st.sec and #st.sec > 0 then
                    B.set_step(fn_name, st.sec, st.line)
                end
                local ok, res = pcall(st.fn, B, V, program)
                if not ok then
                    -- Propagate TapCore Stop immediately
                    if type(res) == "string" and res:find("__TAPCORE_STOPPED__", 1, true) then
                        error(res, 0)
                    end
                    -- Propagate BAS signals (goto, fail_user, success, die)
                    if type(res) == "table" and (res.__bas_signal or res.__bas_goto) then
                        if res.__bas_goto then
                            local target_pc = labels[res.__bas_goto]
                            if target_pc then
                                pop_exited_tries(target_pc)
                                pc = target_pc
                            else
                                error(res, 0)
                            end
                        else
                            error(res, 0)
                        end
                    elseif #try_stack > 0 then
                        -- Caught by BAS Ignore Errors block
                        local top = table.remove(try_stack)
                        V.VAR_WAS_ERROR = true
                        V.VAR_LAST_ERROR = tostring(res)
                        pc = top.end_pc
                    else
                        error(res, 0)
                    end
                else
                    if type(res) == "number" then
                        pop_exited_tries(res)
                        pc = res
                    elseif type(res) == "table" and res.__bas_goto then
                        local target_pc = labels[res.__bas_goto]
                        if target_pc then
                            pop_exited_tries(target_pc)
                            pc = target_pc
                        else
                            error(res, 0)
                        end
                    else
                        pc = pc + 1
                    end
                end
            end
        end
        active_loop_deadline = prev_loop_deadline
    end

    ------------------------------------------------------------
    -- TOP-LEVEL STANDALONE PROGRAM RUNNER
    ------------------------------------------------------------
    function B.run_program(program)
        math.randomseed(os.time() + math.floor((now_sec() % 1) * 1e6))
        B.load_config()
        clear_soft_stop()
        state.running = true
        state.started_at = os.time()
        state.finished_reason = ""
        save_state(true)

        -- Run OnApplicationStart once (same as BAS)
        if program.functions["OnApplicationStart"] then
            local V0 = {}
            B.exec_fn(program, "OnApplicationStart", V0)
        end

        local max_loops = opts.max_iterations or 1000000
        for iter = 1, max_loops do
            -- Reload config each attempt so Web UI proxy/setting changes take effect cleanly
            B.load_config()
            vpn_disabled_for_test = false
            state.attempt = iter
            B.new_http_client()
            local V = {}
            attempt_started_at = now_sec()
            active_loop_deadline = nil
            local ok, err = pcall(B.exec_fn, program, "MAIN", V)
            attempt_started_at = nil
            active_loop_deadline = nil
            if ok then
                state.success_count = state.success_count + 1
                if V.VAR_USERNAME and #B.str(V.VAR_USERNAME) > 0 then
                    state.last_username = B.str(V.VAR_USERNAME)
                    table.insert(state.recent_accounts, 1, {
                        username = state.last_username,
                        password = B.str(V.VAR_PASSWORD),
                        time = os.time()
                    })
                    if #state.recent_accounts > 50 then table.remove(state.recent_accounts) end
                end
                if V.VAR_PROXY then state.last_proxy = B.str(V.VAR_PROXY) end
                save_state(true)
            else
                if type(err) == "string" and err:find("__TAPCORE_STOPPED__", 1, true) then
                    state.running = false
                    state.finished_reason = "Stopped by user"
                    save_state(true)
                    error(err, 0)
                elseif type(err) == "table" and err.__bas_signal == "success" then
                    state.success_count = state.success_count + 1
                    state.last_message = err.message or "Success"
                    if V.VAR_USERNAME and #B.str(V.VAR_USERNAME) > 0 then
                        state.last_username = B.str(V.VAR_USERNAME)
                        table.insert(state.recent_accounts, 1, {
                            username = state.last_username,
                            password = B.str(V.VAR_PASSWORD),
                            time = os.time()
                        })
                        if #state.recent_accounts > 50 then table.remove(state.recent_accounts) end
                    end
                    if V.VAR_PROXY then state.last_proxy = B.str(V.VAR_PROXY) end
                    B.log("SUCCESS: " .. state.last_message)
                    save_state(true)
                    local target = tonumber(config["Tạo Tối Đa"]) or 0
                    if target > 0 and state.success_count >= target then
                        state.running = false
                        state.finished_reason = "Reached target: " .. tostring(target)
                        save_state(true)
                        break
                    end
                elseif type(err) == "table" and err.__bas_signal == "die" then
                    state.running = false
                    state.finished_reason = err.message or "Done"
                    B.log("DONE: " .. state.finished_reason)
                    save_state(true)
                    break
                elseif type(err) == "table" and err.__bas_signal == "watchdog" then
                    state.fail_count = state.fail_count + 1
                    state.watchdog_resets = (state.watchdog_resets or 0) + 1
                    state.last_error = err.message or "Watchdog timeout"
                    B.log(state.last_error .. " → Tự khởi động lại từ đầu MAIN (#" .. tostring(state.watchdog_resets) .. ")")
                    save_state(true)
                    B.sleep(1500)
                elseif type(err) == "table" and (err.__bas_signal == "fail_user" or err.__bas_signal == "fail") then
                    state.fail_count = state.fail_count + 1
                    state.last_error = err.message or "Failed"
                    if V.VAR_PROXY then state.last_proxy = B.str(V.VAR_PROXY) end
                    B.log("FAIL (" .. tostring(state.fail_count) .. "): " .. state.last_error)
                    save_state(true)
                    B.sleep(1500)
                else
                    state.fail_count = state.fail_count + 1
                    state.last_error = tostring(err)
                    B.log("RUNTIME ERROR: " .. state.last_error)
                    save_state(true)
                    B.sleep(3000)
                end
            end

            -- Soft Stop ("Dừng sau acc này"): finish current attempt cleanly, then stop
            if read_soft_stop() then
                clear_soft_stop()
                state.running = false
                state.finished_reason = "Soft Stop (đã dừng sau khi hoàn tất lượt hiện tại)"
                B.log("SOFT STOP: Đã dừng sau lượt #" .. tostring(iter))
                save_state(true)
                break
            end
        end

        state.running = false
        clear_soft_stop()
        save_state(true)
        return state
    end

    B.state = state
    return B
end

return M
