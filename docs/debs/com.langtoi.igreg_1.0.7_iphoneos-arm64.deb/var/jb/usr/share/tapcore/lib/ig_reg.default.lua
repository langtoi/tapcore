-- ================================================================
-- Auto-generated from Tao_IG_backup.xml by IGReg bas2lua.js
-- Compiled at : 2026-11-28T01:13:36.132Z
-- Source hash : 53dab49b5bc3cf0d
-- Functions   : OnApplicationStart, MAIN, Proxy_set, taotaikhoan, API_GMAIL, reg_2
-- Stats       : 6 functions, 106 labels, 1001 steps
-- ================================================================
local BAS = require("bas_runtime")
local PROG = {
  meta = { source = "Tao_IG_backup.xml", hash = "53dab49b5bc3cf0d", compiled_at = "2026-11-28T01:13:36.132Z" },
  functions = {}
}

-- -------- Function: OnApplicationStart (6 steps, 0 labels) --------
do
  local steps = {}
  local labels = {  };
  ;(function()
    steps[1] = { line = 15046, sec = "", fn = function(B, V, PROG)
      B.pset("basglobal", "DEM_ACC", B.json_stringify(0))
    end }
    steps[2] = { line = 15052, sec = "", fn = function(B, V, PROG)
      B.pset("basglobal", "ACC_CHECK", B.json_stringify(false))
    end }
    steps[3] = { line = 15058, sec = "", fn = function(B, V, PROG)
      B.pset("basglobal", "EXCHANGE_STATE", B.json_stringify(false))
    end }
    steps[4] = { line = 15064, sec = "", fn = function(B, V, PROG)
      B.pset("basglobal", "ACCESS_LOCK", B.json_stringify(false))
    end }
    steps[5] = { line = 15070, sec = "", fn = function(B, V, PROG)
      B.pset("basglobal", "LOCK", B.json_stringify(false))
    end }
    steps[6] = { line = 15076, sec = "", fn = function(B, V, PROG)
      B.pset("basglobal", "CHECK_CAPTION", B.json_stringify(B.NULL))
    end }
  end)()
  PROG.functions["OnApplicationStart"] = { name = "OnApplicationStart", steps = steps, labels = labels }
end

-- -------- Function: MAIN (46 steps, 4 labels) --------
do
  local steps = {}
  local labels = { ["MAIN"] = 3, ["label name 1290"] = 20, ["label name 6220"] = 32, ["RA_MAIN"] = 32 };
  ;(function()
    steps[1] = { line = 15530, sec = "", fn = function(B, V, PROG)
      V.VAR_THREAD_INDEX = B.thread_number()
    end }
    steps[2] = { line = 15535, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_588837 = B.rs("Type Proxy", false, false)
      V.VAR_TYPE_PROXY = V.RESOURCE_588837
    end }
    steps[3] = { line = 15547, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_558953 = B.rs("Type Proxy", false, false)
      V.VAR_TYPE_PROXY = V.RESOURCE_558953
    end }
    steps[4] = { line = 15554, sec = "", fn = function(B, V, PROG)
      V.VAR_RESOURCE_IP = B.rpick("IP Iphone")
    end }
    steps[5] = { line = 15559, sec = "", fn = function(B, V, PROG)
      V.VAR_RESOURCE_PROXY = B.rpick("Proxy")
    end }
    steps[6] = { line = 15564, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_VER_GOONED = false
      V.VAR_COUNT_HOAN_THANH = 0
      V.VAR_COUNT_POST = 0
    end }
    steps[7] = { line = 15571, sec = "", fn = function(B, V, PROG)
      V.VAR_IP_IPHONE = B.arr_get(V.VAR_RESOURCE_IP, (B.num(V.VAR_THREAD_INDEX) - B.num(1)))
    end }
    steps[8] = { line = 15576, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_579318 = B.rs("Choose Proxy", false, false)
    end }
    steps[9] = { line = 15576, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_579318, "Grid")) then return 11 end
    end }
    steps[10] = { line = 15583, sec = "", fn = function(B, V, PROG)
      V.VAR_PROXY_RAW = B.arr_get(V.VAR_RESOURCE_PROXY, (B.num(V.VAR_THREAD_INDEX) - B.num(1)))
    end }
    steps[11] = { line = 15591, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_508327 = B.rs("Function", false, false)
    end }
    steps[12] = { line = 15591, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_508327, "Check Acc")) then return 14 end
    end }
    steps[13] = { line = 15598, sec = "", fn = function(B, V, PROG)
      B.exec_fn(PROG, "check_acc", V)
    end }
    steps[14] = { line = 15607, sec = "", fn = function(B, V, PROG)
      V.VAR_IP_IPHONE = B.trim(V.VAR_IP_IPHONE)
    end }
    steps[15] = { line = 15612, sec = "", fn = function(B, V, PROG)
      V.VAR_IP_GOC = V.VAR_IP_IPHONE
    end }
    steps[16] = { line = 15617, sec = "", fn = function(B, V, PROG)
      V.VAR_IS_STARTS_WITH = B.starts_with(V.VAR_IP_IPHONE, "http://")
    end }
    steps[17] = { line = 15622, sec = "", fn = function(B, V, PROG)
      if not B.truthy((not B.truthy(V.VAR_IS_STARTS_WITH))) then return 19 end
    end }
    steps[18] = { line = 15627, sec = "", fn = function(B, V, PROG)
      V.VAR_IP_IPHONE = B.add("http://", V.VAR_IP_IPHONE)
    end }
    steps[19] = { line = 15635, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("cyan"), ["en"] = (B.add("IP IPHONE: ", V.VAR_IP_GOC)), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[20] = { op = "try_begin", line = 15645, end_pc = 22 }
    steps[21] = { line = 15658, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":8080/control/start_playing?path=/sv.lua"), "GET", nil, "", nil)
    end }
    steps[22] = { op = "try_end", line = 15645 }
    steps[23] = { line = 15667, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 25 end
    end }
    steps[24] = { line = 15672, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 1290")
    end }
    steps[25] = { line = 15680, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_371018 = B.rs("Function", false, false)
    end }
    steps[26] = { line = 15680, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_371018, "Tạo Tài Khoản")) then return 28 end
    end }
    steps[27] = { line = 15687, sec = "", fn = function(B, V, PROG)
      return B.goto_label("RA_MAIN")
    end }
    steps[28] = { line = 15695, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_898786 = B.rs("Function", false, false)
    end }
    steps[29] = { line = 15695, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_898786, "Lấy lại tài khoản lỗi")) then return 31 end
    end }
    steps[30] = { line = 15702, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 6220")
    end }
    steps[31] = { line = 15710, sec = "", fn = function(B, V, PROG)
      B.exec_fn(PROG, "doc_DB", V)
    end }
    steps[32] = { line = 15726, sec = "", fn = function(B, V, PROG)
      B.exec_fn(PROG, "Proxy_set", V)
    end }
    steps[33] = { line = 15732, sec = "", fn = function(B, V, PROG)
      B.new_http_client()
    end }
    steps[34] = { line = 15738, sec = "mở sever", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":8080/control/start_playing?path=/sv.lua"), "GET", nil, "", nil)
    end }
    steps[35] = { line = 15744, sec = "", fn = function(B, V, PROG)
      B.sleep(1000)
    end }
    steps[36] = { line = 15749, sec = "thoát", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"\r\nkeyDown(KEY_TYPE.HOME_BUTTON);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\nusleep(100000);\r\nkeyDown(KEY_TYPE.HOME_BUTTON);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\n\r\nusleep(1000000); -- Chờ trình đa nhiệm hiện lên\r\n\r\n\r\ntouchDown(2, 863.20, 1705.23);\r\nusleep(20971.08);\r\ntouchMove(2, 853.59, 1693.71);\r\nusleep(7650.71);\r\ntouchMove(2, 847.84, 1663.90);\r\nusleep(8916.21);\r\ntouchMove(2, 837.26, 1615.80);\r\nusleep(7537.67);\r\ntouchMove(2, 833.43, 1551.34);\r\nusleep(9207.75);\r\ntouchMove(2, 833.43, 1464.74);\r\nusleep(7576.25);\r\ntouchMove(2, 833.43, 1360.85);\r\nusleep(8914.58);\r\ntouchMove(2, 851.68, 1232.91);\r\nusleep(7765.42);\r\ntouchMove(2, 882.39, 1095.34);\r\nusleep(8979.46);\r\ntouchMove(2, 928.48, 983.75);\r\nusleep(7767.67);\r\ntouchMove(2, 958.25, 911.60);\r\nusleep(9061.50);\r\ntouchUp(2, 964.02, 905.84);\r\nusleep(462425.08);\r\n\r\ntouchDown(2, 759.50, 1614.83);\r\nusleep(12281.17);\r\ntouchMove(2, 759.50, 1578.26);\r\nusleep(8606.88);\r\ntouchMove(2, 760.46, 1499.38);\r\nusleep(7841.33);\r\ntouchMove(2, 777.75, 1386.83);\r\nusleep(9069.29);\r\ntouchMove(2, 810.38, 1258.89);\r\nusleep(7597.33);\r\ntouchMove(2, 852.62, 1112.66);\r\nusleep(9040.38);\r\ntouchMove(2, 903.52, 1008.77);\r\nusleep(7585.71);\r\ntouchMove(2, 935.21, 942.38);\r\nusleep(9383.00);\r\ntouchUp(2, 940.96, 936.62);\r\n\r\n\r\n\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[37] = { line = 15755, sec = "HOME", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"\r\n\r\nkeyDown(KEY_TYPE.HOME_BUTTON);\r\nusleep(138611.00);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\nusleep(217773.00);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\nusleep(772038.29);\r\n\r\nkeyDown(KEY_TYPE.HOME_BUTTON);\r\nusleep(217682.00);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\nusleep(138650.21);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\n\r\n\r\n\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[38] = { line = 15761, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[39] = { line = 15766, sec = "Tắt VPN", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"return execute('/var/jb/usr/bin/shadowrocket-proxy-vpn off')\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[40] = { line = 15772, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[41] = { line = 15777, sec = "Bật VPN", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"return execute('/var/jb/usr/bin/shadowrocket-proxy-vpn on')\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[42] = { line = 15783, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[43] = { line = 15788, sec = "HOME", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"\r\n\r\nkeyDown(KEY_TYPE.HOME_BUTTON);\r\nusleep(138611.00);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\nusleep(217773.00);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\nusleep(772038.29);\r\n\r\nkeyDown(KEY_TYPE.HOME_BUTTON);\r\nusleep(217682.00);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\nusleep(138650.21);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\n\r\n\r\n\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[44] = { line = 15794, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_423225 = B.rs("Function", false, false)
    end }
    steps[45] = { line = 15794, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_423225, "Tạo Tài Khoản")) then return 47 end
    end }
    steps[46] = { line = 15801, sec = "", fn = function(B, V, PROG)
      B.exec_fn(PROG, "taotaikhoan", V)
    end }
  end)()
  PROG.functions["MAIN"] = { name = "MAIN", steps = steps, labels = labels }
end

-- -------- Function: Proxy_set (60 steps, 6 labels) --------
do
  local steps = {}
  local labels = { ["label name 6060"] = 4, ["label name 5681"] = 6, ["label name 9230"] = 20, ["label name 3987"] = 23, ["label name 6603"] = 25, ["label name 6929"] = 56 };
  ;(function()
    steps[1] = { line = 15089, sec = "", fn = function(B, V, PROG)
      do local fi = B.json_parse(B.native_fileinfo(B.rinfo("Proxy", "Location"))) or {}; V.VAR_FILEINFO_EXISTS = fi.exists; V.VAR_FILEINFO_SIZE = fi.size; V.VAR_FILEINFO_BASE_DIRECTORY = fi.directory or ""; V.VAR_FILEINFO_IS_DIRECTORY = fi.is_directory; V.VAR_FILEINFO_LAST_MODIFIED = fi.last_modified end
    end }
    steps[2] = { line = 15099, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_FILEINFO_BASE_DIRECTORY, "")) then return 4 end
    end }
    steps[3] = { line = 15104, sec = "", fn = function(B, V, PROG)
      V.VAR_FILEINFO_BASE_DIRECTORY = B.project_directory()
    end }
    steps[4] = { line = 15117, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_307761 = B.rs("Choose Proxy", false, false)
    end }
    steps[5] = { line = 15117, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_307761, "9proxy")) then return 13 end
    end }
    steps[6] = { op = "try_begin", line = 15129, end_pc = 8 }
    steps[7] = { line = 15142, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_912871 = B.rs("Proxy", true, true)
      do local csv_res = B.csv_parse(V.RESOURCE_912871, "|")
      V.VAR_LIST_WITH_ITEMS = csv_res
      V.VAR_PROXY = B.avoid_nilb(csv_res[1], "")
      V.VAR_LINK_CHANG = B.avoid_nilb(csv_res[2], "")
      end
    end }
    steps[8] = { op = "try_end", line = 15129 }
    steps[9] = { line = 15155, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 13 end
    end }
    steps[10] = { line = 15160, sec = "", fn = function(B, V, PROG)
      B.reload("Proxy")
    end }
    steps[11] = { line = 15165, sec = "", fn = function(B, V, PROG)
      B.log("Đã reload")
    end }
    steps[12] = { line = 15170, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5681")
    end }
    steps[13] = { line = 15181, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_889799 = B.rs("Choose Proxy", false, false)
    end }
    steps[14] = { line = 15181, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_889799, "Grid")) then return 20 end
    end }
    steps[15] = { line = 15188, sec = "", fn = function(B, V, PROG)
      do local csv_res = B.csv_parse(V.VAR_PROXY_RAW, "|")
      V.VAR_LIST_WITH_ITEMS = csv_res
      V.VAR_PROXY = B.avoid_nilb(csv_res[1], "")
      V.VAR_LINK_CHANG = B.avoid_nilb(csv_res[2], "")
      end
    end }
    steps[16] = { line = 15196, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(V.VAR_LINK_CHANG, "GET", nil, "", nil)
    end }
    steps[17] = { line = 15202, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[18] = { line = 15208, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 400)) then return 20 end
    end }
    steps[19] = { line = 15213, sec = "", fn = function(B, V, PROG)
      B.die("Proxy Hết Hạn")
    end }
    steps[20] = { line = 15229, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_887020 = B.rs("Choose Proxy", false, false)
    end }
    steps[21] = { line = 15229, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_887020, "Mard")) then return 23 end
    end }
    steps[22] = { line = 15236, sec = "US", fn = function(B, V, PROG)
      V.VAR_PROXY = B.emb_mars_proxy("ultra.marsproxies.com:44445:lvknjneroitjogijdsfie:MS45Ho4ewT_country-us_session-aor5pxwf_lifetime-168h")
    end }
    steps[23] = { line = 15250, sec = "", fn = function(B, V, PROG)
      do local csv_res = B.csv_parse(V.VAR_PROXY, ":")
      V.VAR_LIST_WITH_ITEMS = csv_res
      V.VAR_IP_PPROXY = B.avoid_nilb(csv_res[1], "")
      V.VAR_PORT = B.avoid_nilb(csv_res[2], "")
      V.VAR_USER_PROXY = B.avoid_nilb(csv_res[3], "")
      V.VAR_PASS_PROXY = B.avoid_nilb(csv_res[4], "")
      end
    end }
    steps[24] = { line = 15260, sec = "", fn = function(B, V, PROG)
      do local h = B.proxy_parse(V.VAR_PROXY); local tp = tostring(V.VAR_TYPE_PROXY or "http"):lower(); if tp ~= "auto" then h.IsHttp = (tp == "http") end; B.switch_http_main(); B.http_set_proxy(h.server, h.Port, h.IsHttp, h.name, h.password) end
    end }
    steps[25] = { op = "try_begin", line = 15282, end_pc = 27 }
    steps[26] = { line = 15295, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request("http://ip.bablosoft.com", "GET", nil, "", nil)
    end }
    steps[27] = { op = "try_end", line = 15282 }
    steps[28] = { line = 15304, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 35 end
    end }
    steps[29] = { line = 15309, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_388065 = B.rs("Choose Proxy", false, false)
    end }
    steps[30] = { line = 15309, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_388065, "Grid")) then return 32 end
    end }
    steps[31] = { line = 15316, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 6603")
    end }
    steps[32] = { line = 15324, sec = "", fn = function(B, V, PROG)
      B.new_http_client()
    end }
    steps[33] = { line = 15330, sec = "", fn = function(B, V, PROG)
      B.log("STATUS: Proxy error try again")
    end }
    steps[34] = { line = 15335, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9230")
    end }
    steps[35] = { line = 15343, sec = "", fn = function(B, V, PROG)
      V.VAR_IP = B.http_content()
    end }
    steps[36] = { line = 15349, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_IP, "")) then return 38 end
    end }
    steps[37] = { line = 15354, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 3987")
    end }
    steps[38] = { line = 15362, sec = "", fn = function(B, V, PROG)
      V.VAR_IPINFO_VALID = true; V.VAR_IPINFO_COUNTRY = ""
    end }
    steps[39] = { line = 15376, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 6929")
    end }
    steps[40] = { op = "try_begin", line = 15381, end_pc = 42 }
    steps[41] = { line = 15394, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add("https://api12.scamalytics.com/v3/langtoibk/?key=895ed282528d9fb5a967043e607c2510a1adf3522b57a9ec1f3ba0a1487516ed&ip=", V.VAR_IP), "GET", nil, "", nil)
    end }
    steps[42] = { op = "try_end", line = 15381 }
    steps[43] = { line = 15403, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 45 end
    end }
    steps[44] = { line = 15408, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9230")
    end }
    steps[45] = { line = 15416, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[46] = { line = 15422, sec = "", fn = function(B, V, PROG)
      V.VAR_STATUS_IP = B.jpath_value(V.VAR_SAVED_CONTENT, ".status")
    end }
    steps[47] = { line = 15431, sec = "", fn = function(B, V, PROG)
      V.VAR_IP_COUNTRY_NAME = B.jpath_value(V.VAR_SAVED_CONTENT, ".maxmind_geolite2.ip_country_name")
    end }
    steps[48] = { line = 15440, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.sneq(V.VAR_IP_COUNTRY_NAME, "United States")) then return 51 end
    end }
    steps[49] = { line = 15445, sec = "", fn = function(B, V, PROG)
      B.log(B.add("IP_COUNTRY_NAME: ", V.VAR_IP_COUNTRY_NAME))
    end }
    steps[50] = { line = 15450, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9230")
    end }
  end)()
  ;(function()
    steps[51] = { line = 15458, sec = "", fn = function(B, V, PROG)
      V.VAR_SCAMALYTICS_SCORE = B.jpath_value(V.VAR_SAVED_CONTENT, ".scamalytics_score")
    end }
    steps[52] = { line = 15467, sec = "", fn = function(B, V, PROG)
      if not B.truthy((B.num(V.VAR_SCAMALYTICS_SCORE) > B.num(10))) then return 55 end
    end }
    steps[53] = { line = 15472, sec = "", fn = function(B, V, PROG)
      B.new_http_client()
    end }
    steps[54] = { line = 15478, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9230")
    end }
    steps[55] = { line = 15486, sec = "", fn = function(B, V, PROG)
      B.log(B.add("SCORE: ", V.VAR_SCAMALYTICS_SCORE))
    end }
    steps[56] = { line = 15496, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("gray"), ["en"] = (B.add("Proxy: IP: ", V.VAR_IP)), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[57] = { line = 15501, sec = "", fn = function(B, V, PROG)
      B.new_http_client()
    end }
    steps[58] = { line = 15507, sec = "mở sever", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":8080/control/start_playing?path=/sv.lua"), "GET", nil, "", nil)
    end }
    steps[59] = { line = 15513, sec = "MOVE", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add(B.add(B.add(B.add(B.add(B.add(B.add(B.add(B.add("{\r\n  \"action\": \"RUNLUA\",\r\n  \"data\": \"return execute('/var/jb/usr/bin/shadowrocket-proxy-set ", V.VAR_TYPE_PROXY), " "), V.VAR_IP_PPROXY), " "), V.VAR_PORT), " "), V.VAR_USER_PROXY), " "), V.VAR_PASS_PROXY), "')\"\r\n}\r\n"), "", B.add("custom/", ("application/json")))
    end }
    steps[60] = { line = 15519, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
  end)()
  PROG.functions["Proxy_set"] = { name = "Proxy_set", steps = steps, labels = labels }
end

-- -------- Function: taotaikhoan (790 steps, 82 labels) --------
do
  local steps = {}
  local labels = { ["label name 7129"] = 2, ["label name 6850"] = 11, ["label name 4048"] = 25, ["label name 8395"] = 25, ["label name 1813"] = 30, ["label name 7153"] = 30, ["label name 4767"] = 55, ["label name 2987"] = 55, ["label name 1886"] = 69, ["label name 3470"] = 74, ["label name 1400"] = 74, ["label name 5435"] = 101, ["label name 7123"] = 115, ["label name 6546"] = 126, ["label name 305"] = 135, ["label name 2968"] = 150, ["label name 1281"] = 159, ["label name 5646"] = 160, ["label name 7267"] = 160, ["label name 9106"] = 166, ["label name 4489"] = 171, ["label name 9788"] = 181, ["label name 6602"] = 199, ["label name 3893"] = 206, ["label name 9053"] = 217, ["label name 5544"] = 234, ["label name 7241"] = 265, ["label name 7818"] = 289, ["label name 1953"] = 304, ["label name 2995"] = 316, ["label name 1299"] = 316, ["label name 4834"] = 321, ["label name 572"] = 331, ["label name 1628"] = 331, ["label name 9237"] = 346, ["label name 5651"] = 354, ["label name 663"] = 361, ["label name 5770"] = 361, ["label name 9750"] = 368, ["label name 5253"] = 377, ["label name 9719"] = 387, ["label name 4121"] = 394, ["label name 8552"] = 401, ["label name 2439"] = 406, ["label name 3613"] = 414, ["label name 5483"] = 414, ["label name 5494"] = 433, ["label name 9745"] = 440, ["label name 7519"] = 454, ["label name 7904"] = 454, ["label name 8185"] = 454, ["label name 3673"] = 459, ["label name 5067"] = 474, ["label name 4452"] = 479, ["label name 402"] = 479, ["label name 6211"] = 485, ["label name 8623"] = 491, ["label name 8654"] = 518, ["label name 6882"] = 518, ["label name 403"] = 523, ["label name 3842"] = 527, ["label name 8912"] = 538, ["label name 7292"] = 543, ["label name 397"] = 543, ["label name 8694"] = 569, ["label name 2612"] = 576, ["label name 9538"] = 582, ["label name 8538"] = 583, ["label name 8595"] = 588, ["label name 5957"] = 590, ["label name 4201"] = 602, ["label name 8329"] = 603, ["label name 4949"] = 632, ["label name 8032"] = 658, ["label name 1098"] = 664, ["label name 2802"] = 701, ["label name 6432"] = 711, ["label name 691"] = 730, ["label name 9334"] = 730, ["label name 7467"] = 734, ["label name 4123"] = 750, ["label name 3885"] = 762 };
  ;(function()
    steps[1] = { line = 3269, sec = "", fn = function(B, V, PROG)
      V.VAR_LECH_SONG = 0
    end }
    steps[2] = { line = 3279, sec = "xóa container IG mới", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"return execute('/var/jb/usr/bin/crane-cli delete com.burbn.instagram taoacc')\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[3] = { line = 3285, sec = "tạo container IG mới", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"return execute('/var/jb/usr/bin/crane-cli create com.burbn.instagram taoacc')\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[4] = { line = 3291, sec = "Chuyển Qua IG mới", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"return execute('/var/jb/usr/bin/crane-cli switch com.burbn.instagram taoacc')\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[5] = { line = 3297, sec = "xóa threads taoacc", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"return execute('/var/jb/usr/bin/crane-cli delete com.burbn.barcelona taoacc')\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[6] = { line = 3303, sec = "tạo container threads", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"return execute('/var/jb/usr/bin/crane-cli create com.burbn.barcelona taoacc')\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[7] = { line = 3309, sec = "Chuyển Qua IG mới", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"return execute('/var/jb/usr/bin/crane-cli switch com.burbn.barcelona taoacc')\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[8] = { line = 3315, sec = "Fake Devices", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\"action\":\"RUNLUA\",\"data\":\"return execute('/var/jb/usr/bin/ghost_instagram')\"}", "", B.add("custom/", ("application/json")))
    end }
    steps[9] = { line = 3321, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[10] = { line = 3327, sec = "", fn = function(B, V, PROG)
      V.VAR_JOB_ID = B.jpath_value(V.VAR_SAVED_CONTENT, ".job_id")
    end }
    steps[11] = { line = 3341, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(B.add(B.add("http://", V.VAR_IP_GOC), ":9210/job?id="), V.VAR_JOB_ID), "GET", nil, "", nil)
    end }
    steps[12] = { line = 3347, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[13] = { line = 3353, sec = "", fn = function(B, V, PROG)
      V.VAR_STATE = B.jpath_value(V.VAR_SAVED_CONTENT, ".state")
    end }
    steps[14] = { line = 3362, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_STATE, "running")) then return 17 end
    end }
    steps[15] = { line = 3367, sec = "", fn = function(B, V, PROG)
      B.sleep(1000)
    end }
    steps[16] = { line = 3372, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 6850")
    end }
    steps[17] = { line = 3380, sec = "", fn = function(B, V, PROG)
      V.VAR_SUCCESS_CHECK_SPOOF = B.jpath_value(V.VAR_SAVED_CONTENT, ".verdict")
    end }
    steps[18] = { line = 3389, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SUCCESS_CHECK_SPOOF, "FAIL")) then return 20 end
    end }
    steps[19] = { line = 3394, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7129")
    end }
    steps[20] = { line = 3402, sec = "", fn = function(B, V, PROG)
      V.VAR_DEVICEDISPLAYNAME = B.jpath_value(V.VAR_SAVED_CONTENT, ".display_name")
    end }
    steps[21] = { line = 3411, sec = "iosVersionBuild", fn = function(B, V, PROG)
      V.VAR_IOS = B.jpath_value(V.VAR_SAVED_CONTENT, ".ios")
    end }
    steps[22] = { line = 3420, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("brown"), ["en"] = (B.add(B.add(B.add("DEVICEDISPLAYNAME: ", V.VAR_DEVICEDISPLAYNAME), " || "), V.VAR_IOS)), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[23] = { line = 3425, sec = "", fn = function(B, V, PROG)
      B.sleep(1000)
    end }
    steps[24] = { line = 3430, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_USERNAME_LOI = 0
    end }
    steps[25] = { op = "try_begin", line = 3445, end_pc = 27 }
    steps[26] = { line = 3458, sec = "Vào IG", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"URL\",\r\n    \"data\": \"instagram://\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[27] = { op = "try_end", line = 3445 }
    steps[28] = { line = 3467, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 30 end
    end }
    steps[29] = { line = 3472, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8395")
    end }
    steps[30] = { op = "try_begin", line = 3490, end_pc = 32 }
    steps[31] = { line = 3503, sec = "Click Get started", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Get started\",\r\n    \"timeout\": 20,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[32] = { op = "try_end", line = 3490 }
    steps[33] = { line = 3512, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 35 end
    end }
    steps[34] = { line = 3517, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7153")
    end }
    steps[35] = { line = 3525, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[36] = { line = 3531, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 41 end
    end }
    steps[37] = { line = 3536, sec = "Create new account", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Create new account\",\r\n    \"timeout\": 20,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[38] = { line = 3542, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[39] = { line = 3548, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 41 end
    end }
    steps[40] = { line = 3553, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8395")
    end }
    steps[41] = { line = 3564, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_863384 = B.rs("Shop API", false, false)
    end }
    steps[42] = { line = 3564, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_863384, "Smspool")) then return 48 end
    end }
    steps[43] = { line = 3571, sec = "", fn = function(B, V, PROG)
      B.sleep(5000)
    end }
    steps[44] = { line = 3576, sec = "Mobile number", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Mobile number\",\r\n    \"timeout\": 15,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[45] = { line = 3582, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 3470")
    end }
    steps[46] = { line = 3587, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_666547 = B.rs("Type", false, false)
    end }
    steps[47] = { line = 3587, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_666547, "Phone")) then return 48 end
    end }
    steps[48] = { line = 3600, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_179279 = B.rs("Shop API", false, false)
    end }
    steps[49] = { line = 3600, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_179279, "Smsbower")) then return 55 end
    end }
    steps[50] = { line = 3607, sec = "", fn = function(B, V, PROG)
      B.sleep(5000)
    end }
  end)()
  ;(function()
    steps[51] = { line = 3612, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_666547 = B.rs("Type", false, false)
    end }
    steps[52] = { line = 3612, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_666547, "Phone")) then return 55 end
    end }
    steps[53] = { line = 3619, sec = "Mobile number", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Mobile number\",\r\n    \"timeout\": 15,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[54] = { line = 3625, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 3470")
    end }
    steps[55] = { op = "try_begin", line = 3646, end_pc = 57 }
    steps[56] = { line = 3659, sec = "Click Sign up with email", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Sign up with email\",\r\n    \"timeout\": 25,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[57] = { op = "try_end", line = 3646 }
    steps[58] = { line = 3668, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 60 end
    end }
    steps[59] = { line = 3673, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 2987")
    end }
    steps[60] = { line = 3681, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[61] = { line = 3687, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 68 end
    end }
    steps[62] = { line = 3692, sec = "check what's your birthaday", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Birthday\",\r\n    \"timeout\": 5,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[63] = { line = 3698, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[64] = { line = 3704, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 66 end
    end }
    steps[65] = { line = 3709, sec = "", fn = function(B, V, PROG)
      B.fail_user("Giao diện mới , bỏ qua")
    end }
    steps[66] = { line = 3717, sec = "Click Refresh", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Refresh\",\r\n    \"timeout\": 10,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[67] = { line = 3723, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 4767")
    end }
    steps[68] = { line = 3731, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[69] = { op = "try_begin", line = 3741, end_pc = 71 }
    steps[70] = { line = 3754, sec = "Click Email", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Email\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[71] = { op = "try_end", line = 3741 }
    steps[72] = { line = 3763, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 74 end
    end }
    steps[73] = { line = 3768, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 1886")
    end }
    steps[74] = { line = 3786, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_429990 = B.rs("Shop API", false, false)
    end }
    steps[75] = { line = 3786, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_429990, "Smsbower")) then return 99 end
    end }
    steps[76] = { line = 3793, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_478128 = B.rs("Type", false, false)
    end }
    steps[77] = { line = 3793, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_478128, "Phone")) then return 79 end
    end }
    steps[78] = { line = 3800, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request("https://smsbower.page/stubs/handler_api.php?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&action=getNumber&service=ig&country=36&providerIds=2524", "GET", nil, "", nil)
    end }
    steps[79] = { line = 3809, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_792310 = B.rs("Type", false, false)
    end }
    steps[80] = { line = 3809, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_792310, "ICloud")) then return 82 end
    end }
    steps[81] = { line = 3816, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request("https://smsbower.page/api/mail/getActivation?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&service=ig&domain=icloud.com", "GET", nil, "", nil)
    end }
    steps[82] = { line = 3825, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_324276 = B.rs("Type", false, false)
    end }
    steps[83] = { line = 3825, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_324276, "Mail")) then return 85 end
    end }
    steps[84] = { line = 3832, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request("https://smsbower.page/api/mail/getActivation?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&service=ig&domain=gmail.com", "GET", nil, "", nil)
    end }
    steps[85] = { line = 3841, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[86] = { line = 3847, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_478128 = B.rs("Type", false, false)
    end }
    steps[87] = { line = 3847, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_478128, "Phone")) then return 92 end
    end }
    steps[88] = { line = 3854, sec = "", fn = function(B, V, PROG)
      do local csv_res = B.csv_parse(V.VAR_SAVED_CONTENT, ":")
      V.VAR_ACCESS_NUMBER = B.avoid_nilb(csv_res[1], "")
      V.VAR_MAILID = B.avoid_nilb(csv_res[2], "")
      V.VAR_EMAIL = B.avoid_nilb(csv_res[3], "")
      end
    end }
    steps[89] = { line = 3874, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_ACCESS_NUMBER, "NO_NUMBERS")) then return 91 end
    end }
    steps[90] = { line = 3879, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("brown"), ["en"] = ("NO_NUMBERS"), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[91] = { line = 3887, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5646")
    end }
    steps[92] = { line = 3895, sec = "", fn = function(B, V, PROG)
      V.VAR_STATUS_GET_MAIL = B.jpath_value(V.VAR_SAVED_CONTENT, "status")
    end }
    steps[93] = { line = 3904, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_STATUS_GET_MAIL, 0)) then return 97 end
    end }
    steps[94] = { line = 3909, sec = "", fn = function(B, V, PROG)
      B.log(V.VAR_SAVED_CONTENT)
    end }
    steps[95] = { line = 3914, sec = "", fn = function(B, V, PROG)
      B.sleep(5000)
    end }
    steps[96] = { line = 3919, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 1400")
    end }
    steps[97] = { line = 3927, sec = "", fn = function(B, V, PROG)
      V.VAR_EMAIL = B.jpath_value(V.VAR_SAVED_CONTENT, "mail")
    end }
    steps[98] = { line = 3936, sec = "", fn = function(B, V, PROG)
      V.VAR_MAILID = B.jpath_value(V.VAR_SAVED_CONTENT, "mailId")
    end }
    steps[99] = { line = 3948, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_145744 = B.rs("Shop API", false, false)
    end }
    steps[100] = { line = 3948, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_145744, "API Icloud")) then return 133 end
    end }
  end)()
  ;(function()
    steps[101] = { op = "try_begin", line = 3960, end_pc = 103 }
    steps[102] = { line = 3973, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request("https://65.108.34.108.sslip.io/mail", ("POST"), "", "X-API-Key: uwbefowenfwenfoenfoiwfoiwnfowe33879dsfdkjn", B.add("custom/", ("application/json")))
    end }
    steps[103] = { op = "try_end", line = 3960 }
    steps[104] = { line = 3982, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 107 end
    end }
    steps[105] = { line = 3987, sec = "", fn = function(B, V, PROG)
      B.log(B.add("Error occurred : ", V.VAR_LAST_ERROR))
    end }
    steps[106] = { line = 3992, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5435")
    end }
    steps[107] = { line = 4000, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[108] = { line = 4006, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 502)) then return 111 end
    end }
    steps[109] = { line = 4011, sec = "", fn = function(B, V, PROG)
      B.log(V.VAR_SAVED_STATUS)
    end }
    steps[110] = { line = 4016, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5435")
    end }
    steps[111] = { line = 4024, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 503)) then return 122 end
    end }
    steps[112] = { line = 4029, sec = "", fn = function(B, V, PROG)
      V._loop_4029_111 = B.num(B.parse_int(1)) - 1
    end }
    steps[113] = { line = 4029, sec = "", fn = function(B, V, PROG)
      V._loop_4029_111 = V._loop_4029_111 + 1; V.VAR_CYCLE_INDEX = V._loop_4029_111; if V.VAR_CYCLE_INDEX > B.num(B.parse_int(120)) then return 121 end
    end }
    steps[114] = { line = 4036, sec = "", fn = function(B, V, PROG)
      B.sleep(5000)
    end }
    steps[115] = { op = "try_begin", line = 4046, end_pc = 117 }
    steps[116] = { line = 4059, sec = "Click Email", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Email\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[117] = { op = "try_end", line = 4046 }
    steps[118] = { line = 4068, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 120 end
    end }
    steps[119] = { line = 4073, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7123")
    end }
    steps[120] = { line = 4029, sec = "", fn = function(B, V, PROG)
      return 113
    end }
    steps[121] = { line = 4084, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5435")
    end }
    steps[122] = { line = 4092, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[123] = { line = 4098, sec = "", fn = function(B, V, PROG)
      V.VAR_EMAIL = B.jpath_value(V.VAR_SAVED_CONTENT, "mail")
    end }
    steps[124] = { line = 4107, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_EMAIL, "")) then return 133 end
    end }
    steps[125] = { line = 4112, sec = "", fn = function(B, V, PROG)
      B.log("Không có mail đợi tiếp")
    end }
    steps[126] = { op = "try_begin", line = 4122, end_pc = 128 }
    steps[127] = { line = 4135, sec = "Click Email", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Email\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[128] = { op = "try_end", line = 4122 }
    steps[129] = { line = 4144, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 131 end
    end }
    steps[130] = { line = 4149, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 6546")
    end }
    steps[131] = { line = 4157, sec = "", fn = function(B, V, PROG)
      B.sleep(10000)
    end }
    steps[132] = { line = 4162, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5435")
    end }
    steps[133] = { line = 4173, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_699008 = B.rs("Shop API", false, false)
    end }
    steps[134] = { line = 4173, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_699008, "Smspool")) then return 145 end
    end }
    steps[135] = { line = 4185, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request("https://api.smspool.net/purchase/sms?key=D8z4oRcYIsoo7aIcWPS0tvnUo2h0YOgl&country=9&service=457", "GET", nil, "", nil)
    end }
    steps[136] = { line = 4191, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[137] = { line = 4197, sec = "", fn = function(B, V, PROG)
      V.VAR_SUCCESS = B.jpath_value(V.VAR_SAVED_CONTENT, "success")
    end }
    steps[138] = { line = 4206, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SUCCESS, 0)) then return 142 end
    end }
    steps[139] = { line = 4211, sec = "", fn = function(B, V, PROG)
      B.log(V.VAR_SAVED_CONTENT)
    end }
    steps[140] = { line = 4216, sec = "", fn = function(B, V, PROG)
      B.sleep(10000)
    end }
    steps[141] = { line = 4221, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 305")
    end }
    steps[142] = { line = 4229, sec = "", fn = function(B, V, PROG)
      V.VAR_EMAIL = B.jpath_value(V.VAR_SAVED_CONTENT, "number")
    end }
    steps[143] = { line = 4238, sec = "", fn = function(B, V, PROG)
      V.VAR_ORDERID = B.jpath_value(V.VAR_SAVED_CONTENT, "orderid")
    end }
    steps[144] = { line = 4247, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 1281")
    end }
    steps[145] = { line = 4255, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_862269 = B.rs("Shop API", false, false)
    end }
    steps[146] = { line = 4255, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_862269, "ShopMail999")) then return 148 end
    end }
    steps[147] = { line = 4262, sec = "", fn = function(B, V, PROG)
      B.exec_fn(PROG, "API_GMAIL", V)
    end }
    steps[148] = { line = 4271, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_322183 = B.rs("Shop API", false, false)
    end }
    steps[149] = { line = 4271, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_322183, "Hotmail")) then return 157 end
    end }
    steps[150] = { line = 4283, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request("https://www.shopvia1s.net/api/buy_product?action=buyProduct&id=50510&amount=1&api_key=e0c3fd0c0070f1aebb42f894bdf1b957", "GET", nil, "", nil)
    end }
  end)()
  ;(function()
    steps[151] = { line = 4289, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[152] = { line = 4295, sec = "", fn = function(B, V, PROG)
      V.VAR_LIST_DATA = B.jpath_value(V.VAR_SAVED_CONTENT, ".data[0]")
    end }
    steps[153] = { line = 4304, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_LIST_DATA, "")) then return 156 end
    end }
    steps[154] = { line = 4309, sec = "", fn = function(B, V, PROG)
      B.log(V.VAR_SAVED_CONTENT)
    end }
    steps[155] = { line = 4314, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 2968")
    end }
    steps[156] = { line = 4322, sec = "", fn = function(B, V, PROG)
      do local csv_res = B.csv_parse(V.VAR_LIST_DATA, "|")
      V.VAR_LIST_WITH_ITEMS = csv_res
      V.VAR_EMAIL = B.avoid_nilb(csv_res[1], "")
      V.VAR_PASSMAIL = B.avoid_nilb(csv_res[2], "")
      V.VAR_REFRESH_TOKEN = B.avoid_nilb(csv_res[3], "")
      V.VAR_CLIENT_ID = B.avoid_nilb(csv_res[4], "")
      end
    end }
    steps[157] = { line = 4335, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_391586 = B.rs("Shop API", false, false)
    end }
    steps[158] = { line = 4335, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_391586, "CloneNha")) then return 159 end
    end }
    steps[159] = { line = 4350, sec = "", fn = function(B, V, PROG)
      B.log(V.VAR_EMAIL)
    end }
    steps[160] = { op = "try_begin", line = 4365, end_pc = 162 }
    steps[161] = { line = 4378, sec = "Pate Text", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{ \"action\": \"TEXT\", \"data\": \"", V.VAR_EMAIL), "\" }"), "", B.add("custom/", ("application/json")))
    end }
    steps[162] = { op = "try_end", line = 4365 }
    steps[163] = { line = 4387, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 165 end
    end }
    steps[164] = { line = 4392, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7267")
    end }
    steps[165] = { line = 4400, sec = "", fn = function(B, V, PROG)
      B.sleep(3000)
    end }
    steps[166] = { op = "try_begin", line = 4410, end_pc = 168 }
    steps[167] = { line = 4423, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[168] = { op = "try_end", line = 4410 }
    steps[169] = { line = 4432, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 171 end
    end }
    steps[170] = { line = 4437, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9106")
    end }
    steps[171] = { op = "try_begin", line = 4450, end_pc = 173 }
    steps[172] = { line = 4463, sec = "chekc Email required", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Email required.\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[173] = { op = "try_end", line = 4450 }
    steps[174] = { line = 4472, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 176 end
    end }
    steps[175] = { line = 4477, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 4489")
    end }
    steps[176] = { line = 4485, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[177] = { line = 4491, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 180 end
    end }
    steps[178] = { line = 4496, sec = "chekc Email required", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Email required.\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": -200,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[179] = { line = 4502, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5646")
    end }
    steps[180] = { line = 4510, sec = "check Enter the confirmation code", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Enter the confirmation code\",\r\n    \"timeout\": 10,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[181] = { op = "try_begin", line = 4521, end_pc = 183 }
    steps[182] = { line = 4534, sec = "check Enter the confirmation code", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Enter the confirmation code\",\r\n    \"timeout\": 3,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[183] = { op = "try_end", line = 4521 }
    steps[184] = { line = 4543, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 186 end
    end }
    steps[185] = { line = 4548, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9788")
    end }
    steps[186] = { line = 4556, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[187] = { line = 4562, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 212 end
    end }
    steps[188] = { line = 4567, sec = "Click pass", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n  \"action\": \"COLOR\",\r\n  \"script\": \"const [result, error] = findColors({\r\n    colors: [\r\n        { color: 13832496, x: 0, y: 0 },\r\n        { color: 13832496, x: 1, y: 15 },\r\n        { color: 16777215, x: 13, y: 6 }\r\n    ],\r\n    // count: 30,\r\n    // region: null,\r\n    // debug: false,\r\n    // rightToLeft: false,\r\n    // bottomToTop: false\r\n})\r\n\r\n\r\n\",\r\n  \"mode\": \"check\",\r\n  \"timeout\": 5,\r\n  \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[189] = { line = 4573, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[190] = { line = 4579, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 195 end
    end }
    steps[191] = { line = 4584, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_396878 = B.rs("Shop API", false, false)
    end }
    steps[192] = { line = 4584, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_396878, "Smsbower")) then return 194 end
    end }
    steps[193] = { line = 4591, sec = "HỦy mail", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(B.add("https://smsbower.page/api/mail/setStatus?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&id=", V.VAR_MAILID), "&status=2"), "GET", nil, "", nil)
    end }
    steps[194] = { line = 4600, sec = "", fn = function(B, V, PROG)
      B.fail_user("Mail Lỗi Đỏ")
    end }
    steps[195] = { line = 4608, sec = "Click We restrict certain", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"We restrict certain\",\r\n    \"timeout\": 5,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[196] = { line = 4614, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[197] = { line = 4620, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 199 end
    end }
    steps[198] = { line = 4625, sec = "", fn = function(B, V, PROG)
      B.fail_user("Mail Lỗi")
    end }
    steps[199] = { op = "try_begin", line = 4638, end_pc = 201 }
    steps[200] = { line = 4651, sec = "Click Refresh", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Refresh\",\r\n    \"timeout\": 3,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
  end)()
  ;(function()
    steps[201] = { op = "try_end", line = 4638 }
    steps[202] = { line = 4660, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 204 end
    end }
    steps[203] = { line = 4665, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 6602")
    end }
    steps[204] = { line = 4673, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[205] = { line = 4679, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 211 end
    end }
    steps[206] = { op = "try_begin", line = 4689, end_pc = 208 }
    steps[207] = { line = 4702, sec = "Click Email", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Email\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[208] = { op = "try_end", line = 4689 }
    steps[209] = { line = 4711, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 211 end
    end }
    steps[210] = { line = 4716, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 3893")
    end }
    steps[211] = { line = 4727, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5646")
    end }
    steps[212] = { line = 4735, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("cyan"), ["en"] = ("Check OTP"), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[213] = { line = 4740, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_OTP = 0
    end }
    steps[214] = { line = 4745, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_429990 = B.rs("Shop API", false, false)
    end }
    steps[215] = { line = 4745, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_429990, "Smsbower")) then return 262 end
    end }
    steps[216] = { line = 4752, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_OTP = 0
    end }
    steps[217] = { line = 4762, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_792310 = B.rs("Type", false, false)
    end }
    steps[218] = { line = 4762, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_792310, "ICloud")) then return 232 end
    end }
    steps[219] = { line = 4769, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add("https://smsbower.page/api/mail/getCode?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&mailId=", V.VAR_MAILID), "GET", nil, "", nil)
    end }
    steps[220] = { line = 4775, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[221] = { line = 4781, sec = "", fn = function(B, V, PROG)
      V.VAR_STATUS_CHECK_MAIL = B.jpath_value(V.VAR_SAVED_CONTENT, "status")
    end }
    steps[222] = { line = 4790, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_STATUS_CHECK_MAIL, 0)) then return 231 end
    end }
    steps[223] = { line = 4795, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_OTP = B.add(B.parse_int(V.VAR_CHECK_OTP), B.parse_int(1))
    end }
    steps[224] = { line = 4800, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_CHECK_OTP, 12)) then return 229 end
    end }
    steps[225] = { line = 4805, sec = "HỦy mail", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(B.add("https://smsbower.page/api/mail/setStatus?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&id=", V.VAR_MAILID), "&status=2"), "GET", nil, "", nil)
    end }
    steps[226] = { line = 4811, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[227] = { line = 4817, sec = "", fn = function(B, V, PROG)
      B.log(V.VAR_SAVED_CONTENT)
    end }
    steps[228] = { line = 4822, sec = "", fn = function(B, V, PROG)
      B.fail_user("Không về code")
    end }
    steps[229] = { line = 4830, sec = "", fn = function(B, V, PROG)
      B.sleep(5000)
    end }
    steps[230] = { line = 4835, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9053")
    end }
    steps[231] = { line = 4843, sec = "", fn = function(B, V, PROG)
      V.VAR_OTP = B.jpath_value(V.VAR_SAVED_CONTENT, "code")
    end }
    steps[232] = { line = 4855, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_113412 = B.rs("Type", false, false)
    end }
    steps[233] = { line = 4855, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_113412, "Phone")) then return 246 end
    end }
    steps[234] = { line = 4867, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add("https://smsbower.page/stubs/handler_api.php?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&action=getStatus&id=", V.VAR_MAILID), "GET", nil, "", nil)
    end }
    steps[235] = { line = 4873, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[236] = { line = 4879, sec = "", fn = function(B, V, PROG)
      do local csv_res = B.csv_parse(V.VAR_SAVED_CONTENT, ":")
      V.VAR_STATUS_CHECK = B.avoid_nilb(csv_res[1], "")
      V.VAR_OTP = B.avoid_nilb(csv_res[2], "")
      end
    end }
    steps[237] = { line = 4894, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_STATUS_CHECK, "STATUS_WAIT_CODE")) then return 246 end
    end }
    steps[238] = { line = 4899, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_OTP = B.add(B.parse_int(V.VAR_CHECK_OTP), B.parse_int(1))
    end }
    steps[239] = { line = 4904, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_CHECK_OTP, 20)) then return 244 end
    end }
    steps[240] = { line = 4909, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add("https://smsbower.page/stubs/handler_api.php?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&action=setStatus&status=8&id=", V.VAR_MAILID), "GET", nil, "", nil)
    end }
    steps[241] = { line = 4915, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[242] = { line = 4921, sec = "", fn = function(B, V, PROG)
      B.log(V.VAR_SAVED_CONTENT)
    end }
    steps[243] = { line = 4926, sec = "", fn = function(B, V, PROG)
      B.fail_user("Không về CODE")
    end }
    steps[244] = { line = 4934, sec = "", fn = function(B, V, PROG)
      B.sleep(5000)
    end }
    steps[245] = { line = 4939, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5544")
    end }
    steps[246] = { line = 4950, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_812711 = B.rs("Type", false, false)
    end }
    steps[247] = { line = 4950, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_812711, "Mail")) then return 262 end
    end }
    steps[248] = { line = 4957, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add("https://smsbower.page/api/mail/getCode?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&mailId=", V.VAR_MAILID), "GET", nil, "", nil)
    end }
    steps[249] = { line = 4963, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[250] = { line = 4969, sec = "", fn = function(B, V, PROG)
      V.VAR_STATUS_CHECK_MAIL = B.jpath_value(V.VAR_SAVED_CONTENT, "status")
    end }
  end)()
  ;(function()
    steps[251] = { line = 4978, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_STATUS_CHECK_MAIL, 0)) then return 260 end
    end }
    steps[252] = { line = 4983, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_OTP = B.add(B.parse_int(V.VAR_CHECK_OTP), B.parse_int(1))
    end }
    steps[253] = { line = 4988, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_CHECK_OTP, 12)) then return 258 end
    end }
    steps[254] = { line = 4993, sec = "HỦy mail", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(B.add("https://smsbower.page/api/mail/setStatus?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&id=", V.VAR_MAILID), "&status=2"), "GET", nil, "", nil)
    end }
    steps[255] = { line = 4999, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[256] = { line = 5005, sec = "", fn = function(B, V, PROG)
      B.log(V.VAR_SAVED_CONTENT)
    end }
    steps[257] = { line = 5010, sec = "", fn = function(B, V, PROG)
      B.fail_user("Không về code")
    end }
    steps[258] = { line = 5018, sec = "", fn = function(B, V, PROG)
      B.sleep(5000)
    end }
    steps[259] = { line = 5023, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9053")
    end }
    steps[260] = { line = 5031, sec = "HỦy mail", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(B.add("https://smsbower.page/api/mail/setStatus?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&id=", V.VAR_MAILID), "&status=3"), "GET", nil, "", nil)
    end }
    steps[261] = { line = 5037, sec = "", fn = function(B, V, PROG)
      V.VAR_OTP = B.jpath_value(V.VAR_SAVED_CONTENT, "code")
    end }
    steps[262] = { line = 5052, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_625060 = B.rs("Shop API", false, false)
    end }
    steps[263] = { line = 5052, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_625060, "API Icloud")) then return 284 end
    end }
    steps[264] = { line = 5059, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_OTP_COUNT = 0
    end }
    steps[265] = { op = "try_begin", line = 5069, end_pc = 267 }
    steps[266] = { line = 5082, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request("https://65.108.34.108.sslip.io/code", ("POST"), B.add(B.add("{\r\n  \"mail\": \"", V.VAR_EMAIL), "\"\r\n}"), "X-API-Key: uwbefowenfwenfoenfoiwfoiwnfowe33879dsfdkjn", B.add("custom/", ("application/json")))
    end }
    steps[267] = { op = "try_end", line = 5069 }
    steps[268] = { line = 5091, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 271 end
    end }
    steps[269] = { line = 5096, sec = "", fn = function(B, V, PROG)
      B.log(B.add("Error occurred : ", V.VAR_LAST_ERROR))
    end }
    steps[270] = { line = 5101, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7241")
    end }
    steps[271] = { line = 5109, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[272] = { line = 5115, sec = "", fn = function(B, V, PROG)
      if not B.truthy((B.truthy(B.eq(V.VAR_SAVED_STATUS, 429)) and (B.eq(V.VAR_SAVED_STATUS, 429)) or (B.eq(V.VAR_SAVED_STATUS, 503)))) then return 276 end
    end }
    steps[273] = { line = 5120, sec = "Đợi pass", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 1,\r\n     \"ex\": true,\r\n    \"offset\": -200,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[274] = { line = 5126, sec = "", fn = function(B, V, PROG)
      B.sleep(20000)
    end }
    steps[275] = { line = 5131, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7241")
    end }
    steps[276] = { line = 5139, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[277] = { line = 5145, sec = "", fn = function(B, V, PROG)
      V.VAR_OTP = B.jpath_value(V.VAR_SAVED_CONTENT, ".code")
    end }
    steps[278] = { line = 5154, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_OTP, B.NULL)) then return 284 end
    end }
    steps[279] = { line = 5159, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_OTP_COUNT = B.add(B.parse_int(V.VAR_CHECK_OTP_COUNT), B.parse_int(1))
    end }
    steps[280] = { line = 5164, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_CHECK_OTP_COUNT, 7)) then return 282 end
    end }
    steps[281] = { line = 5169, sec = "", fn = function(B, V, PROG)
      B.fail_user("Không Về Code")
    end }
    steps[282] = { line = 5177, sec = "", fn = function(B, V, PROG)
      B.sleep(5000)
    end }
    steps[283] = { line = 5182, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7241")
    end }
    steps[284] = { line = 5193, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_730559 = B.rs("Shop API", false, false)
    end }
    steps[285] = { line = 5193, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_730559, "CloneNha")) then return 286 end
    end }
    steps[286] = { line = 5203, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_239223 = B.rs("Shop API", false, false)
    end }
    steps[287] = { line = 5203, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_239223, "ShopMail999")) then return 298 end
    end }
    steps[288] = { line = 5210, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_OTP = 0
    end }
    steps[289] = { line = 5220, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add("https://api.shopgmail9999.com/api/ApiV2/CheckOtp?apikey=3ada3340e0d481e83e9c0167bdee4533&orderid=", V.VAR_ORDERID), "GET", nil, "", nil)
    end }
    steps[290] = { line = 5226, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[291] = { line = 5232, sec = "", fn = function(B, V, PROG)
      V.VAR_OTP = B.jpath_value(V.VAR_SAVED_CONTENT, "..otp")
    end }
    steps[292] = { line = 5241, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_OTP, "")) then return 298 end
    end }
    steps[293] = { line = 5246, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_OTP = B.add(B.parse_int(V.VAR_CHECK_OTP), B.parse_int(1))
    end }
    steps[294] = { line = 5251, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_CHECK_OTP, 50)) then return 296 end
    end }
    steps[295] = { line = 5256, sec = "", fn = function(B, V, PROG)
      return B.goto_label("RA_MAIN")
    end }
    steps[296] = { line = 5264, sec = "", fn = function(B, V, PROG)
      B.sleep(3000)
    end }
    steps[297] = { line = 5269, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7818")
    end }
    steps[298] = { line = 5280, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_831866 = B.rs("Shop API", false, false)
    end }
    steps[299] = { line = 5280, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_831866, "Hotmail")) then return 301 end
    end }
    steps[300] = { line = 5287, sec = "", fn = function(B, V, PROG)
      V.VAR_LINK = B.emb_hotmail_read(V.VAR_LIST_DATA)
    end }
  end)()
  ;(function()
    steps[301] = { line = 5296, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_506317 = B.rs("Shop API", false, false)
    end }
    steps[302] = { line = 5296, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_506317, "Smspool")) then return 315 end
    end }
    steps[303] = { line = 5303, sec = "", fn = function(B, V, PROG)
      B.sleep(10000)
    end }
    steps[304] = { line = 5313, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add("https://api.smspool.net/sms/check?key=D8z4oRcYIsoo7aIcWPS0tvnUo2h0YOgl&orderid=", V.VAR_ORDERID), "GET", nil, "", nil)
    end }
    steps[305] = { line = 5319, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[306] = { line = 5325, sec = "", fn = function(B, V, PROG)
      V.VAR_STATUS_SMS = B.jpath_value(V.VAR_SAVED_CONTENT, "status")
    end }
    steps[307] = { line = 5334, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_STATUS_SMS, 1)) then return 314 end
    end }
    steps[308] = { line = 5339, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_OTP = B.add(B.parse_int(V.VAR_CHECK_OTP), B.parse_int(1))
    end }
    steps[309] = { line = 5344, sec = "", fn = function(B, V, PROG)
      B.log(B.add("Check OTP ", V.VAR_CHECK_OTP))
    end }
    steps[310] = { line = 5349, sec = "", fn = function(B, V, PROG)
      B.sleep(10000)
    end }
    steps[311] = { line = 5354, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_CHECK_OTP, 7)) then return 313 end
    end }
    steps[312] = { line = 5359, sec = "", fn = function(B, V, PROG)
      B.fail_user("Không về OTP")
    end }
    steps[313] = { line = 5367, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 1953")
    end }
    steps[314] = { line = 5375, sec = "", fn = function(B, V, PROG)
      V.VAR_OTP = B.jpath_value(V.VAR_SAVED_CONTENT, "sms")
    end }
    steps[315] = { line = 5387, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("cyan"), ["en"] = (B.add("Code: ", V.VAR_OTP)), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[316] = { op = "try_begin", line = 5402, end_pc = 318 }
    steps[317] = { line = 5415, sec = "Pate Text", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{ \"action\": \"TEXT\", \"data\": \"", V.VAR_OTP), "\" }"), "", B.add("custom/", ("application/json")))
    end }
    steps[318] = { op = "try_end", line = 5402 }
    steps[319] = { line = 5424, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 321 end
    end }
    steps[320] = { line = 5429, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 1299")
    end }
    steps[321] = { op = "try_begin", line = 5442, end_pc = 323 }
    steps[322] = { line = 5455, sec = "Đợi pass", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Code is required.\",\r\n    \"timeout\": 5,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[323] = { op = "try_end", line = 5442 }
    steps[324] = { line = 5464, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 326 end
    end }
    steps[325] = { line = 5469, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 4834")
    end }
    steps[326] = { line = 5477, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[327] = { line = 5483, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 330 end
    end }
    steps[328] = { line = 5488, sec = "Đợi pass", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Code is required.\",\r\n    \"timeout\": 5,\r\n     \"ex\": false,\r\n    \"offset\": -100,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[329] = { line = 5494, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 2995")
    end }
    steps[330] = { line = 5502, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_CODE_LOI = 0
    end }
    steps[331] = { op = "try_begin", line = 5517, end_pc = 333 }
    steps[332] = { line = 5530, sec = "check Enter the confirmation code", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Enter the confirmation code\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[333] = { op = "try_end", line = 5517 }
    steps[334] = { line = 5539, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 336 end
    end }
    steps[335] = { line = 5544, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 1628")
    end }
    steps[336] = { line = 5552, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[337] = { line = 5558, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 360 end
    end }
    steps[338] = { line = 5563, sec = "Đợi pass", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Code is required.\",\r\n    \"timeout\": 5,\r\n     \"ex\": false,\r\n    \"offset\": -100,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[339] = { line = 5569, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[340] = { line = 5575, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 342 end
    end }
    steps[341] = { line = 5580, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 2995")
    end }
    steps[342] = { line = 5588, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_CODE_LOI = B.add(B.parse_int(V.VAR_CHECK_CODE_LOI), B.parse_int(1))
    end }
    steps[343] = { line = 5593, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_CHECK_CODE_LOI, 10)) then return 345 end
    end }
    steps[344] = { line = 5598, sec = "", fn = function(B, V, PROG)
      B.fail_user("Không tới nổi trang PASS")
    end }
    steps[345] = { line = 5606, sec = "", fn = function(B, V, PROG)
      B.sleep(5000)
    end }
    steps[346] = { op = "try_begin", line = 5616, end_pc = 348 }
    steps[347] = { line = 5629, sec = "check code correctly", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"confirmation code correctly.\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[348] = { op = "try_end", line = 5616 }
    steps[349] = { line = 5638, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 351 end
    end }
    steps[350] = { line = 5643, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9237")
    end }
  end)()
  ;(function()
    steps[351] = { line = 5651, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[352] = { line = 5657, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 354 end
    end }
    steps[353] = { line = 5662, sec = "", fn = function(B, V, PROG)
      B.fail_user("Code hết hạn")
    end }
    steps[354] = { op = "try_begin", line = 5675, end_pc = 356 }
    steps[355] = { line = 5688, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[356] = { op = "try_end", line = 5675 }
    steps[357] = { line = 5697, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 359 end
    end }
    steps[358] = { line = 5702, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5651")
    end }
    steps[359] = { line = 5710, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 572")
    end }
    steps[360] = { line = 5718, sec = "", fn = function(B, V, PROG)
      V.VAR_PASSWORD = B.random_string(12, "abcdefghijklmnopqrstuvwxyz0123456789")
    end }
    steps[361] = { op = "try_begin", line = 5733, end_pc = 363 }
    steps[362] = { line = 5746, sec = "Đợi pass", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Password\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[363] = { op = "try_end", line = 5733 }
    steps[364] = { line = 5755, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 366 end
    end }
    steps[365] = { line = 5760, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5770")
    end }
    steps[366] = { line = 5768, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[367] = { line = 5774, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 412 end
    end }
    steps[368] = { op = "try_begin", line = 5784, end_pc = 370 }
    steps[369] = { line = 5797, sec = "Full name", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Full name\",\r\n    \"timeout\": 7,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[370] = { op = "try_end", line = 5784 }
    steps[371] = { line = 5806, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 373 end
    end }
    steps[372] = { line = 5811, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9750")
    end }
    steps[373] = { line = 5819, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[374] = { line = 5825, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 377 end
    end }
    steps[375] = { line = 5830, sec = "", fn = function(B, V, PROG)
      V.VAR_LECH_SONG = true
    end }
    steps[376] = { line = 5835, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 4452")
    end }
    steps[377] = { op = "try_begin", line = 5848, end_pc = 379 }
    steps[378] = { line = 5861, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 2,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[379] = { op = "try_end", line = 5848 }
    steps[380] = { line = 5870, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 382 end
    end }
    steps[381] = { line = 5875, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5253")
    end }
    steps[382] = { line = 5883, sec = "check what's your birthaday", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"what's your birthday?\",\r\n    \"timeout\": 2,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[383] = { line = 5889, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[384] = { line = 5895, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 386 end
    end }
    steps[385] = { line = 5900, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7519")
    end }
    steps[386] = { line = 5908, sec = "", fn = function(B, V, PROG)
      B.log("Tiếp tục đợi pass")
    end }
    steps[387] = { op = "try_begin", line = 5918, end_pc = 389 }
    steps[388] = { line = 5931, sec = "How old are you", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"How old are you?\",\r\n    \"timeout\": 2,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[389] = { op = "try_end", line = 5918 }
    steps[390] = { line = 5940, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 392 end
    end }
    steps[391] = { line = 5945, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9719")
    end }
    steps[392] = { line = 5953, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[393] = { line = 5959, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 411 end
    end }
    steps[394] = { op = "try_begin", line = 5969, end_pc = 396 }
    steps[395] = { line = 5982, sec = "How old are you", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"How old are you?\",\r\n    \"timeout\": 2,\r\n     \"ex\": false,\r\n    \"offset\": 200,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[396] = { op = "try_end", line = 5969 }
    steps[397] = { line = 5991, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 399 end
    end }
    steps[398] = { line = 5996, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 4121")
    end }
    steps[399] = { line = 6004, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[400] = { line = 6009, sec = "Pate Text", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{ \"action\": \"TEXT\", \"data\": \"20\" }", "", B.add("custom/", ("application/json")))
    end }
  end)()
  ;(function()
    steps[401] = { op = "try_begin", line = 6020, end_pc = 403 }
    steps[402] = { line = 6033, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 2,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[403] = { op = "try_end", line = 6020 }
    steps[404] = { line = 6042, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 406 end
    end }
    steps[405] = { line = 6047, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8552")
    end }
    steps[406] = { op = "try_begin", line = 6060, end_pc = 408 }
    steps[407] = { line = 6073, sec = "Click OK", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"OK\",\r\n    \"timeout\": 7,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[408] = { op = "try_end", line = 6060 }
    steps[409] = { line = 6082, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 411 end
    end }
    steps[410] = { line = 6087, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 2439")
    end }
    steps[411] = { line = 6098, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 663")
    end }
    steps[412] = { line = 6106, sec = "Pate Text", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{ \"action\": \"TEXT\", \"data\": \"", V.VAR_PASSWORD), "\" }"), "", B.add("custom/", ("application/json")))
    end }
    steps[413] = { line = 6112, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("cyan"), ["en"] = (B.add("Pass: ", V.VAR_PASSWORD)), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[414] = { op = "try_begin", line = 6127, end_pc = 416 }
    steps[415] = { line = 6140, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[416] = { op = "try_end", line = 6127 }
    steps[417] = { line = 6149, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 419 end
    end }
    steps[418] = { line = 6154, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5483")
    end }
    steps[419] = { line = 6162, sec = "", fn = function(B, V, PROG)
      B.sleep(4000)
    end }
    steps[420] = { line = 6167, sec = "Đợi pass", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Password\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[421] = { line = 6173, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[422] = { line = 6179, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 440 end
    end }
    steps[423] = { line = 6184, sec = "", fn = function(B, V, PROG)
      B.log("Click lại NEXT pass")
    end }
    steps[424] = { line = 6189, sec = "Click Refresh", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Refresh\",\r\n    \"timeout\": 10,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[425] = { line = 6195, sec = "Confirm you're human to", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Confirm you're human to\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[426] = { line = 6201, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[427] = { line = 6207, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 429 end
    end }
    steps[428] = { line = 6212, sec = "", fn = function(B, V, PROG)
      B.fail_user("Die")
    end }
    steps[429] = { line = 6220, sec = "Password required", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Password cannot be empty.\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[430] = { line = 6226, sec = "", fn = function(B, V, PROG)
      V.VAR_PASS_EMPTY = B.http_status()
    end }
    steps[431] = { line = 6232, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_PASS_EMPTY) then return 439 end
    end }
    steps[432] = { line = 6237, sec = "Password required", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Password cannot be empty.\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": -150,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[433] = { op = "try_begin", line = 6248, end_pc = 435 }
    steps[434] = { line = 6261, sec = "Click pass", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n  \"action\": \"COLOR\",\r\n  \"script\": \"const [result, error] = findColors({\r\n    colors: [\r\n        { color: 13832496, x: 0, y: 0 },\r\n        { color: 13832496, x: 1, y: 16 },\r\n        { color: 13832496, x: 15, y: 26 },\r\n        { color: 13832496, x: 27, y: -7 }\r\n    ],\r\n    // count: 30,\r\n    // region: null,\r\n    // debug: false,\r\n    // rightToLeft: false,\r\n    // bottomToTop: false\r\n})\r\n\r\n\r\n\",\r\n  \"mode\": \"click\",\r\n  \"timeout\": 5,\r\n  \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[435] = { op = "try_end", line = 6248 }
    steps[436] = { line = 6270, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 438 end
    end }
    steps[437] = { line = 6275, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5494")
    end }
    steps[438] = { line = 6283, sec = "Pate Text", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{ \"action\": \"TEXT\", \"data\": \"", V.VAR_PASSWORD), "\" }"), "", B.add("custom/", ("application/json")))
    end }
    steps[439] = { line = 6292, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 3613")
    end }
    steps[440] = { op = "try_begin", line = 6305, end_pc = 442 }
    steps[441] = { line = 6318, sec = "check what's your birthaday", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"what's your birthday?\",\r\n    \"timeout\": 15,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[442] = { op = "try_end", line = 6305 }
    steps[443] = { line = 6327, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 445 end
    end }
    steps[444] = { line = 6332, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9745")
    end }
    steps[445] = { line = 6340, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[446] = { line = 6346, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 454 end
    end }
    steps[447] = { line = 6351, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_USERNAME_LOI = B.add(B.parse_int(V.VAR_CHECK_USERNAME_LOI), B.parse_int(1))
    end }
    steps[448] = { line = 6356, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_CHECK_USERNAME_LOI, 10)) then return 452 end
    end }
    steps[449] = { line = 6361, sec = "", fn = function(B, V, PROG)
      do local len = B.arr_len(V.VAR_NAME_LIST); if len > 0 then local r = math.random(0, len - 1); V.VAR_NAME_GET = B.arr_get(V.VAR_NAME_LIST, r); B.arr_splice(V.VAR_NAME_LIST, r, 1) else V.VAR_NAME_GET = nil end end
    end }
    steps[450] = { line = 6370, sec = "", fn = function(B, V, PROG)
      V.VAR_USERNAME = B.jpath_value(V.VAR_NAME_GET, "username")
    end }
  end)()
  ;(function()
    steps[451] = { line = 6379, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 403")
    end }
    steps[452] = { line = 6387, sec = "Not now", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Not now\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[453] = { line = 6393, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9538")
    end }
    steps[454] = { op = "try_begin", line = 6416, end_pc = 456 }
    steps[455] = { line = 6429, sec = "check what's your birthaday", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"what's your birthday?\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 400,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[456] = { op = "try_end", line = 6416 }
    steps[457] = { line = 6438, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 459 end
    end }
    steps[458] = { line = 6443, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8185")
    end }
    steps[459] = { op = "try_begin", line = 6456, end_pc = 461 }
    steps[460] = { line = 6469, sec = "Chọn ngày tháng năm sinh", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"\r\n\r\ntouchDown(6, 971.34, 1726.18);\r\nusleep(33677.58);\r\ntouchMove(6, 962.64, 1768.66);\r\nusleep(16559.96);\r\ntouchMove(6, 962.64, 1813.10);\r\nusleep(16813.00);\r\ntouchMove(6, 964.57, 1881.67);\r\nusleep(16412.25);\r\ntouchMove(6, 982.93, 1997.53);\r\nusleep(16628.58);\r\ntouchMove(6, 1027.39, 2159.75);\r\nusleep(15126.88);\r\ntouchUp(6, 1033.19, 2165.55);\r\nusleep(218368.58);\r\n\r\ntouchDown(1, 1014.83, 1724.26);\r\nusleep(66828.00);\r\ntouchMove(1, 999.37, 1734.87);\r\nusleep(16480.71);\r\ntouchMove(1, 999.37, 1739.72);\r\nusleep(16835.08);\r\ntouchMove(1, 999.37, 1742.62);\r\nusleep(16528.33);\r\ntouchMove(1, 999.37, 1746.46);\r\nusleep(16759.58);\r\ntouchMove(1, 999.37, 1750.34);\r\nusleep(16768.04);\r\ntouchMove(1, 999.37, 1754.18);\r\nusleep(16701.42);\r\ntouchMove(1, 999.37, 1759.03);\r\nusleep(16572.88);\r\ntouchMove(1, 999.37, 1765.77);\r\nusleep(16696.54);\r\ntouchMove(1, 999.37, 1770.62);\r\nusleep(16320.12);\r\ntouchMove(1, 999.37, 1775.44);\r\nusleep(17102.46);\r\ntouchMove(1, 999.37, 1779.31);\r\nusleep(16607.42);\r\ntouchMove(1, 999.37, 1781.23);\r\nusleep(16655.12);\r\ntouchMove(1, 999.37, 1784.13);\r\nusleep(16643.29);\r\ntouchMove(1, 999.37, 1787.03);\r\nusleep(16919.29);\r\ntouchMove(1, 999.37, 1789.92);\r\nusleep(16274.50);\r\ntouchMove(1, 999.37, 1792.82);\r\nusleep(16876.42);\r\ntouchMove(1, 999.37, 1794.74);\r\nusleep(16593.42);\r\ntouchMove(1, 999.37, 1796.70);\r\nusleep(16611.38);\r\ntouchMove(1, 999.37, 1799.59);\r\nusleep(16676.67);\r\ntouchMove(1, 999.37, 1802.49);\r\nusleep(16843.58);\r\ntouchMove(1, 999.37, 1805.35);\r\nusleep(16758.00);\r\ntouchMove(1, 999.37, 1808.25);\r\nusleep(16202.79);\r\ntouchMove(1, 1000.33, 1812.13);\r\nusleep(16740.00);\r\ntouchMove(1, 1000.33, 1816.00);\r\nusleep(16659.00);\r\ntouchMove(1, 1000.33, 1821.80);\r\nusleep(16638.00);\r\ntouchMove(1, 1000.33, 1826.61);\r\nusleep(16829.88);\r\ntouchMove(1, 1000.33, 1830.49);\r\nusleep(16537.88);\r\ntouchMove(1, 1000.33, 1834.33);\r\nusleep(16586.33);\r\ntouchMove(1, 1000.33, 1837.23);\r\nusleep(16763.17);\r\ntouchMove(1, 1000.33, 1839.18);\r\nusleep(17320.00);\r\ntouchMove(1, 1000.33, 1841.10);\r\nusleep(16116.79);\r\ntouchMove(1, 1000.33, 1844.00);\r\nusleep(16718.79);\r\ntouchMove(1, 1000.33, 1847.87);\r\nusleep(16650.04);\r\ntouchMove(1, 1000.33, 1851.71);\r\nusleep(16656.62);\r\ntouchMove(1, 1000.33, 1855.59);\r\nusleep(16864.12);\r\ntouchMove(1, 1000.33, 1858.49);\r\nusleep(16489.04);\r\ntouchMove(1, 1000.33, 1863.30);\r\nusleep(16768.17);\r\ntouchMove(1, 1000.33, 1873.92);\r\nusleep(16570.00);\r\ntouchMove(1, 1000.33, 1915.46);\r\nusleep(16549.42);\r\ntouchMove(1, 1007.10, 1986.92);\r\nusleep(16754.21);\r\ntouchMove(1, 1022.56, 2060.30);\r\nusleep(16698.54);\r\ntouchUp(1, 1046.72, 2099.88);\r\nusleep(116577.62);\r\n\r\ntouchDown(2, 1030.29, 1814.05);\r\nusleep(450202.46);\r\ntouchMove(2, 1007.10, 1816.00);\r\nusleep(16665.96);\r\ntouchMove(2, 1007.10, 1816.94);\r\nusleep(16932.29);\r\ntouchMove(2, 1007.10, 1819.84);\r\nusleep(16815.42);\r\ntouchMove(2, 1007.10, 1822.74);\r\nusleep(16508.17);\r\ntouchMove(2, 1007.10, 1825.64);\r\nusleep(17201.04);\r\ntouchMove(2, 1007.10, 1830.49);\r\nusleep(16481.38);\r\ntouchMove(2, 1007.10, 1835.31);\r\nusleep(16303.00);\r\ntouchMove(2, 1007.10, 1840.12);\r\nusleep(17173.75);\r\ntouchMove(2, 1007.10, 1844.98);\r\nusleep(16187.83);\r\ntouchMove(2, 1007.10, 1850.77);\r\nusleep(16640.46);\r\ntouchMove(2, 1007.10, 1856.56);\r\nusleep(16577.50);\r\ntouchMove(2, 1007.10, 1863.30);\r\nusleep(16668.92);\r\ntouchMove(2, 1007.10, 1871.02);\r\nusleep(16563.54);\r\ntouchMove(2, 1007.10, 1879.71);\r\nusleep(16622.54);\r\ntouchMove(2, 1007.10, 1886.48);\r\nusleep(16645.25);\r\ntouchMove(2, 1007.10, 1893.25);\r\nusleep(16624.67);\r\ntouchMove(2, 1007.10, 1899.99);\r\nusleep(16741.08);\r\ntouchMove(2, 1007.10, 1906.77);\r\nusleep(16762.88);\r\ntouchMove(2, 1007.10, 1912.56);\r\nusleep(16434.62);\r\ntouchMove(2, 1007.10, 1917.38);\r\nusleep(16913.79);\r\ntouchMove(2, 1007.10, 1921.25);\r\nusleep(16423.33);\r\ntouchMove(2, 1007.10, 1924.15);\r\nusleep(16727.96);\r\ntouchMove(2, 1007.10, 1927.99);\r\nusleep(16739.58);\r\ntouchMove(2, 1007.10, 1931.87);\r\nusleep(16814.38);\r\ntouchMove(2, 1007.10, 1935.74);\r\nusleep(16482.67);\r\ntouchMove(2, 1007.10, 1939.58);\r\nusleep(16833.00);\r\ntouchMove(2, 1007.10, 1942.48);\r\nusleep(16543.29);\r\ntouchMove(2, 1007.10, 1945.38);\r\nusleep(16783.12);\r\ntouchMove(2, 1007.10, 1948.27);\r\nusleep(17067.38);\r\ntouchMove(2, 1007.10, 1950.23);\r\nusleep(15995.17);\r\ntouchMove(2, 1007.10, 1953.12);\r\nusleep(16821.92);\r\ntouchMove(2, 1007.10, 1956.02);\r\nusleep(16647.25);\r\ntouchMove(2, 1007.10, 1958.92);\r\nusleep(16673.00);\r\ntouchMove(2, 1007.10, 1963.74);\r\nusleep(17015.96);\r\ntouchMove(2, 1007.10, 1967.58);\r\nusleep(16823.25);\r\ntouchMove(2, 1007.10, 1970.48);\r\nusleep(16595.29);\r\ntouchMove(2, 1007.10, 1974.35);\r\nusleep(16118.75);\r\ntouchMove(2, 1007.10, 1977.25);\r\nusleep(17300.00);\r\ntouchMove(2, 1007.10, 1980.15);\r\nusleep(16600.08);\r\ntouchMove(2, 1007.10, 1982.07);\r\nusleep(16550.17);\r\ntouchMove(2, 1007.10, 1985.94);\r\nusleep(16914.46);\r\ntouchMove(2, 1007.10, 1987.86);\r\nusleep(16539.83);\r\ntouchMove(2, 1007.10, 1989.81);\r\nusleep(16744.92);\r\ntouchMove(2, 1007.10, 1992.71);\r\nusleep(16618.21);\r\ntouchMove(2, 1007.10, 1994.63);\r\nusleep(16597.25);\r\ntouchMove(2, 1007.10, 1996.55);\r\nusleep(16706.21);\r\ntouchMove(2, 1007.10, 1998.51);\r\nusleep(16757.54);\r\ntouchMove(2, 1007.10, 2000.43);\r\nusleep(16488.33);\r\ntouchMove(2, 1007.10, 2002.35);\r\nusleep(16579.54);\r\ntouchMove(2, 1007.10, 2003.32);\r\nusleep(16530.88);\r\ntouchMove(2, 1007.10, 2005.25);\r\nusleep(16841.42);\r\ntouchMove(2, 1007.10, 2006.22);\r\nusleep(16281.92);\r\ntouchMove(2, 1007.10, 2008.14);\r\nusleep(16957.46);\r\ntouchMove(2, 1007.10, 2010.10);\r\nusleep(16465.21);\r\ntouchMove(2, 1007.10, 2011.04);\r\nusleep(16558.79);\r\ntouchMove(2, 1007.10, 2012.99);\r\nusleep(16820.25);\r\ntouchMove(2, 1007.10, 2014.91);\r\nusleep(16544.54);\r\ntouchMove(2, 1007.10, 2015.89);\r\nusleep(16800.54);\r\ntouchMove(2, 1007.10, 2017.81);\r\nusleep(16895.08);\r\ntouchMove(2, 1007.10, 2019.73);\r\nusleep(16657.88);\r\ntouchMove(2, 1007.10, 2021.65);\r\nusleep(16621.67);\r\ntouchMove(2, 1007.10, 2022.63);\r\nusleep(16602.54);\r\ntouchMove(2, 1007.10, 2023.61);\r\nusleep(49978.17);\r\ntouchMove(2, 1007.10, 2024.55);\r\nusleep(83238.00);\r\ntouchMove(2, 1008.06, 2025.53);\r\nusleep(15641.33);\r\ntouchUp(2, 1012.90, 2031.32);\r\nusleep(1183587.79);\r\n\r\ntouchDown(3, 720.04, 1900.97);\r\nusleep(34903.04);\r\ntouchMove(3, 712.31, 1863.30);\r\nusleep(15863.17);\r\ntouchMove(3, 712.31, 1796.70);\r\nusleep(17014.08);\r\ntouchMove(3, 718.11, 1666.31);\r\nusleep(16567.96);\r\ntouchMove(3, 756.77, 1506.98);\r\nusleep(16474.08);\r\ntouchMove(3, 819.59, 1355.41);\r\nusleep(16888.04);\r\ntouchMove(3, 883.38, 1240.48);\r\nusleep(16766.38);\r\ntouchUp(3, 925.91, 1174.82);\r\nusleep(1098544.62);\r\n\r\ntouchDown(4, 693.94, 1792.82);\r\nusleep(283545.00);\r\ntouchUp(4, 693.94, 1792.82);\r\nusleep(751849.67);\r\n\r\ntouchDown(5, 344.06, 1878.77);\r\nusleep(16878.79);\r\ntouchMove(5, 334.40, 1844.00);\r\nusleep(15775.54);\r\ntouchMove(5, 334.40, 1784.13);\r\nusleep(17440.38);\r\ntouchMove(5, 348.90, 1713.65);\r\nusleep(16265.38);\r\ntouchMove(5, 388.52, 1603.54);\r\nusleep(16357.21);\r\ntouchMove(5, 445.55, 1465.48);\r\nusleep(16962.54);\r\ntouchUp(5, 532.53, 1314.84);\r\nusleep(283220.25);\r\n\r\ntouchDown(6, 338.26, 1929.94);\r\nusleep(33190.71);\r\ntouchMove(6, 337.30, 1885.51);\r\nusleep(17001.25);\r\ntouchMove(6, 346.00, 1815.02);\r\nusleep(16537.25);\r\ntouchMove(6, 386.59, 1702.06);\r\nusleep(16514.75);\r\ntouchMove(6, 436.85, 1586.19);\r\nusleep(16713.25);\r\ntouchMove(6, 493.87, 1470.29);\r\nusleep(15086.88);\r\ntouchUp(6, 499.67, 1464.50);\r\nusleep(135053.54);\r\n\r\ntouchDown(1, 344.06, 1871.02);\r\nusleep(33365.17);\r\ntouchMove(1, 343.10, 1851.71);\r\nusleep(16775.50);\r\ntouchMove(1, 352.76, 1786.05);\r\nusleep(16344.25);\r\ntouchMove(1, 404.95, 1634.47);\r\nusleep(16875.33);\r\ntouchUp(1, 478.41, 1482.86);\r\nusleep(166477.83);\r\n\r\ntouchDown(2, 349.86, 1861.38);\r\nusleep(33527.54);\r\ntouchMove(2, 351.80, 1847.87);\r\nusleep(16776.42);\r\ntouchMove(2, 351.80, 1834.33);\r\nusleep(16448.29);\r\ntouchMove(2, 351.80, 1820.82);\r\nusleep(16894.62);\r\ntouchMove(2, 352.76, 1811.15);\r\nusleep(16502.38);\r\ntouchMove(2, 353.73, 1803.43);\r\nusleep(16504.75);\r\ntouchMove(2, 355.66, 1798.62);\r\nusleep(16949.75);\r\ntouchMove(2, 356.63, 1793.80);\r\nusleep(16476.04);\r\ntouchMove(2, 357.59, 1788.00);\r\nusleep(16593.38);\r\ntouchMove(2, 362.43, 1774.46);\r\nusleep(16894.83);\r\ntouchMove(2, 378.86, 1738.75);\r\nusleep(16636.17);\r\ntouchMove(2, 400.12, 1688.55);\r\nusleep(16634.62);\r\ntouchUp(2, 418.49, 1647.00);\r\nusleep(366941.33);\r\n\r\ntouchDown(3, 410.75, 1864.28);\r\nusleep(33200.25);\r\ntouchMove(3, 412.69, 1824.69);\r\nusleep(16609.33);\r\ntouchMove(3, 412.69, 1800.54);\r\nusleep(16697.17);\r\ntouchMove(3, 412.69, 1781.23);\r\nusleep(16655.75);\r\ntouchMove(3, 413.65, 1766.74);\r\nusleep(16955.33);\r\ntouchMove(3, 415.59, 1758.05);\r\nusleep(16360.71);\r\ntouchMove(3, 416.55, 1753.23);\r\nusleep(16850.54);\r\ntouchMove(3, 417.52, 1749.36);\r\nusleep(49996.12);\r\ntouchMove(3, 418.49, 1749.36);\r\nusleep(15420.71);\r\ntouchUp(3, 423.32, 1749.36);\r\n\r\n\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[461] = { op = "try_end", line = 6456 }
    steps[462] = { line = 6478, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 464 end
    end }
    steps[463] = { line = 6483, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 3673")
    end }
    steps[464] = { line = 6491, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[465] = { line = 6496, sec = "check 2010", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"2010\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[466] = { line = 6502, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[467] = { line = 6508, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 469 end
    end }
    steps[468] = { line = 6513, sec = "check 2010", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"2005\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[469] = { line = 6522, sec = "check ", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"2026\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 400,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[470] = { line = 6528, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[471] = { line = 6534, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 474 end
    end }
    steps[472] = { line = 6539, sec = "", fn = function(B, V, PROG)
      B.log("Chọn lại ngày tháng")
    end }
    steps[473] = { line = 6544, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7904")
    end }
    steps[474] = { op = "try_begin", line = 6557, end_pc = 476 }
    steps[475] = { line = 6570, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[476] = { op = "try_end", line = 6557 }
    steps[477] = { line = 6579, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 479 end
    end }
    steps[478] = { line = 6584, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5067")
    end }
    steps[479] = { line = 6602, sec = "", fn = function(B, V, PROG)
      V.VAR_LIST_NAME = B.emb_girly_names({firstNames={"Anneliese","Aurelie","Camellia","Carina","Celestia","Clarissa","Clementine","Colette","Cordelia","Cosette","Delphine","Dulcie","Emmeline","Estelle","Evangeline","Evelina","Felicity","Fleur","Francesca","Georgiana","Ginevra","Isadora","Jolie","Juliet","Lavinia","Lilibet","Lisette","Lucille","Lucienne","Madeleine","Magnolia","Marceline","Margaux","Marigold","Mirabelle","Nicolette","Opaline","Ottilie","Primrose","Rosalind","Rosette","Seraphina","Sylvie","Tallulah","Thalia","Theodora","Valerie","Vivienne","Addie","Ainsley","Allie","Amie","Andie","Annie","Ashlyn","Averie","Bambi","Birdie","Bonnie","Bree","Bridget","Callie","Camryn","Carly","Carrie","Cassie","Cece","Celia","Charlie","Chelsea","Cherie","Cici","Coralie","Courtney","Dani","Darcy","Dolly","Edie","Elaina","Eliana","Elise","Elodie","Emery","Emmie","Erin","Essie","Evie","Flora","Gemma","Gigi","Goldie","Gracie","Hallie","Hattie","Heidi","Hollie","Honey","Izzy","Jamie","Jenna","Jessie","Josie","Joy","Kacie","Katie","Kayla","Kaylee","Kelsey","Kendra","Kiki","Lacey","Lainey","Laurel","Lauren","Lexie","Libby","Lillie","Lizzie","Lottie","Lucie","Lulu","Mabel","Maddie","Maggie","Maisie","Mallory","Marnie","Megan","Melanie","Mollie","Molly","Nadia","Nellie","Nikki","Nola","Pearl","Penny","Pippa","Pixie","Poppy","Posie","Rachel","Remi","Romy","Rosie","Roxie","Sadie","Shelby","Sunny","Sydney","Tessa","Tia","Tiffany","Tilly","Tori","Vanessa","Wendy","Winnie","Amber","April","Azalea","Blossom","Briar","Clover","Coral","Dahlia","Eden","Fern","Freesia","Harmony","Hazel","Holly","Iris","Ivory","Ivy","Jade","Juniper","Lavender","Lilac","Lotus","Maple","Meadow","Opal","Orchid","Peach","Peony","Petal","Posey","Rosemary","Saffron","Scarlet","Sky","Summer","Tulip","Vanilla","Velvet","Wisteria","Zinnia"},lastNames={"smith","johnson","williams","brown","jones","garcia","miller","davis","martinez","lopez","wilson","anderson","taylor","thomas","moore","jackson","martin","lee","thompson","white","harris","clark","lewis","robinson","walker","young","allen","king","wright","scott","hill","green","adams","baker","nelson","carter","mitchell","perez","roberts","turner","phillips","campbell","parker","evans","edwards","collins","stewart","morris","rogers","reed","cook","morgan","bell","murphy","bailey","rivera","cooper","richardson","cox","howard","ward","torres","peterson","gray","ramirez","james","watson","brooks","kelly","sanders","price","bennett","wood","barnes","ross","henderson","coleman","jenkins","perry","powell","long","patterson","hughes","flores","washington","butler","simmons","foster","bryant","alexander","russell","griffin","hayes","myers","ford","hamilton","graham","sullivan","wallace","woods","cole","west","jordan","owens","reynolds","fisher","ellis","harrison","gibson","mcdonald","cruz","marshall","ortiz","gomez","murray","freeman","wells","webb","simpson","stevens","tucker","porter","hunter","hicks","crawford","henry","boyd","mason","morales","kennedy","warren","dixon","ramos","reyes","burns","gordon","shaw","holmes","rice","robertson"},girlyWords={"matcha","latte","pilates","skincare","bakery","florals","roses","tulips","coffee","books","bakes","paints","creates","designs","glow","aesthetic","vibes","daily","diary","journal","studio","nails","lashes","beauty","bridal","style","fashion","vintage","thrift","yoga","wellness","travel","wander","sunsets","goldenhour","pastel","coquette","sparkle","honey","peach","angel","babe","girl","muse","era","world","club","life","irl","notes","xo","xoxo"},locations={"nyc","la","miami","nashville","austin","dallas","chicago","seattle","boston","charleston","scottsdale","denver","atlanta","sanfran","london","paris","402","212","310","305","512","615"},targetCount=50})
    end }
    steps[480] = { line = 6608, sec = "", fn = function(B, V, PROG)
      V.VAR_NAME_LIST = B.jpath_change_format(V.VAR_LIST_NAME, "json")
    end }
    steps[481] = { line = 6617, sec = "", fn = function(B, V, PROG)
      do local len = B.arr_len(V.VAR_NAME_LIST); if len > 0 then local r = math.random(0, len - 1); V.VAR_NAME_GET = B.arr_get(V.VAR_NAME_LIST, r); B.arr_splice(V.VAR_NAME_LIST, r, 1) else V.VAR_NAME_GET = nil end end
    end }
    steps[482] = { line = 6626, sec = "", fn = function(B, V, PROG)
      V.VAR_NAME = B.jpath_value(V.VAR_NAME_GET, "name")
    end }
    steps[483] = { line = 6635, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_NAME, "")) then return 485 end
    end }
    steps[484] = { line = 6640, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 402")
    end }
    steps[485] = { op = "try_begin", line = 6653, end_pc = 487 }
    steps[486] = { line = 6666, sec = "", fn = function(B, V, PROG)
      V.VAR_USERNAME = B.jpath_value(V.VAR_NAME_GET, "username")
    end }
    steps[487] = { op = "try_end", line = 6653 }
    steps[488] = { line = 6678, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 490 end
    end }
    steps[489] = { line = 6683, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 6211")
    end }
    steps[490] = { line = 6691, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_NAME = 0
    end }
    steps[491] = { line = 6701, sec = "Full name", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Full name\",\r\n    \"timeout\": 20,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[492] = { line = 6707, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[493] = { line = 6713, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 507 end
    end }
    steps[494] = { line = 6718, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_NAME = B.add(B.parse_int(V.VAR_CHECK_NAME), B.parse_int(1))
    end }
    steps[495] = { line = 6723, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_CHECK_NAME, 5)) then return 497 end
    end }
    steps[496] = { line = 6728, sec = "", fn = function(B, V, PROG)
      return B.goto_label("MAIN")
    end }
    steps[497] = { line = 6736, sec = "", fn = function(B, V, PROG)
      B.log("Tiếp tục đợi NaME")
    end }
    steps[498] = { line = 6741, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Enter the confirmation code\",\r\n    \"timeout\": 10,\r\n     \"ex\": false,\r\n    \"offset\": 600,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[499] = { line = 6747, sec = "Đợi pass", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Password\",\r\n    \"timeout\": 2,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[500] = { line = 6753, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
  end)()
  ;(function()
    steps[501] = { line = 6759, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 505 end
    end }
    steps[502] = { line = 6764, sec = "Pate Text", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{ \"action\": \"TEXT\", \"data\": \"", V.VAR_PASSWORD), "\" }"), "", B.add("custom/", ("application/json")))
    end }
    steps[503] = { line = 6770, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[504] = { line = 6776, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5957")
    end }
    steps[505] = { line = 6784, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[506] = { line = 6790, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8623")
    end }
    steps[507] = { line = 6798, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[508] = { line = 6803, sec = "Pate Text", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{ \"action\": \"TEXT\", \"data\": \"", V.VAR_NAME), "\" }"), "", B.add("custom/", ("application/json")))
    end }
    steps[509] = { line = 6809, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("gray"), ["en"] = (B.add("Điền Full Name : ", V.VAR_NAME)), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[510] = { line = 6814, sec = "Add your details", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Add your details\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[511] = { line = 6820, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS_1 = B.http_status()
    end }
    steps[512] = { line = 6826, sec = "Edit how you'll appear on", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Edit how you'll appear on\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[513] = { line = 6832, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[514] = { line = 6838, sec = "", fn = function(B, V, PROG)
      if not B.truthy((B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) and (B.eq(V.VAR_SAVED_STATUS, 200)) or (B.eq(V.VAR_SAVED_STATUS_1, 200)))) then return 518 end
    end }
    steps[515] = { line = 6843, sec = "", fn = function(B, V, PROG)
      B.sleep(5000)
    end }
    steps[516] = { line = 6848, sec = "Click Username", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Username\",\r\n    \"timeout\": 10,\r\n    \"ex\": true,\r\n    \"offsetX\": 200,\r\n\"offsetY\": 200,\r\n    \"action\": \"click4\",\r\n    \"region\": {\r\n        \"x\": 21.13,\r\n        \"y\": 555.63,\r\n        \"width\": 1059.51,\r\n        \"height\": 371.83\r\n    },\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[517] = { line = 6854, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8912")
    end }
    steps[518] = { op = "try_begin", line = 6872, end_pc = 520 }
    steps[519] = { line = 6885, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[520] = { op = "try_end", line = 6872 }
    steps[521] = { line = 6894, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 523 end
    end }
    steps[522] = { line = 6899, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 6882")
    end }
    steps[523] = { line = 6912, sec = "Create a username", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Create a username\",\r\n    \"timeout\": 25,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[524] = { line = 6918, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[525] = { line = 6924, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 536 end
    end }
    steps[526] = { line = 6929, sec = "", fn = function(B, V, PROG)
      B.log("Click Next lại Full Name")
    end }
    steps[527] = { op = "try_begin", line = 6939, end_pc = 529 }
    steps[528] = { line = 6952, sec = "Click i agree", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"including ads\",\r\n    \"timeout\": 5,\r\n    \"ex\": false,\r\n    \"offset\": 100,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[529] = { op = "try_end", line = 6939 }
    steps[530] = { line = 6961, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 532 end
    end }
    steps[531] = { line = 6966, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 3842")
    end }
    steps[532] = { line = 6974, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[533] = { line = 6980, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 535 end
    end }
    steps[534] = { line = 6985, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 4201")
    end }
    steps[535] = { line = 6993, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8654")
    end }
    steps[536] = { line = 7001, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 538 end
    end }
    steps[537] = { line = 7006, sec = "Click Username", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Username\",\r\n    \"timeout\": 10,\r\n    \"ex\": true,\r\n    \"offsetX\": 50,\r\n\"offsetY\": 50,\r\n    \"action\": \"click3\",\r\n    \"region\": {\r\n        \"x\": 21.13,\r\n        \"y\": 555.63,\r\n        \"width\": 1059.51,\r\n        \"height\": 371.83\r\n    },\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[538] = { line = 7020, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[539] = { line = 7025, sec = "", fn = function(B, V, PROG)
      V.VAR_USERNAME = B.trim(V.VAR_USERNAME)
    end }
    steps[540] = { line = 7030, sec = "Dán username", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{ \"action\": \"TEXT\", \"data\": \"", V.VAR_USERNAME), "\" }"), "", B.add("custom/", ("application/json")))
    end }
    steps[541] = { line = 7036, sec = "", fn = function(B, V, PROG)
      B.sleep(5000)
    end }
    steps[542] = { line = 7041, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_USER = 0
    end }
    steps[543] = { op = "try_begin", line = 7056, end_pc = 545 }
    steps[544] = { line = 7069, sec = "Check acc ", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n  \"action\": \"COLOR\",\r\n  \"script\": \"findColors({ colors: [ {color: 6842990, x: 0, y: 0}, {color: 16777215, x: 1, y: -19}, {color: 16777215, x: 22, y: -3}, {color: 16777215, x: 4, y: 25}, {color: 6842990, x: -19, y: 21}, {color: 13832496, x: 63, y: 0} ] })\",\r\n  \"mode\": \"check\",\r\n  \"timeout\": 3,\r\n  \"region\": [1000, 480, 242, 200]\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[545] = { op = "try_end", line = 7056 }
    steps[546] = { line = 7078, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 548 end
    end }
    steps[547] = { line = 7083, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 397")
    end }
    steps[548] = { line = 7091, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[549] = { line = 7097, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 565 end
    end }
    steps[550] = { line = 7102, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_USER = B.add(B.parse_int(V.VAR_CHECK_USER), B.parse_int(1))
    end }
  end)()
  ;(function()
    steps[551] = { line = 7107, sec = "Is not available", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Is not available\",\r\n    \"timeout\": 5,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[552] = { line = 7113, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[553] = { line = 7119, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 555 end
    end }
    steps[554] = { line = 7124, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_USER = 5
    end }
    steps[555] = { line = 7132, sec = "", fn = function(B, V, PROG)
      if not B.truthy((B.num(V.VAR_CHECK_USER) >= B.num(5))) then return 564 end
    end }
    steps[556] = { line = 7137, sec = "", fn = function(B, V, PROG)
      V.VAR_NAME_GET = B.arr_get(V.VAR_NAME_LIST, 0)
    end }
    steps[557] = { line = 7143, sec = "", fn = function(B, V, PROG)
      V.VAR_USERNAME = B.jpath_value(V.VAR_NAME_GET, "username")
    end }
    steps[558] = { line = 7152, sec = "Edit how you'll appear on", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Edit how you'll appear on\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[559] = { line = 7158, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[560] = { line = 7164, sec = "", fn = function(B, V, PROG)
      if not B.truthy((B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) and (B.eq(V.VAR_SAVED_STATUS, 200)) or (B.eq(V.VAR_SAVED_STATUS_1, 200)))) then return 563 end
    end }
    steps[561] = { line = 7169, sec = "Click Username", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Username\",\r\n    \"timeout\": 10,\r\n    \"ex\": true,\r\n    \"offsetX\": 550,\r\n\"offsetY\": 200,\r\n    \"action\": \"click3\",\r\n    \"region\": {\r\n        \"x\": 21.13,\r\n        \"y\": 555.63,\r\n        \"width\": 1059.51,\r\n        \"height\": 371.83\r\n    },\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[562] = { line = 7175, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8912")
    end }
    steps[563] = { line = 7183, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 403")
    end }
    steps[564] = { line = 7191, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7292")
    end }
    steps[565] = { line = 7199, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("yellow"), ["en"] = (B.add("Đã lấy được username: ", V.VAR_USERNAME)), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[566] = { line = 7204, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_USERNAME_LOI = 0
    end }
    steps[567] = { line = 7209, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS_1, 200)) then return 582 end
    end }
    steps[568] = { line = 7214, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("gray"), ["en"] = ("Giao diện khác"), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[569] = { op = "try_begin", line = 7224, end_pc = 571 }
    steps[570] = { line = 7237, sec = "Accept and continue", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Accept and continue\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[571] = { op = "try_end", line = 7224 }
    steps[572] = { line = 7246, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 574 end
    end }
    steps[573] = { line = 7251, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8694")
    end }
    steps[574] = { line = 7259, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[575] = { line = 7265, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 581 end
    end }
    steps[576] = { op = "try_begin", line = 7275, end_pc = 578 }
    steps[577] = { line = 7288, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[578] = { op = "try_end", line = 7275 }
    steps[579] = { line = 7297, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 581 end
    end }
    steps[580] = { line = 7302, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 2612")
    end }
    steps[581] = { line = 7313, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8595")
    end }
    steps[582] = { line = 7326, sec = "", fn = function(B, V, PROG)
      B.sleep(3000)
    end }
    steps[583] = { op = "try_begin", line = 7336, end_pc = 585 }
    steps[584] = { line = 7349, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[585] = { op = "try_end", line = 7336 }
    steps[586] = { line = 7358, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 588 end
    end }
    steps[587] = { line = 7363, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8538")
    end }
    steps[588] = { line = 7376, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_LECH_SONG) then return 590 end
    end }
    steps[589] = { line = 7381, sec = "", fn = function(B, V, PROG)
      B.exec_fn(PROG, "reg_2", V)
    end }
    steps[590] = { line = 7395, sec = "click Not now", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Not now\",\r\n    \"timeout\": 5,\r\n    \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[591] = { line = 7401, sec = "Click i agree", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"including ads\",\r\n    \"timeout\": 10,\r\n    \"ex\": false,\r\n    \"offset\": 100,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[592] = { line = 7407, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[593] = { line = 7413, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 602 end
    end }
    steps[594] = { line = 7418, sec = "Click Female", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Female\",\r\n    \"timeout\": 3,\r\n    \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[595] = { line = 7424, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[596] = { line = 7430, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 599 end
    end }
    steps[597] = { line = 7435, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[598] = { line = 7441, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5957")
    end }
    steps[599] = { line = 7449, sec = "Allow", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Don't Allow\",\r\n    \"timeout\": 3,\r\n    \"ex\": false,\r\n    \"offset\": -200,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[600] = { line = 7455, sec = "Click i agree", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"including ads\",\r\n    \"timeout\": 3,\r\n    \"ex\": false,\r\n    \"offset\": 100,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
  end)()
  ;(function()
    steps[601] = { line = 7461, sec = "Already have an account?", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Already have an account?\",\r\n    \"timeout\": 10,\r\n    \"ex\": false,\r\n    \"offset\": -200,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[602] = { line = 7475, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_IGREG = 0
    end }
    steps[603] = { line = 7485, sec = "check Agree to instagram's terms", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Agree to instagram's terms\",\r\n    \"timeout\": 3,\r\n    \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[604] = { line = 7491, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[605] = { line = 7497, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 621 end
    end }
    steps[606] = { line = 7502, sec = "", fn = function(B, V, PROG)
      if not B.truthy((B.truthy(B.eq(V.VAR_CHECK_IGREG, 1)) and (B.eq(V.VAR_CHECK_IGREG, 1)) or (B.eq(V.VAR_CHECK_IGREG, 8)))) then return 608 end
    end }
    steps[607] = { line = 7507, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("brown"), ["en"] = ("Check I agree"), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[608] = { line = 7515, sec = "Click i agree", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"including ads\",\r\n    \"timeout\": 3,\r\n    \"ex\": false,\r\n    \"offset\": 100,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[609] = { line = 7521, sec = "Already have an account?", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Already have an account?\",\r\n    \"timeout\": 3,\r\n    \"ex\": false,\r\n    \"offset\": -200,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[610] = { line = 7527, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_IGREG = B.add(B.parse_int(V.VAR_CHECK_IGREG), B.parse_int(1))
    end }
    steps[611] = { line = 7532, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_CHECK_IGREG, 10)) then return 613 end
    end }
    steps[612] = { line = 7537, sec = "", fn = function(B, V, PROG)
      B.fail_user("Tạo Lỗi")
    end }
    steps[613] = { line = 7545, sec = "check An unexpected error occurred.", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"An unexpected error\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[614] = { line = 7551, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS_LOI1 = B.http_status()
    end }
    steps[615] = { line = 7557, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Try Again Later\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[616] = { line = 7563, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[617] = { line = 7569, sec = "", fn = function(B, V, PROG)
      if not B.truthy((B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) and (B.eq(V.VAR_SAVED_STATUS, 200)) or (B.eq(V.VAR_SAVED_STATUS_LOI1, 200)))) then return 619 end
    end }
    steps[618] = { line = 7574, sec = "", fn = function(B, V, PROG)
      B.fail_user("Acc Lỗi")
    end }
    steps[619] = { line = 7582, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[620] = { line = 7588, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8329")
    end }
    steps[621] = { line = 7596, sec = "Click threads", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Skip\",\r\n    \"timeout\": 10,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[622] = { line = 7602, sec = "", fn = function(B, V, PROG)
      B.sleep(5000)
    end }
    steps[623] = { line = 7607, sec = "Review the setting for", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Review the settings for\",\r\n    \"timeout\": 5,\r\n    \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[624] = { line = 7613, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[625] = { line = 7619, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 632 end
    end }
    steps[626] = { line = 7624, sec = "Ấn Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 2,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[627] = { line = 7630, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[628] = { line = 7635, sec = "Not now", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Not now\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[629] = { line = 7641, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[630] = { line = 7646, sec = "Ấn Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 2,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[631] = { line = 7652, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8032")
    end }
    steps[632] = { op = "try_begin", line = 7665, end_pc = 634 }
    steps[633] = { line = 7678, sec = "We could't creare an", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"We were not able to sign you up\",\r\n    \"timeout\": 5,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[634] = { op = "try_end", line = 7665 }
    steps[635] = { line = 7687, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 637 end
    end }
    steps[636] = { line = 7692, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 4949")
    end }
    steps[637] = { line = 7700, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS_CHECK1 = B.http_status()
    end }
    steps[638] = { line = 7706, sec = "check Create a profile that", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Create a profile that\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[639] = { line = 7712, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[640] = { line = 7718, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 642 end
    end }
    steps[641] = { line = 7723, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 8032")
    end }
    steps[642] = { line = 7731, sec = "Try Again Later", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Try Again Later\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[643] = { line = 7737, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS_CHECK = B.http_status()
    end }
    steps[644] = { line = 7743, sec = "Confirm you're human to", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Confirm you're human to\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[645] = { line = 7749, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[646] = { line = 7755, sec = "", fn = function(B, V, PROG)
      if not B.truthy((B.truthy((B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) and (B.eq(V.VAR_SAVED_STATUS, 200)) or (B.eq(V.VAR_SAVED_STATUS_CHECK, 200)))) and ((B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) and (B.eq(V.VAR_SAVED_STATUS, 200)) or (B.eq(V.VAR_SAVED_STATUS_CHECK, 200)))) or (B.eq(V.VAR_SAVED_STATUS_CHECK1, 200)))) then return 648 end
    end }
    steps[647] = { line = 7760, sec = "", fn = function(B, V, PROG)
      B.fail_user("Die")
    end }
    steps[648] = { line = 7768, sec = "check An unexpected error occurred.", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"An unexpected error occurred.\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[649] = { line = 7774, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUSLOI22 = B.http_status()
    end }
    steps[650] = { line = 7780, sec = "Check Lỗi username", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Incorrect Username\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
  end)()
  ;(function()
    steps[651] = { line = 7786, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[652] = { line = 7792, sec = "", fn = function(B, V, PROG)
      if not B.truthy((B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) and (B.eq(V.VAR_SAVED_STATUS, 200)) or (B.eq(V.VAR_SAVED_STATUSLOI22, 200)))) then return 654 end
    end }
    steps[653] = { line = 7797, sec = "", fn = function(B, V, PROG)
      B.fail_user("Acc Erro")
    end }
    steps[654] = { line = 7805, sec = "Ấn Continue", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Skip\",\r\n    \"timeout\": 2,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[655] = { line = 7811, sec = "Ấn Continue", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Done\",\r\n    \"timeout\": 2,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[656] = { line = 7817, sec = "Ấn Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 2,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[657] = { line = 7823, sec = "Not now", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Not now\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[658] = { line = 7834, sec = "thoát", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"appKill('com.burbn.instagram');\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[659] = { line = 7840, sec = "thoát", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"\r\n\r\n\r\nkeyDown(KEY_TYPE.HOME_BUTTON);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\nusleep(100000);\r\nkeyDown(KEY_TYPE.HOME_BUTTON);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\n\r\nusleep(1000000); -- Chờ trình đa nhiệm hiện lên\r\ntouchDown(2, 657.62, 1719.02);\r\nusleep(32964.38);\r\ntouchMove(2, 652.98, 1684.71);\r\nusleep(16640.54);\r\ntouchMove(2, 652.98, 1630.93);\r\nusleep(17161.38);\r\ntouchMove(2, 657.62, 1543.76);\r\nusleep(16059.67);\r\ntouchMove(2, 675.30, 1436.19);\r\nusleep(17233.92);\r\ntouchMove(2, 704.14, 1300.78);\r\nusleep(16385.67);\r\ntouchMove(2, 743.21, 1156.11);\r\nusleep(16619.38);\r\ntouchMove(2, 784.13, 1023.49);\r\nusleep(16505.12);\r\ntouchUp(2, 830.64, 884.40);\r\nusleep(1534120.96);\r\n\r\ntouchDown(2, 335.79, 1452.88);\r\nusleep(50798.58);\r\ntouchMove(2, 339.51, 1394.45);\r\nusleep(16426.42);\r\ntouchMove(2, 339.51, 1348.06);\r\nusleep(16482.00);\r\ntouchMove(2, 336.71, 1284.09);\r\nusleep(16739.75);\r\ntouchMove(2, 336.71, 1210.83);\r\nusleep(16337.58);\r\ntouchMove(2, 336.71, 1118.09);\r\nusleep(16935.46);\r\ntouchMove(2, 351.60, 980.82);\r\nusleep(16911.62);\r\ntouchMove(2, 387.87, 793.51);\r\nusleep(15941.33);\r\ntouchUp(2, 430.66, 600.60);\r\n\r\n\r\n\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[660] = { line = 7846, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 691")
    end }
    steps[661] = { line = 7851, sec = "", fn = function(B, V, PROG)
      V.VAR_2FA = ""
    end }
    steps[662] = { line = 7856, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 1098")
    end }
    steps[663] = { line = 7861, sec = "", fn = function(B, V, PROG)
      V.VAR_NEW_RECORD_ID = B.db_add_record({2, V.VAR_USERNAME, 3, V.VAR_PASSWORD, 4, "", 5, "", 6, "", 7, "", 8, ""})
    end }
    steps[664] = { line = 7874, sec = "", fn = function(B, V, PROG)
      B.sleep(3000)
    end }
    steps[665] = { line = 7879, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9334")
    end }
    steps[666] = { line = 7884, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_923741 = B.rs("Add Profile", false, false)
    end }
    steps[667] = { line = 7884, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.RESOURCE_923741) then return 692 end
    end }
    steps[668] = { line = 7891, sec = "Xóa toàn bộ ảnh", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"clearSystemAlbum();\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[669] = { line = 7897, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_637586 = B.rs("Path IMG", true, false)
      V.VAR_PATH_ANH = V.RESOURCE_637586
    end }
    steps[670] = { line = 7904, sec = "Send IMG", fn = function(B, V, PROG)
      B.emb_upload_photo(V.VAR_PATH_ANH)
    end }
    steps[671] = { line = 7910, sec = "Vào IG", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{\r\n    \"action\": \"URL\",\r\n    \"data\": \"https://www.instagram.com/", V.VAR_USERNAME), "\"\r\n}"), "", B.add("custom/", ("application/json")))
    end }
    steps[672] = { line = 7916, sec = "Not now", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Not now\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[673] = { line = 7922, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[674] = { line = 7927, sec = "Vào IG", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"URL\",\r\n    \"data\": \"https://www.instagram.com/accounts/edit/\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[675] = { line = 7933, sec = "Vào IG", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"URL\",\r\n    \"data\": \"https://www.instagram.com/accounts/edit/\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[676] = { line = 7939, sec = "Not now", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Not now\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[677] = { line = 7945, sec = "BIO", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Bio\",\r\n    \"timeout\": 15,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[678] = { line = 7951, sec = "", fn = function(B, V, PROG)
      V.VAR_TEMPLATE_BIO = [[18 🎀 Norman, OK
      OU student 📚
      add me on snap 👻 emeliexorylx
      
      18 ✨ OKC, Oklahoma
      freshman · coffee & country music ☕🎶
      snap me 👻 emeliewarylx
      
      19 🌸 Tulsa, OK
      psych major 📖 sweet but savage 🌶️
      let's talk on snap 👻 emelievalinx
      
      19 💕 Stillwater, Oklahoma
      OSU 🧡 lake days 🌊
      sc: emeliexorylx 👻
      
      20 🦋 OKC 🤠
      student · gym & tacos 🌮
      hmu on snap 👻 emeliewarylx
      
      20 💋 Norman, OK
      come say hi, I don't bite 😈
      snapchat 👻 emelievalinx
      
      21 🖤 OKC, Oklahoma
      OU senior 📚 road trips 🚗
      add my snap 👻 emeliexorylx
      
      21 💅 Tulsa, OK
      bet you can't handle me 😉
      snap me 👻 emeliewarylx
      
      22 💕 OKC 🤠
      nurse 🩺 coffee addict ☕
      find me on snap 👻 emelievalinx
      
      22 ✨ Norman, Oklahoma
      barista · hiking & sunsets 🌅
      snap 👻 emeliexorylx
      
      23 🖤 Edmond, OK
      dental assistant 🦷 trouble in the best way 😘
      add me on snap 👻 emeliewarylx
      
      23 🌸 OKC 🤠
      teacher 📚 weekend lake trips 🌊
      snap me 👻 emelievalinx
      
      24 💅 Tulsa, Oklahoma
      realtor 🏡 spoil me 💋
      sc: emeliexorylx 👻
      
      24 🌶️ Norman, OK
      esthetician ✨ a lil shy, a lot flirty 😉
      let's talk on snap 👻 emeliewarylx
      
      25 💕 Broken Arrow, OK
      hairstylist 💇‍♀️ easy to fall for 🖤
      add my snap 👻 emelievalinx
      
      25 😉 Moore, Oklahoma
      nurse 🩺 sweet tea & sunsets 🌅
      snapchat 👻 emeliexorylx
      
      19 🎶 Lawton, OK
      student 📚 your favorite trouble 😈
      snap me 👻 emeliewarylx
      
      20 🌅 OKC 🤠
      yoga · coffee · dog mom 🐶
      hmu on snap 👻 emelievalinx
      
      21 💋 Norman, Oklahoma
      OU senior 🎓 spoil me a little 💅
      add me on snap 👻 emeliexorylx
      
      22 🌸 Stillwater, OK
      barista · country concerts 👢
      sc: emeliewarylx 👻
      
      18 ✨ Edmond, OK
      student 📚 sweet but savage 🌶️
      snap me 👻 emelievalinx
      
      23 🖤 OKC, Oklahoma
      esthetician ✨ beach trips & tacos 🌮
      find me on snap 👻 emeliexorylx
      
      24 😏 Tulsa, OK
      server 🍷 bet you've never met a girl like me
      add my snap 👻 emeliewarylx
      
      20 💕 Norman 🤠 Oklahoma
      OSU student 🧡 painting & late drives 🎨
      snapchat 👻 emelievalinx
      
      25 🌶️ Norman, OK
      dental hygienist 🦷 come find out 😉
      snap me 👻 emeliexorylx
      
      19 🦋 OKC 🤠
      student · gym & coffee ☕
      let's talk on snap 👻 emeliewarylx
      
      21 💅 Tulsa, Oklahoma
      student 📚 low key your dream girl 💋
      add me on snap 👻 emelievalinx
      
      22 🌸 Edmond, OK
      nanny 🧸 hiking & horseback riding 🐎
      sc: emeliexorylx 👻
      
      23 💋 Moore, OK
      nurse 🩺 flirty with a soft spot 🖤
      snap me 👻 emeliewarylx
      
      18 🎀 Norman 🤠 Oklahoma
      OU freshman 📚 catch me if you can 😜
      hmu on snap 👻 emelievalinx
      
      20 😈 OKC, OK
      student 🎓 sweet talk gets you everywhere 💋
      add my snap 👻 emeliexorylx
      
      25 💕 Tulsa, Oklahoma
      realtor 🏡 road trips & country music 🎶
      snapchat 👻 emeliewarylx
      
      21 🌅 Stillwater, OK
      OSU 🧡 gym + tacos + chaos 🌮
      snap me 👻 emelievalinx
      
      22 🖤 OKC 🤠
      barista ☕ your new favorite distraction 😏
      find me on snap 👻 emeliexorylx
      
      19 🌸 Broken Arrow, OK
      student 📚 dancing & sunsets 🌅
      add me on snap 👻 emeliewarylx
      
      23 💅 Edmond, Oklahoma
      teacher 📚 spoil me & see what happens 💋
      sc: emelievalinx 👻
      
      24 🌶️ Tulsa, OK
      vet tech 🐾 a lil shy, a lot flirty 😉
      snap me 👻 emeliexorylx
      
      20 ✨ Norman, OK
      OU sophomore 🎓 coffee & country drives ☕
      let's talk on snap 👻 emeliewarylx
      
      18 💕 OKC, Oklahoma
      student 📚 Oklahoma girl through & through 🤠
      add my snap 👻 emelievalinx
      
      25 🖤 OKC, OK
      nurse 🩺 easy to love, hard to forget 💋
      snapchat 👻 emeliexorylx
      
      21 🌸 Moore, OK
      student 🎓 thrift hauls & taco runs 🌮
      snap me 👻 emeliewarylx
      
      24 💅 Tulsa, Oklahoma
      esthetician 🤎 come spoil your new fav girl
      hmu on snap 👻 emelievalinx
      
      22 💕 OKC 🤠
      hairstylist 💇‍♀️ sunsets & slow dances 🌅
      add me on snap 👻 emeliexorylx
      
      19 🦋 Norman, OK
      freshman year & flirty energy 💋
      sc: emeliewarylx 👻
      
      23 😏 Tulsa, OK
      server 🍷 bet I'm cuter than your ex 😜
      snap me 👻 emelievalinx
      ]]
    end }
    steps[679] = { line = 7959, sec = "", fn = function(B, V, PROG)
      V.VAR_BIO = B.emb_random_bio(V.VAR_TEMPLATE_BIO)
    end }
    steps[680] = { line = 7965, sec = "Pate Text", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{ \"action\": \"TEXT\", \"data\": \"", V.VAR_BIO), "\" }"), "", B.add("custom/", ("application/json")))
    end }
    steps[681] = { line = 7971, sec = "", fn = function(B, V, PROG)
      B.sleep(1000)
    end }
    steps[682] = { line = 7976, sec = "Not now", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Done\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[683] = { line = 7982, sec = "", fn = function(B, V, PROG)
      B.sleep(1000)
    end }
    steps[684] = { line = 7987, sec = "Edit profile", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Edit profile\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 200,\r\n    \"offsetX\": -50,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[685] = { line = 7993, sec = "", fn = function(B, V, PROG)
      B.sleep(1000)
    end }
    steps[686] = { line = 7998, sec = "Choose from library", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Choose from library\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[687] = { line = 8004, sec = "", fn = function(B, V, PROG)
      B.sleep(3000)
    end }
    steps[688] = { line = 8009, sec = "Check Library", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Library\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[689] = { line = 8015, sec = "Vuốt xuống", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"\r\ntouchDown(2, 669.24, 494.11);\r\nusleep(28886.71);\r\ntouchMove(2, 665.39, 503.73);\r\nusleep(8632.04);\r\ntouchMove(2, 664.43, 526.82);\r\nusleep(8050.88);\r\ntouchMove(2, 658.68, 553.76);\r\nusleep(8750.00);\r\ntouchMove(2, 654.84, 587.44);\r\nusleep(8065.50);\r\ntouchMove(2, 646.20, 626.88);\r\nusleep(8936.29);\r\ntouchMove(2, 642.36, 677.84);\r\nusleep(7362.96);\r\ntouchMove(2, 640.43, 734.60);\r\nusleep(8992.62);\r\ntouchMove(2, 639.47, 789.46);\r\nusleep(7613.46);\r\ntouchMove(2, 639.47, 857.74);\r\nusleep(9093.75);\r\ntouchMove(2, 639.47, 913.54);\r\nusleep(7695.17);\r\ntouchMove(2, 639.47, 975.09);\r\nusleep(9014.83);\r\ntouchMove(2, 642.36, 1025.12);\r\nusleep(7675.88);\r\ntouchMove(2, 648.11, 1073.22);\r\nusleep(8909.79);\r\ntouchMove(2, 650.03, 1110.76);\r\nusleep(7627.92);\r\ntouchMove(2, 651.95, 1145.37);\r\nusleep(9058.33);\r\ntouchMove(2, 652.91, 1172.32);\r\nusleep(7718.92);\r\ntouchMove(2, 652.91, 1197.33);\r\nusleep(8960.62);\r\ntouchMove(2, 652.91, 1227.14);\r\nusleep(7636.38);\r\ntouchMove(2, 654.84, 1255.99);\r\nusleep(9082.38);\r\ntouchMove(2, 657.72, 1290.63);\r\nusleep(7676.88);\r\ntouchMove(2, 661.55, 1323.34);\r\nusleep(9473.58);\r\ntouchUp(2, 667.32, 1329.10);\r\n\r\n\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[690] = { line = 8021, sec = "Not now", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Done\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[691] = { line = 8027, sec = "Edit profile", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Edit profile\",\r\n    \"timeout\": 15,\r\n     \"ex\": true,\r\n    \"offset\": 200,\r\n    \"offsetX\": -50,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[692] = { line = 8036, sec = "Vào IG", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"URL\",\r\n    \"data\": \"instagram://settings\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[693] = { line = 8042, sec = "Not now", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Not now\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[694] = { line = 8048, sec = "Accounts Center", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Accounts Center\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[695] = { line = 8054, sec = "Accounts Center", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Accounts Center\",\r\n    \"timeout\": 15,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[696] = { line = 8060, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[697] = { line = 8066, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 700 end
    end }
    steps[698] = { line = 8071, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("purple"), ["en"] = ("Không vào được 2FA"), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[699] = { line = 8076, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9334")
    end }
    steps[700] = { line = 8084, sec = "Password and security", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Password and security\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
  end)()
  ;(function()
    steps[701] = { line = 8095, sec = "Password and security", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Password and security\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[702] = { line = 8101, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[703] = { line = 8107, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 707 end
    end }
    steps[704] = { line = 8112, sec = "Password and security", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Not now\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[705] = { line = 8118, sec = "Accounts Center", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Accounts Center\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[706] = { line = 8124, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 2802")
    end }
    steps[707] = { line = 8132, sec = "Two-factor authentication", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Two-factor authentication\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[708] = { line = 8138, sec = "Instagram", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Instagram\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[709] = { line = 8144, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[710] = { line = 8150, sec = "Copy key", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Copy key\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[711] = { line = 8161, sec = "Copy key", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Copy key\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[712] = { line = 8167, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[713] = { line = 8172, sec = "", fn = function(B, V, PROG)
      V.VAR_CLIPBOARD_TEXT = B.emb_read_pasteboard()
    end }
    steps[714] = { line = 8178, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_CLIPBOARD_TEXT, "")) then return 717 end
    end }
    steps[715] = { line = 8183, sec = "", fn = function(B, V, PROG)
      B.log("Code 2FA Rỗng")
    end }
    steps[716] = { line = 8188, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 6432")
    end }
    steps[717] = { line = 8196, sec = "", fn = function(B, V, PROG)
      local s = V.VAR_CLIPBOARD_TEXT
      local result = (B.str(s):gsub("%s+", ""))
      V.VAR_2FA = result
    end }
    steps[718] = { line = 8203, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add("https://2fa.live/tok/", V.VAR_2FA), "GET", nil, "", nil)
    end }
    steps[719] = { line = 8209, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[720] = { line = 8215, sec = "", fn = function(B, V, PROG)
      V.VAR_TOKEN = B.jpath_value(V.VAR_SAVED_CONTENT, "token")
    end }
    steps[721] = { line = 8224, sec = "Enter code", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Enter code\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[722] = { line = 8230, sec = "", fn = function(B, V, PROG)
      B.log(V.VAR_2FA)
    end }
    steps[723] = { line = 8235, sec = "Click Enter Code", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n  \"action\": \"COLOR\",\r\n  \"script\": \"const [result, error] = findColors({\r\n    colors: [\r\n        { color: 15527149, x: 0, y: 0 },\r\n        { color: 6711922, x: 45, y: 2 },\r\n        { color: 6711922, x: 19, y: 0 },\r\n        { color: 8290696, x: 45, y: -9 }\r\n    ],\r\n    // count: 30,\r\n    // region: null,\r\n    // debug: false,\r\n    // rightToLeft: false,\r\n    // bottomToTop: false\r\n})\r\n\r\n\",\r\n  \"mode\": \"click\",\r\n  \"timeout\": 10,\r\n  \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[724] = { line = 8241, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[725] = { line = 8246, sec = "Pate Text", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{ \"action\": \"TEXT\", \"data\": \"", V.VAR_TOKEN), "\" }"), "", B.add("custom/", ("application/json")))
    end }
    steps[726] = { line = 8252, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[727] = { line = 8258, sec = "Click Done", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Done\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[728] = { line = 8264, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[729] = { line = 8269, sec = "", fn = function(B, V, PROG)
      B.db_update_record(V.VAR_NEW_RECORD_ID, {4, V.VAR_2FA})
    end }
    steps[730] = { line = 8293, sec = "Vào IG", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"URL\",\r\n    \"data\": \"instagram://\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[731] = { line = 8299, sec = "", fn = function(B, V, PROG)
      B.sleep(3000)
    end }
    steps[732] = { line = 8304, sec = "HOME", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\"action\":\"RUNLUA\",\"data\":\"return execute('/var/jb/usr/local/bin/ghost-sso-bridge')\"}", "", B.add("custom/", ("application/json")))
    end }
    steps[733] = { line = 8310, sec = "Click Username", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Join using your Meta Account\",\r\n    \"timeout\": 10,\r\n     \"ex\": false,\r\n    \"offset\": 100,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[734] = { line = 8321, sec = "Not now", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Not now\",\r\n    \"timeout\": 20,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[735] = { line = 8327, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[736] = { line = 8333, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 404)) then return 742 end
    end }
    steps[737] = { line = 8338, sec = "set up your experience", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Privacy\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[738] = { line = 8344, sec = "ấn Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[739] = { line = 8350, sec = "Join Threads", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Join Threads\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[740] = { line = 8356, sec = "", fn = function(B, V, PROG)
      B.log("Quay lại ấn Not now")
    end }
    steps[741] = { line = 8361, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7467")
    end }
    steps[742] = { line = 8369, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[743] = { line = 8374, sec = "Click Done", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Follow all\",\r\n    \"timeout\": 5,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[744] = { line = 8380, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[745] = { line = 8385, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_914458 = B.rs("Kiểu Lưu", false, false)
    end }
    steps[746] = { line = 8385, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_914458, "Đẩy File Backup")) then return 771 end
    end }
    steps[747] = { line = 8392, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":9102/backup-now"), ("POST"), "{\r\n  \"selector\": \"both\",\r\n  \"format\": \"ghostpair\",\r\n  \"target_container\": \"taoacc\",\r\n  \"target_ig\": \"taoacc\",\r\n  \"target_th\": \"taoacc\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[748] = { line = 8398, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[749] = { line = 8404, sec = "", fn = function(B, V, PROG)
      V.VAR_JOB_ID = B.jpath_value(V.VAR_SAVED_CONTENT, ".job_id")
    end }
    steps[750] = { line = 8418, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(B.add(V.VAR_IP_IPHONE, ":9102/status?job_id="), V.VAR_JOB_ID), "GET", nil, "", nil)
    end }
  end)()
  ;(function()
    steps[751] = { line = 8424, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[752] = { line = 8430, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_SUCCESS = B.jpath_value(V.VAR_SAVED_CONTENT, ".running")
    end }
    steps[753] = { line = 8439, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_CHECK_SUCCESS) then return 756 end
    end }
    steps[754] = { line = 8444, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[755] = { line = 8449, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 4123")
    end }
    steps[756] = { line = 8457, sec = "", fn = function(B, V, PROG)
      V.VAR_USERNAME_GET = B.jpath_value(V.VAR_SAVED_CONTENT, ".username")
    end }
    steps[757] = { line = 8466, sec = "", fn = function(B, V, PROG)
      V.VAR_OUTPUT_PATH = B.jpath_value(V.VAR_SAVED_CONTENT, ".output_path")
    end }
    steps[758] = { line = 8475, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("cyan"), ["en"] = (B.add(B.add(B.add("Username: ", V.VAR_USERNAME_GET), " ||OUTPUT_PATH: "), V.VAR_OUTPUT_PATH)), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[759] = { line = 8480, sec = "Bắt đầu upload", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":8080/api/backup_upload"), ("POST"), B.add(B.add(B.add(B.add(B.add(B.add("{\r\n  \"url\": \"https://panel.65.109.22.234.sslip.io/api/v1/upload/account\",\r\n  \"api_key\": \"tpi_i87y87ufzaxDEn0aQpBuK52k0jkpN-I2\",\r\n  \"file_path\": \"", V.VAR_OUTPUT_PATH), "\",\r\n  \"username\": \""), V.VAR_USERNAME_GET), "\",\r\n  \"password\": \""), V.VAR_PASSWORD), "\",\r\n  \"2fa\": \"\",\r\n  \"delete_after\": true,\r\n  \"async\": true\r\n}"), "", B.add("custom/", ("application/json")))
    end }
    steps[760] = { line = 8486, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[761] = { line = 8492, sec = "", fn = function(B, V, PROG)
      V.VAR_JOB_ID = B.jpath_value(V.VAR_SAVED_CONTENT, ".job_id")
    end }
    steps[762] = { line = 8506, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(B.add(V.VAR_IP_IPHONE, ":8080/api/backup_upload/status?job_id="), V.VAR_JOB_ID), "GET", nil, "", nil)
    end }
    steps[763] = { line = 8512, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[764] = { line = 8518, sec = "", fn = function(B, V, PROG)
      V.VAR_STAGE = B.jpath_value(V.VAR_SAVED_CONTENT, ".stage")
    end }
    steps[765] = { line = 8527, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_STAGE, "uploading")) then return 768 end
    end }
    steps[766] = { line = 8532, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[767] = { line = 8537, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 3885")
    end }
    steps[768] = { line = 8545, sec = "", fn = function(B, V, PROG)
      V.VAR_UPLOAD_RESPONSE = B.jpath_value(V.VAR_SAVED_CONTENT, ".upload_response")
    end }
    steps[769] = { line = 8554, sec = "", fn = function(B, V, PROG)
      V.VAR_UPLOAD_RESPONSE = B.jpath_change_format(V.VAR_UPLOAD_RESPONSE, "string")
    end }
    steps[770] = { line = 8563, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("orange"), ["en"] = (B.add("Upload_response: ", V.VAR_UPLOAD_RESPONSE)), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[771] = { line = 8571, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_845883 = B.rs("Kiểu Lưu", false, false)
    end }
    steps[772] = { line = 8571, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.RESOURCE_845883, "Đẩy Cookie")) then return 783 end
    end }
    steps[773] = { line = 8578, sec = "xuất cookie", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add(B.add(B.add("{\"action\":\"RUNLUA\",\"data\":\"return execute('/var/jb/usr/local/bin/ghost-cookie-export --payload --username ", V.VAR_USERNAME), " --proxy "), V.VAR_PROXY), "')\"}"), "", B.add("custom/", ("application/json")))
    end }
    steps[774] = { line = 8584, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[775] = { line = 8590, sec = "", fn = function(B, V, PROG)
      V.VAR_DATA = B.jpath_value(V.VAR_SAVED_CONTENT, ".data.accounts[0]")
    end }
    steps[776] = { line = 8599, sec = "", fn = function(B, V, PROG)
      V.VAR_DATA_SEND = B.jpath_change_format(V.VAR_DATA, "string")
    end }
    steps[777] = { line = 8608, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request("https://panel.65.109.22.234.sslip.io/api/v1/import/accounts", ("POST"), V.VAR_DATA_SEND, "Authorization: Bearer tpi_i87y87ufzaxDEn0aQpBuK52k0jkpN-I2", B.add("custom/", ("application/json")))
    end }
    steps[778] = { line = 8614, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[779] = { line = 8620, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("cyan"), ["en"] = (V.VAR_SAVED_CONTENT), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[780] = { line = 8625, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[781] = { line = 8631, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.sneq(V.VAR_SAVED_STATUS, 202)) then return 783 end
    end }
    steps[782] = { line = 8636, sec = "", fn = function(B, V, PROG)
      B.fail_user("Lỗi gửi Acc")
    end }
    steps[783] = { line = 8647, sec = "HOME", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"\r\n\r\nkeyDown(KEY_TYPE.HOME_BUTTON);\r\nusleep(138611.00);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\nusleep(217773.00);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\nusleep(772038.29);\r\n\r\nkeyDown(KEY_TYPE.HOME_BUTTON);\r\nusleep(217682.00);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\nusleep(138650.21);\r\nkeyUp(KEY_TYPE.HOME_BUTTON);\r\n\r\n\r\n\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[784] = { line = 8653, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("blue"), ["en"] = (B.add(B.add(B.add("[INFO] Tổng: ", B.json_parse((B.truthy(B.pget("basglobal", "DEM_ACC")) and (B.pget("basglobal", "DEM_ACC")) or ("\"\"")))), " || Username: "), V.VAR_USERNAME)), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[785] = { line = 8658, sec = "", fn = function(B, V, PROG)
      B.pset("basglobal", "DEM_ACC", B.add(B.parse_int(B.json_parse((B.truthy(B.pget("basglobal", "DEM_ACC")) and (B.pget("basglobal", "DEM_ACC")) or ("0")))), B.parse_int(1)))
    end }
    steps[786] = { line = 8663, sec = "", fn = function(B, V, PROG)
      do local ts = os.date("[%H:%M:%S]"); local mess = "<b>" .. ts .. " Thread #" .. tostring(B.thread_number()) .. " : </b>" .. B.str(B.add(B.add(B.add(B.add(B.add("Thành công: ", B.json_parse((B.truthy(B.pget("basglobal", "DEM_ACC")) and (B.pget("basglobal", "DEM_ACC")) or ("\"\"")))), " || IPHONE: "), V.VAR_IP_GOC), "  || https://www.threads.com/@"), V.VAR_USERNAME)); local url = "https://api.telegram.org/bot6385162686:AAGx4qwiX1aV_WRGGynjfW8AQBOwsls2qGg/sendMessage?chat_id=1344289139&text=" .. B.encode_uri(mess) .. "&parse_mode=HTML"; B.switch_http_internal(); B.http_request(url, "GET", nil, nil, nil); B.switch_http_main() end
    end }
    steps[787] = { line = 8688, sec = "", fn = function(B, V, PROG)
      V.RESOURCE_541705 = B.rs("Tạo Tối Đa", false, false)
    end }
    steps[788] = { line = 8688, sec = "", fn = function(B, V, PROG)
      if not B.truthy((B.num(B.json_parse((B.truthy(B.pget("basglobal", "DEM_ACC")) and (B.pget("basglobal", "DEM_ACC")) or ("\"\"")))) >= B.num(V.RESOURCE_541705))) then return 790 end
    end }
    steps[789] = { line = 8695, sec = "", fn = function(B, V, PROG)
      B.die("Xong")
    end }
    steps[790] = { line = 8703, sec = "", fn = function(B, V, PROG)
      B.success(B.add("Tạo acc thành công: ", V.VAR_USERNAME))
    end }
  end)()
  PROG.functions["taotaikhoan"] = { name = "taotaikhoan", steps = steps, labels = labels }
end

-- -------- Function: API_GMAIL (15 steps, 1 labels) --------
do
  local steps = {}
  local labels = { ["label name 3575"] = 9 };
  ;(function()
    steps[1] = { line = 3148, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request("https://smsbower.page/api/mail/getActivation?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&service=ot&domain=gmail.com", "GET", nil, "", nil)
    end }
    steps[2] = { line = 3154, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[3] = { line = 3160, sec = "", fn = function(B, V, PROG)
      V.VAR_STATUS_GET_MAIL = B.jpath_value(V.VAR_SAVED_CONTENT, "status")
    end }
    steps[4] = { line = 3169, sec = "", fn = function(B, V, PROG)
      V.VAR_EMAIL = B.jpath_value(V.VAR_SAVED_CONTENT, "mail")
    end }
    steps[5] = { line = 3178, sec = "", fn = function(B, V, PROG)
      V.VAR_MAILID = B.jpath_value(V.VAR_SAVED_CONTENT, "mailId")
    end }
    steps[6] = { line = 3187, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add("https://smsbower.page/api/mail/getCode?api_key=cSdW0GnVD261zKU79BHqFhx48oBzojrP&mailId=", V.VAR_MAILID), "GET", nil, "", nil)
    end }
    steps[7] = { line = 3193, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[8] = { line = 3199, sec = "", fn = function(B, V, PROG)
      V.VAR_STATUS_CHECK_MAIL = B.jpath_value(V.VAR_SAVED_CONTENT, "status")
    end }
    steps[9] = { line = 3213, sec = "", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request("https://api.shopgmail9999.com/api/ApiV2/CreateOrder?apikey=3ada3340e0d481e83e9c0167bdee4533&service=instagram&getpass=false", "GET", nil, "", nil)
    end }
    steps[10] = { line = 3219, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[11] = { line = 3225, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.sneq(V.VAR_SAVED_STATUS, 200)) then return 13 end
    end }
    steps[12] = { line = 3230, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 3575")
    end }
    steps[13] = { line = 3238, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_CONTENT = B.http_content()
    end }
    steps[14] = { line = 3244, sec = "", fn = function(B, V, PROG)
      V.VAR_ORDERID = B.jpath_value(V.VAR_SAVED_CONTENT, ".orderid")
    end }
    steps[15] = { line = 3253, sec = "", fn = function(B, V, PROG)
      V.VAR_EMAIL = B.jpath_value(V.VAR_SAVED_CONTENT, ".email")
    end }
  end)()
  PROG.functions["API_GMAIL"] = { name = "API_GMAIL", steps = steps, labels = labels }
end

-- -------- Function: reg_2 (84 steps, 13 labels) --------
do
  local steps = {}
  local labels = { ["label name 7922"] = 2, ["label name 9709"] = 2, ["label name 6991"] = 7, ["label name 5274"] = 14, ["label name 3625"] = 24, ["label name 6828"] = 31, ["label name 5884"] = 37, ["label name 471"] = 43, ["label name 7838"] = 54, ["label name 1965"] = 59, ["label name 7594"] = 70, ["label name 3322"] = 75, ["label name 9629"] = 80 };
  ;(function()
    steps[1] = { line = 651, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_NEXT_PASS = 0
    end }
    steps[2] = { op = "try_begin", line = 666, end_pc = 4 }
    steps[3] = { line = 679, sec = "check what's your birthaday", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"what's your birthday?\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 400,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[4] = { op = "try_end", line = 666 }
    steps[5] = { line = 688, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 7 end
    end }
    steps[6] = { line = 693, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9709")
    end }
    steps[7] = { op = "try_begin", line = 706, end_pc = 9 }
    steps[8] = { line = 719, sec = "Chọn ngày tháng năm sinh", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"action\": \"RUNLUA\",\r\n    \"data\": \"\r\ntouchDown(2, 859.35, 1766.82);\r\nusleep(20938.67);\r\ntouchMove(2, 854.55, 1805.29);\r\nusleep(7462.54);\r\ntouchMove(2, 854.55, 1841.83);\r\nusleep(9152.38);\r\ntouchMove(2, 854.55, 1881.31);\r\nusleep(7527.42);\r\ntouchMove(2, 855.51, 1925.54);\r\nusleep(9075.42);\r\ntouchMove(2, 862.24, 1969.81);\r\nusleep(7704.83);\r\ntouchMove(2, 870.87, 2024.64);\r\nusleep(8869.46);\r\ntouchMove(2, 880.49, 2078.49);\r\nusleep(7632.58);\r\ntouchMove(2, 895.85, 2128.53);\r\nusleep(9444.75);\r\ntouchMove(2, 909.29, 2172.76);\r\nusleep(7305.38);\r\ntouchMove(2, 922.73, 2211.23);\r\nusleep(8855.25);\r\ntouchMove(2, 925.60, 2240.11);\r\nusleep(7985.96);\r\ntouchUp(2, 931.37, 2245.87);\r\nusleep(154359.46);\r\n\r\ntouchDown(2, 936.17, 1834.14);\r\nusleep(45270.71);\r\ntouchMove(2, 935.21, 1842.80);\r\nusleep(9465.71);\r\ntouchMove(2, 935.21, 1856.29);\r\nusleep(7458.92);\r\ntouchMove(2, 935.21, 1868.78);\r\nusleep(8973.67);\r\ntouchMove(2, 935.21, 1878.41);\r\nusleep(7732.29);\r\ntouchMove(2, 935.21, 1888.03);\r\nusleep(9016.96);\r\ntouchMove(2, 934.25, 1894.76);\r\nusleep(7702.58);\r\ntouchMove(2, 934.25, 1900.52);\r\nusleep(8990.67);\r\ntouchMove(2, 933.29, 1905.36);\r\nusleep(7834.54);\r\ntouchMove(2, 933.29, 1908.22);\r\nusleep(8841.79);\r\ntouchMove(2, 933.29, 1910.15);\r\nusleep(7750.88);\r\ntouchMove(2, 933.29, 1913.05);\r\nusleep(8858.50);\r\ntouchMove(2, 932.33, 1915.91);\r\nusleep(7855.92);\r\ntouchMove(2, 932.33, 1920.74);\r\nusleep(8893.42);\r\ntouchMove(2, 932.33, 1925.54);\r\nusleep(7682.42);\r\ntouchMove(2, 932.33, 1929.40);\r\nusleep(9025.67);\r\ntouchMove(2, 932.33, 1936.13);\r\nusleep(7587.12);\r\ntouchMove(2, 932.33, 1942.86);\r\nusleep(8969.25);\r\ntouchMove(2, 932.33, 1949.59);\r\nusleep(7764.17);\r\ntouchMove(2, 932.33, 1957.28);\r\nusleep(8927.79);\r\ntouchMove(2, 932.33, 1963.04);\r\nusleep(7727.88);\r\ntouchMove(2, 932.33, 1968.84);\r\nusleep(8916.38);\r\ntouchMove(2, 932.33, 1972.67);\r\nusleep(7753.00);\r\ntouchMove(2, 932.33, 1976.54);\r\nusleep(9015.04);\r\ntouchMove(2, 932.33, 1981.33);\r\nusleep(7822.62);\r\ntouchMove(2, 932.33, 1985.20);\r\nusleep(8747.38);\r\ntouchMove(2, 932.33, 1989.03);\r\nusleep(7891.62);\r\ntouchMove(2, 932.33, 1991.93);\r\nusleep(8785.92);\r\ntouchMove(2, 933.29, 1995.75);\r\nusleep(7788.42);\r\ntouchMove(2, 934.25, 2001.55);\r\nusleep(8940.29);\r\ntouchMove(2, 934.25, 2006.35);\r\nusleep(7761.33);\r\ntouchMove(2, 935.21, 2011.14);\r\nusleep(8889.62);\r\ntouchMove(2, 935.21, 2015.97);\r\nusleep(7764.75);\r\ntouchMove(2, 935.21, 2020.77);\r\nusleep(8988.62);\r\ntouchMove(2, 935.21, 2024.64);\r\nusleep(7621.12);\r\ntouchMove(2, 936.17, 2027.50);\r\nusleep(9063.17);\r\ntouchMove(2, 936.17, 2031.36);\r\nusleep(7649.79);\r\ntouchMove(2, 937.13, 2034.23);\r\nusleep(9031.96);\r\ntouchMove(2, 937.13, 2039.06);\r\nusleep(7758.67);\r\ntouchMove(2, 938.10, 2045.79);\r\nusleep(8996.29);\r\ntouchMove(2, 938.10, 2048.68);\r\nusleep(7691.00);\r\ntouchMove(2, 939.06, 2056.38);\r\nusleep(8882.38);\r\ntouchMove(2, 939.06, 2063.11);\r\nusleep(7801.00);\r\ntouchMove(2, 939.06, 2070.80);\r\nusleep(8882.79);\r\ntouchMove(2, 939.06, 2079.46);\r\nusleep(7696.25);\r\ntouchMove(2, 939.06, 2088.12);\r\nusleep(9085.21);\r\ntouchMove(2, 939.06, 2094.85);\r\nusleep(7395.42);\r\ntouchMove(2, 939.06, 2102.54);\r\nusleep(9230.42);\r\ntouchMove(2, 939.06, 2111.20);\r\nusleep(7709.04);\r\ntouchMove(2, 939.06, 2122.73);\r\nusleep(8999.33);\r\ntouchMove(2, 939.06, 2139.08);\r\nusleep(7687.12);\r\ntouchMove(2, 939.06, 2161.24);\r\nusleep(8848.25);\r\ntouchMove(2, 939.06, 2192.01);\r\nusleep(7669.75);\r\ntouchMove(2, 944.81, 2219.89);\r\nusleep(8981.12);\r\ntouchUp(2, 950.57, 2225.69);\r\nusleep(195901.17);\r\n\r\ntouchDown(2, 935.21, 1898.59);\r\nusleep(62116.00);\r\ntouchMove(2, 936.17, 1909.18);\r\nusleep(8923.42);\r\ntouchMove(2, 936.17, 1922.64);\r\nusleep(7323.21);\r\ntouchMove(2, 936.17, 1933.23);\r\nusleep(9150.67);\r\ntouchMove(2, 936.17, 1941.89);\r\nusleep(7736.71);\r\ntouchMove(2, 936.17, 1949.59);\r\nusleep(9059.96);\r\ntouchMove(2, 936.17, 1955.35);\r\nusleep(7682.96);\r\ntouchMove(2, 936.17, 1960.18);\r\nusleep(9161.42);\r\ntouchMove(2, 936.17, 1964.01);\r\nusleep(7620.00);\r\ntouchMove(2, 937.13, 1967.88);\r\nusleep(8941.42);\r\ntouchMove(2, 938.10, 1970.74);\r\nusleep(7761.75);\r\ntouchMove(2, 938.10, 1972.67);\r\nusleep(8700.25);\r\ntouchMove(2, 939.06, 1974.60);\r\nusleep(7875.79);\r\ntouchMove(2, 940.00, 1976.54);\r\nusleep(8768.33);\r\ntouchMove(2, 940.96, 1979.40);\r\nusleep(7948.67);\r\ntouchMove(2, 940.96, 1981.33);\r\nusleep(8938.21);\r\ntouchMove(2, 940.96, 1983.26);\r\nusleep(7672.29);\r\ntouchMove(2, 941.92, 1984.23);\r\nusleep(8878.50);\r\ntouchMove(2, 942.88, 1987.09);\r\nusleep(7767.33);\r\ntouchMove(2, 943.85, 1989.03);\r\nusleep(9047.04);\r\ntouchMove(2, 944.81, 1990.96);\r\nusleep(7634.50);\r\ntouchMove(2, 945.77, 1992.89);\r\nusleep(9042.38);\r\ntouchMove(2, 946.73, 1994.79);\r\nusleep(7674.29);\r\ntouchMove(2, 946.73, 1996.72);\r\nusleep(8968.33);\r\ntouchMove(2, 947.69, 1999.62);\r\nusleep(7610.58);\r\ntouchMove(2, 948.65, 2003.45);\r\nusleep(9083.17);\r\ntouchMove(2, 948.65, 2007.31);\r\nusleep(7683.58);\r\ntouchMove(2, 948.65, 2011.14);\r\nusleep(8863.42);\r\ntouchMove(2, 948.65, 2014.04);\r\nusleep(7787.54);\r\ntouchMove(2, 948.65, 2016.94);\r\nusleep(8950.75);\r\ntouchMove(2, 949.61, 2019.80);\r\nusleep(7490.33);\r\ntouchMove(2, 949.61, 2021.74);\r\nusleep(9277.00);\r\ntouchMove(2, 949.61, 2022.70);\r\nusleep(7692.33);\r\ntouchMove(2, 949.61, 2024.64);\r\nusleep(8881.08);\r\ntouchMove(2, 949.61, 2025.60);\r\nusleep(7838.58);\r\ntouchMove(2, 949.61, 2026.53);\r\nusleep(8942.17);\r\ntouchMove(2, 949.61, 2027.50);\r\nusleep(7659.79);\r\ntouchMove(2, 949.61, 2028.46);\r\nusleep(9017.50);\r\ntouchMove(2, 949.61, 2029.43);\r\nusleep(7674.46);\r\ntouchMove(2, 949.61, 2030.40);\r\nusleep(9023.04);\r\ntouchMove(2, 949.61, 2031.36);\r\nusleep(7708.00);\r\ntouchMove(2, 949.61, 2032.33);\r\nusleep(8972.58);\r\ntouchMove(2, 949.61, 2034.23);\r\nusleep(7336.33);\r\ntouchMove(2, 949.61, 2036.16);\r\nusleep(9361.12);\r\ntouchMove(2, 949.61, 2038.09);\r\nusleep(7612.71);\r\ntouchMove(2, 949.61, 2040.99);\r\nusleep(9251.75);\r\ntouchMove(2, 949.61, 2044.82);\r\nusleep(7438.75);\r\ntouchMove(2, 949.61, 2047.72);\r\nusleep(9036.08);\r\ntouchMove(2, 949.61, 2052.51);\r\nusleep(7692.50);\r\ntouchMove(2, 949.61, 2057.35);\r\nusleep(8596.08);\r\ntouchMove(2, 949.61, 2062.14);\r\nusleep(8061.21);\r\ntouchMove(2, 949.61, 2067.90);\r\nusleep(8885.54);\r\ntouchMove(2, 949.61, 2074.63);\r\nusleep(7919.79);\r\ntouchMove(2, 949.61, 2079.46);\r\nusleep(8775.54);\r\ntouchMove(2, 949.61, 2084.26);\r\nusleep(7864.29);\r\ntouchMove(2, 949.61, 2090.05);\r\nusleep(8931.71);\r\ntouchMove(2, 949.61, 2093.88);\r\nusleep(7627.33);\r\ntouchMove(2, 949.61, 2097.75);\r\nusleep(8940.04);\r\ntouchMove(2, 949.61, 2102.54);\r\nusleep(7633.62);\r\ntouchMove(2, 949.61, 2106.41);\r\nusleep(9096.83);\r\ntouchMove(2, 949.61, 2109.27);\r\nusleep(7714.21);\r\ntouchMove(2, 949.61, 2112.17);\r\nusleep(8731.75);\r\ntouchMove(2, 949.61, 2116.00);\r\nusleep(8145.75);\r\ntouchMove(2, 949.61, 2119.87);\r\nusleep(8736.96);\r\ntouchMove(2, 949.61, 2124.66);\r\nusleep(7702.79);\r\ntouchMove(2, 949.61, 2129.49);\r\nusleep(8938.92);\r\ntouchMove(2, 949.61, 2134.29);\r\nusleep(7833.83);\r\ntouchMove(2, 949.61, 2137.19);\r\nusleep(8971.67);\r\ntouchMove(2, 949.61, 2140.05);\r\nusleep(7728.71);\r\ntouchMove(2, 949.61, 2142.95);\r\nusleep(8849.46);\r\ntouchMove(2, 949.61, 2144.88);\r\nusleep(7694.08);\r\ntouchMove(2, 949.61, 2146.78);\r\nusleep(9001.83);\r\ntouchMove(2, 949.61, 2148.71);\r\nusleep(7712.00);\r\ntouchMove(2, 949.61, 2151.61);\r\nusleep(9183.04);\r\ntouchMove(2, 949.61, 2153.54);\r\nusleep(7547.42);\r\ntouchMove(2, 949.61, 2157.37);\r\nusleep(8815.88);\r\ntouchMove(2, 949.61, 2159.30);\r\nusleep(7837.29);\r\ntouchMove(2, 949.61, 2162.20);\r\nusleep(8812.92);\r\ntouchMove(2, 949.61, 2164.10);\r\nusleep(7833.92);\r\ntouchMove(2, 949.61, 2167.00);\r\nusleep(8994.00);\r\ntouchMove(2, 948.65, 2168.93);\r\nusleep(7631.42);\r\ntouchMove(2, 948.65, 2170.83);\r\nusleep(8909.92);\r\ntouchMove(2, 948.65, 2172.76);\r\nusleep(7842.46);\r\ntouchMove(2, 948.65, 2174.69);\r\nusleep(8872.58);\r\ntouchMove(2, 947.69, 2175.66);\r\nusleep(7760.38);\r\ntouchMove(2, 947.69, 2177.59);\r\nusleep(8910.21);\r\ntouchMove(2, 947.69, 2179.49);\r\nusleep(7741.21);\r\ntouchMove(2, 947.69, 2181.42);\r\nusleep(8802.08);\r\ntouchMove(2, 947.69, 2183.35);\r\nusleep(7960.58);\r\ntouchMove(2, 947.69, 2185.29);\r\nusleep(8927.29);\r\ntouchMove(2, 947.69, 2187.18);\r\nusleep(7680.96);\r\ntouchMove(2, 947.69, 2189.11);\r\nusleep(9010.17);\r\ntouchMove(2, 947.69, 2192.01);\r\nusleep(7641.88);\r\ntouchMove(2, 947.69, 2195.84);\r\nusleep(8893.08);\r\ntouchMove(2, 947.69, 2198.74);\r\nusleep(7903.96);\r\ntouchMove(2, 947.69, 2201.64);\r\nusleep(8879.29);\r\ntouchMove(2, 947.69, 2204.50);\r\nusleep(7709.62);\r\ntouchMove(2, 947.69, 2208.37);\r\nusleep(8908.79);\r\ntouchMove(2, 947.69, 2210.30);\r\nusleep(7703.75);\r\ntouchMove(2, 947.69, 2212.20);\r\nusleep(9032.62);\r\ntouchMove(2, 947.69, 2216.06);\r\nusleep(7717.33);\r\ntouchMove(2, 947.69, 2218.92);\r\nusleep(8917.08);\r\ntouchMove(2, 947.69, 2220.86);\r\nusleep(7750.33);\r\ntouchMove(2, 947.69, 2223.76);\r\nusleep(9128.29);\r\ntouchMove(2, 947.69, 2225.69);\r\nusleep(7578.75);\r\ntouchMove(2, 947.69, 2229.52);\r\nusleep(8925.67);\r\ntouchMove(2, 947.69, 2232.42);\r\nusleep(7721.12);\r\ntouchMove(2, 947.69, 2235.28);\r\nusleep(8863.08);\r\ntouchMove(2, 947.69, 2237.21);\r\nusleep(7789.21);\r\ntouchMove(2, 947.69, 2238.18);\r\nusleep(8922.38);\r\ntouchMove(2, 947.69, 2240.11);\r\nusleep(7739.21);\r\ntouchMove(2, 947.69, 2241.08);\r\nusleep(8905.42);\r\ntouchMove(2, 947.69, 2242.04);\r\nusleep(7866.75);\r\ntouchMove(2, 947.69, 2243.01);\r\nusleep(16535.54);\r\ntouchMove(2, 947.69, 2243.94);\r\nusleep(9088.17);\r\ntouchMove(2, 947.69, 2244.91);\r\nusleep(7634.54);\r\ntouchMove(2, 947.69, 2245.87);\r\nusleep(92328.29);\r\ntouchMove(2, 946.73, 2245.87);\r\nusleep(7790.25);\r\ntouchMove(2, 945.77, 2245.87);\r\nusleep(50233.25);\r\ntouchMove(2, 945.77, 2246.84);\r\nusleep(25364.71);\r\ntouchUp(2, 944.81, 2250.71);\r\nusleep(679537.21);\r\n\r\ntouchDown(2, 635.63, 1772.58);\r\nusleep(20917.17);\r\ntouchMove(2, 621.23, 1791.84);\r\nusleep(7691.75);\r\ntouchMove(2, 619.30, 1824.55);\r\nusleep(9124.17);\r\ntouchMove(2, 615.47, 1863.02);\r\nusleep(7302.50);\r\ntouchMove(2, 615.47, 1907.25);\r\nusleep(9161.38);\r\ntouchMove(2, 615.47, 1962.08);\r\nusleep(7440.04);\r\ntouchMove(2, 615.47, 2036.16);\r\nusleep(9166.83);\r\ntouchMove(2, 618.34, 2111.20);\r\nusleep(7580.96);\r\ntouchMove(2, 625.07, 2185.29);\r\nusleep(9041.00);\r\ntouchMove(2, 635.63, 2249.74);\r\nusleep(7760.96);\r\ntouchUp(2, 641.40, 2255.50);\r\nusleep(563663.96);\r\n\r\ntouchDown(2, 661.55, 1827.41);\r\nusleep(320463.04);\r\ntouchUp(2, 661.55, 1827.41);\r\nusleep(547107.62);\r\n\r\ntouchDown(2, 371.58, 1714.86);\r\nusleep(19733.92);\r\ntouchMove(2, 361.98, 1737.01);\r\nusleep(9187.38);\r\ntouchMove(2, 357.18, 1776.45);\r\nusleep(7625.42);\r\ntouchMove(2, 348.54, 1828.38);\r\nusleep(8880.38);\r\ntouchMove(2, 343.73, 1879.37);\r\nusleep(7390.21);\r\ntouchMove(2, 339.89, 1938.99);\r\nusleep(9198.25);\r\ntouchMove(2, 337.97, 2011.14);\r\nusleep(7262.33);\r\ntouchMove(2, 337.02, 2090.05);\r\nusleep(9171.12);\r\ntouchMove(2, 337.02, 2173.73);\r\nusleep(7715.25);\r\ntouchMove(2, 339.89, 2239.15);\r\nusleep(8822.79);\r\ntouchUp(2, 345.66, 2244.91);\r\nusleep(479200.58);\r\n\r\ntouchDown(2, 388.86, 1846.66);\r\nusleep(246052.83);\r\ntouchUp(2, 388.86, 1846.66);\r\n\"\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[9] = { op = "try_end", line = 706 }
    steps[10] = { line = 728, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 12 end
    end }
    steps[11] = { line = 733, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 6991")
    end }
    steps[12] = { line = 741, sec = "", fn = function(B, V, PROG)
      B.sleep(2000)
    end }
    steps[13] = { line = 746, sec = "check ", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"2007\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[14] = { op = "try_begin", line = 757, end_pc = 16 }
    steps[15] = { line = 770, sec = "check ", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"March 22, 2026\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 400,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[16] = { op = "try_end", line = 757 }
    steps[17] = { line = 779, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 19 end
    end }
    steps[18] = { line = 784, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5274")
    end }
    steps[19] = { line = 792, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[20] = { line = 798, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 23 end
    end }
    steps[21] = { line = 803, sec = "", fn = function(B, V, PROG)
      B.log("Chọn lại ngày tháng")
    end }
    steps[22] = { line = 808, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7922")
    end }
    steps[23] = { line = 816, sec = "", fn = function(B, V, PROG)
      B.sleep(1000)
    end }
    steps[24] = { op = "try_begin", line = 826, end_pc = 26 }
    steps[25] = { line = 839, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[26] = { op = "try_end", line = 826 }
    steps[27] = { line = 848, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 29 end
    end }
    steps[28] = { line = 853, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 3625")
    end }
    steps[29] = { line = 861, sec = "", fn = function(B, V, PROG)
      B.sleep(4000)
    end }
    steps[30] = { line = 866, sec = "", fn = function(B, V, PROG)
      V.VAR_PASSWORD = B.random_string(12, "abcdefghijklmnopqrstuvwxyz0123456789")
    end }
    steps[31] = { op = "try_begin", line = 876, end_pc = 33 }
    steps[32] = { line = 889, sec = "Pate Text", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{ \"action\": \"TEXT\", \"data\": \"", V.VAR_PASSWORD), "\" }"), "", B.add("custom/", ("application/json")))
    end }
    steps[33] = { op = "try_end", line = 876 }
    steps[34] = { line = 898, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 36 end
    end }
    steps[35] = { line = 903, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 6828")
    end }
    steps[36] = { line = 911, sec = "", fn = function(B, V, PROG)
      B.logger_log({["color"] = ("cyan"), ["en"] = (B.add("Pass: ", V.VAR_PASSWORD)), ["level"] = ("info"), ["ru"] = ("")})
    end }
    steps[37] = { op = "try_begin", line = 921, end_pc = 39 }
    steps[38] = { line = 934, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[39] = { op = "try_end", line = 921 }
    steps[40] = { line = 943, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 42 end
    end }
    steps[41] = { line = 948, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 5884")
    end }
    steps[42] = { line = 956, sec = "", fn = function(B, V, PROG)
      B.sleep(4000)
    end }
    steps[43] = { op = "try_begin", line = 966, end_pc = 45 }
    steps[44] = { line = 979, sec = "Đợi pass", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Password\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[45] = { op = "try_end", line = 966 }
    steps[46] = { line = 988, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 48 end
    end }
    steps[47] = { line = 993, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 471")
    end }
    steps[48] = { line = 1001, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[49] = { line = 1007, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 85 end
    end }
    steps[50] = { line = 1012, sec = "", fn = function(B, V, PROG)
      V.VAR_CHECK_NEXT_PASS = B.add(B.parse_int(V.VAR_CHECK_NEXT_PASS), B.parse_int(1))
    end }
  end)()
  ;(function()
    steps[51] = { line = 1017, sec = "", fn = function(B, V, PROG)
      if not B.truthy((B.num(V.VAR_CHECK_NEXT_PASS) >= B.num(5))) then return 53 end
    end }
    steps[52] = { line = 1022, sec = "", fn = function(B, V, PROG)
      B.fail_user("Lỗi Tạo")
    end }
    steps[53] = { line = 1030, sec = "", fn = function(B, V, PROG)
      B.log("Click lại NEXT pass")
    end }
    steps[54] = { op = "try_begin", line = 1040, end_pc = 56 }
    steps[55] = { line = 1053, sec = "Click Refresh", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Refresh\",\r\n    \"timeout\": 10,\r\n     \"ex\": false,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[56] = { op = "try_end", line = 1040 }
    steps[57] = { line = 1062, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 59 end
    end }
    steps[58] = { line = 1067, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7838")
    end }
    steps[59] = { op = "try_begin", line = 1080, end_pc = 61 }
    steps[60] = { line = 1093, sec = "Confirm you're human to", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Confirm you're human to\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[61] = { op = "try_end", line = 1080 }
    steps[62] = { line = 1102, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 64 end
    end }
    steps[63] = { line = 1107, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 1965")
    end }
    steps[64] = { line = 1115, sec = "", fn = function(B, V, PROG)
      V.VAR_SAVED_STATUS = B.http_status()
    end }
    steps[65] = { line = 1121, sec = "", fn = function(B, V, PROG)
      if not B.truthy(B.eq(V.VAR_SAVED_STATUS, 200)) then return 67 end
    end }
    steps[66] = { line = 1126, sec = "", fn = function(B, V, PROG)
      B.fail_user("Die")
    end }
    steps[67] = { line = 1134, sec = "Password required", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Password cannot be empty.\",\r\n    \"timeout\": 3,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"check\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[68] = { line = 1140, sec = "", fn = function(B, V, PROG)
      V.VAR_PASS_EMPTY = B.http_status()
    end }
    steps[69] = { line = 1146, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_PASS_EMPTY) then return 80 end
    end }
    steps[70] = { op = "try_begin", line = 1156, end_pc = 72 }
    steps[71] = { line = 1169, sec = "Password required", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Password cannot be empty.\",\r\n    \"timeout\": 5,\r\n     \"ex\": true,\r\n    \"offset\": -150,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[72] = { op = "try_end", line = 1156 }
    steps[73] = { line = 1178, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 75 end
    end }
    steps[74] = { line = 1183, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 7594")
    end }
    steps[75] = { op = "try_begin", line = 1196, end_pc = 77 }
    steps[76] = { line = 1209, sec = "Pate Text", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), B.add(B.add("{ \"action\": \"TEXT\", \"data\": \"", V.VAR_PASSWORD), "\" }"), "", B.add("custom/", ("application/json")))
    end }
    steps[77] = { op = "try_end", line = 1196 }
    steps[78] = { line = 1218, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 80 end
    end }
    steps[79] = { line = 1223, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 3322")
    end }
    steps[80] = { op = "try_begin", line = 1239, end_pc = 82 }
    steps[81] = { line = 1252, sec = "Click Next", fn = function(B, V, PROG)
      B.switch_http_main()
      B.http_request(B.add(V.VAR_IP_IPHONE, ":3000"), ("POST"), "{\r\n    \"text\": \"Next\",\r\n    \"timeout\": 10,\r\n     \"ex\": true,\r\n    \"offset\": 0,\r\n    \"action\": \"click\",\r\n    \"region\": null\r\n}", "", B.add("custom/", ("application/json")))
    end }
    steps[82] = { op = "try_end", line = 1239 }
    steps[83] = { line = 1261, sec = "", fn = function(B, V, PROG)
      if not B.truthy(V.VAR_WAS_ERROR) then return 85 end
    end }
    steps[84] = { line = 1266, sec = "", fn = function(B, V, PROG)
      return B.goto_label("label name 9629")
    end }
  end)()
  PROG.functions["reg_2"] = { name = "reg_2", steps = steps, labels = labels }
end

-- Entry point when executed standalone by TapCore
if not _G.__BAS_NO_AUTORUN then
  local B = BAS.new()
  B.run_program(PROG)
end
return PROG
